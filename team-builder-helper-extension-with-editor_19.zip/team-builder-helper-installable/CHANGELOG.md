# Schema editor changelog

Version number shown in the editor's header and in the activity log on load.
Bump `EDITOR_VERSION` in `editor.js` with each round of changes, and log what
changed here.

## v0.23
- **Fixed a real bug**: some teams were missing uniform variants from the
  dropdown entirely. The variant-name regex only allowed letters and digits
  (`[A-Za-z0-9]+`), but real variant names contain parentheses --
  `DarkMode(Home)`, `1920s(Reimagined)` -- which silently failed to match
  and dropped the whole variant. Confirmed against two real teams: UCLA
  lost 5 of its 9 variants this way, JT lost 2 of its 14 (less obvious,
  since 12 still worked). Now matches any characters in the variant name,
  tested against both teams (14/14 and 9/9 now show correctly) plus a
  synthetic case with a hyphen inside the variant name itself.

## v0.22
- Added a **Reset** button to the Number Spacing slider. The starting value
  is captured once, the first time each jersey is seen, and stays fixed no
  matter how much dragging happens afterward -- shown as "started at: X"
  next to the slider. Reset jumps straight back to it in one click, so
  experimenting freely doesn't risk losing track of where you began.

## v0.21
- **Fixed a real bug in v0.20's Number Spacing slider**: the stored path had
  an extra `numberComp.` prefix that shouldn't have been there.
  `numberMaterialSettings` is a *sibling* of `numberComp`, not nested inside
  it — confirmed by re-checking the original tree screenshot carefully.
  v0.20 would have shown "No numberSpacing field found" instead of a
  working slider on every real payload. Found while building an accurate
  demo, not from an in-game report — worth noting since it means this was
  silently broken from the moment it shipped.

## v0.20
- Added a **Number Spacing** slider — first non-picker control in the tool.
  Writes directly to
  `numberComp.numberMaterialSettings.offsetScaleSpacing.numberSpacing.x`,
  shown live as you drag. Range is `-0.6` to `-0.3`, a user-confirmed
  comfortable range rather than the field's full technical bounds — values
  outside it may still be valid, just untested. `y`/`z`/`w` on the same
  object are left untouched, as are the sibling `chestNumberOffsetScale` /
  `backNumberOffsetScale` / `shoulderNumberOffsetScale` /
  `sleeveNumberOffsetScale` fields that live one level up.

## v0.19
- Added a material-specific placement override layer, sitting on top of the
  brand-level defaults. First confirmed use: **Adidas WithText** needed its
  own pants placement (`scale 0.056/0.112`, `offset 0.16/0.33`) — genuinely
  different from base Adidas (`0.04/0.08`, `0.16/0.265`), confirmed via
  actual Team Builder renders, not just a raw-JSON comparison. Every other
  Adidas material (Cotton, Plastic, Shiny, base) is unaffected and still
  uses the shared brand baseline. For contrast: Jumpman Cotton vs. Diamond
  were confirmed earlier to need no override at all — same placement either
  way — so this layer only activates where a material's actually been
  checked and found to differ, not by default.

## v0.18
- **UA pants now has confirmed placement** — the last brand/piece gap. Source
  is a fresh, provably untouched team's direct JSON export, not Frosty.
  Notably, Frosty's Georgia Tech reading disagreed with this direct JSON
  pull in a real way (opposite-sign offset, near-mirrored rotation), not
  just rounding — going with the direct JSON value as the more trustworthy
  source of the two, consistent with how Nike/Jumpman/Adidas were already
  confirmed (all via raw JSON, not Frosty alone). `layout: null` confirmed
  and actively enforced, same tier as Nike now.
- All four brands (Nike, Jumpman, Under Armour, Adidas) now have full
  confirmed pants placement + layout enforcement. UA's jersey still shows
  a minor, unconfirmed discrepancy against this same fresh export
  (`offset (0.068, -0.12)` vs. the currently stored `(0, -0.1325)`) — left
  unchanged since jersey has never been reported as an issue, but worth
  knowing if UA jersey placement ever comes into question.

## v0.17
- **Nike pants placement is back, now confirmed by a second school** (this
  exact team, via Frosty Editor) — essentially identical to FSU's numbers.
  The earlier "Nike is broken" report that led to removing it in v0.15 was
  almost certainly the same layout-contamination issue diagnosed for Nike
  Plastic, not bad reference data.
- **Real fix this time, not just detection**: confirmed that Nike's native
  pants `layout` is genuinely `null` (no fourth UV-set slot in Frosty,
  unlike Jumpman/Adidas). Any brand with a known layout policy — a specific
  UV path, or explicit null — now enforces it unconditionally on swap,
  overwriting whatever was there. So swapping to Nike now actively resets
  `layout` back to `null` even if a prior Jumpman/Adidas test left a
  different UV set behind, instead of silently inheriting it. UA still has
  no confirmed policy either way, so it still only gets flagged (v0.16),
  not corrected, until real data exists for it too.

## v0.16
- Added contamination detection for brands with no confirmed placement of
  their own (Nike, UA): if the overlay already carries another *known*
  brand's exact layout signature (Jumpman's or Adidas's), the activity log
  now says so explicitly instead of silently leaving it — e.g. a Nike swap
  landing on an overlay that still has Jumpman's `Pants_UVSet_front` gets
  flagged as likely leftover from testing Jumpman, not this team's native
  state. Doesn't fix the numbers (no confirmed correct value to fall back
  to yet) — just makes the cause visible instead of requiring another round
  of screenshots to diagnose.
- Confirmed limitation surfaced by this: **Reset to loaded** only protects
  against edits made within the current session. If a team's live data was
  already permanently modified by an earlier push (e.g. Jumpman tested and
  pushed in a prior session), a fresh fetch pulls that same modified state
  back — there's no clean baseline left to reset to. Getting Nike/UA their
  own confirmed pants placement (the same Frosty Editor approach used for
  Jumpman and Adidas) is the actual fix; this version just makes the
  symptom diagnosable in the meantime.

## v0.15
- Removed pants placement auto-apply for Nike, Adidas, and UA — their pants
  were already rendering correctly untouched, and auto-applying reference
  numbers on top of an already-fine result was actively breaking it (Nike's
  pants going wrong after a Nike swap, reported directly). Pants now gets a
  texture-only swap for those three brands — no scale/offset/rotate/layout
  writes at all, leaving whatever was already there alone. Jumpman keeps
  its full confirmed placement + layout fix, since that's the one brand
  that was actually broken and needed it.

## v0.14
- QOL fix across all three pickers (Jersey Number Font, Helmet Shell, Vendor
  Decal): clicking into a field that already has a selection now
  auto-selects all the text, so typing immediately overwrites it instead of
  needing a manual select-all-and-delete first. Also added an explicit
  **Clear** button next to each picker for a guaranteed one-click reset,
  regardless of browser-specific datalist filtering quirks.

## v0.13
- **Corrected a wrong assumption from v0.12, before it caused a new bug**:
  `layout` isn't a universal mesh constant shared by every brand — it's
  brand-specific, same as the texture itself. Confirmed Adidas uses
  `Pants_UVSet_maddenOld`, genuinely different from Jumpman's
  `Pants_UVSet_front`. v0.12 would have written Jumpman's value onto an
  Adidas swap, introducing a new wrong-layout bug in the name of fixing
  the old one. Layout is now stored per-brand, alongside scale/offset/
  rotate, and only applied when that specific brand has a confirmed value
  — Nike and UA don't yet, so their pants layout is left untouched rather
  than guessed.

## v0.12
- **Found and fixed the real root cause of the pants-specific placement
  bug**, confirmed by an actual in-game test: `textures.layout` was `null`
  on the affected pants overlay, while Florida's own correctly-rendering
  pants overlay has it set to
  `ContentShared/.../uvsets/Pants_UVSet_front`. Scale, offset, and
  `scaledTransform` were all correct the entire time — this missing UV
  reference was the actual gap. Placement auto-apply now sets `layout` on
  pants whenever it's missing, without touching it if something's already
  there.
- Ruled out along the way, for the record: wrong catalog values (numbers
  matched Florida/Oklahoma/Frosty Editor exactly, three independent
  sources), a lookup bug (brand key matching verified correct in code),
  material differences (Cotton and Diamond share the same issue and same
  fix), and a mesh-wide coordinate mismatch (Adidas rendered correctly on
  the same team/template throughout).
- Corrected Jumpman's pants rotation from `5.5` (an average of two school
  exports) to `5.0`, now directly confirmed via Frosty Editor as the
  authoritative source rather than an estimate.

## v0.11
- Audited every stored placement value directly against all school examples
  gathered so far. Everything matched exactly except Jumpman's pants
  rotation — stored as Oklahoma's `6`, but Florida (the actual visual
  reference used throughout this feature) came in at `5`. Averaged to `5.5`
  rather than silently favor one school over the other. Scale and offset
  were already identical between both schools, unaffected.

## v0.10
- **Likely the real fix for the oversized-logo issue that's come up
  repeatedly**: every overlay carries a `transform.scaledTransform` field
  (`{x, y, z, w}`) that's a separate cached copy of scale/offset
  (`x=scale.u, y=scale.v, z=offset.u, w=offset.v`). Confirmed from a real
  payload that it does **not** recompute itself — `scale`/`offset` were
  being set correctly the whole time, but `scaledTransform` stayed frozen
  at the original brand's values. If the in-game renderer reads
  `scaledTransform` instead of recalculating from `scale`/`offset`, that
  would explain exactly what was reported: the texture pattern changes
  (visibly the right brand/material), but the size and position don't,
  because the field that likely actually controls rendering never updated.
  Placement auto-apply now keeps both in sync.

## v0.09
- **Fixed a real bug**: the decal search only ever found and updated the
  *first* matching overlay per piece. Confirmed from real recipe data that
  Nike's socks template carries two separate decal overlays (mirrored left/
  right) while Adidas/Jumpman/UA only carry one — on a Nike-style template,
  swapping brands would silently leave the second overlay on the old
  texture. Now updates every matching overlay found on a piece, not just
  the first.
- Extended placement defaults to **pants and socks**, not just jersey, now
  that real data exists for both — sourced from confirmed recipes across
  Nike, Jumpman, UA, and (new) Adidas. Placement only auto-applies when a
  piece has exactly one decal overlay; a multi-overlay piece (Nike socks)
  gets its texture updated everywhere but placement left alone, since
  there's no confirmed per-side value to apply safely.
- Confirmed Jumpman's jersey scale (`0.03`) is consistent across two
  different schools (Florida, Oklahoma) — not the source of any reported
  oversized-logo issue.

## v0.08
- Removed the manual scale/offset/rotate controls from v0.06 entirely. With
  the per-brand jersey default from v0.07 handling the common cases
  automatically, and no way to preview the effect of a manual tweak anyway,
  they were more clutter than value. Vendor Decal is back to just the
  picker and a plain current-state readout per piece.

## v0.07
- Reversed course on v0.06's "leave placement alone" default. With no way to
  preview the result, manual sliders you can't see the effect of aren't
  meaningfully better than a decent default — so a brand swap now
  auto-applies a per-brand jersey placement (scale/offset/rotate) sourced
  from the confirmed team examples. Nike and UA get their known values;
  Adidas has no confirmed example yet, so it's left untouched rather than
  guessed. Pants/socks also stay untouched — no confirmed data for those
  pieces yet, only jersey.
- The manual scale/offset/rotate controls from v0.06 are still there
  underneath, for whichever cases the default doesn't fit.

## v0.06
- Added manual **scale / offset / rotate** controls under each piece in the
  Vendor Decal section. A brand swap only ever changes the texture
  (col/rsm/normal) — it deliberately never touches placement, since
  placement is confirmed to vary by jersey *template*, not by brand (a
  Jumpman-templated team and a Nike-templated team don't share one correct
  scale). No safe way to auto-derive the right value, so this exposes the
  current values as editable and lets you dial it in by eye instead.
- Reference values on hand so far (jersey only): Nike scale 0.05, offset
  (0.085, -0.1), rotate 350. Jumpman scale 0.03, offset (0.08, -0.089),
  rotate 0. UA scale 0.035, offset (0, -0.133), rotate 0. These are examples
  from specific teams, not universal brand constants — don't assume they
  transfer to a different template.

## v0.05
- Fixed the decal catalog forcing `ContentShared/...` onto all 16 entries.
  That was only ever confirmed for entries whose source path had `/comp/` in
  it (Nike Cotton, Nike Plastic, UA). Nike ShoeDuck never had `/comp/` to
  begin with, and testing confirmed it needs to stay on plain `content/...`
  — forcing it onto `ContentShared` broke it. Same root cause as the earlier
  `/comp/` issue with number fonts: don't generalize one confirmed example
  across every entry in a catalog without checking whether they actually
  share the same source shape.

## v0.04
- **Fixed a real bug**: Vendor Decal always reported "no vendor decal overlay
  found" even when one clearly existed in the payload. The search was looking
  at `part.overlays` directly, but the real path is one level deeper:
  `part.layerCompTexture.overlays`. Confirmed against a real payload where the
  Nike Logo entry was visible in the raw JSON but the tool couldn't find it.
- The Vendor Decal picker now prefills with the currently-equipped brand +
  material when it matches a known catalog entry, instead of always starting
  blank — so switching reads as an actual swap ("Nike Cotton (2022)" → "Nike
  Plastic (2023)") rather than picking blind.

## v0.03
- Added the **Vendor Decal** swapper — confirmed working in-game across
  multiple brands (Nike, Adidas, Jumpman, Under Armour) and materials (Cotton,
  Plastic, Metallic, Shiny, etc.). One picker updates jersey, pants, and socks
  together; brands can be freely mixed and matched regardless of what's
  currently equipped.
- The vendor decal overlay is found **structurally** (whichever overlay's
  texture already points into `.../decals/vendors/...`), not by label text —
  confirmed that `info.label` changes to match whatever brand is currently
  equipped ("Nike Logo" vs "Adidas Logo" on different default teams), so
  label text isn't a safe search key on its own.
- Catalog paths normalized to the confirmed live form
  (`ContentShared/characters/player/parts/uniforms/decals/vendors/<name>`, no
  `/comp/`) — the source list used a different, unconfirmed path shape.

## v0.02
- Fixed the picker input resetting to its placeholder text ("Pick from
  catalog...") right after a selection was applied, even though the
  underlying field was set correctly. The box now shows what was actually
  picked. Clears automatically when a new payload loads or the variant
  changes, so it can't show a stale pick for the wrong context.

## v0.01
- Removed the standalone Accessory picker — Shell already sets the matching
  accessory automatically, so the separate tab was redundant.
- Removed Facemask entirely (not needed).
- Removed the "Set this field only" override inputs/buttons added for testing;
  reverted to plain read-only "what's already there" display under each field.
- Added a **Reset to loaded** button — snapshots the payload the moment it's
  fetched, and reverts to exactly that snapshot, discarding session edits.
- Fixed **Clear mock** giving no visible feedback — it now refreshes the
  Connection panel right after, so "Mocks stored" / "Network mocking" visibly
  update instead of appearing to do nothing.
