# EA JSON Editor Team Builder Helper

This unpacked Chromium extension captures EA Team Builder `nonce-primary.json` URLs for College Football and Madden Team Builder pages. It lets the JSON Editor fetch or mock that payload with the edited JSON currently open in the editor.

## Install Locally

This helper is built for Chromium browsers such as Chrome, Edge, Brave, and Vivaldi. Firefox/Safari use different extension APIs, so use the Tweak rule backup there unless a separate extension build is added later.

1. Open your Chromium browser to `chrome://extensions`. In Edge, use `edge://extensions`.
2. Turn on `Developer mode`.
3. Click `Load unpacked`.
4. Select this folder:
   `C:\Users\Shadow\Desktop\Coding\json-editor-app\team-builder-helper-extension`
5. Approve the requested permissions. The debugger permission is used only to intercept the EA Team Builder JSON request at the network layer, similar to Tweak.
6. Open or reload an EA College Football or Madden Team Builder page, then open one of your teams so the JSON request happens.
7. In the JSON Editor, open `Team Builder Payload` and click `Pull Captured URL`.
8. Click `Fetch URL Into Editor` if you want to load the live payload, edit it, then click `Push Edited JSON to Team Builder`.
9. Reload or open that same Team Builder team. Click `Check Push Status` in the editor to confirm the EA page consumed the pushed payload.

When network mode is active, Chrome may show a visible banner saying the browser is being debugged by the extension. That is expected for Chrome debugger-based request interception.

Stable extension id: `dckljmhmfnjnbchjfaddjhdaaknncclg`

After code changes, go to the browser extensions page, click the reload icon on this unpacked extension, then reload the EA Team Builder tab.

The JSON Editor web app cannot build this behavior directly into the page because browsers isolate `json-editor-8e455.web.app` from `ea.com` network responses. The helper extension runs at the browser layer so it can capture and mock the EA payload safely.

## New in 0.6.0: bundled schema editor

This copy adds a schema-aware editor for team fonts and helmet materials, built into
the extension itself — click the toolbar icon to open it in a new tab. It's a normal
extension page, so it talks to `background.js` directly (no separate site, no
extension ID to configure). It covers:

- Jersey number font, helmet shell material, helmet accent material — confirmed by
  hand-editing to actually work.
- Helmet number font, name font — same mechanism, not yet confirmed; marked
  "unverified" in the UI so that's not mistaken for tested.

`background.js`'s message handlers (`TB_GET_STATUS`, `TB_FETCH_JSON`, `TB_SET_MOCK`,
etc.) were refactored into one shared function used by both `chrome.runtime.onMessage`
(for this bundled page) and `chrome.runtime.onMessageExternal` (for
json-editor-8e455.web.app and localhost dev, unchanged). `bridge.js` and `capture.js`
are untouched.
