# Schema editor changelog

Version number shown in the editor's header and in the activity log on load.
Bump `EDITOR_VERSION` in `editor.js` with each round of changes, and log what
changed here.

## v0.41
- **Found and fixed the root cause of cut-off number fonts**: the crop
  detection only looked for saturated (colorful) pixels, so white/gray
  numbers on dark jerseys (Army, low-saturation alternates, etc.) weren't
  reliably detected, producing overly wide/short crops (up to 2.0 aspect
  ratio) that cut off the number. Fixed by also detecting bright pixels
  regardless of saturation, and enforcing a minimum height:width ratio.
  Re-cropped all 19 affected images (Alabama, App State, Arkansas, Army x2,
  Arkansas State, Arizona State, BYU, FAU x2, FIU x2, Indiana, Iowa State,
  Navy, Northern Illinois, Oregon x2, Texas Tech).
- Zoomed in on all 6 UCF preview images (no longer have access to their
  original source screenshots, so this is a crop of the existing image
  rather than a fresh capture -- two of them are still a bit wide since
  there's a limit to how much can be recovered this way).
- Replaced Virginia Tech (2024) with a new screenshot that actually shows
  the 84 number.

## v0.40
- Confirmed Tulane's City Edition Alternate (already existed in the
  catalog as "Tulane (2025, CITY Edition)" -- relabeled, added an image).
- Added two new high school teams: HS Mustangs (Current Home, its own
  dedicated font -- first team confirmed using it) and HS Rattlers
  (Current Home, shares Tennessee's font).
- Replaced Cincinnati's preview image with a better crop.
- **Removed all remaining entries without a preview image** (38 of them)
  per direct instruction, rather than keeping them at the bottom of the
  list. Every entry in the catalog now has a real screenshot.
- `CATALOG.numberFonts.jersey`: 238 -> 202, alphabetized.

## v0.39
- Added Air Force (2021) preview image.
- **Reframed 189 preview images** (46 from the FB Uniform Editor batches +
  143 from the Frosty Editor batches) to a wider crop that excludes the
  helmet and shows the full team wordmark, number, and more of the torso,
  instead of the tighter/sometimes-cut-off framing from before. The 12
  images from the very first font-gallery session couldn't be re-cropped
  since their original uncropped screenshots are no longer accessible --
  left as-is.
- **Catalog reordered**: entries with a preview image now sort first
  (alphabetical within that group), entries without one sort after
  (also alphabetical), so the gallery view surfaces populated tiles before
  empty placeholders. The Jersey Number Font field's plain-text/datalist
  input pulls from the same array, so it follows this order too.
- Preview coverage: 199 of 238 entries.

## v0.38
- **Data quality pass** on the 22 cross-team-share entries added in v0.37,
  triggered by catching a real bug: Louisiana Tech's "Current Home" font
  was pointing at Virginia Tech's font ("LT" misread as "VT" during OCR).
  Auditing all 22 against their own donor paths found:
  - **15 were unnecessary duplicates** -- the team already had its own
    correctly-pathed entry under a different label (e.g. "North Texas
    (2023, Green)" already existed with the exact font "North Texas
    (Current Home)" was pointing to). Fixed by relabeling the pre-existing
    entry and deleting the redundant new one, in each case.
  - **1 had the wrong path** (New Mexico State -- same "LT" vs "VT" OCR
    confusion as Louisiana Tech). Path corrected, entry kept since it's a
    genuine cross-team share.
  - **6 were genuine** and needed no change (Stanford, UTEP Current
    Throwback, Virginia Current Throwback, Liberty, Louisville Current
    Alternate, North Dakota State Current Away Alternate).
  - Preview images for the 15 relabeled entries were re-cropped under
    their correct final displayName rather than lost.
- **Removed 90 stale/superseded catalog entries**: no profile data, no
  preview image, and the team already has a confirmed "(Current X)" entry
  elsewhere -- almost certainly leftover placeholders from the original
  bulk import that got superseded once the real font was confirmed via
  screenshot.
- **Catalog alphabetized** by label, A-Z.
- `CATALOG.numberFonts.jersey`: 343 -> 238.
- Preview coverage: 198 of 238 entries (up from 183 after accounting for
  the recovery above).

## v0.37
- **Massive confirmation batch**: 130 screenshots (Ohio through Notre Dame,
  roughly two-thirds of the alphabet), all OCR-read directly (Team dropdown,
  Uniform dropdown, and the NUM_Array font reference) rather than inferred
  from file order, after the v0.35.1 timestamp-mapping bug. 108 relabels to
  `Team (Uniform Name)`, plus 22 new team-split entries for cross-team font
  shares (e.g. Michigan State and Jacksonville State each share another
  team's font -- confirmed directly).
- **Bugfix**: the preview-image crop region from earlier batches picked up
  the Data Explorer / Properties side panels instead of the jersey for this
  batch's window layout. Replaced the fixed crop box with per-screenshot
  pixel-based detection (finds the contiguous saturated/bright region in
  the plausible viewport area, since the jersey renders in solid color
  against a near-black background while UI panels are flat gray) --
  auto-detected correctly on all 130 screenshots, spot-verified via OCR
  reading real jersey text ("PURDUE", "TECH") off the output thumbnails.
- `CATALOG.numberFonts.jersey`: 321 -> 343.
- Preview coverage: ~200 of 343 entries now have a real screenshot.

## v0.36
- Confirmed 10 more entries from Frosty Editor screenshots (a different
  tool than FB Uniform Editor, same underlying data): Miami (FL) x3
  (2024 Alternate, Current Camo Alternate, Current Home), Houston, Hawaii,
  Georgia State, Georgia, Florida, Georgia Tech -- all relabeled to
  `Team (Uniform Name)`.
- New cross-team share found: Georgia Southern's "Current Home" uses
  Duke's font (`Standard_Jersey_2021_DUKE_NUM_Array`). Added as its own
  entry so Duke's label is untouched.
- Added 10 new preview images from this batch (skipped one duplicate
  Georgia screenshot that used the same font as another shot). Preview
  coverage: 69 of 321 entries.
- `CATALOG.numberFonts.jersey`: 320 -> 321.

## v0.35.1
- **Bugfix**: every preview image added in v0.35 was mapped to the wrong
  displayName. Root cause: the file-to-team mapping was reconstructed from
  guessed upload/timestamp ordering across two separate screenshot batches,
  and the two batches got swapped relative to each other -- so e.g.
  `ASU_Jersey_2024_NUM_Array.jpg` (labeled "Arizona State, Current 2nd
  Alternate") actually contained Delaware's screenshot.
- Fixed by OCR-reading the actual Team/Uniform dropdown text out of all 49
  source screenshots directly (via tesseract) instead of inferring order,
  then re-cropping all 47 images against that verified mapping. Two of the
  47 crops were spot-verified by re-running OCR on the *output* thumbnail
  and confirming the visible team wordmark matches the filename.
- The 12 images from the original font-gallery session (Cincinnati, VT x2,
  NDSU, AFA, UCF x6, Akron) were untouched by this bug and were restored
  as-is.

## v0.35
- Added 47 new preview images to `previews/`, cropped and compressed from
  the recent screenshot batches (Buffalo through App State, East Carolina
  through BYU, Fresno State through Eastern Michigan). Two entries
  (App State's duplicate confirmation shot, FIU's duplicate Vice-font shot)
  reuse an adjacent image since they're the identical font. Cincinnati was
  skipped since it already had a preview from v0.34.
- Preview coverage: 59 of 320 catalog entries now have a real screenshot
  (up from 12).
- File-to-team mapping was reconstructed from each screenshot's embedded
  capture timestamp rather than upload order, then spot-verified against
  the Team/Uniform dropdown text in a couple of samples before batch
  processing.

## v0.34.1
- **Bugfix**: gallery tiles without a preview image were showing the raw
  broken-image icon instead of the clean placeholder. Cause: the fallback
  used an inline `onerror="..."` attribute, which extension pages' default
  Content-Security-Policy (`script-src 'self'`) silently blocks as inline
  script. Switched to `addEventListener('error', ...)` after the modal
  renders, which isn't affected by that CSP rule.
- Note: only 12 of 320 catalog entries currently have a real preview image
  (Cincinnati, Virginia Tech x2, North Dakota State, Air Force, UCF x6,
  Akron) -- every other entry, including the various Florida schools, is
  expected to show the placeholder until a screenshot gets cropped for it.

## v0.34
- **New: Jersey Number Font gallery picker.** A "Gallery" button next to the
  Jersey Number Font field opens a modal with Gallery/List toggle, search,
  and image tiles. Preview images live in `previews/{displayName}.jpg` and
  are added incrementally as real in-game screenshots get confirmed; entries
  without a file yet show a placeholder tile rather than erroring.
- Bundled 12 real preview images (Cincinnati, Virginia Tech x2, North Dakota
  State, Air Force, UCF x6, Akron) as actual JPGs in `previews/`.
- Relabeled 51 catalog entries from generic year-based labels to precise
  `Team (Uniform Name)` labels matching the actual in-game Team/Uniform
  dropdowns, confirmed via screenshots batch-by-batch.
- Added 6 new team-split entries for previously-undiscovered cross-team font
  shares: Alabama (shares BYU's font), Oregon "Home Gang Green" (shares Ohio
  State's), Clemson (shares Central Michigan's), California (shares
  Arkansas's), and Florida International "Current Home" (shares Eastern
  Michigan's).
- `CATALOG.numberFonts.jersey`: 315 -> 320.

## v0.33
- Removed `VT_Jersey_2020_NUM_Array`, `VT_Jersey_2021_NUM_Array`, and
  `VT_Jersey_2022_NUM_Array` from `CATALOG.numberFonts.jersey`, per direct
  instruction while confirming Virginia Tech reference screenshots. None had
  profile data yet, so nothing lost.
- `CATALOG.numberFonts.jersey`: 321 -> 318.

## v0.32
- **Catalog alphabetized**: `CATALOG.numberFonts.jersey` is now sorted by
  `label`, ascending.
- **Removed 5 helmet fonts miscategorized as jersey number fonts**:
  `ALA_Helmet_2021_NUM_Array`, `FAU_Helmet_2025_NUM_Array`,
  `GASO_Helmet_2025_NUM_Array`, `MINN_Helmet_2024_NUM_Array`,
  `NMSU_Helmet_2021_NUM_Array` -- these were pre-existing catalog entries
  from before this session, not something the recent batch import added.
  None had profile data, so nothing else needed cleanup.
- **Found and fixed 3 pure same-team duplicate entries that v0.31's per-file**
  **split created without recognizing they were the same team twice**:
  Kansas State (Purple/White), Arizona State (Black/Yellow), BYU
  (Black/Blue) -- each pair shared the identical font `path`, same team, same
  year, only the color differed. Merged each pair to one entry, relabeled to
  drop the now-meaningless color suffix (e.g. "Kansas State (2023, Purple)"
  -> "Kansas State (2023)").
- **Found 4 more duplicates that were actually the missing data for existing**
  **flagged entries**: `ECU_JERSEY_2023_BLACK`/`ECU_JERSEY_2023_PURPLEALT`,
  `MTSU_JERSEY_2023_BLUE`, `TROY_JERSEY_2023_RED`, and `KU_JERSEY_2023_BLUE`
  were each that exact team's own file -- same font path, same team, same
  year as an already-cataloged entry that had no profile yet. Merged into
  the original entry instead of kept as a separate one. This resolves 4 of
  the 7 "shared font, no confirmed value of its own" entries flagged in
  v0.31.
- `CATALOG.numberFonts.jersey`: 334 -> 321 (-5 helmets, -8 merged duplicates).
  `NUMBER_LAYOUT_PROFILES`: 220 -> 216 (-8 duplicates, +4 filled-in
  previously-empty entries).
- `LSU_Jersey_2024_NUM_Array` and `EMU_Jersey_2021_NUM_Array` are now
  "partially resolved" rather than fully unconfirmed -- the same team's data
  exists in the catalog under a different year (LSU 2023, EMU 2025) as its
  own separate entry, but the specifically-cataloged year still has nothing.
  Flagged with that nuance in `BATCH_IMPORT_FLAGS.md` rather than silently
  merged across years.
- `FONT_PROFILES_CHECKLIST.md` and `BATCH_IMPORT_FLAGS.md` both rewritten
  against the cleaned state: 216 ✅, 3 🟡 (down from 7), 102 ⬜.

## v0.31
- **Teams that share a font now get their own catalog entry instead of one**
  **shared entry.** 14 fonts from the v0.30 batch had multiple teams'
  exported values disagreeing for what was nominally "the same font" -- this
  version treats that as real per-team tuning rather than a conflict to
  arbitrate. Each team's own file, confirmed via its own `numberComp` texture
  ref, got a new catalog entry (same `path` as the original shared font, so
  the rendered glyphs are identical -- only `numberSpacing`/
  `playerNumberAdjust` differ) instead of forcing one team's numbers onto
  everyone who happens to use that font.
- `CATALOG.numberFonts.jersey`: 276 -> 334 (+58). `NUMBER_LAYOUT_PROFILES`:
  162 -> 220 (+58).
- Labels for the new entries are auto-generated ("Team (Year, Color)"),
  using existing catalog naming precedent where a team already had another
  entry, plain well-known team names otherwise. Not hand-verified one by
  one -- worth a skim in the font picker for anything that reads awkwardly.
- 8 files still held back (unclear team prefix: `EA`, five `FCS*` codes that
  look like generic conference-filler teams, and `MUSHS`) and 7 originally-
  shared fonts still have no confirmed value of their own (the team that
  namesakes the font wasn't itself in this batch, only other teams borrowing
  it). `BATCH_IMPORT_FLAGS.md` rewritten to reflect only what's still
  actually outstanding.
- `FONT_PROFILES_CHECKLIST.md` regenerated against the new 334-entry
  catalog: 220 ✅, 7 🟡, 107 ⬜.

## v0.30
- **Batch import from `All_uniforms_TB.zip`** (253 JerseyPartItem files):
  added 161 new `NUMBER_LAYOUT_PROFILES` entries in one pass. `NUMBER_LAYOUT_PROFILES`
  now covers 162 of 276 catalog fonts.
- Matching was NOT done by filename -- each file's `numberComp` field was
  resolved (ref -> `TintArrayTexture` instance -> `Overlay_1.textures.
  colorTexture` ref) to the actual font asset name it uses, then matched
  against `CATALOG.numberFonts.jersey` by `displayName`. This matters because
  filename/team-year guessing would have been wrong in both directions: some
  teams use two different fonts across their own jerseys (e.g. ASU), and
  several teams share one generic font (various `Nike_Jersey_2025_Stroked*`
  and `Standard_Jersey_*` templates).
- `numberSpacing` taken directly from each file, per the corrected default
  (Arizona was the exception, not the rule). `playerNumberAdjust` taken
  directly as well.
- Only fonts where every file referencing them agreed on both values went in
  automatically. **37 did not make the cut** -- documented in the new
  `BATCH_IMPORT_FLAGS.md`, not added to `editor.js`:
  - 23 resolved to a real font name not present in the catalog at all (mostly
    generic Nike/Standard templates -- likely just uncatalogued, not wrong).
  - 14 where multiple files sharing the exact same font disagreed on the
    values (small drift in some cases, real disagreement in others) --
    picking one arbitrarily risks repeating the Arizona situation.
  - 2 files that couldn't be processed the normal way at all (one had an
    empty `PlayerNumberAdjList` like Arizona's original wrong-file-type case,
    one didn't resolve to a font reference the way every other file did).
- `FONT_PROFILES_CHECKLIST.md` updated to match: 162 ✅, 7 🟡 (catalog-matched
  but conflicting, see `BATCH_IMPORT_FLAGS.md` part B), 107 ⬜ still needed.

## v0.29
- Corrected the default assumption in `FONT_PROFILES_CHECKLIST.md`: the
  file's `numberspacing.x` value is reliable for most teams. Arizona was the
  exception (file said -0.41, real value -0.48), not the norm -- default to
  what the JerseyPartItem file says for `numberSpacing` going forward, and
  only override it when a specific value is given for that team.
  `playerNumberAdjust` guidance is unchanged (still needs the JerseyPartItem
  file specifically, empty array = wrong file type, not "no overrides").
- No code changes in `editor.js` beyond the version bump.

## v0.28
- Added `FONT_PROFILES_CHECKLIST.md`: a full table of all 276 entries in
  `CATALOG.numberFonts.jersey`, tracking which ones have a confirmed
  `NUMBER_LAYOUT_PROFILES` entry and where the two independent pieces
  (`playerNumberAdjust` from a JerseyPartItem export, `numberSpacing` from
  in-game/Frosty rather than the file) came from. Update this file alongside
  every profile added -- it's the source of truth for progress, since
  session memory doesn't carry code state across chats.
- Arizona (2026) marked ✅ Done in the checklist, reflecting the v0.27 state.
- No code/behavior changes in `editor.js` beyond the version bump.

## v0.27
- **Reverted**, after real in-game errors: pulled `chestNumberOffsetScale`,
  `backNumberOffsetScale`, `shoulderNumberOffsetScale`,
  `sleeveNumberOffsetScale`, and `numberSpacingOverrides` entirely out of
  Arizona (2026)'s profile -- not zeroed, removed. One or more of these (most
  likely the unconfirmed-key `numberSpacingOverrides` from v0.26, but not
  isolated) is the suspected cause.
- `numberSpacing` is now `-0.48`, set directly from in-game observation --
  overriding both the v0.24 (`-0.36`) and v0.25/26 (`-0.41`) reference-file
  values. `playerNumberAdjust` is unchanged from v0.25/26 (11 at `-0.67`, 31
  at `-0.58`, everything else at `-0.53`) since that part was never
  implicated.
- Reworked how `applyField` builds and logs a profile application: each
  category (spacing, each offset/scale field, playerNumberAdjust,
  numberSpacingOverrides) is now fully independent and only mentioned in the
  log if the profile actually defines it, rather than a field count that
  didn't distinguish which categories were present. No behavior change for
  existing fully-populated profiles -- this only affects the log text and
  makes partial profiles (like Arizona's now) report accurately.
- **If a team already had v0.25 or v0.26 applied to it**, this version does
  NOT clean that up -- it only stops writing those fields going forward. A
  team that already has the bad data needs the font re-picked fresh (or the
  uniform reset some other way) to actually clear it.

## v0.26
- Added `numberSpacingOverrides` to the Number Layout profile: the XML's
  `number_spacing_overrides` block (per-position `chestNumberSpacing`/
  `backNumberSpacing`/`shoulderNumberSpacing`/`sleeveNumberSpacing` Vec4s,
  plus their four `override*` booleans) is now written wholesale to
  `numberMaterialSettings.offsetScaleSpacing.numberSpacingOverrides`
  alongside the rest of the profile.
- **Unlike every other field in this profile, the key name itself is
  unconfirmed.** The camelCase pattern (`numberSpacingOverrides`) matches
  what's held for every field we've actually verified against a live
  capture, but this specific sub-object never showed up in the Nike capture
  we checked -- not even zero-valued, the key was flat-out absent. It's
  possible this is authoring-only data that never reaches the live JSON at
  all. All values are 0/false for Arizona regardless, so right now this is a
  no-op bet either way -- `setDeep` will happily create the key even if the
  real one is named differently or doesn't exist, so a successful write does
  NOT confirm the guess is right. Only a font with real (non-zero/true)
  override data, applied and checked in-game, will actually test this.

## v0.25
- Found a better reference for Arizona's numbers: `ARIZ_JERSEY_2026_PRABLUE.xml`,
  a `JerseyPartItem` matching the "Arizona (2026)" catalog entry by name.
  Unlike v0.24's source, it carries `numberMaterialSettings.PlayerNumberAdjList`
  directly on the base item, at the same nesting level the live JSON actually
  uses (sibling to `offsetScaleSpacing`) -- no Mix & Match indirection needed.
  Treating this as the authoritative source now.
- **Corrected values, replacing v0.24's**: `numberSpacing` -0.36 -> -0.41,
  Number 11 -0.59 -> -0.67. Also surfaced a **second real outlier** the old
  (empty) source couldn't show at all -- Number 31 at -0.58, distinct from
  every other non-11 entry, which all sit at -0.53.
- **Expanded scope from spacing-only to full Number Layout**: profiles now
  also carry `chestNumberOffsetScale`, `backNumberOffsetScale`,
  `shoulderNumberOffsetScale`, and `sleeveNumberOffsetScale` -- each written
  as a full object replace, same reasoning as `playerNumberAdjust` (a stale
  leftover component from the previous font is worse than a clean swap).
  This is the fix for numbers sitting too high/low or too big/small after a
  font swap -- those values were calibrated for whatever font was there
  before, not the new one.
- Renamed `NUMBER_SPACING_PROFILES` -> `NUMBER_LAYOUT_PROFILES` (and the
  subfield hook `numberSpacingProfiles` -> `numberLayoutProfiles`) to match
  the wider scope. No behavior change for fonts without a profile entry.
- **Caveat carried over into this version**: the reference file has
  `hasShoulder: false` and `hasSleeve: false` -- Arizona's own jersey doesn't
  use those number positions. Their offset/scale values are structurally
  present but were never actually rendered or eyeballed for this font, unlike
  chest/back which Arizona's jersey does use. Specifically worth testing this
  font on a team whose jersey DOES have shoulder or sleeve numbers before
  trusting those two fields.
- Still **NOT confirmed in-game** even in this corrected form -- same test
  plan as v0.24, just checking more fields now.

## v0.24
- Added a **Number Spacing Profile** system: picking a Jersey Number Font can
  now also write a font-specific `numberMaterialSettings.playerNumberAdjust`
  table (per-number kerning, not just the flat `numberSpacing.x` the slider
  already covers) in the same action, when a profile exists for that font.
  Fonts with no profile behave exactly as before -- purely additive.
- **First (and only) profile: Arizona (2026)** (`ARIZ_Jersey_2026_NUM_Array`).
  Values sourced from `ARIZ_JERSEY_2023_BLUE.xml` (the base
  `CharacterUniformJerseyItem` -- `EnableNumberSpacingOverrides` was `true`
  but its own `NumberWidthAdjustmentList` was empty, so NOT the source) and
  `ARIZ_MixAndMatch.xml` (the Mix & Match `FootballMixMatchPart` entry for
  that same jersey, where `DefaultNumberSpacing` and `PlayerNumberAdjList`
  were the ones actually populated): `numberSpacing.x = -0.36`, plus 18
  `playerNumberAdjust` entries -- 10-19 and 21/31/41/51/61/71/81/91 (every
  number containing a "1", the narrow-glyph digit) each at `-0.4`, except
  Number 11 (both digits narrow) at `-0.59`.
- That the live payload even has this field, and its exact shape, is
  confirmed by a real in-game capture from a different team (Nike): same 18
  numbers, same "11 is the outlier" pattern, different tuned widths. What's
  **NOT yet confirmed** is that Arizona's specific values above actually move
  anything in Team Builder -- test before trusting, same as every other field
  in this tool.
- `NUMBER_SPACING_PROFILES` is a flat lookup keyed by font `displayName`, so
  adding the next font once its reference data is confirmed is one more
  entry, not a code change.

## v0.23
- **Fixed a real bug**: some teams were missing uniform variants from the
  dropdown entirely. The variant-name regex only allowed letters and digits
  (`[A-Za-z0-9]+`), but real variant names contain parentheses --
  `DarkMode(Home)`, `1920s(Reimagined)` -- which silently failed to match
  and dropped the whole variant. Confirmed against two real teams: UCLA
  lost 5 of its 9 variants this way, JT lost 2 of its 14 (less obvious,
  since 12 still worked). Now matches any characters in the variant name,
  tested against both teams (14/14 and 9/9 now show correctly) plus a
  synthetic case with a hyphen inside the variant name itself.

## v0.22
- Added a **Reset** button to the Number Spacing slider. The starting value
  is captured once, the first time each jersey is seen, and stays fixed no
  matter how much dragging happens afterward -- shown as "started at: X"
  next to the slider. Reset jumps straight back to it in one click, so
  experimenting freely doesn't risk losing track of where you began.

## v0.21
- **Fixed a real bug in v0.20's Number Spacing slider**: the stored path had
  an extra `numberComp.` prefix that shouldn't have been there.
  `numberMaterialSettings` is a *sibling* of `numberComp`, not nested inside
  it — confirmed by re-checking the original tree screenshot carefully.
  v0.20 would have shown "No numberSpacing field found" instead of a
  working slider on every real payload. Found while building an accurate
  demo, not from an in-game report — worth noting since it means this was
  silently broken from the moment it shipped.

## v0.20
- Added a **Number Spacing** slider — first non-picker control in the tool.
  Writes directly to
  `numberComp.numberMaterialSettings.offsetScaleSpacing.numberSpacing.x`,
  shown live as you drag. Range is `-0.6` to `-0.3`, a user-confirmed
  comfortable range rather than the field's full technical bounds — values
  outside it may still be valid, just untested. `y`/`z`/`w` on the same
  object are left untouched, as are the sibling `chestNumberOffsetScale` /
  `backNumberOffsetScale` / `shoulderNumberOffsetScale` /
  `sleeveNumberOffsetScale` fields that live one level up.

## v0.19
- Added a material-specific placement override layer, sitting on top of the
  brand-level defaults. First confirmed use: **Adidas WithText** needed its
  own pants placement (`scale 0.056/0.112`, `offset 0.16/0.33`) — genuinely
  different from base Adidas (`0.04/0.08`, `0.16/0.265`), confirmed via
  actual Team Builder renders, not just a raw-JSON comparison. Every other
  Adidas material (Cotton, Plastic, Shiny, base) is unaffected and still
  uses the shared brand baseline. For contrast: Jumpman Cotton vs. Diamond
  were confirmed earlier to need no override at all — same placement either
  way — so this layer only activates where a material's actually been
  checked and found to differ, not by default.

## v0.18
- **UA pants now has confirmed placement** — the last brand/piece gap. Source
  is a fresh, provably untouched team's direct JSON export, not Frosty.
  Notably, Frosty's Georgia Tech reading disagreed with this direct JSON
  pull in a real way (opposite-sign offset, near-mirrored rotation), not
  just rounding — going with the direct JSON value as the more trustworthy
  source of the two, consistent with how Nike/Jumpman/Adidas were already
  confirmed (all via raw JSON, not Frosty alone). `layout: null` confirmed
  and actively enforced, same tier as Nike now.
- All four brands (Nike, Jumpman, Under Armour, Adidas) now have full
  confirmed pants placement + layout enforcement. UA's jersey still shows
  a minor, unconfirmed discrepancy against this same fresh export
  (`offset (0.068, -0.12)` vs. the currently stored `(0, -0.1325)`) — left
  unchanged since jersey has never been reported as an issue, but worth
  knowing if UA jersey placement ever comes into question.

## v0.17
- **Nike pants placement is back, now confirmed by a second school** (this
  exact team, via Frosty Editor) — essentially identical to FSU's numbers.
  The earlier "Nike is broken" report that led to removing it in v0.15 was
  almost certainly the same layout-contamination issue diagnosed for Nike
  Plastic, not bad reference data.
- **Real fix this time, not just detection**: confirmed that Nike's native
  pants `layout` is genuinely `null` (no fourth UV-set slot in Frosty,
  unlike Jumpman/Adidas). Any brand with a known layout policy — a specific
  UV path, or explicit null — now enforces it unconditionally on swap,
  overwriting whatever was there. So swapping to Nike now actively resets
  `layout` back to `null` even if a prior Jumpman/Adidas test left a
  different UV set behind, instead of silently inheriting it. UA still has
  no confirmed policy either way, so it still only gets flagged (v0.16),
  not corrected, until real data exists for it too.

## v0.16
- Added contamination detection for brands with no confirmed placement of
  their own (Nike, UA): if the overlay already carries another *known*
  brand's exact layout signature (Jumpman's or Adidas's), the activity log
  now says so explicitly instead of silently leaving it — e.g. a Nike swap
  landing on an overlay that still has Jumpman's `Pants_UVSet_front` gets
  flagged as likely leftover from testing Jumpman, not this team's native
  state. Doesn't fix the numbers (no confirmed correct value to fall back
  to yet) — just makes the cause visible instead of requiring another round
  of screenshots to diagnose.
- Confirmed limitation surfaced by this: **Reset to loaded** only protects
  against edits made within the current session. If a team's live data was
  already permanently modified by an earlier push (e.g. Jumpman tested and
  pushed in a prior session), a fresh fetch pulls that same modified state
  back — there's no clean baseline left to reset to. Getting Nike/UA their
  own confirmed pants placement (the same Frosty Editor approach used for
  Jumpman and Adidas) is the actual fix; this version just makes the
  symptom diagnosable in the meantime.

## v0.15
- Removed pants placement auto-apply for Nike, Adidas, and UA — their pants
  were already rendering correctly untouched, and auto-applying reference
  numbers on top of an already-fine result was actively breaking it (Nike's
  pants going wrong after a Nike swap, reported directly). Pants now gets a
  texture-only swap for those three brands — no scale/offset/rotate/layout
  writes at all, leaving whatever was already there alone. Jumpman keeps
  its full confirmed placement + layout fix, since that's the one brand
  that was actually broken and needed it.

## v0.14
- QOL fix across all three pickers (Jersey Number Font, Helmet Shell, Vendor
  Decal): clicking into a field that already has a selection now
  auto-selects all the text, so typing immediately overwrites it instead of
  needing a manual select-all-and-delete first. Also added an explicit
  **Clear** button next to each picker for a guaranteed one-click reset,
  regardless of browser-specific datalist filtering quirks.

## v0.13
- **Corrected a wrong assumption from v0.12, before it caused a new bug**:
  `layout` isn't a universal mesh constant shared by every brand — it's
  brand-specific, same as the texture itself. Confirmed Adidas uses
  `Pants_UVSet_maddenOld`, genuinely different from Jumpman's
  `Pants_UVSet_front`. v0.12 would have written Jumpman's value onto an
  Adidas swap, introducing a new wrong-layout bug in the name of fixing
  the old one. Layout is now stored per-brand, alongside scale/offset/
  rotate, and only applied when that specific brand has a confirmed value
  — Nike and UA don't yet, so their pants layout is left untouched rather
  than guessed.

## v0.12
- **Found and fixed the real root cause of the pants-specific placement
  bug**, confirmed by an actual in-game test: `textures.layout` was `null`
  on the affected pants overlay, while Florida's own correctly-rendering
  pants overlay has it set to
  `ContentShared/.../uvsets/Pants_UVSet_front`. Scale, offset, and
  `scaledTransform` were all correct the entire time — this missing UV
  reference was the actual gap. Placement auto-apply now sets `layout` on
  pants whenever it's missing, without touching it if something's already
  there.
- Ruled out along the way, for the record: wrong catalog values (numbers
  matched Florida/Oklahoma/Frosty Editor exactly, three independent
  sources), a lookup bug (brand key matching verified correct in code),
  material differences (Cotton and Diamond share the same issue and same
  fix), and a mesh-wide coordinate mismatch (Adidas rendered correctly on
  the same team/template throughout).
- Corrected Jumpman's pants rotation from `5.5` (an average of two school
  exports) to `5.0`, now directly confirmed via Frosty Editor as the
  authoritative source rather than an estimate.

## v0.11
- Audited every stored placement value directly against all school examples
  gathered so far. Everything matched exactly except Jumpman's pants
  rotation — stored as Oklahoma's `6`, but Florida (the actual visual
  reference used throughout this feature) came in at `5`. Averaged to `5.5`
  rather than silently favor one school over the other. Scale and offset
  were already identical between both schools, unaffected.

## v0.10
- **Likely the real fix for the oversized-logo issue that's come up
  repeatedly**: every overlay carries a `transform.scaledTransform` field
  (`{x, y, z, w}`) that's a separate cached copy of scale/offset
  (`x=scale.u, y=scale.v, z=offset.u, w=offset.v`). Confirmed from a real
  payload that it does **not** recompute itself — `scale`/`offset` were
  being set correctly the whole time, but `scaledTransform` stayed frozen
  at the original brand's values. If the in-game renderer reads
  `scaledTransform` instead of recalculating from `scale`/`offset`, that
  would explain exactly what was reported: the texture pattern changes
  (visibly the right brand/material), but the size and position don't,
  because the field that likely actually controls rendering never updated.
  Placement auto-apply now keeps both in sync.

## v0.09
- **Fixed a real bug**: the decal search only ever found and updated the
  *first* matching overlay per piece. Confirmed from real recipe data that
  Nike's socks template carries two separate decal overlays (mirrored left/
  right) while Adidas/Jumpman/UA only carry one — on a Nike-style template,
  swapping brands would silently leave the second overlay on the old
  texture. Now updates every matching overlay found on a piece, not just
  the first.
- Extended placement defaults to **pants and socks**, not just jersey, now
  that real data exists for both — sourced from confirmed recipes across
  Nike, Jumpman, UA, and (new) Adidas. Placement only auto-applies when a
  piece has exactly one decal overlay; a multi-overlay piece (Nike socks)
  gets its texture updated everywhere but placement left alone, since
  there's no confirmed per-side value to apply safely.
- Confirmed Jumpman's jersey scale (`0.03`) is consistent across two
  different schools (Florida, Oklahoma) — not the source of any reported
  oversized-logo issue.

## v0.08
- Removed the manual scale/offset/rotate controls from v0.06 entirely. With
  the per-brand jersey default from v0.07 handling the common cases
  automatically, and no way to preview the effect of a manual tweak anyway,
  they were more clutter than value. Vendor Decal is back to just the
  picker and a plain current-state readout per piece.

## v0.07
- Reversed course on v0.06's "leave placement alone" default. With no way to
  preview the result, manual sliders you can't see the effect of aren't
  meaningfully better than a decent default — so a brand swap now
  auto-applies a per-brand jersey placement (scale/offset/rotate) sourced
  from the confirmed team examples. Nike and UA get their known values;
  Adidas has no confirmed example yet, so it's left untouched rather than
  guessed. Pants/socks also stay untouched — no confirmed data for those
  pieces yet, only jersey.
- The manual scale/offset/rotate controls from v0.06 are still there
  underneath, for whichever cases the default doesn't fit.

## v0.06
- Added manual **scale / offset / rotate** controls under each piece in the
  Vendor Decal section. A brand swap only ever changes the texture
  (col/rsm/normal) — it deliberately never touches placement, since
  placement is confirmed to vary by jersey *template*, not by brand (a
  Jumpman-templated team and a Nike-templated team don't share one correct
  scale). No safe way to auto-derive the right value, so this exposes the
  current values as editable and lets you dial it in by eye instead.
- Reference values on hand so far (jersey only): Nike scale 0.05, offset
  (0.085, -0.1), rotate 350. Jumpman scale 0.03, offset (0.08, -0.089),
  rotate 0. UA scale 0.035, offset (0, -0.133), rotate 0. These are examples
  from specific teams, not universal brand constants — don't assume they
  transfer to a different template.

## v0.05
- Fixed the decal catalog forcing `ContentShared/...` onto all 16 entries.
  That was only ever confirmed for entries whose source path had `/comp/` in
  it (Nike Cotton, Nike Plastic, UA). Nike ShoeDuck never had `/comp/` to
  begin with, and testing confirmed it needs to stay on plain `content/...`
  — forcing it onto `ContentShared` broke it. Same root cause as the earlier
  `/comp/` issue with number fonts: don't generalize one confirmed example
  across every entry in a catalog without checking whether they actually
  share the same source shape.

## v0.04
- **Fixed a real bug**: Vendor Decal always reported "no vendor decal overlay
  found" even when one clearly existed in the payload. The search was looking
  at `part.overlays` directly, but the real path is one level deeper:
  `part.layerCompTexture.overlays`. Confirmed against a real payload where the
  Nike Logo entry was visible in the raw JSON but the tool couldn't find it.
- The Vendor Decal picker now prefills with the currently-equipped brand +
  material when it matches a known catalog entry, instead of always starting
  blank — so switching reads as an actual swap ("Nike Cotton (2022)" → "Nike
  Plastic (2023)") rather than picking blind.

## v0.03
- Added the **Vendor Decal** swapper — confirmed working in-game across
  multiple brands (Nike, Adidas, Jumpman, Under Armour) and materials (Cotton,
  Plastic, Metallic, Shiny, etc.). One picker updates jersey, pants, and socks
  together; brands can be freely mixed and matched regardless of what's
  currently equipped.
- The vendor decal overlay is found **structurally** (whichever overlay's
  texture already points into `.../decals/vendors/...`), not by label text —
  confirmed that `info.label` changes to match whatever brand is currently
  equipped ("Nike Logo" vs "Adidas Logo" on different default teams), so
  label text isn't a safe search key on its own.
- Catalog paths normalized to the confirmed live form
  (`ContentShared/characters/player/parts/uniforms/decals/vendors/<name>`, no
  `/comp/`) — the source list used a different, unconfirmed path shape.

## v0.02
- Fixed the picker input resetting to its placeholder text ("Pick from
  catalog...") right after a selection was applied, even though the
  underlying field was set correctly. The box now shows what was actually
  picked. Clears automatically when a new payload loads or the variant
  changes, so it can't show a stale pick for the wrong context.

## v0.01
- Removed the standalone Accessory picker — Shell already sets the matching
  accessory automatically, so the separate tab was redundant.
- Removed Facemask entirely (not needed).
- Removed the "Set this field only" override inputs/buttons added for testing;
  reverted to plain read-only "what's already there" display under each field.
- Added a **Reset to loaded** button — snapshots the payload the moment it's
  fetched, and reverts to exactly that snapshot, discarding session edits.
- Fixed **Clear mock** giving no visible feedback — it now refreshes the
  Connection panel right after, so "Mocks stored" / "Network mocking" visibly
  update instead of appearing to do nothing.
