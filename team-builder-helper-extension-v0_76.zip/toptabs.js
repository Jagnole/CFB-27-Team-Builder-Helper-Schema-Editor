// ---------- top-level tab switcher (JSON Editor <-> Mask & Stripe Studio) ----------
// Kept as its own external file rather than an inline <script> block in
// editor.html -- extension pages default to a script-src 'self' CSP that
// silently blocks inline scripts, same root cause as the v0.34.1 gallery
// onerror bug. An inline block here would just never attach its listeners,
// no visible error, buttons look dead.
document.getElementById('mainTabEditor').addEventListener('click', () => {
  document.getElementById('mainTabEditor').classList.add('active');
  document.getElementById('mainTabMaskStudio').classList.remove('active');
  document.getElementById('tabpanel-editor').classList.add('active');
  document.getElementById('tabpanel-maskstudio').classList.remove('active');
});
document.getElementById('mainTabMaskStudio').addEventListener('click', () => {
  document.getElementById('mainTabMaskStudio').classList.add('active');
  document.getElementById('mainTabEditor').classList.remove('active');
  document.getElementById('tabpanel-maskstudio').classList.add('active');
  document.getElementById('tabpanel-editor').classList.remove('active');
});
