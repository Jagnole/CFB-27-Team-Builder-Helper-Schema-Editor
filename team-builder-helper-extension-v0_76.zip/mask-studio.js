// ---------- Mask & Stripe Studio ----------
// Standalone image tool, deliberately separate from the payload editor above:
// it never reads or writes teamData JSON. Output is a PNG the user downloads
// and manually re-uploads through Team Builder's own custom-texture upload --
// same reasoning as the rest of this tool's "download PNG, reupload on TB
// site" features. See CHANGELOG for why this isn't wired into the JSON push
// pipeline (no confirmed payload path for either mask type yet).
//
// Masking mechanism: each mask PNG's ALPHA channel (not just its RGB) already
// encodes which pixels are "on" for that colored region -- confirmed by
// inspecting the source files directly. red/green/blue in the mask identify
// separate regions (same channel-ID convention as the Cotton-style vendor
// decal masks), and each region's own alpha carries real anti-aliased edges.
// So: classify each mask pixel by its dominant channel, then use the mask's
// own alpha as the output alpha for whichever content (solid color or an
// uploaded texture) that region is currently assigned.

const MASK_STUDIO_MASKS = [
  { id: 'collar', group: 'decal', name: 'Collar Mask', src: 'masks/collar_mask.png' },
  { id: 'chest', group: 'decal', name: 'Upper Chest Mask', src: 'masks/chest_mask.png' },
  { id: 'combo', group: 'decal', name: 'Collar + Chest Mask', src: 'masks/combo_mask.png' },
  { id: 'stripe06', group: 'stripes', name: 'Stripes — Center 06', src: 'masks/stripe_06.png' },
  { id: 'stripe07', group: 'stripes', name: 'Stripes — Center 07', src: 'masks/stripe_07.png' },
  { id: 'stripe08', group: 'stripes', name: 'Stripes — Center 08', src: 'masks/stripe_08.png' },
  { id: 'stripe09', group: 'stripes', name: 'Stripes — Center 09', src: 'masks/stripe_09.png' },
  { id: 'stripe10', group: 'stripes', name: 'Stripes — Center 10', src: 'masks/stripe_10.png' },
  { id: 'stripe11', group: 'stripes', name: 'Stripes — Center 11', src: 'masks/stripe_11.png' },
  { id: 'stripe12', group: 'stripes', name: 'Stripes — Center 12', src: 'masks/stripe_12.png' },
  { id: 'stripe13', group: 'stripes', name: 'Stripes — Center 13', src: 'masks/stripe_13.png' },
  { id: 'stripe14', group: 'stripes', name: 'Stripes — Center 14', src: 'masks/stripe_14.png' },
  { id: 'stripe20', group: 'stripes', name: 'Stripes — Center 20', src: 'masks/stripe_20.png' },
  { id: 'stripe21', group: 'stripes', name: 'Stripes — Center 21', src: 'masks/stripe_21.png' },
  { id: 'stripe22', group: 'stripes', name: 'Stripes — Center 22', src: 'masks/stripe_22.png' },
  { id: 'stripe23', group: 'stripes', name: 'Stripes — Center 23', src: 'masks/stripe_23.png' }
];

const MASK_STUDIO_REGION_META = {
  r: { label: 'Red region', color: '#ff3b30', defaultHex: '#ff3b30' },
  g: { label: 'Green region', color: '#34c759', defaultHex: '#34c759' },
  b: { label: 'Blue region', color: '#0a84ff', defaultHex: '#0a84ff' }
};

const maskStudio = {
  group: 'decal',
  maskImg: null,
  maskImageData: null,
  selectedMaskId: null,
  regionConfig: {} // key -> { mode: 'color'|'texture', color: '#hex', texImg, fit: 'cover'|'tile', scale: 100 }
};

function msDominantChannel(r, g, b) {
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  if (max - min < 40) return null;
  if (r === max && r > g + 30 && r > b + 30) return 'r';
  if (g === max && g > r + 30 && g > b + 30) return 'g';
  if (b === max && b > r + 30 && b > g + 30) return 'b';
  return null;
}

function msHexToRgb(hex) {
  const v = hex.replace('#', '');
  return [parseInt(v.substr(0, 2), 16), parseInt(v.substr(2, 2), 16), parseInt(v.substr(4, 2), 16)];
}

function initMaskStudio() {
  const tabDecal = document.getElementById('msTabDecal');
  const tabStripes = document.getElementById('msTabStripes');
  if (!tabDecal || !tabStripes) return; // tab not in DOM yet

  tabDecal.addEventListener('click', () => msSwitchGroup('decal'));
  tabStripes.addEventListener('click', () => msSwitchGroup('stripes'));
  document.getElementById('msResetBtn').addEventListener('click', () => {
    msDetectRegions();
    msRender();
  });
  document.getElementById('msDownloadBtn').addEventListener('click', () => {
    const canvas = document.getElementById('msCanvas');
    const link = document.createElement('a');
    link.download = `mask_export_${maskStudio.selectedMaskId || 'mask'}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  });

  msBuildMaskGrid();
  const first = MASK_STUDIO_MASKS.find(m => m.group === 'decal');
  if (first) msSelectMask(first);
}

function msSwitchGroup(g) {
  maskStudio.group = g;
  document.getElementById('msTabDecal').classList.toggle('active', g === 'decal');
  document.getElementById('msTabStripes').classList.toggle('active', g === 'stripes');
  msBuildMaskGrid();
  const first = MASK_STUDIO_MASKS.find(m => m.group === g);
  if (first) msSelectMask(first);
}

function msBuildMaskGrid() {
  const grid = document.getElementById('msMaskGrid');
  grid.innerHTML = '';
  MASK_STUDIO_MASKS.filter(m => m.group === maskStudio.group).forEach(m => {
    const opt = document.createElement('div');
    opt.className = 'ms-mask-option';
    opt.dataset.id = m.id;
    opt.innerHTML = `<img src="${m.src}"><div class="ms-mask-name">${escapeHtml(m.name)}</div>`;
    opt.addEventListener('click', () => msSelectMask(m));
    grid.appendChild(opt);
  });
}

function msSelectMask(m) {
  maskStudio.selectedMaskId = m.id;
  [...document.getElementById('msMaskGrid').children].forEach(el =>
    el.classList.toggle('selected', el.dataset.id === m.id));

  const img = new Image();
  img.onload = () => {
    maskStudio.maskImg = img;
    const off = document.createElement('canvas');
    off.width = img.naturalWidth;
    off.height = img.naturalHeight;
    const octx = off.getContext('2d');
    octx.drawImage(img, 0, 0);
    maskStudio.maskImageData = octx.getImageData(0, 0, off.width, off.height);
    msDetectRegions();
    msRender();
  };
  img.onerror = () => {
    document.getElementById('msRegionList').innerHTML =
      `<div class="hint">Could not load ${escapeHtml(m.src)} -- check the masks/ folder is present in this extension build.</div>`;
  };
  img.src = m.src;
}

function msDetectRegions() {
  const data = maskStudio.maskImageData.data;
  const present = { r: false, g: false, b: false };
  for (let i = 0; i < data.length; i += 4) {
    if (data[i + 3] < 8) continue;
    const dom = msDominantChannel(data[i], data[i + 1], data[i + 2]);
    if (dom) present[dom] = true;
  }
  maskStudio.regionConfig = {};
  ['r', 'g', 'b'].forEach(k => {
    if (!present[k]) return;
    maskStudio.regionConfig[k] = { mode: 'color', color: MASK_STUDIO_REGION_META[k].defaultHex, texImg: null, fit: 'cover', scale: 100 };
  });
  msRenderRegionList();
}

function msRenderRegionList() {
  const regionList = document.getElementById('msRegionList');
  const keys = Object.keys(maskStudio.regionConfig);
  regionList.innerHTML = '';
  if (!keys.length) {
    regionList.innerHTML = '<div class="hint">No colored regions detected in this mask.</div>';
    return;
  }
  keys.forEach(k => {
    const cfg = maskStudio.regionConfig[k];
    const meta = MASK_STUDIO_REGION_META[k];
    const card = document.createElement('div');
    card.className = 'fieldblock';
    card.style.marginBottom = '10px';
    card.innerHTML = `
      <div class="row" style="align-items:center;justify-content:space-between;margin-bottom:8px;">
        <div class="row" style="align-items:center;gap:8px;margin:0;">
          <span style="width:14px;height:14px;border-radius:3px;display:inline-block;background:${meta.color};border:1px solid var(--line);"></span>
          <span class="name" style="font-size:13px;">${meta.label}</span>
        </div>
        <div class="row" style="gap:4px;margin:0;">
          <button type="button" data-mode="color" class="ms-mode-btn ${cfg.mode === 'color' ? 'active' : ''}">Color</button>
          <button type="button" data-mode="texture" class="ms-mode-btn ${cfg.mode === 'texture' ? 'active' : ''}">Texture</button>
        </div>
      </div>
      <div class="ms-color-body" style="display:${cfg.mode === 'color' ? 'flex' : 'none'};align-items:center;gap:8px;">
        <input type="color" class="ms-colorPicker" value="${cfg.color}">
        <input type="text" class="ms-colorHex" value="${cfg.color}" style="width:90px;font-family:var(--mono);font-size:11.5px;">
      </div>
      <div class="ms-tex-body" style="display:${cfg.mode === 'texture' ? 'block' : 'none'};">
        <div class="ms-dropzone">${cfg.texImg ? `<img class="ms-thumb" src="${cfg.texImg.src}"><div>Change texture</div>` : 'Click or drop an image'}</div>
        <input type="file" accept="image/*" style="display:none;">
        <div class="row" style="align-items:center;gap:6px;margin-top:6px;">
          <button type="button" data-fit="cover" class="ms-fit-btn ${cfg.fit === 'cover' ? 'active' : ''}">Cover</button>
          <button type="button" data-fit="tile" class="ms-fit-btn ${cfg.fit === 'tile' ? 'active' : ''}">Tile</button>
          <input type="range" min="10" max="400" value="${cfg.scale}" class="ms-scale-range" style="flex:1;">
          <span class="ms-scale-val" style="font-size:11px;color:var(--ink-faint);width:34px;text-align:right;">${cfg.scale}%</span>
        </div>
      </div>`;

    card.querySelectorAll('.ms-mode-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        cfg.mode = btn.dataset.mode;
        card.querySelectorAll('.ms-mode-btn').forEach(b => b.classList.toggle('active', b === btn));
        card.querySelector('.ms-color-body').style.display = cfg.mode === 'color' ? 'flex' : 'none';
        card.querySelector('.ms-tex-body').style.display = cfg.mode === 'texture' ? 'block' : 'none';
        msRender();
      });
    });

    const colorPicker = card.querySelector('.ms-colorPicker');
    const colorHex = card.querySelector('.ms-colorHex');
    colorPicker.addEventListener('input', () => { cfg.color = colorPicker.value; colorHex.value = colorPicker.value; msRender(); });
    colorHex.addEventListener('change', () => {
      let v = colorHex.value.trim();
      if (!v.startsWith('#')) v = '#' + v;
      if (/^#[0-9a-fA-F]{6}$/.test(v)) { cfg.color = v; colorPicker.value = v; msRender(); }
    });

    const dropzone = card.querySelector('.ms-dropzone');
    const fileInput = card.querySelector('input[type=file]');
    dropzone.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', e => msHandleRegionTexture(k, e.target.files[0]));
    ['dragover', 'dragenter'].forEach(evt => dropzone.addEventListener(evt, e => { e.preventDefault(); dropzone.classList.add('drag'); }));
    ['dragleave', 'drop'].forEach(evt => dropzone.addEventListener(evt, e => { e.preventDefault(); dropzone.classList.remove('drag'); }));
    dropzone.addEventListener('drop', e => msHandleRegionTexture(k, e.dataTransfer.files[0]));

    card.querySelectorAll('.ms-fit-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        cfg.fit = btn.dataset.fit;
        card.querySelectorAll('.ms-fit-btn').forEach(b => b.classList.toggle('active', b === btn));
        msRender();
      });
    });
    const scaleRange = card.querySelector('.ms-scale-range');
    const scaleVal = card.querySelector('.ms-scale-val');
    scaleRange.addEventListener('input', () => {
      cfg.scale = parseInt(scaleRange.value, 10);
      scaleVal.textContent = cfg.scale + '%';
      msRender();
    });

    regionList.appendChild(card);
  });
}

function msHandleRegionTexture(key, file) {
  if (!file || !file.type.startsWith('image/')) return;
  const reader = new FileReader();
  reader.onload = e => {
    const img = new Image();
    img.onload = () => {
      maskStudio.regionConfig[key].texImg = img;
      msRenderRegionList();
      msRender();
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}

function msBuildTextureBuffer(img, w, h, fit, scale) {
  const buf = document.createElement('canvas');
  buf.width = w;
  buf.height = h;
  const bctx = buf.getContext('2d');
  const s = scale / 100;
  if (fit === 'cover') {
    const tw = img.naturalWidth * s, th = img.naturalHeight * s;
    const coverScale = Math.max(w / tw, h / th);
    const dw = tw * coverScale, dh = th * coverScale;
    bctx.drawImage(img, (w - dw) / 2, (h - dh) / 2, dw, dh);
  } else {
    const tw = img.naturalWidth * s, th = img.naturalHeight * s;
    for (let y = 0; y < h; y += th) {
      for (let x = 0; x < w; x += tw) {
        bctx.drawImage(img, x, y, tw, th);
      }
    }
  }
  return bctx.getImageData(0, 0, w, h).data;
}

function msRender() {
  const canvas = document.getElementById('msCanvas');
  const statusMsg = document.getElementById('msStatus');
  const downloadBtn = document.getElementById('msDownloadBtn');
  const ctx = canvas.getContext('2d');

  if (!maskStudio.maskImg || !maskStudio.maskImageData) {
    statusMsg.textContent = 'Pick a mask to begin.';
    downloadBtn.disabled = true;
    return;
  }

  const w = maskStudio.maskImageData.width, h = maskStudio.maskImageData.height;
  canvas.width = w;
  canvas.height = h;

  const keys = Object.keys(maskStudio.regionConfig);
  const texBuffers = {};
  let anyMissingTexture = false;
  keys.forEach(k => {
    const cfg = maskStudio.regionConfig[k];
    if (cfg.mode === 'texture') {
      if (cfg.texImg) texBuffers[k] = msBuildTextureBuffer(cfg.texImg, w, h, cfg.fit, cfg.scale);
      else anyMissingTexture = true;
    }
  });

  const srcM = maskStudio.maskImageData.data;
  const out = ctx.createImageData(w, h);
  const dst = out.data;
  const colorRgb = {};
  keys.forEach(k => { colorRgb[k] = msHexToRgb(maskStudio.regionConfig[k].color); });

  for (let i = 0; i < srcM.length; i += 4) {
    const ma = srcM[i + 3];
    if (ma < 8) { dst[i + 3] = 0; continue; }
    const dom = msDominantChannel(srcM[i], srcM[i + 1], srcM[i + 2]);
    if (!dom || !maskStudio.regionConfig[dom]) { dst[i + 3] = 0; continue; }
    const cfg = maskStudio.regionConfig[dom];
    if (cfg.mode === 'color') {
      const [r, g, b] = colorRgb[dom];
      dst[i] = r; dst[i + 1] = g; dst[i + 2] = b; dst[i + 3] = ma;
    } else if (cfg.mode === 'texture' && texBuffers[dom]) {
      const tb = texBuffers[dom];
      dst[i] = tb[i]; dst[i + 1] = tb[i + 1]; dst[i + 2] = tb[i + 2];
      dst[i + 3] = Math.min(ma, tb[i + 3]);
    } else {
      dst[i + 3] = 0;
    }
  }

  ctx.putImageData(out, 0, 0);

  if (anyMissingTexture) {
    statusMsg.textContent = 'One or more regions are set to Texture but have no image uploaded yet.';
    downloadBtn.disabled = true;
  } else {
    statusMsg.textContent = 'Ready to download.';
    downloadBtn.disabled = false;
  }
}

initMaskStudio();
