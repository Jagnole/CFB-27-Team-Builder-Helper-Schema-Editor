# Batch Import Flags -- All_uniforms_TB.zip

Updated in v0.32 (cleanup pass). What's left:

## Still needs your input: 8 files with an unclear team prefix

Unchanged from v0.31 -- still couldn't confidently attach a real team to these:

- `EA_JERSEY_2024_BLACK.xml`, `EA_JERSEY_2024_WHITE.xml`
- `FCSE_JERSEY_2023_BLUE.xml`, `FCSMW_JERSEY_2023_ORANGE.xml`,
  `FCSNW_JERSEY_2023_BLACK.xml`, `FCSSE_JERSEY_2023_BLACK.xml`,
  `FCSW_JERSEY_2023_PURPLE.xml` (likely generic FCS-conference filler teams)
- `MUSHS_JERSEY_2025_BLUE.xml`

## Resolved in v0.32: 4 of the original 7 "shared font, no own data" entries

`ECU_Jersey_2023_NUM_Array`, `MTSU_Jersey_2023_NUM_Array`,
`TROY_Jersey_2023_NUM_Array`, and `KU_Jersey_2023_NUM_Array` turned out to
already have that exact team's own file in the batch (same font path, same
team, same year) -- just filed under a different-looking name
(`ECU_JERSEY_2023_BLACK`, etc.) instead of recognized as filling the existing
catalog slot. Merged in, duplicate entries removed.

## Partially resolved: 2 more, but under a different year than cataloged

- `LSU_Jersey_2024_NUM_Array` -- still has no 2024 data of its own, but LSU's
  2023 file (`LSU_JERSEY_2023_GOLD`) uses this same font and is in the catalog
  as its own entry. If the font hasn't changed between seasons, ask if you want
  `LSU_Jersey_2024_NUM_Array` filled with the 2023 numbers as a placeholder, or
  left empty until an actual 2024 file shows up.
- `EMU_Jersey_2021_NUM_Array` -- same situation, EMU's 2025 file
  (`EMU_JERSEY_2025_BLACK`) is the one with real data, cataloged separately.

## Still genuinely no data at all: 1

- `CMU_Jersey_2021_NUM_Array` (Central Michigan) -- every file in the batch that
  uses this font (Clemson, Oklahoma State, Toledo, Tulane) is a different team
  borrowing it. No CMU file itself in this batch.

## Cleanup also done in v0.32 (see CHANGELOG for detail)

- Removed 5 pre-existing catalog entries that were actually helmet fonts
  (`ALA_Helmet_2021_NUM_Array` and 4 others) miscategorized under jersey number
  fonts -- none had profile data, so nothing lost.
- Found and merged 3 more pure same-team/same-font duplicates that v0.31's
  per-file split created without realizing it was the same team twice
  (Kansas State Purple/White, Arizona State Black/Yellow, BYU Black/Blue) --
  each is now one entry instead of two, relabeled without the color that no
  longer distinguishes anything.
- Catalog is now alphabetized by label.

## Still dead ends (2, unchanged)

- `BGH_JERSEY_2024_BLACK.xml` -- empty `PlayerNumberAdjList`.
- `PORTRAIT_JERSEY_2026_BLACK.xml` -- no font reference resolved, possibly not
  a real playable jersey.
