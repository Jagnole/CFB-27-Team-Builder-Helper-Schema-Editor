const CATALOG = {"_meta":{"description":"Known font-array texture paths for CFB 27 Team Builder name/number fonts. Not exhaustive -- grow this as more real teams get captured.","generatedFrom":"user-supplied reference lists, not verified against every entry in-game","knownIssues":["[numberFonts.jersey] DUPLICATE PATH used by 5 display names: ['Air Sports Space Force', 'Akron', 'Ball State', 'BYU throwback', 'Clemson'] -> content/characters/player/parts/uniforms/comp/jerseys/numbers/","[numberFonts.jersey] DUPLICATE PATH used by 2 display names: ['EMU_Jersey_2021_NUM_Array', 'FIU_Jersey_2021_NUM_Array'] -> content/characters/player/parts/uniforms/comp/jerseys/numbers/EMU_Jersey_2021_NUM_Array","[numberFonts.jersey] DUPLICATE PATH used by 2 display names: ['FIU Vice 2024', 'FIU Vice 2023'] -> content/characters/player/parts/uniforms/comp/jerseys/numbers/FIU_Jersey_2024_NUM_Array","[numberFonts.jersey] Case mismatch in path root for 'AFA_Jersey_2021_NUM_Array': Content/characters/Player/parts/uniforms/comp/jerseys/numbers/AFA_Jersey_2021_NUM_Array","[numberFonts.jersey] BLANK/placeholder path for 'Air Sports Space Force': content/characters/player/parts/uniforms/comp/jerseys/numbers/","[numberFonts.jersey] BLANK/placeholder path for 'Akron': content/characters/player/parts/uniforms/comp/jerseys/numbers/","[numberFonts.jersey] BLANK/placeholder path for 'Ball State': content/characters/player/parts/uniforms/comp/jerseys/numbers/","[numberFonts.jersey] BLANK/placeholder path for 'BYU throwback': content/characters/player/parts/uniforms/comp/jerseys/numbers/","[numberFonts.jersey] BLANK/placeholder path for 'Clemson': content/characters/player/parts/uniforms/comp/jerseys/numbers/","[numberFonts.jersey] SUSPICIOUS: number-font entry 'FCS West' points at a _NAME_Array path: content/characters/player/parts/uniforms/comp/jerseys/numbers/STANDARD_Jersey_2022_Blocky_NAME_Array","Confirmed by in-game testing: /comp/ is not required. Both the arrayTexture field and the overlay field take the identical path (with /comp/ stripped, if the catalog entry had it). The tool normalizes automatically -- this note is just so the catalog's raw path values (mostly still /comp/-form, as scraped) aren't misread as the literal in-game requirement.","Number-font entries now carry a human-readable 'label' field (e.g. 'Boston College (2021)') built from a code->school mapping, confirmed with the user except: BGH was dropped (unidentifiable), MTDEW is intentionally not a school (branded/promo jersey). The old separate 'alts' bucket was folded into 'jersey' since the label itself now conveys special/throwback/alt status.","numberFonts.jersey replaced wholesale with the user's manually reviewed Label/Reference table (276 entries) -- not merged or re-derived. Paths were generated fresh using the confirmed working pattern (content/characters/player/parts/uniforms/jerseys/numbers/<reference>), not carried over from any prior catalog version.","helmetMaterials.{shell,facemask,accessory} built from the user's reviewed helmet-material-labels.xlsx (wide format). All three use the same path prefix: content/characters/player/parts/uniforms/helmets/helmet_presets/<reference>. Facemask is included but expected to be rarely used.","decals: path prefix is source-aware, not a blanket rule -- entries whose original source path had /comp/ use ContentShared/... with comp stripped (confirmed for Nike Cotton, Nike Plastic, UA via screenshots); entries that never had /comp/ keep plain content/... unchanged (confirmed for Nike ShoeDuck via actual in-game test). Do not force one prefix onto all entries -- that was the bug that shipped in v0.03/v0.04's initial catalog."]},"nameFonts":[{"displayName":"AFA_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/AFA_Jersey_2021_NAME_Array"},{"displayName":"ASU_Jersey_2021_Name_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/ASU_Jersey_2021_Name_Array"},{"displayName":"ASU_Jersey_2023_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/ASU_Jersey_2023_NAME_Array"},{"displayName":"BC_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/BC_Jersey_2021_NAME_Array"},{"displayName":"BSU_Jersey_2022_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/BSU_Jersey_2022_NAME_Array"},{"displayName":"BYU_Jersey_2022_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/BYU_Jersey_2022_NAME_Array"},{"displayName":"CCAR_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/CCAR_Jersey_2021_NAME_Array"},{"displayName":"CIN_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/CIN_Jersey_2021_NAME_Array"},{"displayName":"EMU_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/EMU_Jersey_2021_NAME_Array"},{"displayName":"GASO_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/GASO_Jersey_2021_NAME_Array"},{"displayName":"ILL_Jersey_2022_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/ILL_Jersey_2022_NAME_Array"},{"displayName":"IND_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/IND_Jersey_2021_NAME_Array"},{"displayName":"LOU_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/LOU_Jersey_2021_NAME_Array"},{"displayName":"MSST_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/MSST_Jersey_2021_NAME_Array"},{"displayName":"NEB_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/NEB_Jersey_2021_NAME_Array"},{"displayName":"NMSU_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/NMSU_Jersey_2021_NAME_Array"},{"displayName":"NW_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/NW_Jersey_2021_NAME_Array"},{"displayName":"PUR_Jersey_2023_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/PUR_Jersey_2023_NAME_Array"},{"displayName":"STAN_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/STAN_Jersey_2021_NAME_Array"},{"displayName":"Standard_Jersey_2022_Blocky_02_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_Blocky_02_NAME_Array"},{"displayName":"STANDARD_Jersey_2022_Blocky_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/STANDARD_Jersey_2022_Blocky_NAME_Array"},{"displayName":"Standard_Jersey_2022_BlockyS_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_BlockyS_NAME_Array"},{"displayName":"Standard_Jersey_2022_BlockyS02_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_BlockyS02_NAME_Array"},{"displayName":"Standard_Jersey_2022_BlockySerif_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_BlockySerif_NAME_Array"},{"displayName":"Standard_Jersey_2022_BlockySerifS_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_BlockySerifS_NAME_Array"},{"displayName":"Standard_Jersey_2022_BlockyStroke_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_BlockyStroke_NAME_Array"},{"displayName":"Standard_Jersey_2022_BlockyStrokeS_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_BlockyStrokeS_NAME_Array"},{"displayName":"Standard_Jersey_2022_BlockyStrokeS02_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_BlockyStrokeS02_NAME_Array"},{"displayName":"Standard_Jersey_2022_Smooth_01_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_Smooth_01_NAME_Array"},{"displayName":"Standard_Jersey_2022_Smooth_02_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_Smooth_02_NAME_Array"},{"displayName":"Standard_Jersey_2022_Smooth_03_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_Smooth_03_NAME_Array"},{"displayName":"TAMU_Jersey_2023_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/TAMU_Jersey_2023_NAME_Array"},{"displayName":"TOL_Jersey_2023_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/TOL_Jersey_2023_NAME_Array"},{"displayName":"UAB_Jersey_2024_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/UAB_Jersey_2024_NAME_Array"},{"displayName":"UCF_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/UCF_Jersey_2021_NAME_Array"},{"displayName":"UMD_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/UMD_Jersey_2021_NAME_Array"},{"displayName":"UNLV_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/UNLV_Jersey_2021_NAME_Array"},{"displayName":"UNM_Jersey_2023_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/UNM_Jersey_2023_NAME_Array"},{"displayName":"USA_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/USA_Jersey_2021_NAME_Array"},{"displayName":"USF_Jersey_2023_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/USF_Jersey_2023_NAME_Array"},{"displayName":"USM_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/USM_Jersey_2021_NAME_Array"},{"displayName":"USU_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/USU_Jersey_2021_NAME_Array"},{"displayName":"VT_Jersey_2023_Blocky_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/VT_Jersey_2023_Blocky_NAME_Array"},{"displayName":"WASH_Jersey_2023_Blocky_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/WASH_Jersey_2023_Blocky_NAME_Array"},{"displayName":"WIS_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/WIS_Jersey_2021_NAME_Array"},{"displayName":"WVU_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/WVU_Jersey_2021_NAME_Array"},{"displayName":"WYO_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/WYO_Jersey_2021_NAME_Array"}],"numberFonts":{"jersey":[{"displayName":"AFA_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/AFA_Jersey_2021_NUM_Array","label":"Air Force (2021)"},{"displayName":"AFA_Jersey_2025_Alt_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/AFA_Jersey_2025_Alt_NUM_Array","label":"Air Force (2025, Alt)"},{"displayName":"AKR_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/AKR_Jersey_2021_NUM_Array","label":"Akron (2021)"},{"displayName":"AKR_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/AKR_Jersey_2025_NUM_Array","label":"Akron (2025)"},{"displayName":"APP_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/APP_Jersey_2021_NUM_Array","label":"Appalachian State (2021)"},{"displayName":"APP_JERSEY_2023_BLACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedAllLeague2_NUM_Array","label":"Appalachian State (2023, Black)"},{"displayName":"ARIZ_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ARIZ_Jersey_2021_NUM_Array","label":"Arizona (2021)"},{"displayName":"ARIZ_Jersey_2026_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ARIZ_Jersey_2026_NUM_Array","label":"Arizona (2026)"},{"displayName":"ASU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ASU_Jersey_2021_NUM_Array","label":"Arizona State (2021)"},{"displayName":"ASU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ASU_Jersey_2023_NUM_Array","label":"Arizona State (2023)"},{"displayName":"ASU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ASU_Jersey_2024_NUM_Array","label":"Arizona State (2024)"},{"displayName":"ASU_Jersey_2025_02_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ASU_Jersey_2025_02_NUM_Array","label":"Arizona State (2025, 02)"},{"displayName":"ASU_JERSEY_2025_THROWBACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedFullBlock3_NUM_Array","label":"Arizona State (2025, Throwback)"},{"displayName":"ASU_JERSEY_2025_BLACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/ASU_Jersey_2025_NUM_Array","label":"Arizona State (2025)"},{"displayName":"ARK_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ARK_Jersey_2021_NUM_Array","label":"Arkansas (2021)"},{"displayName":"ARK_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ARK_Jersey_2023_NUM_Array","label":"Arkansas (2023)"},{"displayName":"ARST_Jersey_2023_02_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ARST_Jersey_2023_02_NUM_Array","label":"Arkansas State (2023, 02)"},{"displayName":"ARST_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ARST_Jersey_2023_NUM_Array","label":"Arkansas State (2023)"},{"displayName":"ARMY_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ARMY_Jersey_2021_NUM_Array","label":"Army (2021)"},{"displayName":"ARMY_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ARMY_Jersey_2024_NUM_Array","label":"Army (2024)"},{"displayName":"ARMY_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ARMY_Jersey_2025_NUM_Array","label":"Army (2025)"},{"displayName":"AUB_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/AUB_Jersey_2023_NUM_Array","label":"Auburn (2023)"},{"displayName":"BALL_JERSEY_2024_BLACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_BALL_NUM_Array","label":"Ball State (2024, Black)"},{"displayName":"BAY_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/BAY_Jersey_2021_NUM_Array","label":"Baylor (2021)"},{"displayName":"BSU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/BSU_Jersey_2021_NUM_Array","label":"Boise State (2021)"},{"displayName":"BC_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/BC_Jersey_2021_NUM_Array","label":"Boston College (2021)"},{"displayName":"BC_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/BC_Jersey_2024_NUM_Array","label":"Boston College (2024)"},{"displayName":"BC_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/BC_Jersey_2025_NUM_Array","label":"Boston College (2025)"},{"displayName":"BGSU_JERSEY_2023_BROWN","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_MISS_NUM_Array","label":"Bowling Green (2023, Brown)"},{"displayName":"BUFF_JERSEY_2023_BLUE","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedBoulder3_NUM_Array","label":"Buffalo (2023, Blue)"},{"displayName":"BYU_JERSEY_2023_BLACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedFullBlock_NUM_Array","label":"BYU (2023)"},{"displayName":"BYU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/BYU_Jersey_2024_NUM_Array","label":"BYU (2024)"},{"displayName":"CAL_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CAL_Jersey_2021_NUM_Array","label":"California (2021)"},{"displayName":"CMU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CMU_Jersey_2021_NUM_Array","label":"Central Michigan (2021)"},{"displayName":"CMU_JERSEY_2023_MAROON","path":"content/characters/player/parts/uniforms/jerseys/numbers/LSU_Jersey_2024_NUM_Array","label":"Central Michigan (2023, Maroon)"},{"displayName":"CMU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CMU_Jersey_2023_NUM_Array","label":"Central Michigan (2023)"},{"displayName":"CMU_Jersey_2025_Sleeve_MAROON_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CMU_Jersey_2025_Sleeve_MAROON_NUM_Array","label":"Central Michigan (2025, Sleeve Maroon)"},{"displayName":"CMU_Jersey_2025_Sleeve_WHI_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CMU_Jersey_2025_Sleeve_WHI_NUM_Array","label":"Central Michigan (2025, Sleeve WHI)"},{"displayName":"CHAR_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CHAR_Jersey_2021_NUM_Array","label":"Charlotte (2021)"},{"displayName":"CHAR_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CHAR_Jersey_2023_NUM_Array","label":"Charlotte (2023)"},{"displayName":"CHAR_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CHAR_Jersey_2025_NUM_Array","label":"Charlotte (2025)"},{"displayName":"CIN_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CIN_Jersey_2021_NUM_Array","label":"Cincinnati (2021)"},{"displayName":"CIN_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CIN_Jersey_2025_NUM_Array","label":"Cincinnati (2025)"},{"displayName":"CLEM_JERSEY_2023_ORANGE","path":"content/characters/player/parts/uniforms/jerseys/numbers/CMU_Jersey_2021_NUM_Array","label":"Clemson (2023, Orange)"},{"displayName":"CCAR_Jersey_2021_02_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CCAR_Jersey_2021_02_NUM_Array","label":"Coastal Carolina (2021, 02)"},{"displayName":"CCAR_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CCAR_Jersey_2021_NUM_Array","label":"Coastal Carolina (2021)"},{"displayName":"CCAR_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CCAR_Jersey_2022_NUM_Array","label":"Coastal Carolina (2022)"},{"displayName":"COLO_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/COLO_Jersey_2024_NUM_Array","label":"Colorado (2024)"},{"displayName":"CSU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CSU_Jersey_2021_NUM_Array","label":"Colorado State (2021)"},{"displayName":"CSU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CSU_Jersey_2024_NUM_Array","label":"Colorado State (2024)"},{"displayName":"DEL_Jersey_2024_02_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/DEL_Jersey_2024_02_NUM_Array","label":"Delaware (2024, 02)"},{"displayName":"DEL_Jersey_2024_03_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/DEL_Jersey_2024_03_NUM_Array","label":"Delaware (2024, 03)"},{"displayName":"DEL_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/DEL_Jersey_2024_NUM_Array","label":"Delaware (2024)"},{"displayName":"DUKE_JERSEY_2023_BLACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_DUKE_NUM_Array","label":"Duke (2023, Black)"},{"displayName":"ECU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ECU_Jersey_2021_NUM_Array","label":"East Carolina (2021)"},{"displayName":"ECU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ECU_Jersey_2023_NUM_Array","label":"East Carolina (2023)"},{"displayName":"EMU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/EMU_Jersey_2021_NUM_Array","label":"Eastern Michigan (2021)"},{"displayName":"EMU_JERSEY_2025_BLACK","path":"content/characters/player/parts/uniforms/jerseys/numbers/EMU_Jersey_2021_NUM_Array","label":"Eastern Michigan (2025, Black)"},{"displayName":"FLA_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/FLA_Jersey_2021_NUM_Array","label":"Florida (2021)"},{"displayName":"FLA_JERSEY_2023_THROWBACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_MISS_NUM_Array","label":"Florida (2023, Throwback)"},{"displayName":"FAU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/FAU_Jersey_2021_NUM_Array","label":"Florida Atlantic (2021)"},{"displayName":"FAU_Jersey_2025-2_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/FAU_Jersey_2025-2_NUM_Array","label":"Florida Atlantic (2025, v2)"},{"displayName":"FAU_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/FAU_Jersey_2025_NUM_Array","label":"Florida Atlantic (2025)"},{"displayName":"FIU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/FIU_Jersey_2021_NUM_Array","label":"Florida International (2021)"},{"displayName":"FIU_JERSEY_2023_NAVY","path":"content/characters/player/parts/uniforms/jerseys/numbers/EMU_Jersey_2021_NUM_Array","label":"Florida International (2023, Navy)"},{"displayName":"FIU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/FIU_Jersey_2024_NUM_Array","label":"Florida International (2024)"},{"displayName":"FIU_Jersey_2025_Vice_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/FIU_Jersey_2025_Vice_NUM_Array","label":"Florida International (2025, Vice)"},{"displayName":"FSU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/FSU_Jersey_2021_NUM_Array","label":"Florida State (2021)"},{"displayName":"FRES_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/FRES_Jersey_2021_NUM_Array","label":"Fresno State (2021)"},{"displayName":"UGA_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UGA_Jersey_2021_NUM_Array","label":"Georgia (2021)"},{"displayName":"UGA_JERSEY_2023_RED","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedWideFullBlock_NUM_Array","label":"Georgia (2023, Red)"},{"displayName":"GASO_JERSEY_2023_BLUE","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_DUKE_NUM_Array","label":"Georgia Southern (2023, Blue)"},{"displayName":"GSU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/GSU_Jersey_2021_NUM_Array","label":"Georgia State (2021)"},{"displayName":"GSU_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/GSU_Jersey_2022_NUM_Array","label":"Georgia State (2022)"},{"displayName":"GSU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/GSU_Jersey_2023_NUM_Array","label":"Georgia State (2023)"},{"displayName":"GT_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/GT_Jersey_2022_NUM_Array","label":"Georgia Tech (2022)"},{"displayName":"GT_Jersey_2026_White_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/GT_Jersey_2026_White_NUM_Array","label":"Georgia Tech (2026, White)"},{"displayName":"GT_Jersey_2026_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/GT_Jersey_2026_NUM_Array","label":"Georgia Tech (2026)"},{"displayName":"HAW_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/HAW_Jersey_2021_NUM_Array","label":"Hawaii (2021)"},{"displayName":"HAW_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/HAW_Jersey_2023_NUM_Array","label":"Hawaii (2023)"},{"displayName":"HOU_JERSEY_2023_RED","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_WideFullBlock2_NUM_Array","label":"Houston (2023, Red)"},{"displayName":"HOU_Jersey_2025_Sleeve_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/HOU_Jersey_2025_Sleeve_NUM_Array","label":"Houston (2025, Sleeve)"},{"displayName":"ILL_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ILL_Jersey_2021_NUM_Array","label":"Illinois (2021)"},{"displayName":"ILL_JERSEY_2023_TRHOWBACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_BALL_NUM_Array","label":"Illinois (2023, Trhowback)"},{"displayName":"IND_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/IND_Jersey_2022_NUM_Array","label":"Indiana (2022)"},{"displayName":"IND_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/IND_Jersey_2023_NUM_Array","label":"Indiana (2023)"},{"displayName":"IOWA_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/IOWA_Jersey_2021_NUM_Array","label":"Iowa (2021)"},{"displayName":"ISU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ISU_Jersey_2021_NUM_Array","label":"Iowa State (2021)"},{"displayName":"ISU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ISU_Jersey_2023_NUM_Array","label":"Iowa State (2023)"},{"displayName":"ISU_JERSEY_2024_THROWBACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_UMASS_NUM_Array","label":"Iowa State (2024, Throwback)"},{"displayName":"ISU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ISU_Jersey_2024_NUM_Array","label":"Iowa State (2024)"},{"displayName":"ISU_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ISU_Jersey_2025_NUM_Array","label":"Iowa State (2025)"},{"displayName":"JVST_JERSEY_2023_RED","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_UMASS_NUM_Array","label":"Jacksonville State (2023, Red)"},{"displayName":"JVST_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/JVST_Jersey_2023_NUM_Array","label":"Jacksonville State (2023)"},{"displayName":"JMU_JERSEY_2023_PURPLE","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedVapor_Strike_NUM_Array","label":"James Madison (2023, Purple)"},{"displayName":"KU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/KU_Jersey_2021_NUM_Array","label":"Kansas (2021)"},{"displayName":"KU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/KU_Jersey_2023_NUM_Array","label":"Kansas (2023)"},{"displayName":"KU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/KU_Jersey_2024_NUM_Array","label":"Kansas (2024)"},{"displayName":"KU_Jersey_2025_Shoulders_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/KU_Jersey_2025_Shoulders_NUM_Array","label":"Kansas (2025, Shoulders)"},{"displayName":"KU_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/KU_Jersey_2025_NUM_Array","label":"Kansas (2025)"},{"displayName":"KSU_JERSEY_2023_PURPLE","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_KSU_NUM_Array","label":"Kansas State (2023)"},{"displayName":"KENN_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/KENN_Jersey_2021_NUM_Array","label":"Kennesaw State (2021)"},{"displayName":"KENN_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/KENN_Jersey_2025_NUM_Array","label":"Kennesaw State (2025)"},{"displayName":"KENT_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/KENT_Jersey_2021_NUM_Array","label":"Kent State (2021)"},{"displayName":"KENT_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/KENT_Jersey_2022_NUM_Array","label":"Kent State (2022)"},{"displayName":"KENT_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/KENT_Jersey_2023_NUM_Array","label":"Kent State (2023)"},{"displayName":"KENT_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/KENT_Jersey_2025_NUM_Array","label":"Kent State (2025)"},{"displayName":"UK_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UK_Jersey_2021_NUM_Array","label":"Kentucky (2021)"},{"displayName":"UK_JERSEY_2023_BLUE","path":"content/characters/player/parts/uniforms/jerseys/numbers/TROY_Jersey_2023_NUM_Array","label":"Kentucky (2023, Blue)"},{"displayName":"LIB_Jersey_2023_Num_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/LIB_Jersey_2023_Num_Array","label":"Liberty (2023)"},{"displayName":"ULL_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ULL_Jersey_2021_NUM_Array","label":"Louisiana (2021)"},{"displayName":"ULL_JERSEY_2023_THROWBACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_UMASS_NUM_Array","label":"Louisiana (2023, Throwback)"},{"displayName":"ULL_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ULL_Jersey_2024_NUM_Array","label":"Louisiana (2024)"},{"displayName":"ULL_Jersey_2025_BLOCKSHADOW_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ULL_Jersey_2025_BLOCKSHADOW_NUM_Array","label":"Louisiana (2025, Blockshadow)"},{"displayName":"LT_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/LT_Jersey_2021_NUM_Array","label":"Louisiana Tech (2021)"},{"displayName":"LT_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/LT_Jersey_2023_NUM_Array","label":"Louisiana Tech (2023)"},{"displayName":"ULM_Jersey_2016_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ULM_Jersey_2016_NUM_Array","label":"Louisiana-Monroe (2016)"},{"displayName":"ULM_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ULM_Jersey_2021_NUM_Array","label":"Louisiana-Monroe (2021)"},{"displayName":"ULM_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ULM_Jersey_2024_NUM_Array","label":"Louisiana-Monroe (2024)"},{"displayName":"ULM_JERSEY_2025_GRAY","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_1970_FAL_NUM_Array","label":"Louisiana-Monroe (2025, Gray)"},{"displayName":"LOU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/LOU_Jersey_2021_NUM_Array","label":"Louisville (2021)"},{"displayName":"LOU_Jersey_2024_02_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/LOU_Jersey_2024_02_NUM_Array","label":"Louisville (2024, 02)"},{"displayName":"LOU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/LOU_Jersey_2024_NUM_Array","label":"Louisville (2024)"},{"displayName":"LOU_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/LOU_Jersey_2025_NUM_Array","label":"Louisville (2025)"},{"displayName":"LSU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/LSU_Jersey_2021_NUM_Array","label":"LSU (2021)"},{"displayName":"LSU_JERSEY_2023_GOLD","path":"content/characters/player/parts/uniforms/jerseys/numbers/LSU_Jersey_2024_NUM_Array","label":"LSU (2023, Gold)"},{"displayName":"LSU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/LSU_Jersey_2023_NUM_Array","label":"LSU (2023)"},{"displayName":"LSU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/LSU_Jersey_2024_NUM_Array","label":"LSU (2024)"},{"displayName":"MRSH_JERSEY_2023_BLACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_MRSH_NUM_Array","label":"Marshall (2023, Black)"},{"displayName":"MRSH_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MRSH_Jersey_2025_NUM_Array","label":"Marshall (2025)"},{"displayName":"UMD_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UMD_Jersey_2021_NUM_Array","label":"Maryland (2021)"},{"displayName":"UMD_Jersey_2024_CHROME_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UMD_Jersey_2024_CHROME_NUM_Array","label":"Maryland (2024, Chrome)"},{"displayName":"UMD_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UMD_Jersey_2025_NUM_Array","label":"Maryland (2025)"},{"displayName":"UMD_Jersey_Away_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UMD_Jersey_Away_2023_NUM_Array","label":"Maryland (Away 2023)"},{"displayName":"UMASS_JERSEY_2023_MAROON","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_UMASS_NUM_Array","label":"Massachusetts (2023, Maroon)"},{"displayName":"MEM_JERSEY_2023_BLUE","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2023_MSU_Stroked_NUM_Array","label":"Memphis (2023, Blue)"},{"displayName":"MIA_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MIA_Jersey_2024_NUM_Array","label":"Miami (FL) (2024)"},{"displayName":"MIA_Jersey_2025_Camo_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MIA_Jersey_2025_Camo_NUM_Array","label":"Miami (FL) (2025, Camo)"},{"displayName":"MIA_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MIA_Jersey_2025_NUM_Array","label":"Miami (FL) (2025)"},{"displayName":"MIAOH_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MIAOH_Jersey_2021_NUM_Array","label":"Miami (OH) (2021)"},{"displayName":"MIAOH_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MIAOH_Jersey_2024_NUM_Array","label":"Miami (OH) (2024)"},{"displayName":"MIAOH_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MIAOH_Jersey_2025_NUM_Array","label":"Miami (OH) (2025)"},{"displayName":"MICH_JERSEY_2023_BLUE","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_MICH_NUM_Array","label":"Michigan (2023, Blue)"},{"displayName":"MSU_JERSEY_2023_GREEN","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2023_MSU_Stroked_NUM_Array","label":"Michigan State (2023, Green)"},{"displayName":"MTSU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MTSU_Jersey_2023_NUM_Array","label":"Middle Tennessee (2023)"},{"displayName":"MINN_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MINN_Jersey_2021_NUM_Array","label":"Minnesota (2021)"},{"displayName":"MINN_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MINN_Jersey_2024_NUM_Array","label":"Minnesota (2024)"},{"displayName":"MSST_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MSST_Jersey_2021_NUM_Array","label":"Mississippi State (2021)"},{"displayName":"MSST_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MSST_Jersey_2024_NUM_Array","label":"Mississippi State (2024)"},{"displayName":"MSST_Jersey_2025_Throwback_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MSST_Jersey_2025_Throwback_NUM_Array","label":"Mississippi State (2025, Throwback)"},{"displayName":"MIZZ_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MIZZ_Jersey_2021_NUM_Array","label":"Missouri (2021)"},{"displayName":"MIST_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MIST_Jersey_2024_NUM_Array","label":"Missouri State (2024)"},{"displayName":"MTDEW_Jersey_2025_Shoulder_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MTDEW_Jersey_2025_Shoulder_NUM_Array","label":"Mountain Dew (non-school / branded) (2025, Shoulder)"},{"displayName":"MTDEW_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MTDEW_Jersey_2025_NUM_Array","label":"Mountain Dew (non-school / branded) (2025)"},{"displayName":"NAVY_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NAVY_Jersey_2021_NUM_Array","label":"Navy (2021)"},{"displayName":"NAVY_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NAVY_Jersey_2023_NUM_Array","label":"Navy (2023)"},{"displayName":"NAVY_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NAVY_Jersey_2024_NUM_Array","label":"Navy (2024)"},{"displayName":"NAVY_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NAVY_Jersey_2025_NUM_Array","label":"Navy (2025)"},{"displayName":"NCST_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NCST_Jersey_2021_NUM_Array","label":"NC State (2021)"},{"displayName":"NCST_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NCST_Jersey_2025_NUM_Array","label":"NC State (2025)"},{"displayName":"NEB_JERSEY_2024_RED","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_NEB_NUM_Array","label":"Nebraska (2024, Red)"},{"displayName":"NEB_Jersey_2025_Shoulder_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NEB_Jersey_2025_Shoulder_NUM_Array","label":"Nebraska (2025, Shoulder)"},{"displayName":"NEB_Jersey_2026_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NEB_Jersey_2026_NUM_Array","label":"Nebraska (2026)"},{"displayName":"NEV_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NEV_Jersey_2021_NUM_Array","label":"Nevada (2021)"},{"displayName":"UNM_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UNM_Jersey_2021_NUM_Array","label":"New Mexico (2021)"},{"displayName":"UNM_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UNM_Jersey_2025_NUM_Array","label":"New Mexico (2025)"},{"displayName":"NMSU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NMSU_Jersey_2021_NUM_Array","label":"New Mexico State (2021)"},{"displayName":"NMSU_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NMSU_Jersey_2022_NUM_Array","label":"New Mexico State (2022)"},{"displayName":"NMSU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NMSU_Jersey_2023_NUM_Array","label":"New Mexico State (2023)"},{"displayName":"UNC_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UNC_Jersey_2021_NUM_Array","label":"North Carolina (2021)"},{"displayName":"UNC_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UNC_Jersey_2022_NUM_Array","label":"North Carolina (2022)"},{"displayName":"NDSU_Jersey_2026_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NDSU_Jersey_2026_NUM_Array","label":"North Dakota State (2026)"},{"displayName":"UNT_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UNT_Jersey_2021_NUM_Array","label":"North Texas (2021)"},{"displayName":"UNT_JERSEY_2022_HAYDENFRY","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_STAN_NUM_Array","label":"North Texas (2022, Haydenfry)"},{"displayName":"UNT_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UNT_Jersey_2022_NUM_Array","label":"North Texas (2022)"},{"displayName":"UNT_JERSEY_2023_GREEN","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_MISS_NUM_Array","label":"North Texas (2023, Green)"},{"displayName":"NIU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NIU_Jersey_2021_NUM_Array","label":"Northern Illinois (2021)"},{"displayName":"NIU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NIU_Jersey_2023_NUM_Array","label":"Northern Illinois (2023)"},{"displayName":"NW_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NW_Jersey_2021_NUM_Array","label":"Northwestern (2021)"},{"displayName":"NW_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NW_Jersey_2022_NUM_Array","label":"Northwestern (2022)"},{"displayName":"ND_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ND_Jersey_2021_NUM_Array","label":"Notre Dame (2021)"},{"displayName":"ND_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ND_Jersey_2023_NUM_Array","label":"Notre Dame (2023)"},{"displayName":"ND_Jersey_2024_Shamrock_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ND_Jersey_2024_Shamrock_NUM_Array","label":"Notre Dame (2024, Shamrock)"},{"displayName":"OHIO_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/OHIO_Jersey_2023_NUM_Array","label":"Ohio (2023)"},{"displayName":"OHIO_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/OHIO_Jersey_2024_NUM_Array","label":"Ohio (2024)"},{"displayName":"OSU_Jersey_2023_02_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/OSU_Jersey_2023_02_NUM_Array","label":"Ohio State (2023, 02)"},{"displayName":"OSU_JERSEY_2023_SCARLETT","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedFullBlock3_NUM_Array","label":"Ohio State (2023, Scarlett)"},{"displayName":"OSU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/OSU_Jersey_2024_NUM_Array","label":"Ohio State (2024)"},{"displayName":"OU_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/OU_Jersey_2022_NUM_Array","label":"Oklahoma (2022)"},{"displayName":"OU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/OU_Jersey_2023_NUM_Array","label":"Oklahoma (2023)"},{"displayName":"OU_Jersey_2024_02_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/OU_Jersey_2024_02_NUM_Array","label":"Oklahoma (2024, 02)"},{"displayName":"OU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/OU_Jersey_2024_NUM_Array","label":"Oklahoma (2024)"},{"displayName":"OKST_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/OKST_Jersey_2021_NUM_Array","label":"Oklahoma State (2021)"},{"displayName":"OKST_JERSEY_2023_BLACK","path":"content/characters/player/parts/uniforms/jerseys/numbers/CMU_Jersey_2021_NUM_Array","label":"Oklahoma State (2023, Black)"},{"displayName":"ODU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ODU_Jersey_2021_NUM_Array","label":"Old Dominion (2021)"},{"displayName":"MISS_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MISS_Jersey_2021_NUM_Array","label":"Ole Miss (2021)"},{"displayName":"MISS_JERSEY_2024_BLUE","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_MISS_NUM_Array","label":"Ole Miss (2024, Blue)"},{"displayName":"ORE_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ORE_Jersey_2021_NUM_Array","label":"Oregon (2021)"},{"displayName":"ORE_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ORE_Jersey_2024_NUM_Array","label":"Oregon (2024)"},{"displayName":"ORE_Jersey_2025_ShoeDuck_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ORE_Jersey_2025_ShoeDuck_NUM_Array","label":"Oregon (2025, Shoeduck)"},{"displayName":"ORST_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ORST_Jersey_2021_NUM_Array","label":"Oregon State (2021)"},{"displayName":"ORST_Jersey_2025_Camo_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ORST_Jersey_2025_Camo_NUM_Array","label":"Oregon State (2025, Camo)"},{"displayName":"PSU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/PSU_Jersey_2021_NUM_Array","label":"Penn State (2021)"},{"displayName":"PSU_JERSEY_2023_BLUESTRIPE","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2023_Throwback_NUM_Array","label":"Penn State (2023, Bluestripe)"},{"displayName":"PSU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/PSU_Jersey_2023_NUM_Array","label":"Penn State (2023)"},{"displayName":"PITT_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/PITT_Jersey_2021_NUM_Array","label":"Pittsburgh (2021)"},{"displayName":"PUR_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/PUR_Jersey_2021_NUM_Array","label":"Purdue (2021)"},{"displayName":"PUR_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/PUR_Jersey_2023_NUM_Array","label":"Purdue (2023)"},{"displayName":"RICE_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/RICE_Jersey_2021_NUM_Array","label":"Rice (2021)"},{"displayName":"RICE_JERSEY_2023_LIGHTBLUE","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_STAN_NUM_Array","label":"Rice (2023, Lightblue)"},{"displayName":"RICE_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/RICE_Jersey_2023_NUM_Array","label":"Rice (2023)"},{"displayName":"RICE_Jersey_2026_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/RICE_Jersey_2026_NUM_Array","label":"Rice (2026)"},{"displayName":"RUTG_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/RUTG_Jersey_2021_NUM_Array","label":"Rutgers (2021)"},{"displayName":"SACST_Jersey_2026_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SACST_Jersey_2026_NUM_Array","label":"Sacramento State (2026)"},{"displayName":"SHSU_Jersey_2021_NUM_Array_2","path":"content/characters/player/parts/uniforms/jerseys/numbers/SHSU_Jersey_2021_NUM_Array_2","label":"Sam Houston State (2021, v2)"},{"displayName":"SHSU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SHSU_Jersey_2021_NUM_Array","label":"Sam Houston State (2021)"},{"displayName":"SHSU_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SHSU_Jersey_2025_NUM_Array","label":"Sam Houston State (2025)"},{"displayName":"SDSU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SDSU_Jersey_2021_NUM_Array","label":"San Diego State (2021)"},{"displayName":"SJSU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SJSU_Jersey_2021_NUM_Array","label":"San Jose State (2021)"},{"displayName":"SJSU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SJSU_Jersey_2023_NUM_Array","label":"San Jose State (2023)"},{"displayName":"SMU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SMU_Jersey_2021_NUM_Array","label":"SMU (2021)"},{"displayName":"SMU_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SMU_Jersey_2022_NUM_Array","label":"SMU (2022)"},{"displayName":"SMU_JERSEY_2023_BLUE","path":"content/characters/player/parts/uniforms/jerseys/numbers/MTSU_Jersey_2023_NUM_Array","label":"SMU (2023, Blue)"},{"displayName":"USA_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/USA_Jersey_2021_NUM_Array","label":"South Alabama (2021)"},{"displayName":"USA_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/USA_Jersey_2025_NUM_Array","label":"South Alabama (2025)"},{"displayName":"SC_Jersey_2021_02_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SC_Jersey_2021_02_NUM_Array","label":"South Carolina (2021, 02)"},{"displayName":"SC_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SC_Jersey_2021_NUM_Array","label":"South Carolina (2021)"},{"displayName":"SC_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SC_Jersey_2024_NUM_Array","label":"South Carolina (2024)"},{"displayName":"USF_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/USF_Jersey_2021_NUM_Array","label":"South Florida (2021)"},{"displayName":"USF_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/USF_Jersey_2023_NUM_Array","label":"South Florida (2023)"},{"displayName":"USM_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/USM_Jersey_2021_NUM_Array","label":"Southern Miss (2021)"},{"displayName":"USM_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/USM_Jersey_2025_NUM_Array","label":"Southern Miss (2025)"},{"displayName":"STAN_JERSEY_2023_BLACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_OSU_NUM_Array","label":"Stanford (2023, Black)"},{"displayName":"SYR_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SYR_Jersey_2021_NUM_Array","label":"Syracuse (2021)"},{"displayName":"TCU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TCU_Jersey_2021_NUM_Array","label":"TCU (2021)"},{"displayName":"TCU_Jersey_2026_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TCU_Jersey_2026_NUM_Array","label":"TCU (2026)"},{"displayName":"TEM_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TEM_Jersey_2021_NUM_Array","label":"Temple (2021)"},{"displayName":"TEMP_JERSEY_2025_RED","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_1960_BRO_NUM_Array","label":"Temple (2025, Red)"},{"displayName":"TENN_Jersey_2021_02_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TENN_Jersey_2021_02_NUM_Array","label":"Tennessee (2021, 02)"},{"displayName":"TENN_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TENN_Jersey_2021_NUM_Array","label":"Tennessee (2021)"},{"displayName":"TENN_Jersey_2025_Smokey_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TENN_Jersey_2025_Smokey_NUM_Array","label":"Tennessee (2025, Smokey)"},{"displayName":"TENN_Jersey_2026_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TENN_Jersey_2026_NUM_Array","label":"Tennessee (2026)"},{"displayName":"TEX_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TEX_Jersey_2021_NUM_Array","label":"Texas (2021)"},{"displayName":"TEX_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TEX_Jersey_2024_NUM_Array","label":"Texas (2024)"},{"displayName":"TAMU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TAMU_Jersey_2021_NUM_Array","label":"Texas A&M (2021)"},{"displayName":"TAMU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TAMU_Jersey_2024_NUM_Array","label":"Texas A&M (2024)"},{"displayName":"TAMU_JERSEY_2025_THROWBACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedFullBlock3_NUM_Array","label":"Texas A&M (2025, Throwback)"},{"displayName":"TXST_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TXST_Jersey_2021_NUM_Array","label":"Texas State (2021)"},{"displayName":"TXST_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TXST_Jersey_2023_NUM_Array","label":"Texas State (2023)"},{"displayName":"TXST_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TXST_Jersey_2024_NUM_Array","label":"Texas State (2024)"},{"displayName":"TTU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TTU_Jersey_2021_NUM_Array","label":"Texas Tech (2021)"},{"displayName":"TTU_Jersey_2024_Mahomes_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TTU_Jersey_2024_Mahomes_NUM_Array","label":"Texas Tech (2024, Mahomes)"},{"displayName":"TTU_Jersey_2025_Mahomes_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TTU_Jersey_2025_Mahomes_NUM_Array","label":"Texas Tech (2025, Mahomes)"},{"displayName":"TTU_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TTU_Jersey_2025_NUM_Array","label":"Texas Tech (2025)"},{"displayName":"TTU_Jersey_2026_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TTU_Jersey_2026_NUM_Array","label":"Texas Tech (2026)"},{"displayName":"TOL_JERSEY_2023_BLACK","path":"content/characters/player/parts/uniforms/jerseys/numbers/CMU_Jersey_2021_NUM_Array","label":"Toledo (2023, Black)"},{"displayName":"TOL_JERSEY_2023_BLUE","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedMichiganState3_NUM_Array","label":"Toledo (2023, Blue)"},{"displayName":"TOL_Jersey_2023_Shoulders_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TOL_Jersey_2023_Shoulders_NUM_Array","label":"Toledo (2023, Shoulders)"},{"displayName":"TROY_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TROY_Jersey_2021_NUM_Array","label":"Troy (2021)"},{"displayName":"TROY_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TROY_Jersey_2023_NUM_Array","label":"Troy (2023)"},{"displayName":"TULN_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TULN_Jersey_2021_NUM_Array","label":"Tulane (2021)"},{"displayName":"TULN_JERSEY_2023_BLUE","path":"content/characters/player/parts/uniforms/jerseys/numbers/CMU_Jersey_2021_NUM_Array","label":"Tulane (2023, Blue)"},{"displayName":"TULN_Jersey_2025_CITY_EDITION_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TULN_Jersey_2025_CITY_EDITION_NUM_Array","label":"Tulane (2025, CITY Edition)"},{"displayName":"TLSA_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TLSA_Jersey_2021_NUM_Array","label":"Tulsa (2021)"},{"displayName":"UAB_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UAB_Jersey_2021_NUM_Array","label":"UAB (2021)"},{"displayName":"UCF_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCF_Jersey_2023_NUM_Array","label":"UCF (2023)"},{"displayName":"UCF_Jersey_2024_SPACE_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCF_Jersey_2024_SPACE_NUM_Array","label":"UCF (2024, Space)"},{"displayName":"UCF_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCF_Jersey_2024_NUM_Array","label":"UCF (2024)"},{"displayName":"UCF_Jersey_2025_2_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCF_Jersey_2025_2_NUM_Array","label":"UCF (2025, 2)"},{"displayName":"UCF_Jersey_2025_3_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCF_Jersey_2025_3_NUM_Array","label":"UCF (2025, 3)"},{"displayName":"UCF_Jersey_2025_4_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCF_Jersey_2025_4_NUM_Array","label":"UCF (2025, 4)"},{"displayName":"UCF_Jersey_2025_Space_Gray_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCF_Jersey_2025_Space_Gray_NUM_Array","label":"UCF (2025, Space Gray)"},{"displayName":"UCF_Jersey_2025_Space_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCF_Jersey_2025_Space_NUM_Array","label":"UCF (2025, Space)"},{"displayName":"UCF_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCF_Jersey_2025_NUM_Array","label":"UCF (2025)"},{"displayName":"UCLA_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCLA_Jersey_2021_NUM_Array","label":"UCLA (2021)"},{"displayName":"UCLA_Jersey_2023_ALT_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCLA_Jersey_2023_ALT_NUM_Array","label":"UCLA (2023, ALT)"},{"displayName":"CONN_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CONN_Jersey_2021_NUM_Array","label":"UConn (2021)"},{"displayName":"UNLV_JERSEY_2023_RED","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2023_MSU_Stroked_NUM_Array","label":"UNLV (2023, Red)"},{"displayName":"UNLV_Jersey_2023_Sleeves_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UNLV_Jersey_2023_Sleeves_NUM_Array","label":"UNLV (2023, Sleeves)"},{"displayName":"USC_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/USC_Jersey_2021_NUM_Array","label":"USC (2021)"},{"displayName":"USC_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/USC_Jersey_2023_NUM_Array","label":"USC (2023)"},{"displayName":"USC_Jersey_2024_Throwback_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/USC_Jersey_2024_Throwback_NUM_Array","label":"USC (2024, Throwback)"},{"displayName":"USC_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/USC_Jersey_2024_NUM_Array","label":"USC (2024)"},{"displayName":"UTAH_Jersey_2021_02_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UTAH_Jersey_2021_02_NUM_Array","label":"Utah (2021, 02)"},{"displayName":"UTAH_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UTAH_Jersey_2021_NUM_Array","label":"Utah (2021)"},{"displayName":"UTAH_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UTAH_Jersey_2022_NUM_Array","label":"Utah (2022)"},{"displayName":"USU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/USU_Jersey_2021_NUM_Array","label":"Utah State (2021)"},{"displayName":"UTEP_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UTEP_Jersey_2021_NUM_Array","label":"UTEP (2021)"},{"displayName":"UTEP_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UTEP_Jersey_2025_NUM_Array","label":"UTEP (2025)"},{"displayName":"UTEP_JERSEY_2026_BLUE","path":"content/characters/player/parts/uniforms/jerseys/numbers/KU_Jersey_2023_NUM_Array","label":"UTEP (2026, Blue)"},{"displayName":"UTSA_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UTSA_Jersey_2021_NUM_Array","label":"UTSA (2021)"},{"displayName":"UTSA_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UTSA_Jersey_2025_NUM_Array","label":"UTSA (2025)"},{"displayName":"VAN_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/VAN_Jersey_2021_NUM_Array","label":"Vanderbilt (2021)"},{"displayName":"UVA_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UVA_Jersey_2021_NUM_Array","label":"Virginia (2021)"},{"displayName":"VT_Jersey_2019_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/VT_Jersey_2019_NUM_Array","label":"Virginia Tech (2019)"},{"displayName":"VT_Jersey_2020_02_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/VT_Jersey_2020_02_NUM_Array","label":"Virginia Tech (2020, 02)"},{"displayName":"VT_Jersey_2020_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/VT_Jersey_2020_NUM_Array","label":"Virginia Tech (2020)"},{"displayName":"VT_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/VT_Jersey_2021_NUM_Array","label":"Virginia Tech (2021)"},{"displayName":"VT_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/VT_Jersey_2022_NUM_Array","label":"Virginia Tech (2022)"},{"displayName":"VT_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/VT_Jersey_2023_NUM_Array","label":"Virginia Tech (2023)"},{"displayName":"VT_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/VT_Jersey_2024_NUM_Array","label":"Virginia Tech (2024)"},{"displayName":"WAKE_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WAKE_Jersey_2022_NUM_Array","label":"Wake Forest (2022)"},{"displayName":"WASH_JERSEY_2021_THROWBACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_NEB_NUM_Array","label":"Washington (2021, Throwback)"},{"displayName":"WASH_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WASH_Jersey_2021_NUM_Array","label":"Washington (2021)"},{"displayName":"WASH_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WASH_Jersey_2023_NUM_Array","label":"Washington (2023)"},{"displayName":"WASH_Jersey_2024_Sleeves_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WASH_Jersey_2024_Sleeves_NUM_Array","label":"Washington (2024, Sleeves)"},{"displayName":"WASH_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WASH_Jersey_2024_NUM_Array","label":"Washington (2024)"},{"displayName":"WASH_Jersey_2025_Camo_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WASH_Jersey_2025_Camo_NUM_Array","label":"Washington (2025, Camo)"},{"displayName":"WASH_Jersey_2025_WHI_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WASH_Jersey_2025_WHI_NUM_Array","label":"Washington (2025, WHI)"},{"displayName":"WASH_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WASH_Jersey_2025_NUM_Array","label":"Washington (2025)"},{"displayName":"WSU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WSU_Jersey_2023_NUM_Array","label":"Washington State (2023)"},{"displayName":"WSU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WSU_Jersey_2024_NUM_Array","label":"Washington State (2024)"},{"displayName":"WVU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WVU_Jersey_2021_NUM_Array","label":"West Virginia (2021)"},{"displayName":"WVU_JERSEY_2025_THROWBACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_1983_BRO_NUM_Array","label":"West Virginia (2025, Throwback)"},{"displayName":"WKU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WKU_Jersey_2021_NUM_Array","label":"Western Kentucky (2021)"},{"displayName":"WKU_JERSEY_2023_RED","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedAllLeagueShadow_NUM_Array","label":"Western Kentucky (2023, Red)"},{"displayName":"WMU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WMU_Jersey_2021_NUM_Array","label":"Western Michigan (2021)"},{"displayName":"WMU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WMU_Jersey_2024_NUM_Array","label":"Western Michigan (2024)"},{"displayName":"WIS_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WIS_Jersey_2021_NUM_Array","label":"Wisconsin (2021)"},{"displayName":"WIS_Jersey_2025_Throwback_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WIS_Jersey_2025_Throwback_NUM_Array","label":"Wisconsin (2025, Throwback)"},{"displayName":"WYO_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WYO_Jersey_2021_NUM_Array","label":"Wyoming (2021)"}],"helmetDedicated":[{"displayName":"ALA_Helmet_2021_NUM_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/numbers/ALA_Helmet_2021_NUM_Array","label":"Alabama (2021, Helmet)"},{"displayName":"FAU_Helmet_2023_NUM_Array","path":"content/characters/player/parts/uniforms/comp/helmets/numbers/FAU_Helmet_2023_NUM_Array","label":"Florida Atlantic (2023, Helmet)"},{"displayName":"FAU_Helmet_2025_NUM_Array","path":"content/characters/player/parts/uniforms/comp/helmets/numbers/FAU_Helmet_2025_NUM_Array","label":"Florida Atlantic (2025, Helmet)"},{"displayName":"GASO_Helmet_2025_NUM_Array","path":"content/characters/player/parts/uniforms/comp/helmets/numbers/GASO_Helmet_2025_NUM_Array","label":"Georgia Southern (2025, Helmet)"},{"displayName":"MINN_Helmet_2024_NUM_Array","path":"content/characters/player/parts/uniforms/comp/helmets/numbers/MINN_Helmet_2024_NUM_Array","label":"Minnesota (2024, Helmet)"},{"displayName":"NMSU_Helmet_2021_NUM_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/numbers/NMSU_Helmet_2021_NUM_Array","label":"New Mexico State (2021, Helmet)"},{"displayName":"MISS_Helmet_2023_NUM_Array","path":"content/characters/player/parts/uniforms/comp/helmets/numbers/MISS_Helmet_2023_NUM_Array","label":"Ole Miss (2023, Helmet)"},{"displayName":"TEX_Helmet_2023_NUM_Array","path":"content/characters/player/parts/uniforms/comp/helmets/numbers/TEX_Helmet_2023_NUM_Array","label":"Texas (2023, Helmet)"}],"alts":[]},"helmetMaterials":{"shell":[{"displayName":"AFA_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2021_BLUE_preset","label":"Air Force (2021, BLUE)"},{"displayName":"AFA_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2021_WHITE_preset","label":"Air Force (2021, White)"},{"displayName":"AFA_HELMET_2024_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2024_BLACK_preset","label":"Air Force (2024, Black)"},{"displayName":"AFA_HELMET_2025_ALT_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2025_ALT_preset","label":"Air Force (2025, ALT)"},{"displayName":"AKR_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AKR_HELMET_2021_GOLD_preset","label":"Akron (2021, GOLD)"},{"displayName":"AKR_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AKR_HELMET_2021_WHITE_preset","label":"Akron (2021, White)"},{"displayName":"ALA_HELMET_2021_CRIMSON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ALA_HELMET_2021_CRIMSON_preset","label":"Alabama (2021, Crimson)"},{"displayName":"APP_HELMET_2016_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2016_BLACK_preset","label":"Appalachian State (2016, Black)"},{"displayName":"APP_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2021_BLACK_preset","label":"Appalachian State (2021, Black)"},{"displayName":"APP_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2021_WHITE_preset","label":"Appalachian State (2021, White)"},{"displayName":"APP_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2021_YELLOW_preset","label":"Appalachian State (2021, Yellow)"},{"displayName":"ARIZ_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARIZ_HELMET_2021_RED_preset","label":"Arizona (2021, RED)"},{"displayName":"ARIZ_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARIZ_HELMET_2021_WHITE_preset","label":"Arizona (2021, White)"},{"displayName":"ASU_HELMET_2014_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2014_YELLOW_preset","label":"Arizona State (2014, Yellow)"},{"displayName":"ASU_HELMET_2021_MAROON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2021_MAROON_preset","label":"Arizona State (2021, Maroon)"},{"displayName":"ASU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2021_WHITE_preset","label":"Arizona State (2021, White)"},{"displayName":"ASU_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2021_YELLOW_preset","label":"Arizona State (2021, Yellow)"},{"displayName":"ASU_HELMET_2022_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2022_YELLOW_preset","label":"Arizona State (2022, Yellow)"},{"displayName":"ARK_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARK_HELMET_2021_RED_preset","label":"Arkansas (2021, RED)"},{"displayName":"ARK_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARK_HELMET_2021_WHITE_preset","label":"Arkansas (2021, White)"},{"displayName":"ARST_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARST_HELMET_2021_WHITE_preset","label":"Arkansas State (2021, White)"},{"displayName":"ARST_HELMET_2023_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARST_HELMET_2023_BLACK_preset","label":"Arkansas State (2023, Black)"},{"displayName":"ARMY_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARMY_HELMET_2021_BLACK_preset","label":"Army (2021, Black)"},{"displayName":"ARMY_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARMY_HELMET_2021_GOLD_preset","label":"Army (2021, GOLD)"},{"displayName":"ARMY_HELMET_2025_AN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARMY_HELMET_2025_AN_preset","label":"Army (2025, AN)"},{"displayName":"AUB_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AUB_HELMET_2021_WHITE_preset","label":"Auburn (2021, White)"},{"displayName":"BYU_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2021_BLUE_preset","label":"BYU (2021, BLUE)"},{"displayName":"BYU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2021_WHITE_preset","label":"BYU (2021, White)"},{"displayName":"BYU_HELMET_2022_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2022_BLACK_preset","label":"BYU (2022, Black)"},{"displayName":"BYU_HELMET_2022_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2022_NAVY_preset","label":"BYU (2022, NAVY)"},{"displayName":"BYU_HELMET_2022_NAVYSATIN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2022_NAVYSATIN_preset","label":"BYU (2022, Navysatin)"},{"displayName":"BYU_HELMET_2022_WHITENAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2022_WHITENAVY_preset","label":"BYU (2022, Whitenavy)"},{"displayName":"BALL_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BALL_HELMET_2021_BLACK_preset","label":"Ball State (2021, Black)"},{"displayName":"BALL_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BALL_HELMET_2021_WHITE_preset","label":"Ball State (2021, White)"},{"displayName":"BAY_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_BLACK_preset","label":"Baylor (2021, Black)"},{"displayName":"BAY_HELMET_2021_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_GREEN_preset","label":"Baylor (2021, Green)"},{"displayName":"BAY_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_WHITE_preset","label":"Baylor (2021, White)"},{"displayName":"BAY_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_YELLOW_preset","label":"Baylor (2021, Yellow)"},{"displayName":"BSU_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_BLUE_preset","label":"Boise State (2021, BLUE)"},{"displayName":"BSU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_BLACK_preset","label":"Boise State (2021, Black)"},{"displayName":"BSU_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_ORANGE_preset","label":"Boise State (2021, Orange)"},{"displayName":"BSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_WHITE_preset","label":"Boise State (2021, White)"},{"displayName":"BSU_HELMET_2025_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2025_BLUE_preset","label":"Boise State (2025, BLUE)"},{"displayName":"BC_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BC_HELMET_2021_GOLD_preset","label":"Boston College (2021, GOLD)"},{"displayName":"BGSU_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BGSU_HELMET_2021_ORANGE_preset","label":"Bowling Green (2021, Orange)"},{"displayName":"BGSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BGSU_HELMET_2021_WHITE_preset","label":"Bowling Green (2021, White)"},{"displayName":"BUFF_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BUFF_HELMET_2021_BLUE_preset","label":"Buffalo (2021, BLUE)"},{"displayName":"BUFF_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BUFF_HELMET_2021_BLACK_preset","label":"Buffalo (2021, Black)"},{"displayName":"BUFF_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BUFF_HELMET_2021_WHITE_preset","label":"Buffalo (2021, White)"},{"displayName":"CAL_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CAL_HELMET_2021_YELLOW_preset","label":"California (2021, Yellow)"},{"displayName":"CAL_HELMET_2022_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CAL_HELMET_2022_YELLOW_preset","label":"California (2022, Yellow)"},{"displayName":"CAL_HELMET_2023_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CAL_HELMET_2023_NAVY_preset","label":"California (2023, NAVY)"},{"displayName":"CMU_HELMET_2021_MAROON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CMU_HELMET_2021_MAROON_preset","label":"Central Michigan (2021, Maroon)"},{"displayName":"CMU_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CMU_HELMET_2021_YELLOW_preset","label":"Central Michigan (2021, Yellow)"},{"displayName":"CHAR_HELMET_2021_CHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_CHROME_preset","label":"Charlotte (2021, Chrome)"},{"displayName":"CHAR_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_GOLD_preset","label":"Charlotte (2021, GOLD)"},{"displayName":"CHAR_HELMET_2021_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_GREEN_preset","label":"Charlotte (2021, Green)"},{"displayName":"CHAR_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_WHITE_preset","label":"Charlotte (2021, White)"},{"displayName":"CHAR_HELMET_2025_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2025_WHITE_preset","label":"Charlotte (2025, White)"},{"displayName":"CIN_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CIN_HELMET_2021_BLACK_preset","label":"Cincinnati (2021, Black)"},{"displayName":"CIN_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CIN_HELMET_2021_RED_preset","label":"Cincinnati (2021, RED)"},{"displayName":"CIN_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CIN_HELMET_2021_WHITE_preset","label":"Cincinnati (2021, White)"},{"displayName":"CLEM_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CLEM_HELMET_2021_ORANGE_preset","label":"Clemson (2021, Orange)"},{"displayName":"CCAR_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CCAR_HELMET_2021_BLACK_preset","label":"Coastal Carolina (2021, Black)"},{"displayName":"CCAR_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CCAR_HELMET_2021_WHITE_preset","label":"Coastal Carolina (2021, White)"},{"displayName":"CCAR_HELMET_2022_TEAL_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CCAR_HELMET_2022_TEAL_preset","label":"Coastal Carolina (2022, TEAL)"},{"displayName":"COLO_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2021_BLACK_preset","label":"Colorado (2021, Black)"},{"displayName":"COLO_HELMET_2021_BLACK2_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2021_BLACK2_preset","label":"Colorado (2021, Black2)"},{"displayName":"COLO_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2021_GOLD_preset","label":"Colorado (2021, GOLD)"},{"displayName":"COLO_HELMET_2023_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2023_WHITE_preset","label":"Colorado (2023, White)"},{"displayName":"CSU_HELMET_2021_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CSU_HELMET_2021_GREEN_preset","label":"Colorado State (2021, Green)"},{"displayName":"CSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CSU_HELMET_2021_WHITE_preset","label":"Colorado State (2021, White)"},{"displayName":"DEL_HELMET_2024_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DEL_HELMET_2024_BLUE_preset","label":"Delaware (2024, BLUE)"},{"displayName":"DUKE_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2021_BLUE_preset","label":"Duke (2021, BLUE)"},{"displayName":"DUKE_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2021_BLACK_preset","label":"Duke (2021, Black)"},{"displayName":"DUKE_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2021_WHITE_preset","label":"Duke (2021, White)"},{"displayName":"ECU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2021_BLACK_preset","label":"East Carolina (2021, Black)"},{"displayName":"ECU_HELMET_2021_PURPLEPURPLE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2021_PURPLEPURPLE_preset","label":"East Carolina (2021, Purplepurple)"},{"displayName":"ECU_HELMET_2021_PURPLEYELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2021_PURPLEYELLOW_preset","label":"East Carolina (2021, Purpleyellow)"},{"displayName":"ECU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2021_WHITE_preset","label":"East Carolina (2021, White)"},{"displayName":"EMU_HELMET_2021_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/EMU_HELMET_2021_GREEN_preset","label":"Eastern Michigan (2021, Green)"},{"displayName":"EMU_HELMET_2021_SILVER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/EMU_HELMET_2021_SILVER_preset","label":"Eastern Michigan (2021, Silver)"},{"displayName":"FLA_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_BLUE_preset","label":"Florida (2021, BLUE)"},{"displayName":"FLA_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_ORANGE_preset","label":"Florida (2021, Orange)"},{"displayName":"FLA_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_WHITE_preset","label":"Florida (2021, White)"},{"displayName":"FLA_HELMET_2023_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2023_BLACK_preset","label":"Florida (2023, Black)"},{"displayName":"FAU_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2021_BLUE_preset","label":"Florida Atlantic (2021, BLUE)"},{"displayName":"FAU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2021_BLACK_preset","label":"Florida Atlantic (2021, Black)"},{"displayName":"FAU_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2021_RED_preset","label":"Florida Atlantic (2021, RED)"},{"displayName":"FAU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2021_WHITE_preset","label":"Florida Atlantic (2021, White)"},{"displayName":"FAU_HELMET_2023_WHITEALT_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2023_WHITEALT_preset","label":"Florida Atlantic (2023, Whitealt)"},{"displayName":"FAU_HELMET_2025_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2025_BLUE_preset","label":"Florida Atlantic (2025, BLUE)"},{"displayName":"FIU_HELMET_2021_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2021_NAVY_preset","label":"Florida International (2021, NAVY)"},{"displayName":"FIU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2021_WHITE_preset","label":"Florida International (2021, White)"},{"displayName":"FIU_HELMET_2024_MIAMI_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2024_MIAMI_preset","label":"Florida International (2024, Miami)"},{"displayName":"FIU_HELMET_2025_ViceCity_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2025_ViceCity_preset","label":"Florida International (2025, Vicecity)"},{"displayName":"FSU_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FSU_HELMET_2021_GOLD_preset","label":"Florida State (2021, GOLD)"},{"displayName":"FSU_HELMET_2023_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FSU_HELMET_2023_WHITE_preset","label":"Florida State (2023, White)"},{"displayName":"FRES_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FRES_HELMET_2021_BLACK_preset","label":"Fresno State (2021, Black)"},{"displayName":"FRES_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FRES_HELMET_2021_RED_preset","label":"Fresno State (2021, RED)"},{"displayName":"FRES_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FRES_HELMET_2021_WHITE_preset","label":"Fresno State (2021, White)"},{"displayName":"UGA_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UGA_HELMET_2021_RED_preset","label":"Georgia (2021, RED)"},{"displayName":"GASO_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GASO_HELMET_2021_BLUE_preset","label":"Georgia Southern (2021, BLUE)"},{"displayName":"GASO_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GASO_HELMET_2021_WHITE_preset","label":"Georgia Southern (2021, White)"},{"displayName":"GASO_HELMET_2025_TACKLINGFORCURE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GASO_HELMET_2025_TACKLINGFORCURE_preset","label":"Georgia Southern (2025, Tacklingforcure)"},{"displayName":"GSU_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GSU_HELMET_2021_BLUE_preset","label":"Georgia State (2021, BLUE)"},{"displayName":"GSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GSU_HELMET_2021_WHITE_preset","label":"Georgia State (2021, White)"},{"displayName":"GT_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GT_HELMET_2021_GOLD_preset","label":"Georgia Tech (2021, GOLD)"},{"displayName":"GT_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GT_HELMET_2021_WHITE_preset","label":"Georgia Tech (2021, White)"},{"displayName":"HAW_HELMET_2021_BLACK_02_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_BLACK_02_preset","label":"Hawaii (2021, Black 02)"},{"displayName":"HAW_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_BLACK_preset","label":"Hawaii (2021, Black)"},{"displayName":"HAW_HELMET_2021_WHITE_02_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_WHITE_02_preset","label":"Hawaii (2021, White 02)"},{"displayName":"HAW_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_WHITE_preset","label":"Hawaii (2021, White)"},{"displayName":"HOU_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HOU_HELMET_2021_RED_preset","label":"Houston (2021, RED)"},{"displayName":"HOU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HOU_HELMET_2021_WHITE_preset","label":"Houston (2021, White)"},{"displayName":"HOU_HELMET_2021_WHITEBLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HOU_HELMET_2021_WHITEBLACK_preset","label":"Houston (2021, Whiteblack)"},{"displayName":"ILL_HELMET_2021_LEATHER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ILL_HELMET_2021_LEATHER_preset","label":"Illinois (2021, Leather)"},{"displayName":"ILL_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ILL_HELMET_2021_ORANGE_preset","label":"Illinois (2021, Orange)"},{"displayName":"IND_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/IND_HELMET_2021_RED_preset","label":"Indiana (2021, RED)"},{"displayName":"IOWA_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/IOWA_HELMET_2021_BLACK_preset","label":"Iowa (2021, Black)"},{"displayName":"ISU_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ISU_HELMET_2021_RED_preset","label":"Iowa State (2021, RED)"},{"displayName":"ISU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ISU_HELMET_2021_WHITE_preset","label":"Iowa State (2021, White)"},{"displayName":"ISU_HELMET_2022_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ISU_HELMET_2022_BLACK_preset","label":"Iowa State (2022, Black)"},{"displayName":"JVST_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JVST_HELMET_2021_RED_preset","label":"Jacksonville State (2021, RED)"},{"displayName":"JVST_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JVST_HELMET_2021_WHITE_preset","label":"Jacksonville State (2021, White)"},{"displayName":"JMU_HELMET_2023_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JMU_HELMET_2023_GOLD_preset","label":"James Madison (2023, GOLD)"},{"displayName":"JMU_HELMET_2023_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JMU_HELMET_2023_WHITE_preset","label":"James Madison (2023, White)"},{"displayName":"KU_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_BLUE_preset","label":"Kansas (2021, BLUE)"},{"displayName":"KU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_BLACK_preset","label":"Kansas (2021, Black)"},{"displayName":"KU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_WHITE_preset","label":"Kansas (2021, White)"},{"displayName":"KU_HELMET_2025_Blue_Alt_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2025_Blue_Alt_preset","label":"Kansas (2025, Blue Alt)"},{"displayName":"KSU_HELMET_2021_SILVER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KSU_HELMET_2021_SILVER_preset","label":"Kansas State (2021, Silver)"},{"displayName":"KSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KSU_HELMET_2021_WHITE_preset","label":"Kansas State (2021, White)"},{"displayName":"KENN_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENN_HELMET_2021_BLACK_preset","label":"Kennesaw State (2021, Black)"},{"displayName":"KENN_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENN_HELMET_2021_YELLOW_preset","label":"Kennesaw State (2021, Yellow)"},{"displayName":"KENT_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2021_BLACK_preset","label":"Kent State (2021, Black)"},{"displayName":"KENT_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2021_GOLD_preset","label":"Kent State (2021, GOLD)"},{"displayName":"KENT_HELMET_2023_Navy_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2023_Navy_preset","label":"Kent State (2023, Navy)"},{"displayName":"UK_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2021_BLUE_preset","label":"Kentucky (2021, BLUE)"},{"displayName":"UK_HELMET_2022_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2022_BLACK_preset","label":"Kentucky (2022, Black)"},{"displayName":"UK_HELMET_2022_CHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2022_CHROME_preset","label":"Kentucky (2022, Chrome)"},{"displayName":"UK_HELMET_2022_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2022_WHITE_preset","label":"Kentucky (2022, White)"},{"displayName":"LSU_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LSU_HELMET_2021_GOLD_preset","label":"LSU (2021, GOLD)"},{"displayName":"LSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LSU_HELMET_2021_WHITE_preset","label":"LSU (2021, White)"},{"displayName":"LIB_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LIB_HELMET_2021_BLUE_preset","label":"Liberty (2021, BLUE)"},{"displayName":"LIB_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LIB_HELMET_2021_RED_preset","label":"Liberty (2021, RED)"},{"displayName":"LIB_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LIB_HELMET_2021_WHITE_preset","label":"Liberty (2021, White)"},{"displayName":"ULL_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULL_HELMET_2021_RED_preset","label":"Louisiana (2021, RED)"},{"displayName":"ULL_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULL_HELMET_2021_WHITE_preset","label":"Louisiana (2021, White)"},{"displayName":"LT_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LT_HELMET_2021_RED_preset","label":"Louisiana Tech (2021, RED)"},{"displayName":"LT_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LT_HELMET_2021_WHITE_preset","label":"Louisiana Tech (2021, White)"},{"displayName":"ULM_HELMET_2016_CAMO_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULM_HELMET_2016_CAMO_preset","label":"Louisiana-Monroe (2016, CAMO)"},{"displayName":"ULM_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULM_HELMET_2021_WHITE_preset","label":"Louisiana-Monroe (2021, White)"},{"displayName":"ULM_HELMET_2025_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULM_HELMET_2025_BLACK_preset","label":"Louisiana-Monroe (2025, Black)"},{"displayName":"LOU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LOU_HELMET_2021_BLACK_preset","label":"Louisville (2021, Black)"},{"displayName":"LOU_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LOU_HELMET_2021_RED_preset","label":"Louisville (2021, RED)"},{"displayName":"LOU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LOU_HELMET_2021_WHITE_preset","label":"Louisville (2021, White)"},{"displayName":"MRSH_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MRSH_HELMET_2021_WHITE_preset","label":"Marshall (2021, White)"},{"displayName":"MRSH_HELMET_2025_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MRSH_HELMET_2025_GREEN_preset","label":"Marshall (2025, Green)"},{"displayName":"UMD_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMD_HELMET_2021_BLACK_preset","label":"Maryland (2021, Black)"},{"displayName":"UMD_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMD_HELMET_2021_RED_preset","label":"Maryland (2021, RED)"},{"displayName":"UMD_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMD_HELMET_2021_WHITE_preset","label":"Maryland (2021, White)"},{"displayName":"MEM_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2021_BLUE_preset","label":"Memphis (2021, BLUE)"},{"displayName":"MEM_HELMET_2021_GRAY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2021_GRAY_preset","label":"Memphis (2021, GRAY)"},{"displayName":"MEM_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2021_WHITE_preset","label":"Memphis (2021, White)"},{"displayName":"MEM_HELMET_2022_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2022_WHITE_preset","label":"Memphis (2022, White)"},{"displayName":"MEM_HELMET_2022_WHITEBLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2022_WHITEBLACK_preset","label":"Memphis (2022, Whiteblack)"},{"displayName":"MIA_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIA_HELMET_2021_WHITE_preset","label":"Miami (FL) (2021, White)"},{"displayName":"MIA_HELMET_2025_CAMO_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIA_HELMET_2025_CAMO_preset","label":"Miami (FL) (2025, CAMO)"},{"displayName":"MIAOH_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIAOH_HELMET_2021_RED_preset","label":"Miami (OH) (2021, RED)"},{"displayName":"MIAOH_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIAOH_HELMET_2021_WHITE_preset","label":"Miami (OH) (2021, White)"},{"displayName":"MICH_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MICH_HELMET_2021_BLUE_preset","label":"Michigan (2021, BLUE)"},{"displayName":"MSU_HELMET_2015_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2015_GREEN_preset","label":"Michigan State (2015, Green)"},{"displayName":"MSU_HELMET_2017_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2017_WHITE_preset","label":"Michigan State (2017, White)"},{"displayName":"MSU_HELMET_2021_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2021_GREEN_preset","label":"Michigan State (2021, Green)"},{"displayName":"MSU_HELMET_2023_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2023_BLACK_preset","label":"Michigan State (2023, Black)"},{"displayName":"MTSU_HELMET_2021_GREY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTSU_HELMET_2021_GREY_preset","label":"Middle Tennessee (2021, GREY)"},{"displayName":"MTSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTSU_HELMET_2021_WHITE_preset","label":"Middle Tennessee (2021, White)"},{"displayName":"MINN_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2021_RED_preset","label":"Minnesota (2021, RED)"},{"displayName":"MINN_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2021_YELLOW_preset","label":"Minnesota (2021, Yellow)"},{"displayName":"MINN_HELMET_2022_CHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2022_CHROME_preset","label":"Minnesota (2022, Chrome)"},{"displayName":"MINN_HELMET_2022_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2022_WHITE_preset","label":"Minnesota (2022, White)"},{"displayName":"MINN_HELMET_2023_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2023_BLACK_preset","label":"Minnesota (2023, Black)"},{"displayName":"MSST_HELMET_2021_MAROON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSST_HELMET_2021_MAROON_preset","label":"Mississippi State (2021, Maroon)"},{"displayName":"MSST_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSST_HELMET_2021_WHITE_preset","label":"Mississippi State (2021, White)"},{"displayName":"MSST_HELMET_2025_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSST_HELMET_2025_BLACK_preset","label":"Mississippi State (2025, Black)"},{"displayName":"MIZZ_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIZZ_HELMET_2021_BLACK_preset","label":"Missouri (2021, Black)"},{"displayName":"MIZZ_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIZZ_HELMET_2021_YELLOW_preset","label":"Missouri (2021, Yellow)"},{"displayName":"MIZZ_HELMET_2023_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIZZ_HELMET_2023_WHITE_preset","label":"Missouri (2023, White)"},{"displayName":"MIST_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIST_HELMET_2021_BLACK_preset","label":"Missouri State (2021, Black)"},{"displayName":"MTDEW_HELMET_2025_Alt_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTDEW_HELMET_2025_Alt_preset","label":"Mountain Dew (non-school / branded) (2025, Alt)"},{"displayName":"MTDEW_HELMET_2025_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTDEW_HELMET_2025_GREEN_preset","label":"Mountain Dew (non-school / branded) (2025, Green)"},{"displayName":"MTDEW_HELMET_2025_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTDEW_HELMET_2025_WHITE_preset","label":"Mountain Dew (non-school / branded) (2025, White)"},{"displayName":"NCST_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NCST_HELMET_2021_BLACK_preset","label":"NC State (2021, Black)"},{"displayName":"NCST_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NCST_HELMET_2021_RED_preset","label":"NC State (2021, RED)"},{"displayName":"NCST_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NCST_HELMET_2021_WHITE_preset","label":"NC State (2021, White)"},{"displayName":"NAVY_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NAVY_HELMET_2021_GOLD_preset","label":"Navy (2021, GOLD)"},{"displayName":"NAVY_HELMET_2021_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NAVY_HELMET_2021_NAVY_preset","label":"Navy (2021, NAVY)"},{"displayName":"NAVY_HELMET_2025_AN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NAVY_HELMET_2025_AN_preset","label":"Navy (2025, AN)"},{"displayName":"NEB_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEB_HELMET_2021_WHITE_preset","label":"Nebraska (2021, White)"},{"displayName":"NEV_HELMET_2021_SILVER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEV_HELMET_2021_SILVER_preset","label":"Nevada (2021, Silver)"},{"displayName":"NEV_Helmet_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEV_Helmet_2021_WHITE_preset","label":"Nevada (2021, White)"},{"displayName":"NEV_HELMET_2023_NAVYBLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEV_HELMET_2023_NAVYBLUE_preset","label":"Nevada (2023, Navyblue)"},{"displayName":"UNM_HELMET_2021_GRAY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_GRAY_preset","label":"New Mexico (2021, GRAY)"},{"displayName":"UNM_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_RED_preset","label":"New Mexico (2021, RED)"},{"displayName":"UNM_HELMET_2021_SILVER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_SILVER_preset","label":"New Mexico (2021, Silver)"},{"displayName":"UNM_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_WHITE_preset","label":"New Mexico (2021, White)"},{"displayName":"UNM_HELMET_2023_SILVER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2023_SILVER_preset","label":"New Mexico (2023, Silver)"},{"displayName":"NMSU_HELMET_2021_CRIMSON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NMSU_HELMET_2021_CRIMSON_preset","label":"New Mexico State (2021, Crimson)"},{"displayName":"NMSU_HELMET_2023_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NMSU_HELMET_2023_WHITE_preset","label":"New Mexico State (2023, White)"},{"displayName":"UNC_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNC_HELMET_2021_BLUE_preset","label":"North Carolina (2021, BLUE)"},{"displayName":"UNC_HELMET_2021_CHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNC_HELMET_2021_CHROME_preset","label":"North Carolina (2021, Chrome)"},{"displayName":"UNC_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNC_HELMET_2021_WHITE_preset","label":"North Carolina (2021, White)"},{"displayName":"UNT_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_BLACK_preset","label":"North Texas (2021, Black)"},{"displayName":"UNT_HELMET_2021_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_GREEN_preset","label":"North Texas (2021, Green)"},{"displayName":"UNT_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_WHITE_preset","label":"North Texas (2021, White)"},{"displayName":"NIU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NIU_HELMET_2021_BLACK_preset","label":"Northern Illinois (2021, Black)"},{"displayName":"NW_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2021_BLACK_preset","label":"Northwestern (2021, Black)"},{"displayName":"NW_HELMET_2021_PURPLE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2021_PURPLE_preset","label":"Northwestern (2021, Purple)"},{"displayName":"NW_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2021_WHITE_preset","label":"Northwestern (2021, White)"},{"displayName":"NW_HELMET_2022_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2022_BLACK_preset","label":"Northwestern (2022, Black)"},{"displayName":"ND_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ND_HELMET_2021_GOLD_preset","label":"Notre Dame (2021, GOLD)"},{"displayName":"OHIO_HELMET_2023_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OHIO_HELMET_2023_GREEN_preset","label":"Ohio (2023, Green)"},{"displayName":"OHIO_HELMET_2023_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OHIO_HELMET_2023_WHITE_preset","label":"Ohio (2023, White)"},{"displayName":"OSU_Helmet_2021_Black_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OSU_Helmet_2021_Black_preset","label":"Ohio State (2021, Black)"},{"displayName":"OSU_Helmet_2021_Grey_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OSU_Helmet_2021_Grey_preset","label":"Ohio State (2021, GREY)"},{"displayName":"OU_Helmet_2021_CRIMSON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_Helmet_2021_CRIMSON_preset","label":"Oklahoma (2021, Crimson)"},{"displayName":"OU_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_RED_preset","label":"Oklahoma (2021, RED)"},{"displayName":"OU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_WHITE_preset","label":"Oklahoma (2021, White)"},{"displayName":"OU_Helmet_2021_WOODCREAM_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_Helmet_2021_WOODCREAM_preset","label":"Oklahoma (2021, Woodcream)"},{"displayName":"OU_HELMET_2021_WOODCRIMSON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_WOODCRIMSON_preset","label":"Oklahoma (2021, Woodcrimson)"},{"displayName":"OKST_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2021_BLACK_preset","label":"Oklahoma State (2021, Black)"},{"displayName":"OKST_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2021_ORANGE_preset","label":"Oklahoma State (2021, Orange)"},{"displayName":"OKST_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2021_WHITE_preset","label":"Oklahoma State (2021, White)"},{"displayName":"ODU_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ODU_HELMET_2021_BLUE_preset","label":"Old Dominion (2021, BLUE)"},{"displayName":"ODU_HELMET_2021_LIGHTBLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ODU_HELMET_2021_LIGHTBLUE_preset","label":"Old Dominion (2021, Lightblue)"},{"displayName":"ODU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ODU_HELMET_2021_WHITE_preset","label":"Old Dominion (2021, White)"},{"displayName":"ODU_HELMET_2024_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ODU_HELMET_2024_WHITE_preset","label":"Old Dominion (2024, White)"},{"displayName":"MISS_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_BLUE_preset","label":"Ole Miss (2021, BLUE)"},{"displayName":"MISS_HELMET_2021_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_NAVY_preset","label":"Ole Miss (2021, NAVY)"},{"displayName":"MISS_HELMET_2021_SPLATTER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_SPLATTER_preset","label":"Ole Miss (2021, Splatter)"},{"displayName":"MISS_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_WHITE_preset","label":"Ole Miss (2021, White)"},{"displayName":"ORE_HELMET_2021_WHITEGREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2021_WHITEGREEN_preset","label":"Oregon (2021, Whitegreen)"},{"displayName":"ORE_HELMET_2021_YELLOWSTEEL_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2021_YELLOWSTEEL_preset","label":"Oregon (2021, Yellowsteel)"},{"displayName":"ORE_HELMET_2023_BLACKCARBON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2023_BLACKCARBON_preset","label":"Oregon (2023, Blackcarbon)"},{"displayName":"ORE_HELMET_2023_CHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2023_CHROME_preset","label":"Oregon (2023, Chrome)"},{"displayName":"ORE_HELMET_2023_EGGSHELL_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2023_EGGSHELL_preset","label":"Oregon (2023, Eggshell)"},{"displayName":"ORE_HELMET_2023_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2023_GREEN_preset","label":"Oregon (2023, Green)"},{"displayName":"ORE_HELMET_2024_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2024_GREEN_preset","label":"Oregon (2024, Green)"},{"displayName":"ORE_HELMET_2024_THROWBACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2024_THROWBACK_preset","label":"Oregon (2024, Throwback)"},{"displayName":"ORST_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORST_HELMET_2021_BLACK_preset","label":"Oregon State (2021, Black)"},{"displayName":"ORST_HELMET_2023_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORST_HELMET_2023_ORANGE_preset","label":"Oregon State (2023, Orange)"},{"displayName":"PSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PSU_HELMET_2021_WHITE_preset","label":"Penn State (2021, White)"},{"displayName":"PSU_HELMET_2022_WHITESTRIPE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PSU_HELMET_2022_WHITESTRIPE_preset","label":"Penn State (2022, Whitestripe)"},{"displayName":"PITT_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PITT_HELMET_2021_YELLOW_preset","label":"Pittsburgh (2021, Yellow)"},{"displayName":"PITT_HELMET_2023_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PITT_HELMET_2023_WHITE_preset","label":"Pittsburgh (2023, White)"},{"displayName":"PUR_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2021_BLACK_preset","label":"Purdue (2021, Black)"},{"displayName":"PUR_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2021_GOLD_preset","label":"Purdue (2021, GOLD)"},{"displayName":"PUR_HELMET_2023_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2023_GOLD_preset","label":"Purdue (2023, GOLD)"},{"displayName":"RICE_HELMET_2021_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RICE_HELMET_2021_NAVY_preset","label":"Rice (2021, NAVY)"},{"displayName":"RICE_HELMET_2021_SILVER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RICE_HELMET_2021_SILVER_preset","label":"Rice (2021, Silver)"},{"displayName":"RUTG_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RUTG_HELMET_2021_RED_preset","label":"Rutgers (2021, RED)"},{"displayName":"SMU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SMU_HELMET_2021_BLACK_preset","label":"SMU (2021, Black)"},{"displayName":"SMU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SMU_HELMET_2021_WHITE_preset","label":"SMU (2021, White)"},{"displayName":"SMU_HELMET_2021_WHITEALT_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SMU_HELMET_2021_WHITEALT_preset","label":"SMU (2021, Whitealt)"},{"displayName":"SHSU_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SHSU_HELMET_2021_ORANGE_preset","label":"Sam Houston State (2021, Orange)"},{"displayName":"SHSU_HELMET_2023_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SHSU_HELMET_2023_ORANGE_preset","label":"Sam Houston State (2023, Orange)"},{"displayName":"SDSU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SDSU_HELMET_2021_BLACK_preset","label":"San Diego State (2021, Black)"},{"displayName":"SJSU_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SJSU_HELMET_2021_BLUE_preset","label":"San Jose State (2021, BLUE)"},{"displayName":"SJSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SJSU_HELMET_2021_WHITE_preset","label":"San Jose State (2021, White)"},{"displayName":"USA_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USA_HELMET_2021_WHITE_preset","label":"South Alabama (2021, White)"},{"displayName":"SC_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SC_HELMET_2021_BLACK_preset","label":"South Carolina (2021, Black)"},{"displayName":"SC_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SC_HELMET_2021_RED_preset","label":"South Carolina (2021, RED)"},{"displayName":"SC_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SC_HELMET_2021_WHITE_preset","label":"South Carolina (2021, White)"},{"displayName":"USF_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USF_HELMET_2021_GOLD_preset","label":"South Florida (2021, GOLD)"},{"displayName":"USF_HELMET_2021_WHITEGREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USF_HELMET_2021_WHITEGREEN_preset","label":"South Florida (2021, Whitegreen)"},{"displayName":"USF_HELMET_2024_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USF_HELMET_2024_BLACK_preset","label":"South Florida (2024, Black)"},{"displayName":"USM_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USM_HELMET_2021_BLACK_preset","label":"Southern Miss (2021, Black)"},{"displayName":"USM_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USM_HELMET_2021_WHITE_preset","label":"Southern Miss (2021, White)"},{"displayName":"STAN_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2021_WHITE_preset","label":"Stanford (2021, White)"},{"displayName":"STAN_HELMET_2021_WHITEBLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2021_WHITEBLACK_preset","label":"Stanford (2021, Whiteblack)"},{"displayName":"STAN_HELMET_2023_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2023_BLACK_preset","label":"Stanford (2023, Black)"},{"displayName":"STAN_HELMET_2023_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2023_RED_preset","label":"Stanford (2023, RED)"},{"displayName":"STAN_HELMET_2023_REDSCRIPT_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2023_REDSCRIPT_preset","label":"Stanford (2023, Redscript)"},{"displayName":"SYR_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SYR_HELMET_2021_ORANGE_preset","label":"Syracuse (2021, Orange)"},{"displayName":"SYR_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SYR_HELMET_2021_WHITE_preset","label":"Syracuse (2021, White)"},{"displayName":"TCU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TCU_HELMET_2021_BLACK_preset","label":"TCU (2021, Black)"},{"displayName":"TCU_HELMET_2021_PURPLE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TCU_HELMET_2021_PURPLE_preset","label":"TCU (2021, Purple)"},{"displayName":"TCU_HELMET_2023_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TCU_HELMET_2023_WHITE_preset","label":"TCU (2023, White)"},{"displayName":"TCU_HELMET_2024_CHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TCU_HELMET_2024_CHROME_preset","label":"TCU (2024, Chrome)"},{"displayName":"TEMP_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2021_RED_preset","label":"Temple (2021, RED) [TEMP]"},{"displayName":"TEM_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEM_HELMET_2021_RED_preset","label":"Temple (2021, RED) [TEM]"},{"displayName":"TEM_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEM_HELMET_2021_WHITE_preset","label":"Temple (2021, White)"},{"displayName":"TEMP_HELMET_2025_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2025_RED_preset","label":"Temple (2025, RED)"},{"displayName":"TEMP_HELMET_2025_WHI_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2025_WHI_preset","label":"Temple (2025, WHI)"},{"displayName":"TENN_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2021_ORANGE_preset","label":"Tennessee (2021, Orange)"},{"displayName":"TENN_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2021_WHITE_preset","label":"Tennessee (2021, White)"},{"displayName":"TENN_HELMET_2022_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2022_BLACK_preset","label":"Tennessee (2022, Black)"},{"displayName":"TENN_HELMET_2024_GRAY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2024_GRAY_preset","label":"Tennessee (2024, GRAY)"},{"displayName":"TENN_HELMET_2025_Smokey_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2025_Smokey_preset","label":"Tennessee (2025, Smokey)"},{"displayName":"TEX_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEX_HELMET_2021_WHITE_preset","label":"Texas (2021, White)"},{"displayName":"TAMU_HELMET_2021_MAROON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TAMU_HELMET_2021_MAROON_preset","label":"Texas A&M (2021, Maroon)"},{"displayName":"TAMU_HELMET_2023_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TAMU_HELMET_2023_BLACK_preset","label":"Texas A&M (2023, Black)"},{"displayName":"TXST_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TXST_HELMET_2021_GOLD_preset","label":"Texas State (2021, GOLD)"},{"displayName":"TXST_HELMET_2021_MAROON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TXST_HELMET_2021_MAROON_preset","label":"Texas State (2021, Maroon)"},{"displayName":"TXST_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TXST_HELMET_2021_WHITE_preset","label":"Texas State (2021, White)"},{"displayName":"TTU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2021_BLACK_preset","label":"Texas Tech (2021, Black)"},{"displayName":"TTU_HELMET_2021_GRAY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2021_GRAY_preset","label":"Texas Tech (2021, GRAY)"},{"displayName":"TTU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2021_WHITE_preset","label":"Texas Tech (2021, White)"},{"displayName":"TTU_HELMET_2025_WHIMAHOMES_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2025_WHIMAHOMES_preset","label":"Texas Tech (2025, Whimahomes)"},{"displayName":"TOL_HELMET_2021_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TOL_HELMET_2021_NAVY_preset","label":"Toledo (2021, NAVY)"},{"displayName":"TOL_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TOL_HELMET_2021_YELLOW_preset","label":"Toledo (2021, Yellow)"},{"displayName":"TOL_HELMET_2025_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TOL_HELMET_2025_WHITE_preset","label":"Toledo (2025, White)"},{"displayName":"TROY_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TROY_HELMET_2021_RED_preset","label":"Troy (2021, RED)"},{"displayName":"TROY_HELMET_2021_SILVER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TROY_HELMET_2021_SILVER_preset","label":"Troy (2021, Silver)"},{"displayName":"TROY_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TROY_HELMET_2021_WHITE_preset","label":"Troy (2021, White)"},{"displayName":"TULN_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2021_BLUE_preset","label":"Tulane (2021, BLUE)"},{"displayName":"TULN_HELMET_2021_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2021_GREEN_preset","label":"Tulane (2021, Green)"},{"displayName":"TULN_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2021_WHITE_preset","label":"Tulane (2021, White)"},{"displayName":"TULN_HELMET_2025_CITY_EDITION_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2025_CITY_EDITION_preset","label":"Tulane (2025, CITY Edition)"},{"displayName":"TULN_HELMET_2025_Wumbu_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2025_Wumbu_preset","label":"Tulane (2025, Wumbu)"},{"displayName":"TLSA_HELMET_2023_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TLSA_HELMET_2023_GOLD_preset","label":"Tulsa (2023, GOLD)"},{"displayName":"TLSA_HELMET_2023_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TLSA_HELMET_2023_WHITE_preset","label":"Tulsa (2023, White)"},{"displayName":"UAB_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UAB_HELMET_2021_GOLD_preset","label":"UAB (2021, GOLD)"},{"displayName":"UAB_HELMET_2021_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UAB_HELMET_2021_GREEN_preset","label":"UAB (2021, Green)"},{"displayName":"UAB_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UAB_HELMET_2021_WHITE_preset","label":"UAB (2021, White)"},{"displayName":"UAB_HELMET_2021_WHITELIMEGREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UAB_HELMET_2021_WHITELIMEGREEN_preset","label":"UAB (2021, Whitelimegreen)"},{"displayName":"UCF_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2021_GOLD_preset","label":"UCF (2021, GOLD)"},{"displayName":"UCF_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2021_WHITE_preset","label":"UCF (2021, White)"},{"displayName":"UCF_HELMET_2023_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2023_BLACK_preset","label":"UCF (2023, Black)"},{"displayName":"UCF_HELMET_2023_SPACE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2023_SPACE_preset","label":"UCF (2023, Space)"},{"displayName":"UCF_HELMET_2024_SPACE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2024_SPACE_preset","label":"UCF (2024, Space)"},{"displayName":"UCF_HELMET_2025_SPACE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2025_SPACE_preset","label":"UCF (2025, Space)"},{"displayName":"UCLA_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCLA_HELMET_2021_GOLD_preset","label":"UCLA (2021, GOLD)"},{"displayName":"UCLA_HELMET_2023_GOLDALT_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCLA_HELMET_2023_GOLDALT_preset","label":"UCLA (2023, Goldalt)"},{"displayName":"CONN_HELMET_2021_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CONN_HELMET_2021_NAVY_preset","label":"UConn (2021, NAVY)"},{"displayName":"CONN_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CONN_HELMET_2021_WHITE_preset","label":"UConn (2021, White)"},{"displayName":"CONN_HELMET_2025_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CONN_HELMET_2025_NAVY_preset","label":"UConn (2025, NAVY)"},{"displayName":"UMASS_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMASS_HELMET_2021_RED_preset","label":"UMass (2021, RED)"},{"displayName":"UMASS_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMASS_HELMET_2021_WHITE_preset","label":"UMass (2021, White)"},{"displayName":"UNLV_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2021_BLACK_preset","label":"UNLV (2021, Black)"},{"displayName":"UNLV_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2021_RED_preset","label":"UNLV (2021, RED)"},{"displayName":"UNLV_HELMET_2021_SILVER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2021_SILVER_preset","label":"UNLV (2021, Silver)"},{"displayName":"UNLV_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2021_WHITE_preset","label":"UNLV (2021, White)"},{"displayName":"USC_HELMET_2021_CARDINAL_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USC_HELMET_2021_CARDINAL_preset","label":"USC (2021, Cardinal)"},{"displayName":"USC_HELMET_2021_CARDINALCHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USC_HELMET_2021_CARDINALCHROME_preset","label":"USC (2021, Cardinalchrome)"},{"displayName":"UTEP_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTEP_HELMET_2021_ORANGE_preset","label":"UTEP (2021, Orange)"},{"displayName":"UTEP_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTEP_HELMET_2021_WHITE_preset","label":"UTEP (2021, White)"},{"displayName":"UTEP_HELMET_2025_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTEP_HELMET_2025_BLUE_preset","label":"UTEP (2025, BLUE)"},{"displayName":"UTSA_HELMET_2021_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTSA_HELMET_2021_NAVY_preset","label":"UTSA (2021, NAVY)"},{"displayName":"UTSA_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTSA_HELMET_2021_WHITE_preset","label":"UTSA (2021, White)"},{"displayName":"UTAH_HELMET_2020_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2020_WHITE_preset","label":"Utah (2020, White)"},{"displayName":"UTAH_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2021_RED_preset","label":"Utah (2021, RED)"},{"displayName":"UTAH_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2021_WHITE_preset","label":"Utah (2021, White)"},{"displayName":"UTAH_HELMET_2023_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2023_BLACK_preset","label":"Utah (2023, Black)"},{"displayName":"UTAH_HELMET_2025_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2025_RED_preset","label":"Utah (2025, RED)"},{"displayName":"USU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USU_HELMET_2021_BLACK_preset","label":"Utah State (2021, Black)"},{"displayName":"USU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USU_HELMET_2021_WHITE_preset","label":"Utah State (2021, White)"},{"displayName":"VAN_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VAN_HELMET_2021_GOLD_preset","label":"Vanderbilt (2021, GOLD)"},{"displayName":"VAN_HELMET_2022_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VAN_HELMET_2022_BLACK_preset","label":"Vanderbilt (2022, Black)"},{"displayName":"VAN_HELMET_2022_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VAN_HELMET_2022_WHITE_preset","label":"Vanderbilt (2022, White)"},{"displayName":"UVA_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UVA_HELMET_2021_BLUE_preset","label":"Virginia (2021, BLUE)"},{"displayName":"UVA_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UVA_HELMET_2021_WHITE_preset","label":"Virginia (2021, White)"},{"displayName":"VT_HELMET_2016_MAROON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2016_MAROON_preset","label":"Virginia Tech (2016, Maroon)"},{"displayName":"VT_HELMET_2016_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2016_WHITE_preset","label":"Virginia Tech (2016, White)"},{"displayName":"VT_HELMET_2021_MAROON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2021_MAROON_preset","label":"Virginia Tech (2021, Maroon)"},{"displayName":"VT_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2021_WHITE_preset","label":"Virginia Tech (2021, White)"},{"displayName":"WAKE_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WAKE_HELMET_2021_BLACK_preset","label":"Wake Forest (2021, Black)"},{"displayName":"WAKE_HELMET_2022_CHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WAKE_HELMET_2022_CHROME_preset","label":"Wake Forest (2022, Chrome)"},{"displayName":"WASH_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2021_GOLD_preset","label":"Washington (2021, GOLD)"},{"displayName":"WASH_HELMET_2021_GOLDCHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2021_GOLDCHROME_preset","label":"Washington (2021, Goldchrome)"},{"displayName":"WASH_HELMET_2023_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2023_BLACK_preset","label":"Washington (2023, Black)"},{"displayName":"WASH_HELMET_2023_PURPLECHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2023_PURPLECHROME_preset","label":"Washington (2023, Purplechrome)"},{"displayName":"WSU_HELMET_2021_DARKGRAY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WSU_HELMET_2021_DARKGRAY_preset","label":"Washington State (2021, Darkgray)"},{"displayName":"WSU_HELMET_2021_GRAY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WSU_HELMET_2021_GRAY_preset","label":"Washington State (2021, GRAY)"},{"displayName":"WSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WSU_HELMET_2021_WHITE_preset","label":"Washington State (2021, White)"},{"displayName":"WSU_HELMET_2022_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WSU_HELMET_2022_RED_preset","label":"Washington State (2022, RED)"},{"displayName":"WVU_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2021_BLUE_preset","label":"West Virginia (2021, BLUE)"},{"displayName":"WVU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2021_BLACK_preset","label":"West Virginia (2021, Black)"},{"displayName":"WVU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2021_WHITE_preset","label":"West Virginia (2021, White)"},{"displayName":"WVU_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2021_YELLOW_preset","label":"West Virginia (2021, Yellow)"},{"displayName":"WVU_HELMET_2025_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2025_BLUE_preset","label":"West Virginia (2025, BLUE)"},{"displayName":"WKU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2021_BLACK_preset","label":"Western Kentucky (2021, Black)"},{"displayName":"WKU_HELMET_2021_CHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2021_CHROME_preset","label":"Western Kentucky (2021, Chrome)"},{"displayName":"WKU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2021_WHITE_preset","label":"Western Kentucky (2021, White)"},{"displayName":"WMU_HELMET_2021_BROWN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WMU_HELMET_2021_BROWN_preset","label":"Western Michigan (2021, Brown)"},{"displayName":"WMU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WMU_HELMET_2021_WHITE_preset","label":"Western Michigan (2021, White)"},{"displayName":"WIS_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WIS_HELMET_2021_WHITE_preset","label":"Wisconsin (2021, White)"},{"displayName":"WYO_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WYO_HELMET_2021_WHITE_preset","label":"Wyoming (2021, White)"}],"facemask":[{"displayName":"AFA_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2021_BLUE_Facemask_preset","label":"Air Force (2021, BLUE)"},{"displayName":"AFA_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2021_WHITE_Facemask_preset","label":"Air Force (2021, White)"},{"displayName":"AFA_HELMET_2023_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2023_BLUE_Facemask_preset","label":"Air Force (2023, BLUE)"},{"displayName":"AFA_HELMET_2024_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2024_BLUE_Facemask_preset","label":"Air Force (2024, BLUE)"},{"displayName":"AFA_HELMET_2024_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2024_BLACK_Facemask_preset","label":"Air Force (2024, Black)"},{"displayName":"AFA_HELMET_2025_ALT_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2025_ALT_Facemask_preset","label":"Air Force (2025, ALT)"},{"displayName":"AKR_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AKR_HELMET_2021_GOLD_Facemask_preset","label":"Akron (2021, GOLD)"},{"displayName":"AKR_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AKR_HELMET_2021_WHITE_Facemask_preset","label":"Akron (2021, White)"},{"displayName":"ALA_HELMET_2021_CRIMSON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ALA_HELMET_2021_CRIMSON_Facemask_preset","label":"Alabama (2021, Crimson)"},{"displayName":"APP_HELMET_2016_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2016_BLACK_Facemask_preset","label":"Appalachian State (2016, Black)"},{"displayName":"APP_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2021_BLACK_Facemask_preset","label":"Appalachian State (2021, Black)"},{"displayName":"APP_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2021_WHITE_Facemask_preset","label":"Appalachian State (2021, White)"},{"displayName":"APP_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2021_YELLOW_Facemask_preset","label":"Appalachian State (2021, Yellow)"},{"displayName":"ARIZ_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARIZ_HELMET_2021_NAVY_Facemask_preset","label":"Arizona (2021, NAVY)"},{"displayName":"ARIZ_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARIZ_HELMET_2021_RED_Facemask_preset","label":"Arizona (2021, RED)"},{"displayName":"ARIZ_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARIZ_HELMET_2021_WHITE_Facemask_preset","label":"Arizona (2021, White)"},{"displayName":"ASU_HELMET_2014_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2014_YELLOW_Facemask_preset","label":"Arizona State (2014, Yellow)"},{"displayName":"ASU_HELMET_2021_MAROON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2021_MAROON_Facemask_preset","label":"Arizona State (2021, Maroon)"},{"displayName":"ASU_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2021_YELLOW_Facemask_preset","label":"Arizona State (2021, Yellow)"},{"displayName":"ASU_HELMET_2022_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2022_YELLOW_Facemask_preset","label":"Arizona State (2022, Yellow)"},{"displayName":"ASU_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2023_BLACK_Facemask_preset","label":"Arizona State (2023, Black)"},{"displayName":"ASU_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2023_WHITE_Facemask_preset","label":"Arizona State (2023, White)"},{"displayName":"ARK_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARK_HELMET_2021_RED_Facemask_preset","label":"Arkansas (2021, RED)"},{"displayName":"ARK_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARK_HELMET_2021_WHITE_Facemask_preset","label":"Arkansas (2021, White)"},{"displayName":"ARST_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARST_HELMET_2021_WHITE_Facemask_preset","label":"Arkansas State (2021, White)"},{"displayName":"ARST_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARST_HELMET_2023_BLACK_Facemask_preset","label":"Arkansas State (2023, Black)"},{"displayName":"ARMY_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARMY_HELMET_2021_GOLD_Facemask_preset","label":"Army (2021, GOLD)"},{"displayName":"ARMY_HELMET_2025_AN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARMY_HELMET_2025_AN_Facemask_preset","label":"Army (2025, AN)"},{"displayName":"AUB_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AUB_HELMET_2021_NAVY_Facemask_preset","label":"Auburn (2021, NAVY)"},{"displayName":"AUB_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AUB_HELMET_2021_ORANGE_Facemask_preset","label":"Auburn (2021, Orange)"},{"displayName":"AUB_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AUB_HELMET_2021_WHITE_Facemask_preset","label":"Auburn (2021, White)"},{"displayName":"BYU_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2021_BLUE_Facemask_preset","label":"BYU (2021, BLUE)"},{"displayName":"BYU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2021_WHITE_Facemask_preset","label":"BYU (2021, White)"},{"displayName":"BYU_HELMET_2022_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2022_BLACK_Facemask_preset","label":"BYU (2022, Black)"},{"displayName":"BYU_HELMET_2022_WHITENAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2022_WHITENAVY_Facemask_preset","label":"BYU (2022, Whitenavy)"},{"displayName":"BYU_HELMET_2023_CHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2023_CHROME_Facemask_preset","label":"BYU (2023, Chrome)"},{"displayName":"BYU_HELMET_2023_THROWBACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2023_THROWBACK_Facemask_preset","label":"BYU (2023, Throwback)"},{"displayName":"BYU_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2023_WHITE_Facemask_preset","label":"BYU (2023, White)"},{"displayName":"BALL_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BALL_HELMET_2021_BLACK_Facemask_preset","label":"Ball State (2021, Black)"},{"displayName":"BALL_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BALL_HELMET_2021_WHITE_Facemask_preset","label":"Ball State (2021, White)"},{"displayName":"BAY_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_BLACK_Facemask_preset","label":"Baylor (2021, Black)"},{"displayName":"BAY_HELMET_2021_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_GREEN_Facemask_preset","label":"Baylor (2021, Green)"},{"displayName":"BAY_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_WHITE_Facemask_preset","label":"Baylor (2021, White)"},{"displayName":"BAY_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_YELLOW_Facemask_preset","label":"Baylor (2021, Yellow)"},{"displayName":"BAY_HELMET_2025_CHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2025_CHROME_Facemask_preset","label":"Baylor (2025, Chrome)"},{"displayName":"BSU_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_BLUE_Facemask_preset","label":"Boise State (2021, BLUE)"},{"displayName":"BSU_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_ORANGE_Facemask_preset","label":"Boise State (2021, Orange)"},{"displayName":"BSU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_WHITE_Facemask_preset","label":"Boise State (2021, White)"},{"displayName":"BSU_HELMET_2023_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2023_ORANGE_Facemask_preset","label":"Boise State (2023, Orange)"},{"displayName":"BC_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BC_HELMET_2021_GOLD_Facemask_preset","label":"Boston College (2021, GOLD)"},{"displayName":"BGSU_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BGSU_HELMET_2021_ORANGE_Facemask_preset","label":"Bowling Green (2021, Orange)"},{"displayName":"BGSU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BGSU_HELMET_2021_WHITE_Facemask_preset","label":"Bowling Green (2021, White)"},{"displayName":"BUFF_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BUFF_HELMET_2021_BLUE_Facemask_preset","label":"Buffalo (2021, BLUE)"},{"displayName":"BUFF_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BUFF_HELMET_2021_BLACK_Facemask_preset","label":"Buffalo (2021, Black)"},{"displayName":"BUFF_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BUFF_HELMET_2021_WHITE_Facemask_preset","label":"Buffalo (2021, White)"},{"displayName":"BUFF_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BUFF_HELMET_2023_BLACK_Facemask_preset","label":"Buffalo (2023, Black)"},{"displayName":"CAL_HELMET_2022_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CAL_HELMET_2022_YELLOW_Facemask_preset","label":"California (2022, Yellow)"},{"displayName":"CAL_HELMET_2023_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CAL_HELMET_2023_NAVY_Facemask_preset","label":"California (2023, NAVY)"},{"displayName":"CMU_HELMET_2021_MAROON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CMU_HELMET_2021_MAROON_Facemask_preset","label":"Central Michigan (2021, Maroon)"},{"displayName":"CMU_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CMU_HELMET_2021_YELLOW_Facemask_preset","label":"Central Michigan (2021, Yellow)"},{"displayName":"CHAR_HELMET_2021_CHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_CHROME_Facemask_preset","label":"Charlotte (2021, Chrome)"},{"displayName":"CHAR_HELMET_2021_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_GREEN_Facemask_preset","label":"Charlotte (2021, Green)"},{"displayName":"CHAR_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_WHITE_Facemask_preset","label":"Charlotte (2021, White)"},{"displayName":"CHAR_HELMET_2025_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2025_WHITE_Facemask_preset","label":"Charlotte (2025, White)"},{"displayName":"CIN_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CIN_HELMET_2021_BLACK_Facemask_preset","label":"Cincinnati (2021, Black)"},{"displayName":"CIN_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CIN_HELMET_2021_RED_Facemask_preset","label":"Cincinnati (2021, RED)"},{"displayName":"CIN_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CIN_HELMET_2021_WHITE_Facemask_preset","label":"Cincinnati (2021, White)"},{"displayName":"CLEM_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CLEM_HELMET_2021_ORANGE_Facemask_preset","label":"Clemson (2021, Orange)"},{"displayName":"CCAR_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CCAR_HELMET_2021_BLACK_Facemask_preset","label":"Coastal Carolina (2021, Black)"},{"displayName":"CCAR_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CCAR_HELMET_2021_WHITE_Facemask_preset","label":"Coastal Carolina (2021, White)"},{"displayName":"COLO_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2021_BLACK_Facemask_preset","label":"Colorado (2021, Black)"},{"displayName":"COLO_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2021_GOLD_Facemask_preset","label":"Colorado (2021, GOLD)"},{"displayName":"COLO_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2021_WHITE_Facemask_preset","label":"Colorado (2021, White)"},{"displayName":"COLO_HELMET_2023_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2023_GOLD_Facemask_preset","label":"Colorado (2023, GOLD)"},{"displayName":"CSU_HELMET_2021_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CSU_HELMET_2021_GREEN_Facemask_preset","label":"Colorado State (2021, Green)"},{"displayName":"CSU_HELMET_2021_PRIDE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CSU_HELMET_2021_PRIDE_Facemask_preset","label":"Colorado State (2021, Pride)"},{"displayName":"CSU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CSU_HELMET_2021_WHITE_Facemask_preset","label":"Colorado State (2021, White)"},{"displayName":"DEL_HELMET_2024_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DEL_HELMET_2024_BLUE_Facemask_preset","label":"Delaware (2024, BLUE)"},{"displayName":"DUKE_HELMET_2019_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2019_BLUE_Facemask_preset","label":"Duke (2019, BLUE)"},{"displayName":"DUKE_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2021_BLUE_Facemask_preset","label":"Duke (2021, BLUE)"},{"displayName":"DUKE_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2021_BLACK_Facemask_preset","label":"Duke (2021, Black)"},{"displayName":"DUKE_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2021_WHITE_Facemask_preset","label":"Duke (2021, White)"},{"displayName":"Duke_HELMET_2022_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/Duke_HELMET_2022_BLUE_Facemask_preset","label":"Duke (2022, BLUE)"},{"displayName":"ECU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2021_BLACK_Facemask_preset","label":"East Carolina (2021, Black)"},{"displayName":"ECU_HELMET_2021_PURPLEPURPLE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2021_PURPLEPURPLE_Facemask_preset","label":"East Carolina (2021, Purplepurple)"},{"displayName":"ECU_HELMET_2021_PURPLEYELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2021_PURPLEYELLOW_Facemask_preset","label":"East Carolina (2021, Purpleyellow)"},{"displayName":"ECU_HELMET_2025_PURPLE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2025_PURPLE_Facemask_preset","label":"East Carolina (2025, Purple)"},{"displayName":"EMU_HELMET_2021_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/EMU_HELMET_2021_GREEN_Facemask_preset","label":"Eastern Michigan (2021, Green)"},{"displayName":"EMU_HELMET_2021_SILVER_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/EMU_HELMET_2021_SILVER_Facemask_preset","label":"Eastern Michigan (2021, Silver)"},{"displayName":"FCSE_HELMET_2023_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FCSE_HELMET_2023_BLUE_Facemask_preset","label":"FCS East (generic) (2023, BLUE)"},{"displayName":"FCSMW_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FCSMW_HELMET_2023_BLACK_Facemask_preset","label":"FCS Midwest (generic) (2023, Black)"},{"displayName":"FCSSE_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FCSSE_HELMET_2023_BLACK_Facemask_preset","label":"FCS Southeast (generic) (2023, Black)"},{"displayName":"FCSW_HELMET_2023_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FCSW_HELMET_2023_GOLD_Facemask_preset","label":"FCS West (generic) (2023, GOLD)"},{"displayName":"FLA_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_BLUE_Facemask_preset","label":"Florida (2021, BLUE)"},{"displayName":"FLA_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_ORANGE_Facemask_preset","label":"Florida (2021, Orange)"},{"displayName":"FLA_HELMET_2021_THROWBACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_THROWBACK_Facemask_preset","label":"Florida (2021, Throwback)"},{"displayName":"FLA_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_WHITE_Facemask_preset","label":"Florida (2021, White)"},{"displayName":"FLA_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2023_BLACK_Facemask_preset","label":"Florida (2023, Black)"},{"displayName":"FAU_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2021_BLUE_Facemask_preset","label":"Florida Atlantic (2021, BLUE)"},{"displayName":"FAU_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2021_RED_Facemask_preset","label":"Florida Atlantic (2021, RED)"},{"displayName":"FAU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2021_WHITE_Facemask_preset","label":"Florida Atlantic (2021, White)"},{"displayName":"FAU_HELMET_2023_WHITEALT_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2023_WHITEALT_Facemask_preset","label":"Florida Atlantic (2023, Whitealt)"},{"displayName":"FIU_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2021_NAVY_Facemask_preset","label":"Florida International (2021, NAVY)"},{"displayName":"FIU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2021_WHITE_Facemask_preset","label":"Florida International (2021, White)"},{"displayName":"FIU_HELMET_2025_ViceCity_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2025_ViceCity_Facemask_preset","label":"Florida International (2025, Vicecity)"},{"displayName":"FSU_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FSU_HELMET_2021_GOLD_Facemask_preset","label":"Florida State (2021, GOLD)"},{"displayName":"FSU_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FSU_HELMET_2023_WHITE_Facemask_preset","label":"Florida State (2023, White)"},{"displayName":"FRES_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FRES_HELMET_2021_BLACK_Facemask_preset","label":"Fresno State (2021, Black)"},{"displayName":"FRES_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FRES_HELMET_2021_RED_Facemask_preset","label":"Fresno State (2021, RED)"},{"displayName":"FRES_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FRES_HELMET_2021_WHITE_Facemask_preset","label":"Fresno State (2021, White)"},{"displayName":"UGA_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UGA_HELMET_2021_RED_Facemask_preset","label":"Georgia (2021, RED)"},{"displayName":"GASO_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GASO_HELMET_2021_BLUE_Facemask_preset","label":"Georgia Southern (2021, BLUE)"},{"displayName":"GSU_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GSU_HELMET_2021_BLUE_Facemask_preset","label":"Georgia State (2021, BLUE)"},{"displayName":"GSU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GSU_HELMET_2021_BLACK_Facemask_preset","label":"Georgia State (2021, Black)"},{"displayName":"GSU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GSU_HELMET_2021_WHITE_Facemask_preset","label":"Georgia State (2021, White)"},{"displayName":"GT_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GT_HELMET_2021_GOLD_Facemask_preset","label":"Georgia Tech (2021, GOLD)"},{"displayName":"GT_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GT_HELMET_2021_WHITE_Facemask_preset","label":"Georgia Tech (2021, White)"},{"displayName":"GT_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GT_HELMET_2023_BLACK_Facemask_preset","label":"Georgia Tech (2023, Black)"},{"displayName":"GT_HELMET_2023_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GT_HELMET_2023_GOLD_Facemask_preset","label":"Georgia Tech (2023, GOLD)"},{"displayName":"GT_HELMET_2025_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GT_HELMET_2025_GOLD_Facemask_preset","label":"Georgia Tech (2025, GOLD)"},{"displayName":"HAW_HELMET_2021_BLACK_02_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_BLACK_02_Facemask_preset","label":"Hawaii (2021, Black 02)"},{"displayName":"HAW_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_BLACK_Facemask_preset","label":"Hawaii (2021, Black)"},{"displayName":"HAW_HELMET_2021_WHITE_02_Facemask","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_WHITE_02_Facemask","label":"Hawaii (2021, White 02)"},{"displayName":"HAW_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_WHITE_Facemask_preset","label":"Hawaii (2021, White)"},{"displayName":"HOU_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HOU_HELMET_2021_RED_Facemask_preset","label":"Houston (2021, RED)"},{"displayName":"HOU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HOU_HELMET_2021_WHITE_Facemask_preset","label":"Houston (2021, White)"},{"displayName":"HOU_HELMET_2021_WHITEBLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HOU_HELMET_2021_WHITEBLACK_Facemask_preset","label":"Houston (2021, Whiteblack)"},{"displayName":"ILL_HELMET_2021_GRAY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ILL_HELMET_2021_GRAY_Facemask_preset","label":"Illinois (2021, GRAY)"},{"displayName":"ILL_HELMET_2021_LEATHER_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ILL_HELMET_2021_LEATHER_Facemask_preset","label":"Illinois (2021, Leather)"},{"displayName":"ILL_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ILL_HELMET_2021_ORANGE_Facemask_preset","label":"Illinois (2021, Orange)"},{"displayName":"ILL_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ILL_HELMET_2021_WHITE_Facemask_preset","label":"Illinois (2021, White)"},{"displayName":"IND_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/IND_HELMET_2021_RED_Facemask_preset","label":"Indiana (2021, RED)"},{"displayName":"IOWA_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/IOWA_HELMET_2021_BLACK_Facemask_preset","label":"Iowa (2021, Black)"},{"displayName":"ISU_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ISU_HELMET_2021_RED_Facemask_preset","label":"Iowa State (2021, RED)"},{"displayName":"ISU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ISU_HELMET_2021_WHITE_Facemask_preset","label":"Iowa State (2021, White)"},{"displayName":"ISU_HELMET_2022_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ISU_HELMET_2022_BLACK_Facemask_preset","label":"Iowa State (2022, Black)"},{"displayName":"ISU_HELMET_2024_THROWBACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ISU_HELMET_2024_THROWBACK_Facemask_preset","label":"Iowa State (2024, Throwback)"},{"displayName":"JVST_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JVST_HELMET_2021_RED_Facemask_preset","label":"Jacksonville State (2021, RED)"},{"displayName":"JVST_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JVST_HELMET_2021_WHITE_Facemask_preset","label":"Jacksonville State (2021, White)"},{"displayName":"JMU_HELMET_2023_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JMU_HELMET_2023_GOLD_Facemask_preset","label":"James Madison (2023, GOLD)"},{"displayName":"JMU_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JMU_HELMET_2023_WHITE_Facemask_preset","label":"James Madison (2023, White)"},{"displayName":"KU_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_BLUE_Facemask_preset","label":"Kansas (2021, BLUE)"},{"displayName":"KU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_BLACK_Facemask_preset","label":"Kansas (2021, Black)"},{"displayName":"KU_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_RED_Facemask_preset","label":"Kansas (2021, RED)"},{"displayName":"KU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_WHITE_Facemask_preset","label":"Kansas (2021, White)"},{"displayName":"KU_HELMET_2025_Blue_Alt_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2025_Blue_Alt_Facemask_preset","label":"Kansas (2025, Blue Alt)"},{"displayName":"KSU_HELMET_2021_SILVER_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KSU_HELMET_2021_SILVER_Facemask_preset","label":"Kansas State (2021, Silver)"},{"displayName":"KENN_HELMET_2021_CHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENN_HELMET_2021_CHROME_Facemask_preset","label":"Kennesaw State (2021, Chrome)"},{"displayName":"KENN_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENN_HELMET_2021_YELLOW_Facemask_preset","label":"Kennesaw State (2021, Yellow)"},{"displayName":"KENT_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2021_BLACK_Facemask_preset","label":"Kent State (2021, Black)"},{"displayName":"KENT_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2021_GOLD_Facemask_preset","label":"Kent State (2021, GOLD)"},{"displayName":"KENT_HELMET_2023_Navy_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2023_Navy_Facemask_preset","label":"Kent State (2023, Navy)"},{"displayName":"KENT_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2023_WHITE_Facemask_preset","label":"Kent State (2023, White)"},{"displayName":"UK_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2021_BLUE_Facemask_preset","label":"Kentucky (2021, BLUE)"},{"displayName":"UK_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2021_WHITE_Facemask_preset","label":"Kentucky (2021, White)"},{"displayName":"UK_HELMET_2022_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2022_BLACK_Facemask_preset","label":"Kentucky (2022, Black)"},{"displayName":"UK_HELMET_2022_CHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2022_CHROME_Facemask_preset","label":"Kentucky (2022, Chrome)"},{"displayName":"UK_HELMET_2022_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2022_WHITE_Facemask_preset","label":"Kentucky (2022, White)"},{"displayName":"LSU_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LSU_HELMET_2021_GOLD_Facemask_preset","label":"LSU (2021, GOLD)"},{"displayName":"LSU_HELMET_2021_PURPLE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LSU_HELMET_2021_PURPLE_Facemask_preset","label":"LSU (2021, Purple)"},{"displayName":"LSU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LSU_HELMET_2021_WHITE_Facemask_preset","label":"LSU (2021, White)"},{"displayName":"LIB_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LIB_HELMET_2021_BLUE_Facemask_preset","label":"Liberty (2021, BLUE)"},{"displayName":"LIB_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LIB_HELMET_2021_RED_Facemask_preset","label":"Liberty (2021, RED)"},{"displayName":"LIB_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LIB_HELMET_2021_WHITE_Facemask_preset","label":"Liberty (2021, White)"},{"displayName":"ULL_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULL_HELMET_2021_BLACK_Facemask_preset","label":"Louisiana (2021, Black)"},{"displayName":"ULL_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULL_HELMET_2021_RED_Facemask_preset","label":"Louisiana (2021, RED)"},{"displayName":"ULL_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULL_HELMET_2023_WHITE_Facemask_preset","label":"Louisiana (2023, White)"},{"displayName":"LT_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LT_HELMET_2021_RED_Facemask_preset","label":"Louisiana Tech (2021, RED)"},{"displayName":"LT_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LT_HELMET_2021_WHITE_Facemask_preset","label":"Louisiana Tech (2021, White)"},{"displayName":"ULM_HELMET_2016_CAMO_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULM_HELMET_2016_CAMO_Facemask_preset","label":"Louisiana-Monroe (2016, CAMO)"},{"displayName":"ULM_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULM_HELMET_2021_WHITE_Facemask_preset","label":"Louisiana-Monroe (2021, White)"},{"displayName":"LOU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LOU_HELMET_2021_BLACK_Facemask_preset","label":"Louisville (2021, Black)"},{"displayName":"LOU_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LOU_HELMET_2021_RED_Facemask_preset","label":"Louisville (2021, RED)"},{"displayName":"LOU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LOU_HELMET_2021_WHITE_Facemask_preset","label":"Louisville (2021, White)"},{"displayName":"MRSH_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MRSH_HELMET_2021_WHITE_Facemask_preset","label":"Marshall (2021, White)"},{"displayName":"UMD_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMD_HELMET_2021_BLACK_Facemask_preset","label":"Maryland (2021, Black)"},{"displayName":"UMD_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMD_HELMET_2021_RED_Facemask_preset","label":"Maryland (2021, RED)"},{"displayName":"UMD_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMD_HELMET_2021_WHITE_Facemask_preset","label":"Maryland (2021, White)"},{"displayName":"MEM_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2021_BLUE_Facemask_preset","label":"Memphis (2021, BLUE)"},{"displayName":"MEM_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2021_WHITE_Facemask_preset","label":"Memphis (2021, White)"},{"displayName":"MEM_HELMET_2022_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2022_WHITE_Facemask_preset","label":"Memphis (2022, White)"},{"displayName":"MEM_HELMET_2022_WHITEBLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2022_WHITEBLACK_Facemask_preset","label":"Memphis (2022, Whiteblack)"},{"displayName":"MEM_HELMET_2023_GRAY_facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2023_GRAY_facemask_preset","label":"Memphis (2023, GRAY)"},{"displayName":"MIA_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIA_HELMET_2021_BLACK_Facemask_preset","label":"Miami (FL) (2021, Black)"},{"displayName":"MIA_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIA_HELMET_2021_WHITE_Facemask_preset","label":"Miami (FL) (2021, White)"},{"displayName":"MIAOH_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIAOH_HELMET_2021_RED_Facemask_preset","label":"Miami (OH) (2021, RED)"},{"displayName":"MIAOH_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIAOH_HELMET_2021_WHITE_Facemask_preset","label":"Miami (OH) (2021, White)"},{"displayName":"MIAOH_HELMET_2021_WHITEALT_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIAOH_HELMET_2021_WHITEALT_Facemask_preset","label":"Miami (OH) (2021, Whitealt)"},{"displayName":"MIAOH_HELMET_2025_REDALT_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIAOH_HELMET_2025_REDALT_Facemask_preset","label":"Miami (OH) (2025, Redalt)"},{"displayName":"MICH_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MICH_HELMET_2021_BLUE_Facemask_preset","label":"Michigan (2021, BLUE)"},{"displayName":"MSU_HELMET_2015_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2015_GREEN_Facemask_preset","label":"Michigan State (2015, Green)"},{"displayName":"MSU_HELMET_2017_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2017_WHITE_Facemask_preset","label":"Michigan State (2017, White)"},{"displayName":"MSU_HELMET_2021_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2021_GREEN_Facemask_preset","label":"Michigan State (2021, Green)"},{"displayName":"MSU_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2023_BLACK_Facemask_preset","label":"Michigan State (2023, Black)"},{"displayName":"MTSU_HELMET_2021_GREY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTSU_HELMET_2021_GREY_Facemask_preset","label":"Middle Tennessee (2021, GREY)"},{"displayName":"MTSU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTSU_HELMET_2021_WHITE_Facemask_preset","label":"Middle Tennessee (2021, White)"},{"displayName":"MINN_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2021_RED_Facemask_preset","label":"Minnesota (2021, RED)"},{"displayName":"MINN_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2021_YELLOW_Facemask_preset","label":"Minnesota (2021, Yellow)"},{"displayName":"MINN_HELMET_2022_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2022_BLACK_Facemask_preset","label":"Minnesota (2022, Black)"},{"displayName":"MINN_HELMET_2022_CHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2022_CHROME_Facemask_preset","label":"Minnesota (2022, Chrome)"},{"displayName":"MINN_HELMET_2022_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2022_YELLOW_Facemask_preset","label":"Minnesota (2022, Yellow)"},{"displayName":"MINN_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2023_WHITE_Facemask_preset","label":"Minnesota (2023, White)"},{"displayName":"MSST_HELMET_2021_MAROON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSST_HELMET_2021_MAROON_Facemask_preset","label":"Mississippi State (2021, Maroon)"},{"displayName":"MSST_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSST_HELMET_2021_WHITE_Facemask_preset","label":"Mississippi State (2021, White)"},{"displayName":"MIZZ_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIZZ_HELMET_2021_BLACK_Facemask_preset","label":"Missouri (2021, Black)"},{"displayName":"MIZZ_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIZZ_HELMET_2021_YELLOW_Facemask_preset","label":"Missouri (2021, Yellow)"},{"displayName":"MIST_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIST_HELMET_2021_BLACK_Facemask_preset","label":"Missouri State (2021, Black)"},{"displayName":"MIST_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIST_HELMET_2021_WHITE_Facemask_preset","label":"Missouri State (2021, White)"},{"displayName":"MTDEW_HELMET_2025_Alt_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTDEW_HELMET_2025_Alt_Facemask_preset","label":"Mountain Dew (non-school / branded) (2025, Alt)"},{"displayName":"MTDEW_HELMET_2025_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTDEW_HELMET_2025_GREEN_Facemask_preset","label":"Mountain Dew (non-school / branded) (2025, Green)"},{"displayName":"MTDEW_HELMET_2025_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTDEW_HELMET_2025_WHITE_Facemask_preset","label":"Mountain Dew (non-school / branded) (2025, White)"},{"displayName":"NCST_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NCST_HELMET_2021_BLACK_Facemask_preset","label":"NC State (2021, Black)"},{"displayName":"NCST_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NCST_HELMET_2021_RED_Facemask_preset","label":"NC State (2021, RED)"},{"displayName":"NCST_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NCST_HELMET_2021_WHITE_Facemask_preset","label":"NC State (2021, White)"},{"displayName":"NAVY_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NAVY_HELMET_2021_GOLD_Facemask_preset","label":"Navy (2021, GOLD)"},{"displayName":"NAVY_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NAVY_HELMET_2021_NAVY_Facemask_preset","label":"Navy (2021, NAVY)"},{"displayName":"NEB_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEB_HELMET_2021_WHITE_Facemask_preset","label":"Nebraska (2021, White)"},{"displayName":"NEV_HELMET_2021_SILVER_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEV_HELMET_2021_SILVER_Facemask_preset","label":"Nevada (2021, Silver)"},{"displayName":"NEV_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEV_HELMET_2021_WHITE_Facemask_preset","label":"Nevada (2021, White)"},{"displayName":"NEV_HELMET_2023_NAVYBLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEV_HELMET_2023_NAVYBLUE_Facemask_preset","label":"Nevada (2023, Navyblue)"},{"displayName":"UNM_HELMET_2021_GRAY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_GRAY_Facemask_preset","label":"New Mexico (2021, GRAY)"},{"displayName":"UNM_HELMET_2021_SILVER_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_SILVER_Facemask_preset","label":"New Mexico (2021, Silver)"},{"displayName":"UNM_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_WHITE_Facemask_preset","label":"New Mexico (2021, White)"},{"displayName":"UNM_HELMET_2023_SILVER_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2023_SILVER_Facemask_preset","label":"New Mexico (2023, Silver)"},{"displayName":"NMSU_HELMET_2021_CHROMECRIMSON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NMSU_HELMET_2021_CHROMECRIMSON_Facemask_preset","label":"New Mexico State (2021, Chromecrimson)"},{"displayName":"NMSU_HELMET_2021_CRIMSON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NMSU_HELMET_2021_CRIMSON_Facemask_preset","label":"New Mexico State (2021, Crimson)"},{"displayName":"NMSU_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NMSU_HELMET_2023_WHITE_Facemask_preset","label":"New Mexico State (2023, White)"},{"displayName":"UNC_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNC_HELMET_2021_BLUE_Facemask_preset","label":"North Carolina (2021, BLUE)"},{"displayName":"UNC_HELMET_2021_CHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNC_HELMET_2021_CHROME_Facemask_preset","label":"North Carolina (2021, Chrome)"},{"displayName":"UNC_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNC_HELMET_2021_WHITE_Facemask_preset","label":"North Carolina (2021, White)"},{"displayName":"UNT_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_BLACK_Facemask_preset","label":"North Texas (2021, Black)"},{"displayName":"UNT_HELMET_2021_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_GREEN_Facemask_preset","label":"North Texas (2021, Green)"},{"displayName":"UNT_HELMET_2021_THROWBACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_THROWBACK_Facemask_preset","label":"North Texas (2021, Throwback)"},{"displayName":"UNT_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_WHITE_Facemask_preset","label":"North Texas (2021, White)"},{"displayName":"NIU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NIU_HELMET_2021_BLACK_Facemask_preset","label":"Northern Illinois (2021, Black)"},{"displayName":"NW_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2021_BLACK_Facemask_preset","label":"Northwestern (2021, Black)"},{"displayName":"NW_HELMET_2021_PURPLE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2021_PURPLE_Facemask_preset","label":"Northwestern (2021, Purple)"},{"displayName":"NW_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2021_WHITE_Facemask_preset","label":"Northwestern (2021, White)"},{"displayName":"NW_HELMET_2022_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2022_BLACK_Facemask_preset","label":"Northwestern (2022, Black)"},{"displayName":"ND_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ND_HELMET_2021_GOLD_Facemask_preset","label":"Notre Dame (2021, GOLD)"},{"displayName":"OHIO_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OHIO_HELMET_2023_BLACK_Facemask_preset","label":"Ohio (2023, Black)"},{"displayName":"OHIO_HELMET_2023_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OHIO_HELMET_2023_GREEN_Facemask_preset","label":"Ohio (2023, Green)"},{"displayName":"OHIO_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OHIO_HELMET_2023_WHITE_Facemask_preset","label":"Ohio (2023, White)"},{"displayName":"OSU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OSU_HELMET_2021_BLACK_Facemask_preset","label":"Ohio State (2021, Black)"},{"displayName":"OSU_HELMET_2021_GREY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OSU_HELMET_2021_GREY_Facemask_preset","label":"Ohio State (2021, GREY)"},{"displayName":"OU_HELMET_2021_CRIMSON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_CRIMSON_Facemask_preset","label":"Oklahoma (2021, Crimson)"},{"displayName":"OU_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_RED_Facemask_preset","label":"Oklahoma (2021, RED)"},{"displayName":"OU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_WHITE_Facemask_preset","label":"Oklahoma (2021, White)"},{"displayName":"OU_HELMET_2021_WOODCREAM_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_WOODCREAM_Facemask_preset","label":"Oklahoma (2021, Woodcream)"},{"displayName":"OU_HELMET_2021_WOODCRIMSON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_WOODCRIMSON_Facemask_preset","label":"Oklahoma (2021, Woodcrimson)"},{"displayName":"OKST_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2021_BLACK_Facemask_preset","label":"Oklahoma State (2021, Black)"},{"displayName":"OKST_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2021_ORANGE_Facemask_preset","label":"Oklahoma State (2021, Orange)"},{"displayName":"OKST_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2021_WHITE_Facemask_preset","label":"Oklahoma State (2021, White)"},{"displayName":"OKST_HELMET_2023_GRAY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2023_GRAY_Facemask_preset","label":"Oklahoma State (2023, GRAY)"},{"displayName":"ODU_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ODU_HELMET_2021_BLUE_Facemask_preset","label":"Old Dominion (2021, BLUE)"},{"displayName":"ODU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ODU_HELMET_2021_WHITE_Facemask_preset","label":"Old Dominion (2021, White)"},{"displayName":"MISS_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_BLUE_Facemask_preset","label":"Ole Miss (2021, BLUE)"},{"displayName":"MISS_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_NAVY_Facemask_preset","label":"Ole Miss (2021, NAVY)"},{"displayName":"MISS_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_WHITE_Facemask_preset","label":"Ole Miss (2021, White)"},{"displayName":"ORE_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2021_WHITE_Facemask_preset","label":"Oregon (2021, White)"},{"displayName":"ORE_HELMET_2021_WHITEGREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2021_WHITEGREEN_Facemask_preset","label":"Oregon (2021, Whitegreen)"},{"displayName":"ORE_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2021_YELLOW_Facemask_preset","label":"Oregon (2021, Yellow)"},{"displayName":"ORE_HELMET_2021_YELLOWSTEEL_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2021_YELLOWSTEEL_Facemask_preset","label":"Oregon (2021, Yellowsteel)"},{"displayName":"ORE_HELMET_2023_BLACKCARBON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2023_BLACKCARBON_Facemask_preset","label":"Oregon (2023, Blackcarbon)"},{"displayName":"ORE_HELMET_2023_CHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2023_CHROME_Facemask_preset","label":"Oregon (2023, Chrome)"},{"displayName":"ORE_HELMET_2023_EGGSHELL_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2023_EGGSHELL_Facemask_preset","label":"Oregon (2023, Eggshell)"},{"displayName":"ORE_HELMET_2024_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2024_GREEN_Facemask_preset","label":"Oregon (2024, Green)"},{"displayName":"ORE_HELMET_2024_THROWBACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2024_THROWBACK_Facemask_preset","label":"Oregon (2024, Throwback)"},{"displayName":"ORE_HELMET_2025_SHOEDUCK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2025_SHOEDUCK_Facemask_preset","label":"Oregon (2025, Shoeduck)"},{"displayName":"ORST_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORST_HELMET_2021_BLACK_Facemask_preset","label":"Oregon State (2021, Black)"},{"displayName":"PSU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PSU_HELMET_2021_WHITE_Facemask_preset","label":"Penn State (2021, White)"},{"displayName":"PSU_HELMET_2022_WHITESTRIPE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PSU_HELMET_2022_WHITESTRIPE_Facemask_preset","label":"Penn State (2022, Whitestripe)"},{"displayName":"PITT_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PITT_HELMET_2021_YELLOW_Facemask_preset","label":"Pittsburgh (2021, Yellow)"},{"displayName":"PITT_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PITT_HELMET_2023_WHITE_Facemask_preset","label":"Pittsburgh (2023, White)"},{"displayName":"PUR_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2021_BLACK_Facemask_preset","label":"Purdue (2021, Black)"},{"displayName":"PUR_HELMET_2021_BLACKALT_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2021_BLACKALT_Facemask_preset","label":"Purdue (2021, Blackalt)"},{"displayName":"PUR_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2021_GOLD_Facemask_preset","label":"Purdue (2021, GOLD)"},{"displayName":"PUR_HELMET_2023_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2023_GOLD_Facemask_preset","label":"Purdue (2023, GOLD)"},{"displayName":"RICE_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RICE_HELMET_2021_NAVY_Facemask_preset","label":"Rice (2021, NAVY)"},{"displayName":"RICE_HELMET_2021_SILVER_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RICE_HELMET_2021_SILVER_Facemask_preset","label":"Rice (2021, Silver)"},{"displayName":"RICE_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RICE_HELMET_2021_WHITE_Facemask_preset","label":"Rice (2021, White)"},{"displayName":"RICE_HELMET_2022_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RICE_HELMET_2022_NAVY_Facemask_preset","label":"Rice (2022, NAVY)"},{"displayName":"RUTG_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RUTG_HELMET_2021_BLACK_Facemask_preset","label":"Rutgers (2021, Black)"},{"displayName":"RUTG_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RUTG_HELMET_2021_RED_Facemask_preset","label":"Rutgers (2021, RED)"},{"displayName":"SMU_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SMU_HELMET_2021_BLUE_Facemask_preset","label":"SMU (2021, BLUE)"},{"displayName":"SMU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SMU_HELMET_2021_WHITE_Facemask_preset","label":"SMU (2021, White)"},{"displayName":"SMU_HELMET_2023_WHITEALT_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SMU_HELMET_2023_WHITEALT_Facemask_preset","label":"SMU (2023, Whitealt)"},{"displayName":"SHSU_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SHSU_HELMET_2021_ORANGE_Facemask_preset","label":"Sam Houston State (2021, Orange)"},{"displayName":"SHSU_HELMET_2023_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SHSU_HELMET_2023_ORANGE_Facemask_preset","label":"Sam Houston State (2023, Orange)"},{"displayName":"SDSU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SDSU_HELMET_2021_BLACK_Facemask_preset","label":"San Diego State (2021, Black)"},{"displayName":"SJSU_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SJSU_HELMET_2021_BLUE_Facemask_preset","label":"San Jose State (2021, BLUE)"},{"displayName":"SJSU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SJSU_HELMET_2021_WHITE_Facemask_preset","label":"San Jose State (2021, White)"},{"displayName":"USA_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USA_HELMET_2021_NAVY_Facemask_preset","label":"South Alabama (2021, NAVY)"},{"displayName":"USA_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USA_HELMET_2021_RED_Facemask_preset","label":"South Alabama (2021, RED)"},{"displayName":"USA_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USA_HELMET_2021_WHITE_Facemask_preset","label":"South Alabama (2021, White)"},{"displayName":"USA_HELMET_2022_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USA_HELMET_2022_RED_Facemask_preset","label":"South Alabama (2022, RED)"},{"displayName":"SC_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SC_HELMET_2021_BLACK_Facemask_preset","label":"South Carolina (2021, Black)"},{"displayName":"SC_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SC_HELMET_2021_RED_Facemask_preset","label":"South Carolina (2021, RED)"},{"displayName":"SC_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SC_HELMET_2021_WHITE_Facemask_preset","label":"South Carolina (2021, White)"},{"displayName":"USF_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USF_HELMET_2021_GOLD_Facemask_preset","label":"South Florida (2021, GOLD)"},{"displayName":"USF_HELMET_2021_WHITEGREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USF_HELMET_2021_WHITEGREEN_Facemask_preset","label":"South Florida (2021, Whitegreen)"},{"displayName":"USM_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USM_HELMET_2021_BLACK_Facemask_preset","label":"Southern Miss (2021, Black)"},{"displayName":"USM_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USM_HELMET_2021_WHITE_Facemask_preset","label":"Southern Miss (2021, White)"},{"displayName":"STAN_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2021_WHITE_Facemask_preset","label":"Stanford (2021, White)"},{"displayName":"STAN_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2023_BLACK_Facemask_preset","label":"Stanford (2023, Black)"},{"displayName":"STAN_HELMET_2023_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2023_RED_Facemask_preset","label":"Stanford (2023, RED)"},{"displayName":"SYR_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SYR_HELMET_2021_ORANGE_Facemask_preset","label":"Syracuse (2021, Orange)"},{"displayName":"SYR_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SYR_HELMET_2021_WHITE_Facemask_preset","label":"Syracuse (2021, White)"},{"displayName":"TCU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TCU_HELMET_2021_BLACK_Facemask_preset","label":"TCU (2021, Black)"},{"displayName":"TCU_HELMET_2021_PURPLE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TCU_HELMET_2021_PURPLE_Facemask_preset","label":"TCU (2021, Purple)"},{"displayName":"TCU_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TCU_HELMET_2023_WHITE_Facemask_preset","label":"TCU (2023, White)"},{"displayName":"TEMP_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2021_RED_Facemask_preset","label":"Temple (2021, RED) [TEMP]"},{"displayName":"TEM_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEM_HELMET_2021_RED_Facemask_preset","label":"Temple (2021, RED) [TEM]"},{"displayName":"TEMP_HELMET_2021_REDALT_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2021_REDALT_Facemask_preset","label":"Temple (2021, Redalt)"},{"displayName":"TEM_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEM_HELMET_2021_WHITE_Facemask_preset","label":"Temple (2021, White)"},{"displayName":"TEMP_HELMET_2025_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2025_RED_Facemask_preset","label":"Temple (2025, RED)"},{"displayName":"TEMP_HELMET_2025_WHI_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2025_WHI_Facemask_preset","label":"Temple (2025, WHI)"},{"displayName":"TENN_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2021_ORANGE_Facemask_preset","label":"Tennessee (2021, Orange)"},{"displayName":"TENN_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2021_WHITE_Facemask_preset","label":"Tennessee (2021, White)"},{"displayName":"TENN_HELMET_2022_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2022_BLACK_Facemask_preset","label":"Tennessee (2022, Black)"},{"displayName":"TENN_HELMET_2024_GRAY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2024_GRAY_Facemask_preset","label":"Tennessee (2024, GRAY)"},{"displayName":"TENN_HELMET_2025_Smokey_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2025_Smokey_Facemask_preset","label":"Tennessee (2025, Smokey)"},{"displayName":"TEX_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEX_HELMET_2021_WHITE_Facemask_preset","label":"Texas (2021, White)"},{"displayName":"TAMU_HELMET_2021_MAROON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TAMU_HELMET_2021_MAROON_Facemask_preset","label":"Texas A&M (2021, Maroon)"},{"displayName":"TAMU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TAMU_HELMET_2021_WHITE_Facemask_preset","label":"Texas A&M (2021, White)"},{"displayName":"TAMU_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TAMU_HELMET_2023_BLACK_Facemask_preset","label":"Texas A&M (2023, Black)"},{"displayName":"TXST_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TXST_HELMET_2021_BLACK_Facemask_preset","label":"Texas State (2021, Black)"},{"displayName":"TXST_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TXST_HELMET_2021_GOLD_Facemask_preset","label":"Texas State (2021, GOLD)"},{"displayName":"TXST_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TXST_HELMET_2021_WHITE_Facemask_preset","label":"Texas State (2021, White)"},{"displayName":"TXST_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TXST_HELMET_2023_WHITE_Facemask_preset","label":"Texas State (2023, White)"},{"displayName":"TTU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2021_BLACK_Facemask_preset","label":"Texas Tech (2021, Black)"},{"displayName":"TTU_HELMET_2021_GRAY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2021_GRAY_Facemask_preset","label":"Texas Tech (2021, GRAY)"},{"displayName":"TTU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2021_WHITE_Facemask_preset","label":"Texas Tech (2021, White)"},{"displayName":"TTU_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2023_WHITE_Facemask_preset","label":"Texas Tech (2023, White)"},{"displayName":"TOL_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TOL_HELMET_2021_NAVY_Facemask_preset","label":"Toledo (2021, NAVY)"},{"displayName":"TOL_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TOL_HELMET_2021_YELLOW_Facemask_preset","label":"Toledo (2021, Yellow)"},{"displayName":"TROY_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TROY_HELMET_2021_RED_Facemask_preset","label":"Troy (2021, RED)"},{"displayName":"TROY_HELMET_2021_SILVER_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TROY_HELMET_2021_SILVER_Facemask_preset","label":"Troy (2021, Silver)"},{"displayName":"TROY_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TROY_HELMET_2021_WHITE_Facemask_preset","label":"Troy (2021, White)"},{"displayName":"TROY_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TROY_HELMET_2023_BLACK_Facemask_preset","label":"Troy (2023, Black)"},{"displayName":"TULN_HELMET_2021_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2021_GREEN_Facemask_preset","label":"Tulane (2021, Green)"},{"displayName":"TULN_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2021_WHITE_Facemask_preset","label":"Tulane (2021, White)"},{"displayName":"TULN_HELMET_2025_CITY_EDITION_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2025_CITY_EDITION_Facemask_preset","label":"Tulane (2025, CITY Edition)"},{"displayName":"TULN_HELMET_2025_Wumbu_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2025_Wumbu_Facemask_preset","label":"Tulane (2025, Wumbu)"},{"displayName":"TLSA_HELMET_2023_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TLSA_HELMET_2023_GOLD_Facemask_preset","label":"Tulsa (2023, GOLD)"},{"displayName":"TLSA_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TLSA_HELMET_2023_WHITE_Facemask_preset","label":"Tulsa (2023, White)"},{"displayName":"UAB_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UAB_HELMET_2021_GOLD_Facemask_preset","label":"UAB (2021, GOLD)"},{"displayName":"UAB_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UAB_HELMET_2021_WHITE_Facemask_preset","label":"UAB (2021, White)"},{"displayName":"UCF_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2021_GOLD_Facemask_preset","label":"UCF (2021, GOLD)"},{"displayName":"UCF_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2021_WHITE_Facemask_preset","label":"UCF (2021, White)"},{"displayName":"UCF_HELMET_2023_SPACE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2023_SPACE_Facemask_preset","label":"UCF (2023, Space)"},{"displayName":"UCF_HELMET_2024_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2024_GOLD_Facemask_preset","label":"UCF (2024, GOLD)"},{"displayName":"UCLA_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCLA_HELMET_2021_GOLD_Facemask_preset","label":"UCLA (2021, GOLD)"},{"displayName":"UCLA_HELMET_2023_GOLDALT_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCLA_HELMET_2023_GOLDALT_Facemask_preset","label":"UCLA (2023, Goldalt)"},{"displayName":"CONN_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CONN_HELMET_2021_NAVY_Facemask_preset","label":"UConn (2021, NAVY)"},{"displayName":"CONN_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CONN_HELMET_2021_WHITE_Facemask_preset","label":"UConn (2021, White)"},{"displayName":"CONN_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CONN_HELMET_2023_WHITE_Facemask_preset","label":"UConn (2023, White)"},{"displayName":"UMASS_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMASS_HELMET_2021_BLACK_Facemask_preset","label":"UMass (2021, Black)"},{"displayName":"UMASS_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMASS_HELMET_2021_RED_Facemask_preset","label":"UMass (2021, RED)"},{"displayName":"UMASS_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMASS_HELMET_2021_WHITE_Facemask_preset","label":"UMass (2021, White)"},{"displayName":"UNLV_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2021_BLACK_Facemask_preset","label":"UNLV (2021, Black)"},{"displayName":"UNLV_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2021_RED_Facemask_preset","label":"UNLV (2021, RED)"},{"displayName":"UNLV_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2021_WHITE_Facemask_preset","label":"UNLV (2021, White)"},{"displayName":"UNLV_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2023_WHITE_Facemask_preset","label":"UNLV (2023, White)"},{"displayName":"UNLV_HELMET_2024_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2024_RED_Facemask_preset","label":"UNLV (2024, RED)"},{"displayName":"USC_HELMET_2021_CARDINAL_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USC_HELMET_2021_CARDINAL_Facemask_preset","label":"USC (2021, Cardinal)"},{"displayName":"USC_HELMET_2021_CARDINALCHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USC_HELMET_2021_CARDINALCHROME_Facemask_preset","label":"USC (2021, Cardinalchrome)"},{"displayName":"UTEP_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTEP_HELMET_2021_ORANGE_Facemask_preset","label":"UTEP (2021, Orange)"},{"displayName":"UTEP_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTEP_HELMET_2021_WHITE_Facemask_preset","label":"UTEP (2021, White)"},{"displayName":"UTEP_HELMET_2025_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTEP_HELMET_2025_BLUE_Facemask_preset","label":"UTEP (2025, BLUE)"},{"displayName":"UTSA_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTSA_HELMET_2021_BLACK_Facemask_preset","label":"UTSA (2021, Black)"},{"displayName":"UTSA_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTSA_HELMET_2021_NAVY_Facemask_preset","label":"UTSA (2021, NAVY)"},{"displayName":"UTSA_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTSA_HELMET_2021_WHITE_Facemask_preset","label":"UTSA (2021, White)"},{"displayName":"UTAH_HELMET_2020_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2020_WHITE_Facemask_preset","label":"Utah (2020, White)"},{"displayName":"UTAH_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2021_RED_Facemask_preset","label":"Utah (2021, RED)"},{"displayName":"UTAH_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2021_WHITE_Facemask_preset","label":"Utah (2021, White)"},{"displayName":"UTAH_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2023_BLACK_Facemask_preset","label":"Utah (2023, Black)"},{"displayName":"USU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USU_HELMET_2021_BLACK_Facemask_preset","label":"Utah State (2021, Black)"},{"displayName":"USU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USU_HELMET_2021_WHITE_Facemask_preset","label":"Utah State (2021, White)"},{"displayName":"VAN_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VAN_HELMET_2021_GOLD_Facemask_preset","label":"Vanderbilt (2021, GOLD)"},{"displayName":"VAN_HELMET_2022_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VAN_HELMET_2022_WHITE_Facemask_preset","label":"Vanderbilt (2022, White)"},{"displayName":"UVA_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UVA_HELMET_2021_BLUE_Facemask_preset","label":"Virginia (2021, BLUE)"},{"displayName":"UVA_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UVA_HELMET_2021_WHITE_Facemask_preset","label":"Virginia (2021, White)"},{"displayName":"VT_HELMET_2016_MAROON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2016_MAROON_Facemask_preset","label":"Virginia Tech (2016, Maroon)"},{"displayName":"VT_HELMET_2016_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2016_WHITE_Facemask_preset","label":"Virginia Tech (2016, White)"},{"displayName":"VT_HELMET_2021_MAROON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2021_MAROON_Facemask_preset","label":"Virginia Tech (2021, Maroon)"},{"displayName":"VT_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2021_WHITE_Facemask_preset","label":"Virginia Tech (2021, White)"},{"displayName":"VT_HELMET_2025_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2025_ORANGE_Facemask_preset","label":"Virginia Tech (2025, Orange)"},{"displayName":"WAKE_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WAKE_HELMET_2021_BLACK_Facemask_preset","label":"Wake Forest (2021, Black)"},{"displayName":"WASH_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2021_GOLD_Facemask_preset","label":"Washington (2021, GOLD)"},{"displayName":"WASH_HELMET_2021_GOLDCHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2021_GOLDCHROME_Facemask_preset","label":"Washington (2021, Goldchrome)"},{"displayName":"WASH_HELMET_2023_PURPLECHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2023_PURPLECHROME_Facemask_preset","label":"Washington (2023, Purplechrome)"},{"displayName":"WSU_HELMET_2021_DARKGRAY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WSU_HELMET_2021_DARKGRAY_Facemask_preset","label":"Washington State (2021, Darkgray)"},{"displayName":"WSU_HELMET_2021_GRAY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WSU_HELMET_2021_GRAY_Facemask_preset","label":"Washington State (2021, GRAY)"},{"displayName":"WSU_HELMET_2023_DARKGRAY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WSU_HELMET_2023_DARKGRAY_Facemask_preset","label":"Washington State (2023, Darkgray)"},{"displayName":"WVU_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2021_BLUE_Facemask_preset","label":"West Virginia (2021, BLUE)"},{"displayName":"WVU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2021_BLACK_Facemask_preset","label":"West Virginia (2021, Black)"},{"displayName":"WVU_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2021_YELLOW_Facemask_preset","label":"West Virginia (2021, Yellow)"},{"displayName":"WKU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2021_BLACK_Facemask_preset","label":"Western Kentucky (2021, Black)"},{"displayName":"WKU_HELMET_2021_CHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2021_CHROME_Facemask_preset","label":"Western Kentucky (2021, Chrome)"},{"displayName":"WKU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2021_WHITE_Facemask_preset","label":"Western Kentucky (2021, White)"},{"displayName":"WKU_HELMET_2024_THROWBACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2024_THROWBACK_Facemask_preset","label":"Western Kentucky (2024, Throwback)"},{"displayName":"WMU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WMU_HELMET_2021_WHITE_Facemask_preset","label":"Western Michigan (2021, White)"},{"displayName":"WIS_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WIS_HELMET_2021_RED_Facemask_preset","label":"Wisconsin (2021, RED)"},{"displayName":"WIS_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WIS_HELMET_2021_WHITE_Facemask_preset","label":"Wisconsin (2021, White)"},{"displayName":"WYO_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WYO_HELMET_2021_WHITE_Facemask_preset","label":"Wyoming (2021, White)"}],"accessory":[{"displayName":"AFA_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2021_BLUE_Acc_preset","label":"Air Force (2021, BLUE)"},{"displayName":"AFA_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2021_WHITE_Acc_preset","label":"Air Force (2021, White)"},{"displayName":"AFA_HELMET_2025_ALT_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2025_ALT_Acc_preset","label":"Air Force (2025, ALT)"},{"displayName":"AKR_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AKR_HELMET_2021_GOLD_Acc_preset","label":"Akron (2021, GOLD)"},{"displayName":"AKR_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AKR_HELMET_2021_WHITE_Acc_preset","label":"Akron (2021, White)"},{"displayName":"ALA_HELMET_2021_CRIMSON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ALA_HELMET_2021_CRIMSON_Acc_preset","label":"Alabama (2021, Crimson)"},{"displayName":"APP_HELMET_2016_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2016_BLACK_Acc_preset","label":"Appalachian State (2016, Black)"},{"displayName":"APP_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2021_BLACK_Acc_preset","label":"Appalachian State (2021, Black)"},{"displayName":"APP_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2021_WHITE_Acc_preset","label":"Appalachian State (2021, White)"},{"displayName":"APP_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2021_YELLOW_Acc_preset","label":"Appalachian State (2021, Yellow)"},{"displayName":"ARIZ_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARIZ_HELMET_2021_WHITE_Acc_preset","label":"Arizona (2021, White)"},{"displayName":"ASU_HELMET_2014_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2014_YELLOW_Acc_preset","label":"Arizona State (2014, Yellow)"},{"displayName":"ASU_HELMET_2021_MAROON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2021_MAROON_Acc_preset","label":"Arizona State (2021, Maroon)"},{"displayName":"ASU_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2021_YELLOW_Acc_preset","label":"Arizona State (2021, Yellow)"},{"displayName":"ASU_HELMET_2022_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2022_YELLOW_Acc_preset","label":"Arizona State (2022, Yellow)"},{"displayName":"ARK_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARK_HELMET_2021_RED_Acc_preset","label":"Arkansas (2021, RED)"},{"displayName":"ARK_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARK_HELMET_2021_WHITE_Acc_preset","label":"Arkansas (2021, White)"},{"displayName":"ARST_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARST_HELMET_2021_WHITE_Acc_preset","label":"Arkansas State (2021, White)"},{"displayName":"ARST_HELMET_2023_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARST_HELMET_2023_BLACK_Acc_preset","label":"Arkansas State (2023, Black)"},{"displayName":"ARMY_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARMY_HELMET_2021_GOLD_Acc_preset","label":"Army (2021, GOLD)"},{"displayName":"AUB_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AUB_HELMET_2021_WHITE_Acc_preset","label":"Auburn (2021, White)"},{"displayName":"BYU_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2021_BLUE_Acc_preset","label":"BYU (2021, BLUE)"},{"displayName":"BYU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2021_WHITE_Acc_preset","label":"BYU (2021, White)"},{"displayName":"BYU_HELMET_2022_NAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2022_NAVY_Acc_preset","label":"BYU (2022, NAVY)"},{"displayName":"BYU_HELMET_2022_WHITENAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2022_WHITENAVY_Acc_preset","label":"BYU (2022, Whitenavy)"},{"displayName":"BALL_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BALL_HELMET_2021_BLACK_Acc_preset","label":"Ball State (2021, Black)"},{"displayName":"BALL_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BALL_HELMET_2021_WHITE_Acc_preset","label":"Ball State (2021, White)"},{"displayName":"BAY_HELMET_2021_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_GREEN_Acc_preset","label":"Baylor (2021, Green)"},{"displayName":"BAY_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_WHITE_Acc_preset","label":"Baylor (2021, White)"},{"displayName":"BAY_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_YELLOW_Acc_preset","label":"Baylor (2021, Yellow)"},{"displayName":"BSU_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_BLUE_Acc_preset","label":"Boise State (2021, BLUE)"},{"displayName":"BSU_HELMET_2021_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_ORANGE_Acc_preset","label":"Boise State (2021, Orange)"},{"displayName":"BSU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_WHITE_Acc_preset","label":"Boise State (2021, White)"},{"displayName":"BC_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BC_HELMET_2021_GOLD_Acc_preset","label":"Boston College (2021, GOLD)"},{"displayName":"BGSU_HELMET_2021_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BGSU_HELMET_2021_ORANGE_Acc_preset","label":"Bowling Green (2021, Orange)"},{"displayName":"BGSU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BGSU_HELMET_2021_WHITE_Acc_preset","label":"Bowling Green (2021, White)"},{"displayName":"BUFF_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BUFF_HELMET_2021_BLUE_Acc_preset","label":"Buffalo (2021, BLUE)"},{"displayName":"BUFF_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BUFF_HELMET_2021_WHITE_Acc_preset","label":"Buffalo (2021, White)"},{"displayName":"CAL_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CAL_HELMET_2021_YELLOW_Acc_preset","label":"California (2021, Yellow)"},{"displayName":"CAL_HELMET_2022_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CAL_HELMET_2022_YELLOW_Acc_preset","label":"California (2022, Yellow)"},{"displayName":"CAL_HELMET_2023_NAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CAL_HELMET_2023_NAVY_Acc_preset","label":"California (2023, NAVY)"},{"displayName":"CMU_HELMET_2021_MAROON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CMU_HELMET_2021_MAROON_Acc_preset","label":"Central Michigan (2021, Maroon)"},{"displayName":"CMU_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CMU_HELMET_2021_YELLOW_Acc_preset","label":"Central Michigan (2021, Yellow)"},{"displayName":"CHAR_HELMET_2021_CHROME_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_CHROME_Acc_preset","label":"Charlotte (2021, Chrome)"},{"displayName":"CHAR_HELMET_2021_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_GREEN_Acc_preset","label":"Charlotte (2021, Green)"},{"displayName":"CHAR_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_WHITE_Acc_preset","label":"Charlotte (2021, White)"},{"displayName":"CHAR_HELMET_2025_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2025_WHITE_Acc_preset","label":"Charlotte (2025, White)"},{"displayName":"CIN_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CIN_HELMET_2021_BLACK_Acc_preset","label":"Cincinnati (2021, Black)"},{"displayName":"CIN_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CIN_HELMET_2021_RED_Acc_preset","label":"Cincinnati (2021, RED)"},{"displayName":"CIN_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CIN_HELMET_2021_WHITE_Acc_preset","label":"Cincinnati (2021, White)"},{"displayName":"CLEM_HELMET_2021_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CLEM_HELMET_2021_ORANGE_Acc_preset","label":"Clemson (2021, Orange)"},{"displayName":"CCAR_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CCAR_HELMET_2021_BLACK_Acc_preset","label":"Coastal Carolina (2021, Black)"},{"displayName":"CCAR_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CCAR_HELMET_2021_WHITE_Acc_preset","label":"Coastal Carolina (2021, White)"},{"displayName":"COLO_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2021_BLACK_Acc_preset","label":"Colorado (2021, Black)"},{"displayName":"COLO_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2021_GOLD_Acc_preset","label":"Colorado (2021, GOLD)"},{"displayName":"CSU_HELMET_2021_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CSU_HELMET_2021_GREEN_Acc_preset","label":"Colorado State (2021, Green)"},{"displayName":"CSU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CSU_HELMET_2021_WHITE_Acc_preset","label":"Colorado State (2021, White)"},{"displayName":"DUKE_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2021_BLUE_Acc_preset","label":"Duke (2021, BLUE)"},{"displayName":"DUKE_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2021_BLACK_Acc_preset","label":"Duke (2021, Black)"},{"displayName":"DUKE_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2021_WHITE_Acc_preset","label":"Duke (2021, White)"},{"displayName":"ECU_HELMET_2021_PURPLEPURPLE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2021_PURPLEPURPLE_Acc_preset","label":"East Carolina (2021, Purplepurple)"},{"displayName":"ECU_HELMET_2021_PURPLEYELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2021_PURPLEYELLOW_Acc_preset","label":"East Carolina (2021, Purpleyellow)"},{"displayName":"EMU_HELMET_2021_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/EMU_HELMET_2021_GREEN_Acc_preset","label":"Eastern Michigan (2021, Green)"},{"displayName":"EMU_HELMET_2021_SILVER_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/EMU_HELMET_2021_SILVER_Acc_preset","label":"Eastern Michigan (2021, Silver)"},{"displayName":"FLA_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_BLUE_Acc_preset","label":"Florida (2021, BLUE)"},{"displayName":"FLA_HELMET_2021_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_ORANGE_Acc_preset","label":"Florida (2021, Orange)"},{"displayName":"FLA_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_WHITE_Acc_preset","label":"Florida (2021, White)"},{"displayName":"FLA_HELMET_2023_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2023_BLACK_Acc_preset","label":"Florida (2023, Black)"},{"displayName":"FAU_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2021_RED_Acc_preset","label":"Florida Atlantic (2021, RED)"},{"displayName":"FAU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2021_WHITE_Acc_preset","label":"Florida Atlantic (2021, White)"},{"displayName":"FAU_HELMET_2023_WHITEALT_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2023_WHITEALT_Acc_preset","label":"Florida Atlantic (2023, Whitealt)"},{"displayName":"FIU_HELMET_2021_NAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2021_NAVY_Acc_preset","label":"Florida International (2021, NAVY)"},{"displayName":"FIU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2021_WHITE_Acc_preset","label":"Florida International (2021, White)"},{"displayName":"FIU_HELMET_2025_ViceCity_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2025_ViceCity_Acc_preset","label":"Florida International (2025, Vicecity)"},{"displayName":"FSU_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FSU_HELMET_2021_GOLD_Acc_preset","label":"Florida State (2021, GOLD)"},{"displayName":"FRES_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FRES_HELMET_2021_RED_Acc_preset","label":"Fresno State (2021, RED)"},{"displayName":"FRES_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FRES_HELMET_2021_WHITE_Acc_preset","label":"Fresno State (2021, White)"},{"displayName":"UGA_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UGA_HELMET_2021_RED_Acc_preset","label":"Georgia (2021, RED)"},{"displayName":"GASO_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GASO_HELMET_2021_BLUE_Acc_preset","label":"Georgia Southern (2021, BLUE)"},{"displayName":"GSU_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GSU_HELMET_2021_BLUE_Acc_preset","label":"Georgia State (2021, BLUE)"},{"displayName":"GSU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GSU_HELMET_2021_WHITE_Acc_preset","label":"Georgia State (2021, White)"},{"displayName":"GT_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GT_HELMET_2021_GOLD_Acc_preset","label":"Georgia Tech (2021, GOLD)"},{"displayName":"GT_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GT_HELMET_2021_WHITE_Acc_preset","label":"Georgia Tech (2021, White)"},{"displayName":"HAW_HELMET_2021_BLACK_02_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_BLACK_02_Acc_preset","label":"Hawaii (2021, Black 02)"},{"displayName":"HAW_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_BLACK_Acc_preset","label":"Hawaii (2021, Black)"},{"displayName":"HAW_HELMET_2021_WHITE_02_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_WHITE_02_Acc_preset","label":"Hawaii (2021, White 02)"},{"displayName":"HAW_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_WHITE_Acc_preset","label":"Hawaii (2021, White)"},{"displayName":"HOU_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HOU_HELMET_2021_RED_Acc_preset","label":"Houston (2021, RED)"},{"displayName":"HOU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HOU_HELMET_2021_WHITE_Acc_preset","label":"Houston (2021, White)"},{"displayName":"HOU_HELMET_2021_WHITEBLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HOU_HELMET_2021_WHITEBLACK_Acc_preset","label":"Houston (2021, Whiteblack)"},{"displayName":"ILL_HELMET_2021_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ILL_HELMET_2021_ORANGE_Acc_preset","label":"Illinois (2021, Orange)"},{"displayName":"IND_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/IND_HELMET_2021_RED_Acc_preset","label":"Indiana (2021, RED)"},{"displayName":"IOWA_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/IOWA_HELMET_2021_BLACK_Acc_preset","label":"Iowa (2021, Black)"},{"displayName":"ISU_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ISU_HELMET_2021_RED_Acc_preset","label":"Iowa State (2021, RED)"},{"displayName":"ISU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ISU_HELMET_2021_WHITE_Acc_preset","label":"Iowa State (2021, White)"},{"displayName":"JVST_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JVST_HELMET_2021_RED_Acc_preset","label":"Jacksonville State (2021, RED)"},{"displayName":"JMU_HELMET_2023_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JMU_HELMET_2023_WHITE_Acc_preset","label":"James Madison (2023, White)"},{"displayName":"KU_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_BLUE_Acc_preset","label":"Kansas (2021, BLUE)"},{"displayName":"KU_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_BLACK_Acc_preset","label":"Kansas (2021, Black)"},{"displayName":"KU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_WHITE_Acc_preset","label":"Kansas (2021, White)"},{"displayName":"KU_HELMET_2025_Blue_Alt_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2025_Blue_Alt_Acc_preset","label":"Kansas (2025, Blue Alt)"},{"displayName":"KSU_HELMET_2021_SILVER_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KSU_HELMET_2021_SILVER_Acc_preset","label":"Kansas State (2021, Silver)"},{"displayName":"KENN_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENN_HELMET_2021_YELLOW_Acc_preset","label":"Kennesaw State (2021, Yellow)"},{"displayName":"KENT_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2021_BLACK_Acc_preset","label":"Kent State (2021, Black)"},{"displayName":"KENT_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2021_GOLD_Acc_preset","label":"Kent State (2021, GOLD)"},{"displayName":"KENT_HELMET_2023_Navy_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2023_Navy_Acc_preset","label":"Kent State (2023, Navy)"},{"displayName":"UK_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2021_BLUE_Acc_preset","label":"Kentucky (2021, BLUE)"},{"displayName":"UK_HELMET_2022_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2022_BLACK_Acc_preset","label":"Kentucky (2022, Black)"},{"displayName":"UK_HELMET_2022_CHROME_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2022_CHROME_Acc_preset","label":"Kentucky (2022, Chrome)"},{"displayName":"UK_HELMET_2022_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2022_WHITE_Acc_preset","label":"Kentucky (2022, White)"},{"displayName":"LSU_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LSU_HELMET_2021_GOLD_Acc_preset","label":"LSU (2021, GOLD)"},{"displayName":"LSU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LSU_HELMET_2021_WHITE_Acc_preset","label":"LSU (2021, White)"},{"displayName":"LIB_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LIB_HELMET_2021_BLUE_Acc_preset","label":"Liberty (2021, BLUE)"},{"displayName":"LIB_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LIB_HELMET_2021_RED_Acc_preset","label":"Liberty (2021, RED)"},{"displayName":"LIB_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LIB_HELMET_2021_WHITE_Acc_preset","label":"Liberty (2021, White)"},{"displayName":"ULL_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULL_HELMET_2021_RED_Acc_preset","label":"Louisiana (2021, RED)"},{"displayName":"LT_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LT_HELMET_2021_RED_Acc_preset","label":"Louisiana Tech (2021, RED)"},{"displayName":"LT_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LT_HELMET_2021_WHITE_Acc_preset","label":"Louisiana Tech (2021, White)"},{"displayName":"ULM_HELMET_2016_CAMO_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULM_HELMET_2016_CAMO_Acc_preset","label":"Louisiana-Monroe (2016, CAMO)"},{"displayName":"ULM_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULM_HELMET_2021_WHITE_Acc_preset","label":"Louisiana-Monroe (2021, White)"},{"displayName":"LOU_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LOU_HELMET_2021_BLACK_Acc_preset","label":"Louisville (2021, Black)"},{"displayName":"LOU_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LOU_HELMET_2021_RED_Acc_preset","label":"Louisville (2021, RED)"},{"displayName":"LOU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LOU_HELMET_2021_WHITE_Acc_preset","label":"Louisville (2021, White)"},{"displayName":"MRSH_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MRSH_HELMET_2021_WHITE_Acc_preset","label":"Marshall (2021, White)"},{"displayName":"UMD_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMD_HELMET_2021_RED_Acc_preset","label":"Maryland (2021, RED)"},{"displayName":"UMD_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMD_HELMET_2021_WHITE_Acc_preset","label":"Maryland (2021, White)"},{"displayName":"MEM_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2021_BLUE_Acc_preset","label":"Memphis (2021, BLUE)"},{"displayName":"MEM_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2021_WHITE_Acc_preset","label":"Memphis (2021, White)"},{"displayName":"MEM_HELMET_2022_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2022_WHITE_Acc_preset","label":"Memphis (2022, White)"},{"displayName":"MEM_HELMET_2022_WHITEBLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2022_WHITEBLACK_Acc_preset","label":"Memphis (2022, Whiteblack)"},{"displayName":"MIA_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIA_HELMET_2021_WHITE_Acc_preset","label":"Miami (FL) (2021, White)"},{"displayName":"MIAOH_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIAOH_HELMET_2021_WHITE_Acc_preset","label":"Miami (OH) (2021, White)"},{"displayName":"MICH_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MICH_HELMET_2021_BLUE_Acc_preset","label":"Michigan (2021, BLUE)"},{"displayName":"MSU_HELMET_2015_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2015_GREEN_Acc_preset","label":"Michigan State (2015, Green)"},{"displayName":"MSU_HELMET_2017_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2017_WHITE_Acc_preset","label":"Michigan State (2017, White)"},{"displayName":"MSU_HELMET_2021_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2021_GREEN_Acc_preset","label":"Michigan State (2021, Green)"},{"displayName":"MSU_HELMET_2023_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2023_BLACK_Acc_preset","label":"Michigan State (2023, Black)"},{"displayName":"MTSU_HELMET_2021_GREY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTSU_HELMET_2021_GREY_Acc_preset","label":"Middle Tennessee (2021, GREY)"},{"displayName":"MTSU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTSU_HELMET_2021_WHITE_Acc_preset","label":"Middle Tennessee (2021, White)"},{"displayName":"MINN_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2021_RED_Acc_preset","label":"Minnesota (2021, RED)"},{"displayName":"MINN_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2021_YELLOW_Acc_preset","label":"Minnesota (2021, Yellow)"},{"displayName":"MSST_HELMET_2021_MAROON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSST_HELMET_2021_MAROON_Acc_preset","label":"Mississippi State (2021, Maroon)"},{"displayName":"MSST_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSST_HELMET_2021_WHITE_Acc_preset","label":"Mississippi State (2021, White)"},{"displayName":"MIZZ_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIZZ_HELMET_2021_BLACK_Acc_preset","label":"Missouri (2021, Black)"},{"displayName":"MIZZ_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIZZ_HELMET_2021_YELLOW_Acc_preset","label":"Missouri (2021, Yellow)"},{"displayName":"MTDEW_HELMET_2025_Alt_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTDEW_HELMET_2025_Alt_Acc_preset","label":"Mountain Dew (non-school / branded) (2025, Alt)"},{"displayName":"MTDEW_HELMET_2025_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTDEW_HELMET_2025_GREEN_Acc_preset","label":"Mountain Dew (non-school / branded) (2025, Green)"},{"displayName":"MTDEW_HELMET_2025_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTDEW_HELMET_2025_WHITE_Acc_preset","label":"Mountain Dew (non-school / branded) (2025, White)"},{"displayName":"NCST_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NCST_HELMET_2021_RED_Acc_preset","label":"NC State (2021, RED)"},{"displayName":"NCST_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NCST_HELMET_2021_WHITE_Acc_preset","label":"NC State (2021, White)"},{"displayName":"NAVY_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NAVY_HELMET_2021_GOLD_Acc_preset","label":"Navy (2021, GOLD)"},{"displayName":"NAVY_HELMET_2021_NAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NAVY_HELMET_2021_NAVY_Acc_preset","label":"Navy (2021, NAVY)"},{"displayName":"NEB_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEB_HELMET_2021_WHITE_Acc_preset","label":"Nebraska (2021, White)"},{"displayName":"NEV_HELMET_2021_SILVER_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEV_HELMET_2021_SILVER_Acc_preset","label":"Nevada (2021, Silver)"},{"displayName":"NEV_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEV_HELMET_2021_WHITE_Acc_preset","label":"Nevada (2021, White)"},{"displayName":"NEV_HELMET_2023_NAVYBLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEV_HELMET_2023_NAVYBLUE_Acc_preset","label":"Nevada (2023, Navyblue)"},{"displayName":"UNM_HELMET_2021_GRAY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_GRAY_Acc_preset","label":"New Mexico (2021, GRAY)"},{"displayName":"UNM_HELMET_2021_SILVER_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_SILVER_Acc_preset","label":"New Mexico (2021, Silver)"},{"displayName":"UNM_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_WHITE_Acc_preset","label":"New Mexico (2021, White)"},{"displayName":"UNM_HELMET_2023_SILVER_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2023_SILVER_Acc_preset","label":"New Mexico (2023, Silver)"},{"displayName":"NMSU_HELMET_2021_CRIMSON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NMSU_HELMET_2021_CRIMSON_Acc_preset","label":"New Mexico State (2021, Crimson)"},{"displayName":"UNC_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNC_HELMET_2021_BLUE_Acc_preset","label":"North Carolina (2021, BLUE)"},{"displayName":"UNC_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNC_HELMET_2021_WHITE_Acc_preset","label":"North Carolina (2021, White)"},{"displayName":"UNT_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_BLACK_Acc_preset","label":"North Texas (2021, Black)"},{"displayName":"UNT_HELMET_2021_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_GREEN_Acc_preset","label":"North Texas (2021, Green)"},{"displayName":"UNT_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_WHITE_Acc_preset","label":"North Texas (2021, White)"},{"displayName":"NIU_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NIU_HELMET_2021_BLACK_Acc_preset","label":"Northern Illinois (2021, Black)"},{"displayName":"NW_HELMET_2021_PURPLE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2021_PURPLE_Acc_preset","label":"Northwestern (2021, Purple)"},{"displayName":"NW_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2021_WHITE_Acc_preset","label":"Northwestern (2021, White)"},{"displayName":"NW_HELMET_2022_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2022_BLACK_Acc_preset","label":"Northwestern (2022, Black)"},{"displayName":"ND_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ND_HELMET_2021_GOLD_Acc_preset","label":"Notre Dame (2021, GOLD)"},{"displayName":"OHIO_HELMET_2023_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OHIO_HELMET_2023_GREEN_Acc_preset","label":"Ohio (2023, Green)"},{"displayName":"OSU_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OSU_HELMET_2021_BLACK_Acc_preset","label":"Ohio State (2021, Black)"},{"displayName":"OSU_HELMET_2021_GREY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OSU_HELMET_2021_GREY_Acc_preset","label":"Ohio State (2021, GREY)"},{"displayName":"OU_HELMET_2021_CRIMSON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_CRIMSON_Acc_preset","label":"Oklahoma (2021, Crimson)"},{"displayName":"OU_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_RED_Acc_preset","label":"Oklahoma (2021, RED)"},{"displayName":"OU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_WHITE_Acc_preset","label":"Oklahoma (2021, White)"},{"displayName":"OU_HELMET_2021_WOODCREAM_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_WOODCREAM_Acc_preset","label":"Oklahoma (2021, Woodcream)"},{"displayName":"OU_HELMET_2021_WOODCRIMSON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_WOODCRIMSON_Acc_preset","label":"Oklahoma (2021, Woodcrimson)"},{"displayName":"OKST_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2021_BLACK_Acc_preset","label":"Oklahoma State (2021, Black)"},{"displayName":"OKST_HELMET_2021_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2021_ORANGE_Acc_preset","label":"Oklahoma State (2021, Orange)"},{"displayName":"OKST_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2021_WHITE_Acc_preset","label":"Oklahoma State (2021, White)"},{"displayName":"ODU_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ODU_HELMET_2021_BLUE_Acc_preset","label":"Old Dominion (2021, BLUE)"},{"displayName":"ODU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ODU_HELMET_2021_WHITE_Acc_preset","label":"Old Dominion (2021, White)"},{"displayName":"MISS_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_BLUE_Acc_preset","label":"Ole Miss (2021, BLUE)"},{"displayName":"MISS_HELMET_2021_NAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_NAVY_Acc_preset","label":"Ole Miss (2021, NAVY)"},{"displayName":"MISS_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_WHITE_Acc_preset","label":"Ole Miss (2021, White)"},{"displayName":"ORE_HELMET_2021_WHITEGREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2021_WHITEGREEN_Acc_preset","label":"Oregon (2021, Whitegreen)"},{"displayName":"ORE_HELMET_2021_YELLOWSTEEL_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2021_YELLOWSTEEL_Acc_preset","label":"Oregon (2021, Yellowsteel)"},{"displayName":"ORE_HELMET_2023_EGGSHELL_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2023_EGGSHELL_Acc_preset","label":"Oregon (2023, Eggshell)"},{"displayName":"ORST_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORST_HELMET_2021_BLACK_Acc_preset","label":"Oregon State (2021, Black)"},{"displayName":"ORST_HELMET_2023_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORST_HELMET_2023_ORANGE_Acc_preset","label":"Oregon State (2023, Orange)"},{"displayName":"PSU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PSU_HELMET_2021_WHITE_Acc_preset","label":"Penn State (2021, White)"},{"displayName":"PSU_HELMET_2022_WHITESTRIPE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PSU_HELMET_2022_WHITESTRIPE_Acc_preset","label":"Penn State (2022, Whitestripe)"},{"displayName":"PITT_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PITT_HELMET_2021_YELLOW_Acc_preset","label":"Pittsburgh (2021, Yellow)"},{"displayName":"PUR_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2021_BLACK_Acc_preset","label":"Purdue (2021, Black)"},{"displayName":"PUR_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2021_GOLD_Acc_preset","label":"Purdue (2021, GOLD)"},{"displayName":"PUR_HELMET_2023_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2023_GOLD_Acc_preset","label":"Purdue (2023, GOLD)"},{"displayName":"RICE_HELMET_2021_NAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RICE_HELMET_2021_NAVY_Acc_preset","label":"Rice (2021, NAVY)"},{"displayName":"RICE_HELMET_2021_SILVER_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RICE_HELMET_2021_SILVER_Acc_preset","label":"Rice (2021, Silver)"},{"displayName":"RUTG_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RUTG_HELMET_2021_RED_Acc_preset","label":"Rutgers (2021, RED)"},{"displayName":"SMU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SMU_HELMET_2021_WHITE_Acc_preset","label":"SMU (2021, White)"},{"displayName":"SMU_HELMET_2021_WHITEALT_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SMU_HELMET_2021_WHITEALT_Acc_preset","label":"SMU (2021, Whitealt)"},{"displayName":"SHSU_HELMET_2021_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SHSU_HELMET_2021_ORANGE_Acc_preset","label":"Sam Houston State (2021, Orange)"},{"displayName":"SHSU_HELMET_2023_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SHSU_HELMET_2023_ORANGE_Acc_preset","label":"Sam Houston State (2023, Orange)"},{"displayName":"SDSU_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SDSU_HELMET_2021_BLACK_Acc_preset","label":"San Diego State (2021, Black)"},{"displayName":"SJSU_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SJSU_HELMET_2021_BLUE_Acc_preset","label":"San Jose State (2021, BLUE)"},{"displayName":"SJSU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SJSU_HELMET_2021_WHITE_Acc_preset","label":"San Jose State (2021, White)"},{"displayName":"USA_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USA_HELMET_2021_WHITE_Acc_preset","label":"South Alabama (2021, White)"},{"displayName":"SC_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SC_HELMET_2021_BLACK_Acc_preset","label":"South Carolina (2021, Black)"},{"displayName":"SC_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SC_HELMET_2021_RED_Acc_preset","label":"South Carolina (2021, RED)"},{"displayName":"SC_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SC_HELMET_2021_WHITE_Acc_preset","label":"South Carolina (2021, White)"},{"displayName":"USF_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USF_HELMET_2021_GOLD_Acc_preset","label":"South Florida (2021, GOLD)"},{"displayName":"USF_HELMET_2021_WHITEGREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USF_HELMET_2021_WHITEGREEN_Acc_preset","label":"South Florida (2021, Whitegreen)"},{"displayName":"USM_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USM_HELMET_2021_BLACK_Acc_preset","label":"Southern Miss (2021, Black)"},{"displayName":"USM_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USM_HELMET_2021_WHITE_Acc_preset","label":"Southern Miss (2021, White)"},{"displayName":"STAN_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2021_WHITE_Acc_preset","label":"Stanford (2021, White)"},{"displayName":"STAN_HELMET_2023_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2023_BLACK_Acc_preset","label":"Stanford (2023, Black)"},{"displayName":"SYR_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SYR_HELMET_2021_WHITE_Acc_preset","label":"Syracuse (2021, White)"},{"displayName":"TCU_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TCU_HELMET_2021_BLACK_Acc_preset","label":"TCU (2021, Black)"},{"displayName":"TCU_HELMET_2021_PURPLE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TCU_HELMET_2021_PURPLE_Acc_preset","label":"TCU (2021, Purple)"},{"displayName":"TEMP_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2021_RED_Acc_preset","label":"Temple (2021, RED) [TEMP]"},{"displayName":"TEM_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEM_HELMET_2021_RED_Acc_preset","label":"Temple (2021, RED) [TEM]"},{"displayName":"TEM_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEM_HELMET_2021_WHITE_Acc_preset","label":"Temple (2021, White)"},{"displayName":"TEMP_HELMET_2025_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2025_RED_Acc_preset","label":"Temple (2025, RED)"},{"displayName":"TEMP_HELMET_2025_WHI_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2025_WHI_Acc_preset","label":"Temple (2025, WHI)"},{"displayName":"TENN_HELMET_2021_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2021_ORANGE_Acc_preset","label":"Tennessee (2021, Orange)"},{"displayName":"TENN_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2021_WHITE_Acc_preset","label":"Tennessee (2021, White)"},{"displayName":"TENN_HELMET_2022_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2022_BLACK_Acc_preset","label":"Tennessee (2022, Black)"},{"displayName":"TENN_HELMET_2025_Smokey_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2025_Smokey_Acc_preset","label":"Tennessee (2025, Smokey)"},{"displayName":"TEX_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEX_HELMET_2021_WHITE_Acc_preset","label":"Texas (2021, White)"},{"displayName":"TAMU_HELMET_2021_MAROON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TAMU_HELMET_2021_MAROON_Acc_preset","label":"Texas A&M (2021, Maroon)"},{"displayName":"TXST_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TXST_HELMET_2021_GOLD_Acc_preset","label":"Texas State (2021, GOLD)"},{"displayName":"TTU_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2021_BLACK_Acc_preset","label":"Texas Tech (2021, Black)"},{"displayName":"TTU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2021_WHITE_Acc_preset","label":"Texas Tech (2021, White)"},{"displayName":"TOL_HELMET_2021_NAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TOL_HELMET_2021_NAVY_Acc_preset","label":"Toledo (2021, NAVY)"},{"displayName":"TOL_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TOL_HELMET_2021_YELLOW_Acc_preset","label":"Toledo (2021, Yellow)"},{"displayName":"TROY_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TROY_HELMET_2021_RED_Acc_preset","label":"Troy (2021, RED)"},{"displayName":"TROY_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TROY_HELMET_2021_WHITE_Acc_preset","label":"Troy (2021, White)"},{"displayName":"TULN_HELMET_2021_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2021_GREEN_Acc_preset","label":"Tulane (2021, Green)"},{"displayName":"TULN_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2021_WHITE_Acc_preset","label":"Tulane (2021, White)"},{"displayName":"TULN_HELMET_2025_CITY_EDITION_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2025_CITY_EDITION_Acc_preset","label":"Tulane (2025, CITY Edition)"},{"displayName":"TULN_HELMET_2025_Wumbu_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2025_Wumbu_Acc_preset","label":"Tulane (2025, Wumbu)"},{"displayName":"TLSA_HELMET_2023_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TLSA_HELMET_2023_GOLD_Acc_preset","label":"Tulsa (2023, GOLD)"},{"displayName":"UAB_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UAB_HELMET_2021_GOLD_Acc_preset","label":"UAB (2021, GOLD)"},{"displayName":"UAB_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UAB_HELMET_2021_WHITE_Acc_preset","label":"UAB (2021, White)"},{"displayName":"UCF_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2021_GOLD_Acc_preset","label":"UCF (2021, GOLD)"},{"displayName":"UCF_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2021_WHITE_Acc_preset","label":"UCF (2021, White)"},{"displayName":"UCF_HELMET_2023_SPACE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2023_SPACE_Acc_preset","label":"UCF (2023, Space)"},{"displayName":"UCLA_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCLA_HELMET_2021_GOLD_Acc_preset","label":"UCLA (2021, GOLD)"},{"displayName":"UCLA_HELMET_2023_GOLDALT_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCLA_HELMET_2023_GOLDALT_Acc_preset","label":"UCLA (2023, Goldalt)"},{"displayName":"CONN_HELMET_2021_NAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CONN_HELMET_2021_NAVY_Acc_preset","label":"UConn (2021, NAVY)"},{"displayName":"CONN_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CONN_HELMET_2021_WHITE_Acc_preset","label":"UConn (2021, White)"},{"displayName":"UMASS_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMASS_HELMET_2021_RED_Acc_preset","label":"UMass (2021, RED)"},{"displayName":"UMASS_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMASS_HELMET_2021_WHITE_Acc_preset","label":"UMass (2021, White)"},{"displayName":"UNLV_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2021_RED_Acc_preset","label":"UNLV (2021, RED)"},{"displayName":"UNLV_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2021_WHITE_Acc_preset","label":"UNLV (2021, White)"},{"displayName":"USC_HELMET_2021_CARDINAL_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USC_HELMET_2021_CARDINAL_Acc_preset","label":"USC (2021, Cardinal)"},{"displayName":"USC_HELMET_2021_CARDINALCHROME_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USC_HELMET_2021_CARDINALCHROME_Acc_preset","label":"USC (2021, Cardinalchrome)"},{"displayName":"UTEP_HELMET_2021_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTEP_HELMET_2021_ORANGE_Acc_preset","label":"UTEP (2021, Orange)"},{"displayName":"UTEP_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTEP_HELMET_2021_WHITE_Acc_preset","label":"UTEP (2021, White)"},{"displayName":"UTEP_HELMET_2025_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTEP_HELMET_2025_BLUE_Acc_preset","label":"UTEP (2025, BLUE)"},{"displayName":"UTSA_HELMET_2021_NAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTSA_HELMET_2021_NAVY_Acc_preset","label":"UTSA (2021, NAVY)"},{"displayName":"UTSA_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTSA_HELMET_2021_WHITE_Acc_preset","label":"UTSA (2021, White)"},{"displayName":"UTAH_HELMET_2020_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2020_WHITE_Acc_preset","label":"Utah (2020, White)"},{"displayName":"UTAH_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2021_RED_Acc_preset","label":"Utah (2021, RED)"},{"displayName":"UTAH_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2021_WHITE_Acc_preset","label":"Utah (2021, White)"},{"displayName":"USU_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USU_HELMET_2021_BLACK_Acc_preset","label":"Utah State (2021, Black)"},{"displayName":"USU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USU_HELMET_2021_WHITE_Acc_preset","label":"Utah State (2021, White)"},{"displayName":"VAN_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VAN_HELMET_2021_GOLD_Acc_preset","label":"Vanderbilt (2021, GOLD)"},{"displayName":"VAN_HELMET_2022_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VAN_HELMET_2022_WHITE_Acc_preset","label":"Vanderbilt (2022, White)"},{"displayName":"UVA_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UVA_HELMET_2021_BLUE_Acc_preset","label":"Virginia (2021, BLUE)"},{"displayName":"UVA_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UVA_HELMET_2021_WHITE_Acc_preset","label":"Virginia (2021, White)"},{"displayName":"VT_HELMET_2016_MAROON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2016_MAROON_Acc_preset","label":"Virginia Tech (2016, Maroon)"},{"displayName":"VT_HELMET_2016_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2016_WHITE_Acc_preset","label":"Virginia Tech (2016, White)"},{"displayName":"VT_HELMET_2021_MAROON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2021_MAROON_Acc_preset","label":"Virginia Tech (2021, Maroon)"},{"displayName":"VT_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2021_WHITE_Acc_preset","label":"Virginia Tech (2021, White)"},{"displayName":"WAKE_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WAKE_HELMET_2021_BLACK_Acc_preset","label":"Wake Forest (2021, Black)"},{"displayName":"WASH_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2021_GOLD_Acc_preset","label":"Washington (2021, GOLD)"},{"displayName":"WASH_HELMET_2021_GOLDCHROME_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2021_GOLDCHROME_Acc_preset","label":"Washington (2021, Goldchrome)"},{"displayName":"WASH_HELMET_2023_PURPLECHROME_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2023_PURPLECHROME_Acc_preset","label":"Washington (2023, Purplechrome)"},{"displayName":"WSU_HELMET_2021_DARKGRAY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WSU_HELMET_2021_DARKGRAY_Acc_preset","label":"Washington State (2021, Darkgray)"},{"displayName":"WSU_HELMET_2021_GRAY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WSU_HELMET_2021_GRAY_Acc_preset","label":"Washington State (2021, GRAY)"},{"displayName":"WVU_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2021_BLUE_Acc_preset","label":"West Virginia (2021, BLUE)"},{"displayName":"WVU_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2021_YELLOW_Acc_preset","label":"West Virginia (2021, Yellow)"},{"displayName":"WKU_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2021_BLACK_Acc_preset","label":"Western Kentucky (2021, Black)"},{"displayName":"WKU_HELMET_2021_CHROME_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2021_CHROME_Acc_preset","label":"Western Kentucky (2021, Chrome)"},{"displayName":"WKU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2021_WHITE_Acc_preset","label":"Western Kentucky (2021, White)"},{"displayName":"WMU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WMU_HELMET_2021_WHITE_Acc_preset","label":"Western Michigan (2021, White)"},{"displayName":"WIS_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WIS_HELMET_2021_WHITE_Acc_preset","label":"Wisconsin (2021, White)"},{"displayName":"WYO_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WYO_HELMET_2021_WHITE_Acc_preset","label":"Wyoming (2021, White)"}]},"decals":[{"label":"Adidas (2023)","brand":"Adidas","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_rsm"},{"label":"Adidas (2022)","brand":"Adidas","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2022_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2022_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2022_rsm"},{"label":"Adidas Plastic (2023)","brand":"Adidas","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_Plastic_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_Plastic_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_Plastic_rsm"},{"label":"Adidas Shiny (2023)","brand":"Adidas","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_Shiny_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_Shiny_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_Shiny_rsm"},{"label":"Adidas WithText (2023)","brand":"Adidas","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_WithText_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_WithText_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_WithText_rsm"},{"label":"Jumpman Cotton (2022)","brand":"Jumpman","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Jumpman_Decal_2022_Cotton_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Jumpman_Decal_2022_Cotton_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Jumpman_Decal_2022_Cotton_rsm"},{"label":"Jumpman Diamond (2022)","brand":"Jumpman","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Jumpman_Decal_2022_Diamond_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Jumpman_Decal_2022_Diamond_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Jumpman_Decal_2022_Diamond_rsm"},{"label":"Nike Cotton (2022)","brand":"Nike","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Nike_Decal_2022_Cotton_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Nike_Decal_2022_Cotton_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Nike_Decal_2022_Cotton_rsm"},{"label":"Nike Diamond (2022)","brand":"Nike","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Nike_Decal_2022_Diamond_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Nike_Decal_2022_Diamond_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Nike_Decal_2022_Diamond_rsm"},{"label":"Nike Plastic (2023)","brand":"Nike","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Nike_Decal_2023_Plastic_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Nike_Decal_2023_Plastic_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Nike_Decal_2023_Plastic_rsm"},{"label":"Under Armour Cotton (2022)","brand":"Under Armour","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2022_Cotton_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2022_Cotton_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2022_Cotton_rsm"},{"label":"Under Armour Metallic (2022)","brand":"Under Armour","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2022_Metallic_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2022_Metallic_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2022_Metallic_rsm"},{"label":"Under Armour Cotton 02 (2023)","brand":"Under Armour","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2023_Cotton_02_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2023_Cotton_02_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2023_Cotton_02_rsm"},{"label":"Under Armour Cotton (2023)","brand":"Under Armour","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2023_Cotton_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2023_Cotton_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2023_Cotton_rsm"},{"label":"Under Armour Plastic (2023)","brand":"Under Armour","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2023_Plastic_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2023_Plastic_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2023_Plastic_rsm"},{"label":"Nike ShoeDuck (2025)","brand":"Nike","col":"content/characters/player/parts/uniforms/decals/vendors/NIKE_Decal_2025_ShoeDuck_col","norm":"content/characters/player/parts/uniforms/decals/vendors/NIKE_Decal_2025_ShoeDuck_norm","rsm":"content/characters/player/parts/uniforms/decals/vendors/NIKE_Decal_2025_ShoeDuck_rsm"}]};

const state = {
  extensionId: null, // unused now -- this page is bundled in the extension, so messaging is internal
  urls: [],
  selectedUrl: null,
  payload: null,
  variants: [],
  selectedVariantIdx: 0,
  originalRawText: '', // snapshot taken when a payload is first fetched, for Reset to loaded
  spacingOriginals: {}, // jerseyKey -> the numberSpacing.x value seen the first time it was rendered, for the per-field reset button
  lastSelections: {} // gsKey -> last applied text, so the picker shows what was actually chosen
};

// Bump this with every round of changes to this tool. See CHANGELOG.md for what
// each version actually changed.
const EDITOR_VERSION = 'v0.32';

// ---------- logging ----------
function log(msg, level = '') {
  const el = document.getElementById('logOut');
  const div = document.createElement('div');
  div.className = 'entry' + (level ? ' ' + level : '');
  const ts = new Date().toLocaleTimeString();
  div.innerHTML = `<span class="ts">${ts}</span>${escapeHtml(msg)}`;
  el.appendChild(div);
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

// ---------- extension messaging ----------
// This page is bundled inside the extension itself (opened via the toolbar icon),
// so messages go through chrome.runtime.sendMessage() with no target ID -- that
// routes to this same extension's own background.js via chrome.runtime.onMessage,
// which now shares its handling logic with the external-facing API.
function sendToExtension(type, extra = {}) {
  return new Promise((resolve, reject) => {
    if (!window.chrome || !chrome.runtime || !chrome.runtime.sendMessage) {
      reject(new Error('chrome.runtime is unavailable. This page must be opened as chrome-extension://…/editor.html, not a regular file or web page.'));
      return;
    }
    try {
      chrome.runtime.sendMessage(Object.assign({ type }, extra), (response) => {
        if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
        if (!response) { reject(new Error('No response from background.js.')); return; }
        if (response.ok === false) { reject(new Error(response.error || 'Extension returned an error.')); return; }
        resolve(response);
      });
    } catch (err) { reject(err); }
  });
}

// ---------- status / urls ----------
document.getElementById('btnStatus').addEventListener('click', refreshStatus);
async function refreshStatus() {
  try {
    const r = await sendToExtension('TB_GET_STATUS');
    state.urls = r.urls || [];
    renderStatus(r);
    renderUrlList();
    log('Status refreshed — helper v' + r.helperVersion + ', ' + state.urls.length + ' known URL(s).', 'ok');
  } catch (err) {
    document.getElementById('statusOut').innerHTML = `<div class="badge err">error</div> ${escapeHtml(err.message)}`;
    log('Status refresh failed: ' + err.message, 'err');
  }
}

function renderStatus(r) {
  const s = r.status || {};
  const nm = s.networkMocking || {};
  const lastHit = s.lastMockHit;
  document.getElementById('statusOut').innerHTML = `
    <div class="status-grid">
      <div>Helper version: <b>${escapeHtml(r.helperVersion || '—')}</b></div>
      <div>Active page key: <b>${escapeHtml(r.activePage?.pageKey || '—')}</b></div>
      <div>Network mocking: <b>${nm.enabled ? 'enabled' : 'off'}</b></div>
      <div>Mocks stored: <b>${Object.keys(r.mocks || {}).length}</b></div>
      <div style="grid-column:1 / -1;">Last mock hit: <b>${lastHit ? escapeHtml(lastHit.teamName || lastHit.url) + ' @ ' + new Date(lastHit.usedAt).toLocaleTimeString() : '—'}</b></div>
    </div>`;
}

function renderUrlList() {
  const el = document.getElementById('urlListOut');
  if (!state.urls.length) { el.innerHTML = '<div class="hint">No nonce-primary.json URLs discovered yet — open a team in Team Builder, then refresh status.</div>'; return; }
  el.innerHTML = '<div class="urllist">' + state.urls.map((u, i) => `
    <div class="urlitem${u.url === state.selectedUrl ? ' selected' : ''}" data-idx="${i}">${escapeHtml(u.url)}</div>
  `).join('') + '</div>';
  el.querySelectorAll('.urlitem').forEach(node => {
    node.addEventListener('click', () => {
      state.selectedUrl = state.urls[+node.dataset.idx].url;
      document.getElementById('urlManual').value = state.selectedUrl;
      renderUrlList();
    });
  });
}

// ---------- fetch / parse payload ----------
document.getElementById('btnFetch').addEventListener('click', fetchPayload);
async function fetchPayload() {
  let url = document.getElementById('urlManual').value.trim();
  if (!url && state.urls.length) {
    url = state.urls[0].url;
    document.getElementById('urlManual').value = url;
    log('No URL selected — using the top discovered one automatically.');
  }
  if (!url) { log('No URL entered, and none discovered yet — click "Refresh status" first.', 'err'); return; }
  state.selectedUrl = url;
  try {
    const r = await sendToExtension('TB_FETCH_JSON', { url });
    document.getElementById('rawText').value = r.text;
    state.originalRawText = r.text;
    loadFromRawText();
    log('Fetched payload (' + r.text.length + ' chars).', 'ok');
  } catch (err) {
    log('Fetch failed: ' + err.message, 'err');
  }
}

document.getElementById('btnResync').addEventListener('click', loadFromRawText);
function loadFromRawText() {
  const raw = document.getElementById('rawText').value;
  try {
    state.payload = JSON.parse(raw);
  } catch (err) {
    log('Could not parse current text as JSON: ' + err.message, 'err');
    return;
  }
  state.variants = deriveVariants(state.payload);
  state.selectedVariantIdx = 0;
  state.lastSelections = {};
  state.spacingOriginals = {};
  const teamName = state.payload?.teamData?.teamInfos?.TEAM_NAME;
  document.getElementById('teamNameBadge').textContent = teamName ? ' — ' + teamName : '';
  renderEditor();
}

function deriveVariants(payload) {
  const helmets = payload?.teamData?.frostbiteData?.uniformParts?.helmets || {};
  const jerseys = payload?.teamData?.frostbiteData?.uniformParts?.jerseys || {};
  const pants = payload?.teamData?.frostbiteData?.uniformParts?.pants || {};
  const socks = payload?.teamData?.frostbiteData?.uniformParts?.socks || {};
  const suffixOf = (key, kind) => {
    // Was [A-Za-z0-9]+ -- too narrow. Confirmed real variant names contain
    // parentheses ("DarkMode(Home)", "1920s(Reimagined)") and possibly other
    // punctuation, which that pattern silently failed to match, dropping the
    // whole variant from the list. This is deliberately permissive (any
    // character) since there's no reliable way to enumerate every symbol a
    // team name might use -- the only real constraint is that it can't be
    // followed by another "-<kind>" later in the string, which greedy
    // matching against the trailing $ already handles correctly.
    const m = key.match(new RegExp('-(.+)-' + kind + '$', 'i'));
    return m ? m[1] : null;
  };
  const suffixes = new Set();
  Object.keys(helmets).forEach(k => { const s = suffixOf(k, 'helmet'); if (s) suffixes.add(s); });
  Object.keys(jerseys).forEach(k => { const s = suffixOf(k, 'jersey'); if (s) suffixes.add(s); });
  Object.keys(pants).forEach(k => { const s = suffixOf(k, 'pants'); if (s) suffixes.add(s); });
  Object.keys(socks).forEach(k => { const s = suffixOf(k, 'socks'); if (s) suffixes.add(s); });
  return [...suffixes].map(suffix => ({
    label: suffix.replace(/([a-z])([A-Z])/g, '$1 $2'),
    suffix,
    helmetKey: Object.keys(helmets).find(k => suffixOf(k, 'helmet') === suffix) || null,
    jerseyKey: Object.keys(jerseys).find(k => suffixOf(k, 'jersey') === suffix) || null,
    pantsKey: Object.keys(pants).find(k => suffixOf(k, 'pants') === suffix) || null,
    socksKey: Object.keys(socks).find(k => suffixOf(k, 'socks') === suffix) || null
  }));
}

// ---------- deep get/set ----------
function getDeep(obj, path) {
  let cur = obj;
  for (const p of path) { if (cur == null) return undefined; cur = cur[p]; }
  return cur;
}
function setDeep(obj, path, value) {
  let cur = obj;
  for (let i = 0; i < path.length - 1; i++) {
    if (cur[path[i]] == null) return false;
    cur = cur[path[i]];
  }
  cur[path[path.length - 1]] = value;
  return true;
}

// ---------- field definitions ----------
function isUsableFontPath(p) { return !!p && !/\/(numbers|name_fonts)\/?$/i.test(p); }

// Confirmed by testing: /comp/ isn't needed at all. Both arrayTexture.textureId and
// the overlay's textureId work fine set to the exact same non-/comp/ path. The real
// original bug was simply that arrayTexture can't be left blank -- it was never about
// the two fields needing different path shapes. This strips /comp/ from whatever the
// catalog has on record (most entries have it, a few newer ones don't), so both
// targets always get the same normalized, confirmed-working form.
function stripCompSegment(path) {
  return path.replace('/uniforms/comp/', '/uniforms/');
}

// ---------- per-font number layout profiles ----------
// A font isn't just a texture swap -- correctly rendering it also depends on
// fields the old font-picker never touched: the flat numberSpacing.x the
// slider exposes, a per-number kerning correction table
// (numberMaterialSettings.playerNumberAdjust), AND four offset/scale blocks
// (chest/back/shoulder/sleeve) that control where each number sits and how
// big it renders -- confirmed as the actual cause of numbers sitting too
// high/low or too big/small when a font is swapped without them, since those
// values were calibrated for whatever font was there before, not the new one.
//
// v0.24 shipped a first pass sourced from ARIZ_JERSEY_2023_BLUE.xml (base
// item, empty PlayerNumberAdjList) + ARIZ_MixAndMatch.xml (Mix & Match
// FootballMixMatchPart entry) stitched together. SUPERSEDED here --
// ARIZ_JERSEY_2026_PRABLUE.xml (a JerseyPartItem, matching the "Arizona
// (2026)" catalog entry by name) turned out to be a cleaner, more direct
// source: it carries numberMaterialSettings.PlayerNumberAdjList (and the four
// offset/scale blocks) directly on the base item itself, at the exact
// nesting level the live JSON uses (sibling to offsetScaleSpacing, no Mix &
// Match indirection needed). Corrected values below replace the v0.24 ones:
// numberSpacing -0.36 -> -0.41, Number 11 -0.59 -> -0.67, and a second real
// outlier surfaced that the empty v0.24 source couldn't show at all --
// Number 31 at -0.58, distinct from every other non-11 entry at -0.53.
//
// CAVEAT: this same source file has hasShoulder=false and hasSleeve=false --
// Arizona's own jersey doesn't use those number positions at all. Its
// shoulderNumberOffsetScale/sleeveNumberOffsetScale values below are
// structurally present but were never actually rendered or eyeballed for
// this font, unlike chest/back which Arizona's jersey does use. Worth
// specifically testing this font on a team whose jersey DOES have shoulder
// or sleeve numbers before trusting those two fields.
//
// This is a lookup, not hardcoded logic, on purpose: adding the next font
// once its reference data is confirmed is one more entry here, no code
// changes. Keyed by font displayName (matches CATALOG.numberFonts.jersey
// entries' own displayName field).
//
// STATUS: Arizona (2026) is the first entry -- still a test case, not yet
// confirmed in-game even in this corrected form. Don't add more until this
// one's confirmed to actually move things in Team Builder, not just write
// without error.
const NUMBER_LAYOUT_PROFILES = {
  // ---- All fonts below: batch-imported from All_uniforms_TB.zip (v0.30/v0.31) ----
  // Matched by resolving each file's numberComp ref -> TintArrayTexture instance
  // -> Overlay_1.textures.colorTexture ref -> font asset name, not by filename.
  // Teams sharing a font each keep their OWN entry+values (v0.31) rather than
  // one shared entry -- picking one team's font never changes another team's.
  // A few pure same-team/same-font duplicates were merged back into their
  // original catalog slot in this pass (see CHANGELOG v0.32).
  'AFA_Jersey_2021_NUM_Array': {
    numberSpacing: -0.334362,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.73 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'AFA_Jersey_2025_Alt_NUM_Array': {
    numberSpacing: -0.65,
    playerNumberAdjust: [
      { number: 10, width: -0.65 }, { number: 11, width: -0.65 }, { number: 12, width: -0.65 },
      { number: 13, width: -0.65 }, { number: 14, width: -0.65 }, { number: 15, width: -0.65 },
      { number: 16, width: -0.65 }, { number: 17, width: -0.68 }, { number: 18, width: -0.65 },
      { number: 19, width: -0.65 }, { number: 21, width: -0.65 }, { number: 31, width: -0.65 },
      { number: 41, width: -0.65 }, { number: 51, width: -0.65 }, { number: 61, width: -0.65 },
      { number: 71, width: -0.68 }, { number: 81, width: -0.65 }, { number: 91, width: -0.65 }
    ]
  },
  'AKR_Jersey_2025_NUM_Array': {
    numberSpacing: -0.424,
    playerNumberAdjust: [
      { number: 10, width: -0.49 }, { number: 11, width: -0.72 }, { number: 12, width: -0.49 },
      { number: 13, width: -0.49 }, { number: 14, width: -0.49 }, { number: 15, width: -0.49 },
      { number: 16, width: -0.49 }, { number: 17, width: -0.49 }, { number: 18, width: -0.49 },
      { number: 19, width: -0.49 }, { number: 21, width: -0.49 }, { number: 31, width: -0.49 },
      { number: 41, width: -0.49 }, { number: 51, width: -0.49 }, { number: 61, width: -0.49 },
      { number: 71, width: -0.49 }, { number: 81, width: -0.49 }, { number: 91, width: -0.49 }
    ]
  },
  'APP_JERSEY_2023_BLACK': {
    numberSpacing: -0.46,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.65 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.51 }, { number: 31, width: -0.51 },
      { number: 41, width: -0.51 }, { number: 51, width: -0.51 }, { number: 61, width: -0.51 },
      { number: 71, width: -0.51 }, { number: 81, width: -0.51 }, { number: 91, width: -0.51 }
    ]
  },
  // Reverted in v0.27: the four offset/scale blocks and numberSpacingOverrides
  // caused real in-game errors once tested and are pulled out entirely, not
  // just zeroed -- if either turns out to be needed later, treat it as a new
  // experiment on its own rather than restoring this. numberSpacing is set to
  // -0.48 here per direct in-game observation, overriding whatever any
  // reference XML said (-0.36 in v0.24, -0.41 in v0.25/26) -- this value
  // came from testing, not a file. playerNumberAdjust keeps the corrected
  // ARIZ_JERSEY_2026_PRABLUE.xml values (11 at -0.67, 31 at -0.58, everything
  // else at -0.53) since that part was never implicated in the errors.
  'ARIZ_Jersey_2026_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.67 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.53 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'ARK_Jersey_2021_NUM_Array': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.63 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'ARK_Jersey_2023_NUM_Array': {
    numberSpacing: -0.39,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.68 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.54 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'ARMY_Jersey_2021_NUM_Array': {
    numberSpacing: -0.404939115,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.66 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.59 }, { number: 15, width: -0.59 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'ARMY_Jersey_2024_NUM_Array': {
    numberSpacing: -0.52,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.64 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.59 }, { number: 15, width: -0.59 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 40, width: -0.47 }, { number: 41, width: -0.57 }, { number: 42, width: -0.49 },
      { number: 43, width: -0.47 }, { number: 44, width: -0.45 }, { number: 45, width: -0.47 },
      { number: 46, width: -0.47 }, { number: 47, width: -0.51 }, { number: 48, width: -0.47 },
      { number: 49, width: -0.51 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'ARMY_Jersey_2025_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.66 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'ARST_Jersey_2023_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.61 }, { number: 11, width: -0.69 }, { number: 12, width: -0.61 },
      { number: 13, width: -0.61 }, { number: 14, width: -0.61 }, { number: 15, width: -0.61 },
      { number: 16, width: -0.61 }, { number: 17, width: -0.61 }, { number: 18, width: -0.61 },
      { number: 19, width: -0.61 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.59 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'ASU_JERSEY_2025_BLACK': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.7 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.6 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.6 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.6 }, { number: 31, width: -0.6 },
      { number: 41, width: -0.6 }, { number: 51, width: -0.6 }, { number: 61, width: -0.6 },
      { number: 71, width: -0.6 }, { number: 81, width: -0.6 }, { number: 91, width: -0.6 }
    ]
  },
  'ASU_JERSEY_2025_THROWBACK': {
    numberSpacing: -0.47,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.68 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'ASU_Jersey_2025_02_NUM_Array': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.64 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'AUB_Jersey_2023_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.64 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.56 }, { number: 51, width: -0.56 }, { number: 61, width: -0.56 },
      { number: 71, width: -0.56 }, { number: 81, width: -0.56 }, { number: 91, width: -0.56 }
    ]
  },
  'BALL_JERSEY_2024_BLACK': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.62 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'BAY_Jersey_2021_NUM_Array': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.75 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.6 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.6 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.6 }, { number: 31, width: -0.6 },
      { number: 41, width: -0.6 }, { number: 51, width: -0.6 }, { number: 61, width: -0.6 },
      { number: 71, width: -0.6 }, { number: 81, width: -0.6 }, { number: 91, width: -0.6 }
    ]
  },
  'BC_Jersey_2025_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.75 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.6 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.6 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.6 }, { number: 31, width: -0.6 },
      { number: 41, width: -0.6 }, { number: 51, width: -0.6 }, { number: 61, width: -0.6 },
      { number: 71, width: -0.6 }, { number: 81, width: -0.6 }, { number: 91, width: -0.6 }
    ]
  },
  'BGSU_JERSEY_2023_BROWN': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.59 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'BSU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.68 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.6 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.55 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.62 }, { number: 51, width: -0.59 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.59 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'BUFF_JERSEY_2023_BLUE': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.7 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.56 }, { number: 15, width: -0.61 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'BYU_JERSEY_2023_BLACK': {
    numberSpacing: -0.49,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.66 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.56 }, { number: 51, width: -0.56 }, { number: 61, width: -0.56 },
      { number: 71, width: -0.56 }, { number: 81, width: -0.56 }, { number: 91, width: -0.56 }
    ]
  },
  'BYU_Jersey_2024_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.62 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'CCAR_Jersey_2021_02_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.63 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.54 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'CHAR_Jersey_2025_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.51 }, { number: 11, width: -0.62 }, { number: 12, width: -0.51 },
      { number: 13, width: -0.51 }, { number: 14, width: -0.51 }, { number: 15, width: -0.51 },
      { number: 16, width: -0.51 }, { number: 17, width: -0.51 }, { number: 18, width: -0.51 },
      { number: 19, width: -0.51 }, { number: 21, width: -0.51 }, { number: 31, width: -0.51 },
      { number: 40, width: -0.38 }, { number: 41, width: -0.51 }, { number: 42, width: -0.38 },
      { number: 43, width: -0.38 }, { number: 44, width: -0.32 }, { number: 45, width: -0.38 },
      { number: 46, width: -0.38 }, { number: 48, width: -0.38 }, { number: 49, width: -0.38 },
      { number: 51, width: -0.51 }, { number: 61, width: -0.51 }, { number: 71, width: -0.51 },
      { number: 81, width: -0.51 }, { number: 91, width: -0.51 }
    ]
  },
  'CIN_Jersey_2025_NUM_Array': {
    numberSpacing: -0.39,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.59 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.55 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.5 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.5 }, { number: 24, width: -0.35 },
      { number: 27, width: -0.35 }, { number: 31, width: -0.5 }, { number: 34, width: -0.35 },
      { number: 37, width: -0.35 }, { number: 40, width: -0.35 }, { number: 41, width: -0.45 },
      { number: 42, width: -0.35 }, { number: 43, width: -0.35 }, { number: 44, width: -0.33 },
      { number: 45, width: -0.35 }, { number: 46, width: -0.35 }, { number: 47, width: -0.35 },
      { number: 48, width: -0.35 }, { number: 49, width: -0.35 }, { number: 51, width: -0.5 },
      { number: 54, width: -0.35 }, { number: 57, width: -0.35 }, { number: 61, width: -0.5 },
      { number: 64, width: -0.35 }, { number: 67, width: -0.35 }, { number: 71, width: -0.48 },
      { number: 74, width: -0.42 }, { number: 77, width: -0.35 }, { number: 81, width: -0.5 },
      { number: 84, width: -0.35 }, { number: 87, width: -0.35 }, { number: 91, width: -0.5 },
      { number: 94, width: -0.35 }, { number: 97, width: -0.35 }
    ]
  },
  'CLEM_JERSEY_2023_ORANGE': {
    numberSpacing: -0.39,
    playerNumberAdjust: [
      { number: 10, width: -0.47 }, { number: 11, width: -0.57 }, { number: 12, width: -0.47 },
      { number: 13, width: -0.47 }, { number: 14, width: -0.47 }, { number: 15, width: -0.47 },
      { number: 16, width: -0.47 }, { number: 17, width: -0.47 }, { number: 18, width: -0.47 },
      { number: 19, width: -0.47 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  },
  'CMU_JERSEY_2023_MAROON': {
    numberSpacing: -0.365,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.57 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.48 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.48 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.48 }, { number: 31, width: -0.48 },
      { number: 41, width: -0.48 }, { number: 51, width: -0.48 }, { number: 61, width: -0.48 },
      { number: 71, width: -0.48 }, { number: 81, width: -0.48 }, { number: 91, width: -0.48 }
    ]
  },
  'CMU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.56,
    playerNumberAdjust: [
      { number: 10, width: -0.64 }, { number: 11, width: -0.71 }, { number: 12, width: -0.64 },
      { number: 13, width: -0.64 }, { number: 14, width: -0.64 }, { number: 15, width: -0.64 },
      { number: 16, width: -0.64 }, { number: 17, width: -0.64 }, { number: 18, width: -0.64 },
      { number: 19, width: -0.64 }, { number: 21, width: -0.64 }, { number: 31, width: -0.64 },
      { number: 41, width: -0.64 }, { number: 51, width: -0.64 }, { number: 61, width: -0.64 },
      { number: 71, width: -0.64 }, { number: 81, width: -0.64 }, { number: 91, width: -0.64 }
    ]
  },
  'COLO_Jersey_2024_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.65 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.57 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.49 }, { number: 24, width: -0.44 },
      { number: 31, width: -0.49 }, { number: 34, width: -0.44 }, { number: 40, width: -0.39 },
      { number: 41, width: -0.49 }, { number: 42, width: -0.39 }, { number: 43, width: -0.39 },
      { number: 44, width: -0.38 }, { number: 45, width: -0.4 }, { number: 46, width: -0.38 },
      { number: 47, width: -0.43 }, { number: 48, width: -0.39 }, { number: 49, width: -0.39 },
      { number: 51, width: -0.53 }, { number: 54, width: -0.41 }, { number: 61, width: -0.49 },
      { number: 64, width: -0.43 }, { number: 71, width: -0.52 }, { number: 74, width: -0.54 },
      { number: 81, width: -0.49 }, { number: 84, width: -0.43 }, { number: 91, width: -0.49 },
      { number: 94, width: -0.43 }
    ]
  },
  'CONN_Jersey_2021_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.67 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.52 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.52 }, { number: 31, width: -0.52 },
      { number: 41, width: -0.52 }, { number: 51, width: -0.52 }, { number: 61, width: -0.52 },
      { number: 71, width: -0.52 }, { number: 81, width: -0.52 }, { number: 91, width: -0.52 }
    ]
  },
  'CSU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.46 }, { number: 11, width: -0.58 }, { number: 12, width: -0.46 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.46 }, { number: 15, width: -0.46 },
      { number: 16, width: -0.46 }, { number: 17, width: -0.46 }, { number: 18, width: -0.46 },
      { number: 19, width: -0.46 }, { number: 21, width: -0.5 }, { number: 24, width: -0.32 },
      { number: 31, width: -0.5 }, { number: 34, width: -0.32 }, { number: 41, width: -0.46 },
      { number: 42, width: -0.3 }, { number: 43, width: -0.3 }, { number: 44, width: -0.27 },
      { number: 45, width: -0.3 }, { number: 46, width: -0.3 }, { number: 47, width: -0.42 },
      { number: 48, width: -0.3 }, { number: 49, width: -0.3 }, { number: 51, width: -0.5 },
      { number: 54, width: -0.32 }, { number: 61, width: -0.5 }, { number: 64, width: -0.32 },
      { number: 71, width: -0.5 }, { number: 74, width: -0.42 }, { number: 81, width: -0.5 },
      { number: 84, width: -0.32 }, { number: 91, width: -0.5 }, { number: 94, width: -0.32 }
    ]
  },
  'DEL_Jersey_2024_NUM_Array': {
    numberSpacing: -0.59,
    playerNumberAdjust: [
      { number: 10, width: -0.63 }, { number: 11, width: -0.73 }, { number: 12, width: -0.63 },
      { number: 13, width: -0.63 }, { number: 14, width: -0.63 }, { number: 15, width: -0.63 },
      { number: 16, width: -0.63 }, { number: 17, width: -0.57 }, { number: 18, width: -0.63 },
      { number: 19, width: -0.63 }, { number: 21, width: -0.69 }, { number: 27, width: -0.53 },
      { number: 31, width: -0.69 }, { number: 37, width: -0.53 }, { number: 40, width: -0.58 },
      { number: 41, width: -0.69 }, { number: 43, width: -0.58 }, { number: 44, width: -0.58 },
      { number: 45, width: -0.58 }, { number: 46, width: -0.58 }, { number: 47, width: -0.51 },
      { number: 48, width: -0.58 }, { number: 49, width: -0.58 }, { number: 50, width: -0.58 },
      { number: 51, width: -0.69 }, { number: 52, width: -0.58 }, { number: 53, width: -0.58 },
      { number: 54, width: -0.58 }, { number: 55, width: -0.58 }, { number: 56, width: -0.58 },
      { number: 57, width: -0.51 }, { number: 58, width: -0.58 }, { number: 59, width: -0.58 },
      { number: 61, width: -0.69 }, { number: 67, width: -0.53 }, { number: 70, width: -0.58 },
      { number: 71, width: -0.69 }, { number: 72, width: -0.59 }, { number: 73, width: -0.59 },
      { number: 74, width: -0.59 }, { number: 75, width: -0.58 }, { number: 76, width: -0.58 },
      { number: 77, width: -0.52 }, { number: 78, width: -0.58 }, { number: 79, width: -0.58 },
      { number: 81, width: -0.69 }, { number: 87, width: -0.53 }, { number: 91, width: -0.69 },
      { number: 97, width: -0.53 }
    ]
  },
  'DUKE_JERSEY_2023_BLACK': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.66 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'ECU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.72 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.62 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.69 }, { number: 31, width: -0.69 },
      { number: 41, width: -0.69 }, { number: 51, width: -0.69 }, { number: 61, width: -0.69 },
      { number: 71, width: -0.65 }, { number: 81, width: -0.69 }, { number: 91, width: -0.69 }
    ]
  },
  'ECU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.65 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.65 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.55 }, { number: 42, width: -0.43 }, { number: 43, width: -0.43 },
      { number: 45, width: -0.43 }, { number: 46, width: -0.43 }, { number: 47, width: -0.43 },
      { number: 48, width: -0.43 }, { number: 49, width: -0.43 }, { number: 51, width: -0.56 },
      { number: 54, width: -0.52 }, { number: 61, width: -0.56 }, { number: 71, width: -0.56 },
      { number: 81, width: -0.56 }, { number: 91, width: -0.56 }
    ]
  },
  'EMU_JERSEY_2025_BLACK': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.56 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'FAU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.35,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.57 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.41 }, { number: 31, width: -0.41 },
      { number: 41, width: -0.41 }, { number: 51, width: -0.41 }, { number: 61, width: -0.41 },
      { number: 71, width: -0.38 }, { number: 81, width: -0.41 }, { number: 91, width: -0.41 }
    ]
  },
  'FAU_Jersey_2025-2_NUM_Array': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.68 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 44, width: -0.42 }, { number: 51, width: -0.58 },
      { number: 61, width: -0.58 }, { number: 71, width: -0.58 }, { number: 81, width: -0.58 },
      { number: 91, width: -0.58 }
    ]
  },
  'FAU_Jersey_2025_NUM_Array': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.59 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.48 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.48 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.48 }, { number: 31, width: -0.48 },
      { number: 41, width: -0.48 }, { number: 51, width: -0.48 }, { number: 61, width: -0.48 },
      { number: 71, width: -0.48 }, { number: 81, width: -0.48 }, { number: 91, width: -0.48 }
    ]
  },
  'FIU_JERSEY_2023_NAVY': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.56 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'FIU_Jersey_2024_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.56 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'FIU_Jersey_2025_Vice_NUM_Array': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.61 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.52 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.52 }, { number: 31, width: -0.52 },
      { number: 41, width: -0.52 }, { number: 51, width: -0.52 }, { number: 61, width: -0.52 },
      { number: 71, width: -0.52 }, { number: 81, width: -0.52 }, { number: 91, width: -0.52 }
    ]
  },
  'FLA_JERSEY_2023_THROWBACK': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.59 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'FLA_Jersey_2021_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.68 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.57 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.51 }, { number: 31, width: -0.51 },
      { number: 41, width: -0.51 }, { number: 51, width: -0.51 }, { number: 61, width: -0.51 },
      { number: 71, width: -0.51 }, { number: 81, width: -0.51 }, { number: 91, width: -0.51 }
    ]
  },
  'FRES_Jersey_2021_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.47 }, { number: 11, width: -0.62 }, { number: 12, width: -0.47 },
      { number: 13, width: -0.47 }, { number: 14, width: -0.47 }, { number: 15, width: -0.47 },
      { number: 16, width: -0.47 }, { number: 17, width: -0.47 }, { number: 18, width: -0.47 },
      { number: 19, width: -0.47 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'FSU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.46,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.69 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.59 }, { number: 15, width: -0.59 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'GASO_JERSEY_2023_BLUE': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.66 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'GSU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.52,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.71 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.59 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.6 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 40, width: -0.48 }, { number: 41, width: -0.65 }, { number: 42, width: -0.48 },
      { number: 43, width: -0.48 }, { number: 44, width: -0.48 }, { number: 45, width: -0.5 },
      { number: 46, width: -0.48 }, { number: 47, width: -0.52 }, { number: 48, width: -0.48 },
      { number: 49, width: -0.48 }, { number: 51, width: -0.62 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.62 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'GT_Jersey_2026_NUM_Array': {
    numberSpacing: -0.41,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.62 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.56 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.52 }, { number: 31, width: -0.52 },
      { number: 41, width: -0.52 }, { number: 51, width: -0.52 }, { number: 61, width: -0.52 },
      { number: 71, width: -0.52 }, { number: 81, width: -0.52 }, { number: 91, width: -0.52 }
    ]
  },
  'GT_Jersey_2026_White_NUM_Array': {
    numberSpacing: -0.41,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.62 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.56 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.52 }, { number: 31, width: -0.52 },
      { number: 41, width: -0.52 }, { number: 51, width: -0.52 }, { number: 61, width: -0.52 },
      { number: 71, width: -0.52 }, { number: 81, width: -0.52 }, { number: 91, width: -0.52 }
    ]
  },
  'HAW_Jersey_2021_NUM_Array': {
    numberSpacing: -0.41,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.63 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.49 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.53 }, { number: 24, width: -0.37 },
      { number: 31, width: -0.53 }, { number: 34, width: -0.37 }, { number: 40, width: -0.35 },
      { number: 41, width: -0.53 }, { number: 42, width: -0.35 }, { number: 43, width: -0.35 },
      { number: 44, width: -0.32 }, { number: 45, width: -0.35 }, { number: 46, width: -0.35 },
      { number: 47, width: -0.35 }, { number: 48, width: -0.35 }, { number: 49, width: -0.35 },
      { number: 51, width: -0.53 }, { number: 54, width: -0.37 }, { number: 61, width: -0.53 },
      { number: 64, width: -0.37 }, { number: 71, width: -0.53 }, { number: 74, width: -0.37 },
      { number: 81, width: -0.53 }, { number: 84, width: -0.37 }, { number: 91, width: -0.53 },
      { number: 94, width: -0.37 }
    ]
  },
  'HOU_JERSEY_2023_RED': {
    numberSpacing: -0.36,
    playerNumberAdjust: [
      { number: 10, width: -0.45 }, { number: 11, width: -0.56 }, { number: 12, width: -0.45 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.52 }, { number: 15, width: -0.45 },
      { number: 16, width: -0.45 }, { number: 17, width: -0.45 }, { number: 18, width: -0.45 },
      { number: 19, width: -0.45 }, { number: 21, width: -0.42 }, { number: 31, width: -0.44 },
      { number: 41, width: -0.45 }, { number: 51, width: -0.42 }, { number: 61, width: -0.42 },
      { number: 71, width: -0.42 }, { number: 81, width: -0.42 }, { number: 91, width: -0.42 }
    ]
  },
  'ILL_JERSEY_2023_TRHOWBACK': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.62 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'ILL_Jersey_2021_NUM_Array': {
    numberSpacing: -0.404939115,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.62 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.53 }, { number: 23, width: -0.43 },
      { number: 31, width: -0.54 }, { number: 32, width: -0.46 }, { number: 33, width: -0.48 },
      { number: 34, width: -0.46 }, { number: 35, width: -0.46 }, { number: 36, width: -0.46 },
      { number: 37, width: -0.46 }, { number: 38, width: -0.46 }, { number: 39, width: -0.45 },
      { number: 41, width: -0.53 }, { number: 43, width: -0.43 }, { number: 51, width: -0.53 },
      { number: 53, width: -0.43 }, { number: 61, width: -0.53 }, { number: 63, width: -0.43 },
      { number: 71, width: -0.53 }, { number: 73, width: -0.43 }, { number: 81, width: -0.53 },
      { number: 83, width: -0.43 }, { number: 91, width: -0.53 }, { number: 93, width: -0.43 }
    ]
  },
  'IND_Jersey_2022_NUM_Array': {
    numberSpacing: -0.39,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.63 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 24, width: -0.35 },
      { number: 31, width: -0.5 }, { number: 34, width: -0.35 }, { number: 41, width: -0.47 },
      { number: 42, width: -0.35 }, { number: 43, width: -0.35 }, { number: 44, width: -0.35 },
      { number: 45, width: -0.35 }, { number: 46, width: -0.35 }, { number: 47, width: -0.35 },
      { number: 48, width: -0.35 }, { number: 49, width: -0.35 }, { number: 51, width: -0.5 },
      { number: 54, width: -0.35 }, { number: 61, width: -0.5 }, { number: 64, width: -0.35 },
      { number: 71, width: -0.5 }, { number: 74, width: -0.35 }, { number: 81, width: -0.5 },
      { number: 84, width: -0.35 }, { number: 91, width: -0.5 }, { number: 94, width: -0.35 }
    ]
  },
  'IOWA_Jersey_2021_NUM_Array': {
    numberSpacing: -0.39,
    playerNumberAdjust: [
      { number: 10, width: -0.47 }, { number: 11, width: -0.55 }, { number: 12, width: -0.47 },
      { number: 13, width: -0.47 }, { number: 14, width: -0.53 }, { number: 15, width: -0.47 },
      { number: 16, width: -0.47 }, { number: 17, width: -0.47 }, { number: 18, width: -0.47 },
      { number: 19, width: -0.47 }, { number: 21, width: -0.49 }, { number: 31, width: -0.49 },
      { number: 41, width: -0.49 }, { number: 51, width: -0.49 }, { number: 61, width: -0.49 },
      { number: 71, width: -0.49 }, { number: 81, width: -0.49 }, { number: 91, width: -0.49 }
    ]
  },
  'ISU_JERSEY_2024_THROWBACK': {
    numberSpacing: -0.53,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.69 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.62 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.62 }, { number: 51, width: -0.62 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.62 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'ISU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.28,
    playerNumberAdjust: [
      { number: 10, width: -0.43 }, { number: 11, width: -0.55 }, { number: 12, width: -0.43 },
      { number: 13, width: -0.43 }, { number: 14, width: -0.43 }, { number: 15, width: -0.43 },
      { number: 16, width: -0.43 }, { number: 17, width: -0.43 }, { number: 18, width: -0.43 },
      { number: 19, width: -0.43 }, { number: 21, width: -0.4 }, { number: 31, width: -0.4 },
      { number: 41, width: -0.4 }, { number: 51, width: -0.4 }, { number: 61, width: -0.4 },
      { number: 71, width: -0.4 }, { number: 81, width: -0.4 }, { number: 91, width: -0.4 }
    ]
  },
  'ISU_Jersey_2024_NUM_Array': {
    numberSpacing: -0.26,
    playerNumberAdjust: [
      { number: 10, width: -0.42 }, { number: 11, width: -0.54 }, { number: 12, width: -0.42 },
      { number: 13, width: -0.42 }, { number: 14, width: -0.42 }, { number: 15, width: -0.42 },
      { number: 16, width: -0.42 }, { number: 17, width: -0.42 }, { number: 18, width: -0.42 },
      { number: 19, width: -0.42 }, { number: 21, width: -0.4 }, { number: 31, width: -0.4 },
      { number: 41, width: -0.4 }, { number: 51, width: -0.4 }, { number: 61, width: -0.4 },
      { number: 71, width: -0.4 }, { number: 81, width: -0.4 }, { number: 91, width: -0.4 }
    ]
  },
  'JMU_JERSEY_2023_PURPLE': {
    numberSpacing: -0.52,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.7 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.62 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.6 }, { number: 31, width: -0.6 },
      { number: 41, width: -0.6 }, { number: 51, width: -0.6 }, { number: 61, width: -0.6 },
      { number: 71, width: -0.6 }, { number: 81, width: -0.6 }, { number: 91, width: -0.6 }
    ]
  },
  'JVST_JERSEY_2023_RED': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.66 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.59 }, { number: 15, width: -0.59 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.59 }, { number: 31, width: -0.59 },
      { number: 41, width: -0.59 }, { number: 51, width: -0.59 }, { number: 61, width: -0.59 },
      { number: 71, width: -0.59 }, { number: 81, width: -0.59 }, { number: 91, width: -0.59 }
    ]
  },
  'KENN_Jersey_2025_NUM_Array': {
    numberSpacing: -0.49,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 10, width: -0.58 }, { number: 11, width: -0.67 },
      { number: 12, width: -0.58 }, { number: 13, width: -0.58 }, { number: 14, width: -0.58 },
      { number: 15, width: -0.58 }, { number: 16, width: -0.58 }, { number: 17, width: -0.58 },
      { number: 18, width: -0.58 }, { number: 19, width: -0.58 }, { number: 21, width: -0.58 },
      { number: 31, width: -0.58 }, { number: 40, width: -0.45 }, { number: 41, width: -0.58 },
      { number: 42, width: -0.45 }, { number: 43, width: -0.45 }, { number: 44, width: -0.45 },
      { number: 45, width: -0.45 }, { number: 46, width: -0.45 }, { number: 47, width: -0.45 },
      { number: 48, width: -0.45 }, { number: 49, width: -0.45 }, { number: 50, width: -0.45 },
      { number: 51, width: -0.58 }, { number: 52, width: -0.45 }, { number: 53, width: -0.45 },
      { number: 54, width: -0.45 }, { number: 55, width: -0.45 }, { number: 56, width: -0.45 },
      { number: 57, width: -0.45 }, { number: 58, width: -0.45 }, { number: 59, width: -0.45 },
      { number: 61, width: -0.58 }, { number: 70, width: -0.45 }, { number: 71, width: -0.58 },
      { number: 72, width: -0.45 }, { number: 73, width: -0.45 }, { number: 74, width: -0.45 },
      { number: 75, width: -0.45 }, { number: 76, width: -0.45 }, { number: 77, width: -0.45 },
      { number: 78, width: -0.45 }, { number: 79, width: -0.45 }, { number: 81, width: -0.58 }
    ]
  },
  'KENT_Jersey_2023_NUM_Array': {
    numberSpacing: -0.43,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.57 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.44 }, { number: 31, width: -0.44 },
      { number: 41, width: -0.44 }, { number: 51, width: -0.44 }, { number: 61, width: -0.44 },
      { number: 71, width: -0.44 }, { number: 81, width: -0.44 }, { number: 91, width: -0.44 }
    ]
  },
  'KENT_Jersey_2025_NUM_Array': {
    numberSpacing: -0.41,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.56 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'KSU_JERSEY_2023_PURPLE': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.62 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'KU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.55,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.7 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.62 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.62 }, { number: 51, width: -0.62 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.62 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'KU_Jersey_2024_NUM_Array': {
    numberSpacing: -0.41,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.62 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'LOU_Jersey_2024_NUM_Array': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.68 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.62 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.62 }, { number: 51, width: -0.62 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.62 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'LOU_Jersey_2025_NUM_Array': {
    numberSpacing: -0.55,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.7 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.6 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.6 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.6 }, { number: 31, width: -0.6 },
      { number: 41, width: -0.6 }, { number: 51, width: -0.6 }, { number: 61, width: -0.6 },
      { number: 71, width: -0.6 }, { number: 81, width: -0.6 }, { number: 91, width: -0.6 }
    ]
  },
  'LSU_JERSEY_2023_GOLD': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.46 }, { number: 11, width: -0.55 }, { number: 12, width: -0.46 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.49 }, { number: 15, width: -0.46 },
      { number: 16, width: -0.46 }, { number: 17, width: -0.46 }, { number: 18, width: -0.46 },
      { number: 19, width: -0.46 }, { number: 21, width: -0.46 }, { number: 31, width: -0.46 },
      { number: 41, width: -0.46 }, { number: 51, width: -0.46 }, { number: 61, width: -0.46 },
      { number: 71, width: -0.46 }, { number: 81, width: -0.46 }, { number: 91, width: -0.46 }
    ]
  },
  'LSU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.69 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.56 }, { number: 51, width: -0.56 }, { number: 61, width: -0.56 },
      { number: 71, width: -0.56 }, { number: 81, width: -0.56 }, { number: 91, width: -0.56 }
    ]
  },
  'LT_Jersey_2023_NUM_Array': {
    numberSpacing: -0.43,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.6 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.59 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.52 }, { number: 31, width: -0.52 },
      { number: 41, width: -0.52 }, { number: 51, width: -0.52 }, { number: 61, width: -0.52 },
      { number: 71, width: -0.52 }, { number: 81, width: -0.52 }, { number: 91, width: -0.52 }
    ]
  },
  'MEM_JERSEY_2023_BLUE': {
    numberSpacing: -0.334046632,
    playerNumberAdjust: [
      { number: 10, width: -0.46 }, { number: 11, width: -0.56 }, { number: 12, width: -0.46 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.43 }, { number: 15, width: -0.46 },
      { number: 16, width: -0.46 }, { number: 17, width: -0.46 }, { number: 18, width: -0.46 },
      { number: 19, width: -0.46 }, { number: 21, width: -0.46 }, { number: 31, width: -0.46 },
      { number: 41, width: -0.44 }, { number: 51, width: -0.46 }, { number: 61, width: -0.46 },
      { number: 71, width: -0.46 }, { number: 81, width: -0.46 }, { number: 91, width: -0.46 }
    ]
  },
  'MIAOH_Jersey_2021_NUM_Array': {
    numberSpacing: -0.53,
    playerNumberAdjust: [
      { number: 10, width: -0.64 }, { number: 11, width: -0.66 }, { number: 12, width: -0.64 },
      { number: 13, width: -0.64 }, { number: 14, width: -0.64 }, { number: 15, width: -0.64 },
      { number: 16, width: -0.64 }, { number: 17, width: -0.64 }, { number: 18, width: -0.64 },
      { number: 19, width: -0.64 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'MIA_Jersey_2024_NUM_Array': {
    numberSpacing: -0.43,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.64 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'MIA_Jersey_2025_Camo_NUM_Array': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.46 }, { number: 11, width: -0.57 }, { number: 12, width: -0.46 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.46 }, { number: 15, width: -0.46 },
      { number: 16, width: -0.46 }, { number: 17, width: -0.46 }, { number: 18, width: -0.46 },
      { number: 19, width: -0.46 }, { number: 21, width: -0.46 }, { number: 31, width: -0.46 },
      { number: 41, width: -0.46 }, { number: 51, width: -0.46 }, { number: 61, width: -0.46 },
      { number: 71, width: -0.46 }, { number: 81, width: -0.46 }, { number: 91, width: -0.46 }
    ]
  },
  'MIA_Jersey_2025_NUM_Array': {
    numberSpacing: -0.445,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.54 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.48 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.48 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.48 }, { number: 31, width: -0.48 },
      { number: 41, width: -0.48 }, { number: 51, width: -0.48 }, { number: 61, width: -0.48 },
      { number: 71, width: -0.48 }, { number: 81, width: -0.48 }, { number: 91, width: -0.48 }
    ]
  },
  'MICH_JERSEY_2023_BLUE': {
    numberSpacing: -0.47,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.67 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.59 }, { number: 15, width: -0.59 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'MINN_Jersey_2021_NUM_Array': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.44 }, { number: 11, width: -0.57 }, { number: 12, width: -0.44 },
      { number: 13, width: -0.44 }, { number: 14, width: -0.44 }, { number: 15, width: -0.44 },
      { number: 16, width: -0.44 }, { number: 17, width: -0.44 }, { number: 18, width: -0.44 },
      { number: 19, width: -0.44 }, { number: 21, width: -0.44 }, { number: 31, width: -0.44 },
      { number: 41, width: -0.44 }, { number: 51, width: -0.44 }, { number: 61, width: -0.44 },
      { number: 71, width: -0.44 }, { number: 81, width: -0.44 }, { number: 91, width: -0.44 }
    ]
  },
  'MISS_JERSEY_2024_BLUE': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.59 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'MIST_Jersey_2024_NUM_Array': {
    numberSpacing: -0.47,
    playerNumberAdjust: [
      { number: 10, width: -0.63 }, { number: 11, width: -0.67 }, { number: 12, width: -0.63 },
      { number: 13, width: -0.65 }, { number: 14, width: -0.6 }, { number: 15, width: -0.64 },
      { number: 16, width: -0.63 }, { number: 17, width: -0.63 }, { number: 18, width: -0.63 },
      { number: 19, width: -0.63 }, { number: 21, width: -0.565 }, { number: 23, width: -0.53 },
      { number: 26, width: -0.53 }, { number: 30, width: -0.5 }, { number: 31, width: -0.59 },
      { number: 32, width: -0.5 }, { number: 33, width: -0.53 }, { number: 34, width: -0.5 },
      { number: 35, width: -0.5 }, { number: 36, width: -0.5 }, { number: 37, width: -0.5 },
      { number: 38, width: -0.5 }, { number: 39, width: -0.5 }, { number: 41, width: -0.565 },
      { number: 43, width: -0.53 }, { number: 46, width: -0.53 }, { number: 51, width: -0.59 },
      { number: 52, width: -0.5 }, { number: 53, width: -0.53 }, { number: 53, width: -0.53 },
      { number: 55, width: -0.5 }, { number: 56, width: -0.53 }, { number: 56, width: -0.5 },
      { number: 57, width: -0.5 }, { number: 59, width: -0.5 }, { number: 60, width: -0.5 },
      { number: 61, width: -0.59 }, { number: 62, width: -0.53 }, { number: 63, width: -0.53 },
      { number: 64, width: -0.5 }, { number: 65, width: -0.53 }, { number: 66, width: -0.53 },
      { number: 67, width: -0.53 }, { number: 68, width: -0.5 }, { number: 69, width: -0.5 },
      { number: 71, width: -0.61 }, { number: 73, width: -0.6 }, { number: 76, width: -0.6 },
      { number: 81, width: -0.565 }, { number: 83, width: -0.53 }, { number: 86, width: -0.51 },
      { number: 91, width: -0.565 }, { number: 93, width: -0.53 }, { number: 96, width: -0.51 }
    ]
  },
  'MIZZ_Jersey_2021_NUM_Array': {
    numberSpacing: -0.47,
    playerNumberAdjust: [
      { number: 10, width: -0.61 }, { number: 11, width: -0.66 }, { number: 12, width: -0.61 },
      { number: 13, width: -0.61 }, { number: 14, width: -0.61 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.59 }, { number: 18, width: -0.61 },
      { number: 19, width: -0.61 }, { number: 21, width: -0.51 }, { number: 31, width: -0.51 },
      { number: 41, width: -0.51 }, { number: 51, width: -0.51 }, { number: 61, width: -0.51 },
      { number: 71, width: -0.51 }, { number: 81, width: -0.51 }, { number: 91, width: -0.51 }
    ]
  },
  'MRSH_JERSEY_2023_BLACK': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.63 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.49 }, { number: 31, width: -0.49 },
      { number: 41, width: -0.49 }, { number: 51, width: -0.49 }, { number: 61, width: -0.49 },
      { number: 71, width: -0.49 }, { number: 81, width: -0.49 }, { number: 91, width: -0.49 }
    ]
  },
  'MRSH_Jersey_2025_NUM_Array': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.61 }, { number: 11, width: -0.7 }, { number: 12, width: -0.61 },
      { number: 13, width: -0.61 }, { number: 14, width: -0.61 }, { number: 15, width: -0.61 },
      { number: 16, width: -0.61 }, { number: 17, width: -0.61 }, { number: 18, width: -0.61 },
      { number: 19, width: -0.61 }, { number: 21, width: -0.61 }, { number: 31, width: -0.61 },
      { number: 41, width: -0.61 }, { number: 51, width: -0.61 }, { number: 61, width: -0.61 },
      { number: 71, width: -0.61 }, { number: 81, width: -0.61 }, { number: 91, width: -0.61 }
    ]
  },
  'MSST_Jersey_2021_NUM_Array': {
    numberSpacing: -0.381234229,
    playerNumberAdjust: [
      { number: 10, width: -0.49 }, { number: 11, width: -0.63 }, { number: 12, width: -0.49 },
      { number: 13, width: -0.49 }, { number: 14, width: -0.55 }, { number: 15, width: -0.49 },
      { number: 16, width: -0.49 }, { number: 17, width: -0.6 }, { number: 18, width: -0.49 },
      { number: 19, width: -0.49 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  },
  'MSST_Jersey_2024_NUM_Array': {
    numberSpacing: -0.381234229,
    playerNumberAdjust: [
      { number: 10, width: -0.49 }, { number: 11, width: -0.63 }, { number: 12, width: -0.49 },
      { number: 13, width: -0.49 }, { number: 14, width: -0.55 }, { number: 15, width: -0.49 },
      { number: 16, width: -0.49 }, { number: 17, width: -0.6 }, { number: 18, width: -0.49 },
      { number: 19, width: -0.49 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  },
  'MSST_Jersey_2025_Throwback_NUM_Array': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.54 }, { number: 11, width: -0.66 }, { number: 12, width: -0.54 },
      { number: 13, width: -0.54 }, { number: 14, width: -0.6 }, { number: 15, width: -0.54 },
      { number: 16, width: -0.54 }, { number: 17, width: -0.54 }, { number: 18, width: -0.54 },
      { number: 19, width: -0.54 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.54 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'MSU_JERSEY_2023_GREEN': {
    numberSpacing: -0.33,
    playerNumberAdjust: [
      { number: 10, width: -0.46 }, { number: 11, width: -0.56 }, { number: 12, width: -0.46 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.43 }, { number: 15, width: -0.46 },
      { number: 16, width: -0.46 }, { number: 17, width: -0.46 }, { number: 18, width: -0.46 },
      { number: 19, width: -0.46 }, { number: 21, width: -0.46 }, { number: 31, width: -0.46 },
      { number: 41, width: -0.44 }, { number: 51, width: -0.46 }, { number: 61, width: -0.46 },
      { number: 71, width: -0.46 }, { number: 81, width: -0.46 }, { number: 91, width: -0.46 }
    ]
  },
  'MTSU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.54 }, { number: 11, width: -0.62 }, { number: 12, width: -0.54 },
      { number: 13, width: -0.54 }, { number: 14, width: -0.58 }, { number: 15, width: -0.54 },
      { number: 16, width: -0.54 }, { number: 17, width: -0.54 }, { number: 18, width: -0.54 },
      { number: 19, width: -0.54 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.54 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'NAVY_Jersey_2021_NUM_Array': {
    numberSpacing: -0.36,
    playerNumberAdjust: [
      { number: 10, width: -0.46 }, { number: 11, width: -0.57 }, { number: 12, width: -0.46 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.46 }, { number: 15, width: -0.46 },
      { number: 16, width: -0.46 }, { number: 17, width: -0.46 }, { number: 18, width: -0.46 },
      { number: 19, width: -0.46 }, { number: 21, width: -0.46 }, { number: 31, width: -0.46 },
      { number: 41, width: -0.46 }, { number: 51, width: -0.46 }, { number: 61, width: -0.46 },
      { number: 71, width: -0.46 }, { number: 81, width: -0.46 }, { number: 91, width: -0.46 }
    ]
  },
  'NAVY_Jersey_2023_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.66 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'NAVY_Jersey_2024_NUM_Array': {
    numberSpacing: -0.49,
    playerNumberAdjust: [
      { number: 10, width: -0.66 }, { number: 11, width: -0.8 }, { number: 12, width: -0.66 },
      { number: 13, width: -0.66 }, { number: 14, width: -0.66 }, { number: 15, width: -0.66 },
      { number: 16, width: -0.66 }, { number: 17, width: -0.66 }, { number: 18, width: -0.66 },
      { number: 19, width: -0.66 }, { number: 21, width: -0.66 }, { number: 31, width: -0.66 },
      { number: 41, width: -0.66 }, { number: 51, width: -0.66 }, { number: 61, width: -0.66 },
      { number: 71, width: -0.66 }, { number: 81, width: -0.66 }, { number: 91, width: -0.66 }
    ]
  },
  'NAVY_Jersey_2025_NUM_Array': {
    numberSpacing: -0.46,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.52 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.52 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.48 }, { number: 31, width: -0.48 },
      { number: 41, width: -0.48 }, { number: 51, width: -0.48 }, { number: 61, width: -0.48 },
      { number: 71, width: -0.48 }, { number: 81, width: -0.48 }, { number: 91, width: -0.48 }
    ]
  },
  'NCST_Jersey_2021_NUM_Array': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.66 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.55 }, { number: 15, width: -0.59 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.52 }, { number: 42, width: -0.43 }, { number: 43, width: -0.43 },
      { number: 44, width: -0.4 }, { number: 45, width: -0.43 }, { number: 46, width: -0.43 },
      { number: 47, width: -0.43 }, { number: 48, width: -0.43 }, { number: 49, width: -0.43 },
      { number: 51, width: -0.54 }, { number: 61, width: -0.54 }, { number: 71, width: -0.54 },
      { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'NCST_Jersey_2025_NUM_Array': {
    numberSpacing: -0.47,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.71 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.55 }, { number: 15, width: -0.59 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.59 }, { number: 24, width: -0.42 },
      { number: 31, width: -0.59 }, { number: 34, width: -0.42 }, { number: 40, width: -0.42 },
      { number: 41, width: -0.54 }, { number: 42, width: -0.42 }, { number: 43, width: -0.42 },
      { number: 44, width: -0.38 }, { number: 45, width: -0.42 }, { number: 46, width: -0.42 },
      { number: 47, width: -0.42 }, { number: 48, width: -0.42 }, { number: 49, width: -0.42 },
      { number: 51, width: -0.59 }, { number: 54, width: -0.42 }, { number: 61, width: -0.59 },
      { number: 64, width: -0.42 }, { number: 71, width: -0.59 }, { number: 74, width: -0.5 },
      { number: 81, width: -0.59 }, { number: 84, width: -0.42 }, { number: 91, width: -0.59 },
      { number: 94, width: -0.42 }
    ]
  },
  'NDSU_Jersey_2026_NUM_Array': {
    numberSpacing: -0.24,
    playerNumberAdjust: [
      { number: 10, width: -0.28 }, { number: 11, width: -0.42 }, { number: 12, width: -0.28 },
      { number: 13, width: -0.28 }, { number: 14, width: -0.28 }, { number: 15, width: -0.28 },
      { number: 16, width: -0.28 }, { number: 17, width: -0.28 }, { number: 18, width: -0.28 },
      { number: 19, width: -0.28 }, { number: 21, width: -0.28 }, { number: 31, width: -0.28 },
      { number: 40, width: -0.15 }, { number: 41, width: -0.28 }, { number: 42, width: -0.22 },
      { number: 43, width: -0.22 }, { number: 44, width: -0.2 }, { number: 45, width: -0.22 },
      { number: 46, width: -0.22 }, { number: 47, width: -0.22 }, { number: 48, width: -0.17 },
      { number: 49, width: -0.22 }, { number: 51, width: -0.28 }, { number: 61, width: -0.28 },
      { number: 71, width: -0.28 }, { number: 81, width: -0.28 }, { number: 91, width: -0.28 }
    ]
  },
  'ND_Jersey_2021_NUM_Array': {
    numberSpacing: -0.52,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.7 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.64 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.63 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.6 }, { number: 42, width: -0.49 }, { number: 43, width: -0.49 },
      { number: 44, width: -0.46 }, { number: 45, width: -0.49 }, { number: 46, width: -0.49 },
      { number: 47, width: -0.54 }, { number: 48, width: -0.5 }, { number: 49, width: -0.49 },
      { number: 51, width: -0.62 }, { number: 61, width: -0.62 }, { number: 71, width: -0.62 },
      { number: 81, width: -0.61 }, { number: 91, width: -0.62 }
    ]
  },
  'ND_Jersey_2024_Shamrock_NUM_Array': {
    numberSpacing: -0.58,
    playerNumberAdjust: [
      { number: 10, width: -0.66 }, { number: 11, width: -0.77 }, { number: 12, width: -0.66 },
      { number: 13, width: -0.66 }, { number: 14, width: -0.66 }, { number: 15, width: -0.66 },
      { number: 16, width: -0.66 }, { number: 17, width: -0.7 }, { number: 18, width: -0.66 },
      { number: 19, width: -0.66 }, { number: 21, width: -0.64 }, { number: 31, width: -0.64 },
      { number: 41, width: -0.66 }, { number: 51, width: -0.64 }, { number: 61, width: -0.64 },
      { number: 71, width: -0.64 }, { number: 81, width: -0.64 }, { number: 91, width: -0.64 }
    ]
  },
  'NEB_JERSEY_2024_RED': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.68 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.58 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.64 }, { number: 31, width: -0.64 },
      { number: 41, width: -0.64 }, { number: 51, width: -0.64 }, { number: 61, width: -0.63 },
      { number: 71, width: -0.64 }, { number: 81, width: -0.64 }, { number: 91, width: -0.64 }
    ]
  },
  'NEB_Jersey_2026_NUM_Array': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.69 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'NEV_Jersey_2021_NUM_Array': {
    numberSpacing: -0.32,
    playerNumberAdjust: [
      { number: 10, width: -0.44 }, { number: 11, width: -0.58 }, { number: 12, width: -0.44 },
      { number: 13, width: -0.44 }, { number: 14, width: -0.41 }, { number: 15, width: -0.44 },
      { number: 16, width: -0.44 }, { number: 17, width: -0.44 }, { number: 18, width: -0.44 },
      { number: 19, width: -0.44 }, { number: 21, width: -0.44 }, { number: 24, width: -0.27 },
      { number: 31, width: -0.44 }, { number: 34, width: -0.27 }, { number: 41, width: -0.44 },
      { number: 44, width: -0.27 }, { number: 51, width: -0.44 }, { number: 54, width: -0.27 },
      { number: 61, width: -0.44 }, { number: 64, width: -0.27 }, { number: 71, width: -0.44 },
      { number: 74, width: -0.32 }, { number: 81, width: -0.44 }, { number: 84, width: -0.27 },
      { number: 91, width: -0.44 }, { number: 94, width: -0.27 }
    ]
  },
  'NIU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.47 }, { number: 11, width: -0.62 }, { number: 12, width: -0.47 },
      { number: 13, width: -0.47 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'NIU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.62 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.48 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.48 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.42 }, { number: 31, width: -0.42 },
      { number: 41, width: -0.42 }, { number: 51, width: -0.42 }, { number: 61, width: -0.42 },
      { number: 71, width: -0.42 }, { number: 81, width: -0.42 }, { number: 91, width: -0.42 }
    ]
  },
  'NW_Jersey_2021_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.63 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'NW_Jersey_2022_NUM_Array': {
    numberSpacing: -0.53,
    playerNumberAdjust: [
      { number: 10, width: -0.63 }, { number: 11, width: -0.76 }, { number: 12, width: -0.63 },
      { number: 13, width: -0.63 }, { number: 14, width: -0.63 }, { number: 15, width: -0.63 },
      { number: 16, width: -0.63 }, { number: 17, width: -0.63 }, { number: 18, width: -0.63 },
      { number: 19, width: -0.63 }, { number: 21, width: -0.63 }, { number: 31, width: -0.63 },
      { number: 41, width: -0.63 }, { number: 51, width: -0.63 }, { number: 61, width: -0.63 },
      { number: 71, width: -0.63 }, { number: 81, width: -0.63 }, { number: 91, width: -0.63 }
    ]
  },
  'ODU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.63 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.56 }, { number: 51, width: -0.56 }, { number: 61, width: -0.56 },
      { number: 71, width: -0.56 }, { number: 81, width: -0.56 }, { number: 91, width: -0.56 }
    ]
  },
  'OHIO_Jersey_2023_NUM_Array': {
    numberSpacing: -0.49,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.68 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.58 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.59 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'OHIO_Jersey_2024_NUM_Array': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.63 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.52 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'OKST_JERSEY_2023_BLACK': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.47 }, { number: 11, width: -0.57 }, { number: 12, width: -0.47 },
      { number: 13, width: -0.47 }, { number: 14, width: -0.47 }, { number: 15, width: -0.47 },
      { number: 16, width: -0.47 }, { number: 17, width: -0.47 }, { number: 18, width: -0.47 },
      { number: 19, width: -0.47 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  },
  'ORE_Jersey_2021_NUM_Array': {
    numberSpacing: -0.438335419,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.73 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.58 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'ORE_Jersey_2024_NUM_Array': {
    numberSpacing: -0.52,
    playerNumberAdjust: [
      { number: 10, width: -0.63 }, { number: 11, width: -0.74 }, { number: 12, width: -0.63 },
      { number: 13, width: -0.63 }, { number: 14, width: -0.61 }, { number: 15, width: -0.63 },
      { number: 16, width: -0.63 }, { number: 17, width: -0.63 }, { number: 18, width: -0.63 },
      { number: 19, width: -0.63 }, { number: 21, width: -0.63 }, { number: 24, width: -0.5 },
      { number: 31, width: -0.63 }, { number: 34, width: -0.5 }, { number: 40, width: -0.5 },
      { number: 41, width: -0.63 }, { number: 42, width: -0.5 }, { number: 43, width: -0.5 },
      { number: 44, width: -0.48 }, { number: 45, width: -0.5 }, { number: 46, width: -0.5 },
      { number: 47, width: -0.52 }, { number: 48, width: -0.5 }, { number: 49, width: -0.5 },
      { number: 51, width: -0.63 }, { number: 54, width: -0.5 }, { number: 61, width: -0.63 },
      { number: 64, width: -0.5 }, { number: 71, width: -0.63 }, { number: 74, width: -0.5 },
      { number: 81, width: -0.63 }, { number: 84, width: -0.5 }, { number: 91, width: -0.63 },
      { number: 94, width: -0.5 }
    ]
  },
  'ORE_Jersey_2025_ShoeDuck_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.68 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.52 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.56 }, { number: 44, width: -0.37 }, { number: 51, width: -0.56 },
      { number: 61, width: -0.56 }, { number: 71, width: -0.56 }, { number: 81, width: -0.56 },
      { number: 91, width: -0.56 }
    ]
  },
  'ORST_Jersey_2021_NUM_Array': {
    numberSpacing: -0.39,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.62 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.51 }, { number: 31, width: -0.51 },
      { number: 41, width: -0.51 }, { number: 51, width: -0.51 }, { number: 61, width: -0.51 },
      { number: 71, width: -0.51 }, { number: 81, width: -0.51 }, { number: 91, width: -0.51 }
    ]
  },
  'ORST_Jersey_2025_Camo_NUM_Array': {
    numberSpacing: -0.34,
    playerNumberAdjust: [
      { number: 10, width: -0.46 }, { number: 11, width: -0.6 }, { number: 12, width: -0.46 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.46 }, { number: 15, width: -0.46 },
      { number: 16, width: -0.46 }, { number: 17, width: -0.46 }, { number: 18, width: -0.46 },
      { number: 19, width: -0.46 }, { number: 21, width: -0.46 }, { number: 31, width: -0.46 },
      { number: 40, width: -0.31 }, { number: 41, width: -0.46 }, { number: 42, width: -0.31 },
      { number: 43, width: -0.31 }, { number: 44, width: -0.29 }, { number: 45, width: -0.31 },
      { number: 46, width: -0.31 }, { number: 47, width: -0.31 }, { number: 48, width: -0.31 },
      { number: 49, width: -0.31 }, { number: 51, width: -0.46 }, { number: 61, width: -0.46 },
      { number: 71, width: -0.46 }, { number: 81, width: -0.46 }, { number: 91, width: -0.46 }
    ]
  },
  'OSU_JERSEY_2023_SCARLETT': {
    numberSpacing: -0.49,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.67 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.59 }, { number: 15, width: -0.59 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'OSU_Jersey_2023_02_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.64 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'OU_Jersey_2022_NUM_Array': {
    numberSpacing: -0.3667013,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.61 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.48 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.48 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  },
  'OU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.3667013,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.63 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.49 }, { number: 31, width: -0.49 },
      { number: 41, width: -0.49 }, { number: 51, width: -0.49 }, { number: 61, width: -0.49 },
      { number: 71, width: -0.49 }, { number: 81, width: -0.49 }, { number: 91, width: -0.49 }
    ]
  },
  'OU_Jersey_2024_02_NUM_Array': {
    numberSpacing: -0.495,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.7 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.57 }, { number: 24, width: -0.44 },
      { number: 31, width: -0.57 }, { number: 34, width: -0.44 }, { number: 40, width: -0.42 },
      { number: 41, width: -0.53 }, { number: 42, width: -0.42 }, { number: 43, width: -0.42 },
      { number: 44, width: -0.36 }, { number: 45, width: -0.42 }, { number: 46, width: -0.42 },
      { number: 47, width: -0.42 }, { number: 48, width: -0.42 }, { number: 49, width: -0.42 },
      { number: 51, width: -0.57 }, { number: 54, width: -0.44 }, { number: 61, width: -0.57 },
      { number: 64, width: -0.44 }, { number: 71, width: -0.57 }, { number: 74, width: -0.5 },
      { number: 81, width: -0.57 }, { number: 84, width: -0.44 }, { number: 91, width: -0.57 },
      { number: 94, width: -0.44 }
    ]
  },
  'OU_Jersey_2024_NUM_Array': {
    numberSpacing: -0.3667013,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.63 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.49 }, { number: 31, width: -0.49 },
      { number: 41, width: -0.49 }, { number: 51, width: -0.49 }, { number: 61, width: -0.49 },
      { number: 71, width: -0.49 }, { number: 81, width: -0.49 }, { number: 91, width: -0.49 }
    ]
  },
  'PITT_Jersey_2021_NUM_Array': {
    numberSpacing: -0.54,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.69 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.6 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.64 }, { number: 31, width: -0.64 },
      { number: 41, width: -0.64 }, { number: 51, width: -0.64 }, { number: 61, width: -0.64 },
      { number: 71, width: -0.64 }, { number: 81, width: -0.64 }, { number: 91, width: -0.64 }
    ]
  },
  'PSU_JERSEY_2023_BLUESTRIPE': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.525 }, { number: 11, width: -0.655 }, { number: 12, width: -0.525 },
      { number: 13, width: -0.525 }, { number: 14, width: -0.525 }, { number: 15, width: -0.525 },
      { number: 16, width: -0.525 }, { number: 17, width: -0.525 }, { number: 18, width: -0.525 },
      { number: 19, width: -0.525 }, { number: 21, width: -0.525 }, { number: 31, width: -0.525 },
      { number: 41, width: -0.525 }, { number: 51, width: -0.525 }, { number: 61, width: -0.525 },
      { number: 71, width: -0.525 }, { number: 81, width: -0.525 }, { number: 91, width: -0.525 }
    ]
  },
  'PSU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.62 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'PUR_Jersey_2023_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.65 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.53 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.54 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'RICE_JERSEY_2023_LIGHTBLUE': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.66 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'RICE_Jersey_2026_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.72 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.58 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'RUTG_Jersey_2021_NUM_Array': {
    numberSpacing: -0.383319438,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.57 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.51 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.5 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.48 }, { number: 31, width: -0.48 },
      { number: 41, width: -0.48 }, { number: 51, width: -0.48 }, { number: 61, width: -0.48 },
      { number: 71, width: -0.48 }, { number: 81, width: -0.48 }, { number: 91, width: -0.48 }
    ]
  },
  'SACST_Jersey_2026_NUM_Array': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.68 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'SC_Jersey_2021_NUM_Array': {
    numberSpacing: -0.47,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.65 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.55 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 42, width: -0.44 }, { number: 43, width: -0.44 },
      { number: 44, width: -0.45 }, { number: 45, width: -0.44 }, { number: 46, width: -0.44 },
      { number: 47, width: -0.44 }, { number: 48, width: -0.44 }, { number: 49, width: -0.44 },
      { number: 51, width: -0.57 }, { number: 61, width: -0.57 }, { number: 71, width: -0.57 },
      { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'SHSU_Jersey_2025_NUM_Array': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.45 }, { number: 11, width: -0.52 }, { number: 12, width: -0.45 },
      { number: 13, width: -0.45 }, { number: 14, width: -0.45 }, { number: 15, width: -0.45 },
      { number: 16, width: -0.45 }, { number: 17, width: -0.45 }, { number: 18, width: -0.45 },
      { number: 19, width: -0.45 }, { number: 21, width: -0.45 }, { number: 31, width: -0.45 },
      { number: 41, width: -0.45 }, { number: 51, width: -0.45 }, { number: 61, width: -0.45 },
      { number: 71, width: -0.45 }, { number: 81, width: -0.45 }, { number: 91, width: -0.45 }
    ]
  },
  'SJSU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.68 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.6 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.6 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.6 }, { number: 31, width: -0.6 },
      { number: 41, width: -0.6 }, { number: 51, width: -0.6 }, { number: 61, width: -0.6 },
      { number: 71, width: -0.6 }, { number: 81, width: -0.6 }, { number: 91, width: -0.6 }
    ]
  },
  'SMU_JERSEY_2023_BLUE': {
    numberSpacing: -0.47,
    playerNumberAdjust: [
      { number: 10, width: -0.54 }, { number: 11, width: -0.62 }, { number: 12, width: -0.54 },
      { number: 13, width: -0.54 }, { number: 14, width: -0.58 }, { number: 15, width: -0.54 },
      { number: 16, width: -0.54 }, { number: 17, width: -0.54 }, { number: 18, width: -0.54 },
      { number: 19, width: -0.54 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.54 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'SMU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.67 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.58 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'SMU_Jersey_2022_NUM_Array': {
    numberSpacing: -0.52,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.7 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.6 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.6 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.62 }, { number: 51, width: -0.62 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.62 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'STAN_JERSEY_2023_BLACK': {
    numberSpacing: -0.36,
    playerNumberAdjust: [
      { number: 10, width: -0.45 }, { number: 11, width: -0.54 }, { number: 12, width: -0.45 },
      { number: 13, width: -0.45 }, { number: 14, width: -0.45 }, { number: 15, width: -0.45 },
      { number: 16, width: -0.45 }, { number: 17, width: -0.45 }, { number: 18, width: -0.45 },
      { number: 19, width: -0.45 }, { number: 21, width: -0.43 }, { number: 31, width: -0.43 },
      { number: 41, width: -0.43 }, { number: 51, width: -0.43 }, { number: 61, width: -0.43 },
      { number: 71, width: -0.43 }, { number: 81, width: -0.43 }, { number: 91, width: -0.43 }
    ]
  },
  'SYR_Jersey_2021_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.7 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.59 }, { number: 15, width: -0.59 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'TAMU_JERSEY_2025_THROWBACK': {
    numberSpacing: -0.46,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.68 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'TAMU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.51 }, { number: 11, width: -0.63 }, { number: 12, width: -0.51 },
      { number: 13, width: -0.51 }, { number: 14, width: -0.51 }, { number: 15, width: -0.51 },
      { number: 16, width: -0.51 }, { number: 17, width: -0.51 }, { number: 18, width: -0.51 },
      { number: 19, width: -0.51 }, { number: 21, width: -0.51 }, { number: 31, width: -0.51 },
      { number: 41, width: -0.51 }, { number: 51, width: -0.51 }, { number: 61, width: -0.51 },
      { number: 71, width: -0.51 }, { number: 81, width: -0.51 }, { number: 91, width: -0.51 }
    ]
  },
  'TAMU_Jersey_2024_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.63 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'TCU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.64 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.45 }, { number: 31, width: -0.45 },
      { number: 41, width: -0.45 }, { number: 51, width: -0.45 }, { number: 61, width: -0.45 },
      { number: 71, width: -0.45 }, { number: 81, width: -0.45 }, { number: 91, width: -0.45 }
    ]
  },
  'TCU_Jersey_2026_NUM_Array': {
    numberSpacing: -0.36,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.59 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.45 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.48 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.48 }, { number: 24, width: -0.32 },
      { number: 31, width: -0.48 }, { number: 34, width: -0.32 }, { number: 40, width: -0.31 },
      { number: 41, width: -0.48 }, { number: 42, width: -0.31 }, { number: 43, width: -0.31 },
      { number: 44, width: -0.29 }, { number: 46, width: -0.31 }, { number: 46, width: -0.31 },
      { number: 47, width: -0.31 }, { number: 48, width: -0.31 }, { number: 49, width: -0.31 },
      { number: 51, width: -0.48 }, { number: 54, width: -0.32 }, { number: 61, width: -0.48 },
      { number: 64, width: -0.32 }, { number: 71, width: -0.48 }, { number: 74, width: -0.36 },
      { number: 81, width: -0.48 }, { number: 84, width: -0.32 }, { number: 91, width: -0.48 },
      { number: 94, width: -0.32 }
    ]
  },
  'TEMP_JERSEY_2025_RED': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.45 }, { number: 11, width: -0.56 }, { number: 12, width: -0.45 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.52 }, { number: 15, width: -0.45 },
      { number: 16, width: -0.45 }, { number: 17, width: -0.45 }, { number: 18, width: -0.45 },
      { number: 19, width: -0.45 }, { number: 21, width: -0.42 }, { number: 31, width: -0.44 },
      { number: 41, width: -0.45 }, { number: 51, width: -0.42 }, { number: 61, width: -0.42 },
      { number: 71, width: -0.42 }, { number: 81, width: -0.42 }, { number: 91, width: -0.42 }
    ]
  },
  'TEM_Jersey_2021_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.4 }, { number: 11, width: -0.5 }, { number: 12, width: -0.4 },
      { number: 13, width: -0.4 }, { number: 14, width: -0.4 }, { number: 15, width: -0.4 },
      { number: 16, width: -0.4 }, { number: 17, width: -0.4 }, { number: 18, width: -0.4 },
      { number: 19, width: -0.4 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  },
  'TENN_Jersey_2021_NUM_Array': {
    numberSpacing: -0.52,
    playerNumberAdjust: [
      { number: 10, width: -0.61 }, { number: 11, width: -0.71 }, { number: 12, width: -0.61 },
      { number: 13, width: -0.61 }, { number: 14, width: -0.61 }, { number: 15, width: -0.61 },
      { number: 16, width: -0.61 }, { number: 17, width: -0.64 }, { number: 18, width: -0.61 },
      { number: 19, width: -0.61 }, { number: 21, width: -0.61 }, { number: 27, width: -0.54 },
      { number: 31, width: -0.61 }, { number: 37, width: -0.54 }, { number: 41, width: -0.61 },
      { number: 47, width: -0.54 }, { number: 51, width: -0.61 }, { number: 57, width: -0.54 },
      { number: 61, width: -0.61 }, { number: 67, width: -0.54 }, { number: 71, width: -0.64 },
      { number: 72, width: -0.54 }, { number: 73, width: -0.54 }, { number: 74, width: -0.54 },
      { number: 75, width: -0.54 }, { number: 76, width: -0.54 }, { number: 77, width: -0.56 },
      { number: 78, width: -0.54 }, { number: 79, width: -0.54 }, { number: 81, width: -0.61 },
      { number: 87, width: -0.54 }, { number: 91, width: -0.61 }, { number: 97, width: -0.54 }
    ]
  },
  'TENN_Jersey_2025_Smokey_NUM_Array': {
    numberSpacing: -0.41,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.63 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.52 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.52 }, { number: 31, width: -0.52 },
      { number: 41, width: -0.52 }, { number: 51, width: -0.52 }, { number: 61, width: -0.52 },
      { number: 71, width: -0.52 }, { number: 81, width: -0.52 }, { number: 91, width: -0.52 }
    ]
  },
  'TENN_Jersey_2026_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.68 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.51 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.55 }, { number: 24, width: -0.37 },
      { number: 31, width: -0.55 }, { number: 34, width: -0.37 }, { number: 40, width: -0.35 },
      { number: 41, width: -0.52 }, { number: 42, width: -0.35 }, { number: 43, width: -0.35 },
      { number: 44, width: -0.33 }, { number: 45, width: -0.35 }, { number: 46, width: -0.35 },
      { number: 47, width: -0.35 }, { number: 48, width: -0.35 }, { number: 49, width: -0.35 },
      { number: 51, width: -0.55 }, { number: 54, width: -0.37 }, { number: 61, width: -0.55 },
      { number: 64, width: -0.37 }, { number: 71, width: -0.55 }, { number: 74, width: -0.37 },
      { number: 81, width: -0.55 }, { number: 84, width: -0.37 }, { number: 91, width: -0.55 },
      { number: 94, width: -0.37 }
    ]
  },
  'TEX_Jersey_2024_NUM_Array': {
    numberSpacing: -0.404939115,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.63 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.54 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'TLSA_Jersey_2021_NUM_Array': {
    numberSpacing: -0.36,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.7 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.54 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'TOL_JERSEY_2023_BLACK': {
    numberSpacing: -0.3938529,
    playerNumberAdjust: [
      { number: 10, width: -0.47 }, { number: 11, width: -0.57 }, { number: 12, width: -0.47 },
      { number: 13, width: -0.47 }, { number: 14, width: -0.47 }, { number: 15, width: -0.47 },
      { number: 16, width: -0.47 }, { number: 17, width: -0.47 }, { number: 18, width: -0.47 },
      { number: 19, width: -0.47 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  },
  'TOL_JERSEY_2023_BLUE': {
    numberSpacing: -0.52,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.63 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.56 }, { number: 51, width: -0.56 }, { number: 61, width: -0.56 },
      { number: 71, width: -0.56 }, { number: 81, width: -0.56 }, { number: 91, width: -0.56 }
    ]
  },
  'TROY_Jersey_2023_NUM_Array': {
    numberSpacing: -0.54,
    playerNumberAdjust: [
      { number: 10, width: -0.63 }, { number: 11, width: -0.73 }, { number: 12, width: -0.63 },
      { number: 13, width: -0.63 }, { number: 14, width: -0.63 }, { number: 15, width: -0.63 },
      { number: 16, width: -0.63 }, { number: 17, width: -0.63 }, { number: 18, width: -0.63 },
      { number: 19, width: -0.63 }, { number: 21, width: -0.61 }, { number: 31, width: -0.61 },
      { number: 41, width: -0.61 }, { number: 51, width: -0.61 }, { number: 61, width: -0.61 },
      { number: 71, width: -0.61 }, { number: 81, width: -0.61 }, { number: 91, width: -0.61 }
    ]
  },
  'TTU_Jersey_2025_Mahomes_NUM_Array': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.66 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'TTU_Jersey_2025_NUM_Array': {
    numberSpacing: -0.3,
    playerNumberAdjust: [
      { number: 10, width: -0.44 }, { number: 11, width: -0.58 }, { number: 12, width: -0.44 },
      { number: 13, width: -0.44 }, { number: 14, width: -0.44 }, { number: 15, width: -0.44 },
      { number: 16, width: -0.44 }, { number: 17, width: -0.44 }, { number: 18, width: -0.44 },
      { number: 19, width: -0.44 }, { number: 21, width: -0.44 }, { number: 31, width: -0.44 },
      { number: 40, width: -0.27 }, { number: 41, width: -0.41 }, { number: 42, width: -0.27 },
      { number: 43, width: -0.27 }, { number: 44, width: -0.27 }, { number: 45, width: -0.27 },
      { number: 46, width: -0.27 }, { number: 47, width: -0.27 }, { number: 48, width: -0.27 },
      { number: 49, width: -0.27 }, { number: 51, width: -0.44 }, { number: 61, width: -0.44 },
      { number: 71, width: -0.44 }, { number: 81, width: -0.44 }, { number: 91, width: -0.44 }
    ]
  },
  'TTU_Jersey_2026_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.54 }, { number: 11, width: -0.69 }, { number: 12, width: -0.54 },
      { number: 13, width: -0.54 }, { number: 14, width: -0.54 }, { number: 15, width: -0.54 },
      { number: 16, width: -0.54 }, { number: 17, width: -0.54 }, { number: 18, width: -0.54 },
      { number: 19, width: -0.54 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 40, width: -0.41 }, { number: 41, width: -0.52 }, { number: 42, width: -0.41 },
      { number: 43, width: -0.41 }, { number: 44, width: -0.39 }, { number: 45, width: -0.41 },
      { number: 46, width: -0.41 }, { number: 47, width: -0.41 }, { number: 48, width: -0.41 },
      { number: 49, width: -0.41 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'TULN_JERSEY_2023_BLUE': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.47 }, { number: 11, width: -0.57 }, { number: 12, width: -0.47 },
      { number: 13, width: -0.47 }, { number: 14, width: -0.47 }, { number: 15, width: -0.47 },
      { number: 16, width: -0.47 }, { number: 17, width: -0.47 }, { number: 18, width: -0.47 },
      { number: 19, width: -0.47 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  },
  'TULN_Jersey_2025_CITY_EDITION_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.66 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.58 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.54 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 70, width: -0.46 }, { number: 71, width: -0.55 }, { number: 72, width: -0.46 },
      { number: 73, width: -0.46 }, { number: 74, width: -0.46 }, { number: 75, width: -0.46 },
      { number: 76, width: -0.46 }, { number: 77, width: -0.46 }, { number: 78, width: -0.46 },
      { number: 79, width: -0.46 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'TXST_Jersey_2023_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.44 }, { number: 11, width: -0.54 }, { number: 12, width: -0.44 },
      { number: 13, width: -0.44 }, { number: 14, width: -0.44 }, { number: 15, width: -0.44 },
      { number: 16, width: -0.44 }, { number: 17, width: -0.44 }, { number: 18, width: -0.44 },
      { number: 19, width: -0.44 }, { number: 21, width: -0.44 }, { number: 31, width: -0.44 },
      { number: 41, width: -0.44 }, { number: 51, width: -0.44 }, { number: 61, width: -0.44 },
      { number: 71, width: -0.44 }, { number: 81, width: -0.44 }, { number: 91, width: -0.44 }
    ]
  },
  'TXST_Jersey_2024_NUM_Array': {
    numberSpacing: -0.36,
    playerNumberAdjust: [
      { number: 10, width: -0.46 }, { number: 11, width: -0.58 }, { number: 12, width: -0.46 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.46 }, { number: 15, width: -0.46 },
      { number: 16, width: -0.46 }, { number: 17, width: -0.46 }, { number: 18, width: -0.46 },
      { number: 19, width: -0.46 }, { number: 21, width: -0.48 }, { number: 24, width: -0.34 },
      { number: 31, width: -0.48 }, { number: 34, width: -0.34 }, { number: 40, width: -0.33 },
      { number: 41, width: -0.48 }, { number: 42, width: -0.33 }, { number: 43, width: -0.33 },
      { number: 44, width: -0.33 }, { number: 45, width: -0.33 }, { number: 46, width: -0.33 },
      { number: 47, width: -0.33 }, { number: 48, width: -0.33 }, { number: 49, width: -0.33 },
      { number: 51, width: -0.48 }, { number: 54, width: -0.34 }, { number: 61, width: -0.48 },
      { number: 64, width: -0.34 }, { number: 71, width: -0.48 }, { number: 74, width: -0.44 },
      { number: 81, width: -0.48 }, { number: 84, width: -0.34 }, { number: 91, width: -0.48 },
      { number: 94, width: -0.34 }
    ]
  },
  'UAB_Jersey_2021_NUM_Array': {
    numberSpacing: -0.35,
    playerNumberAdjust: [
      { number: 10, width: -0.555 }, { number: 11, width: -0.6 }, { number: 12, width: -0.555 },
      { number: 13, width: -0.555 }, { number: 14, width: -0.555 }, { number: 15, width: -0.555 },
      { number: 16, width: -0.555 }, { number: 17, width: -0.555 }, { number: 18, width: -0.555 },
      { number: 19, width: -0.555 }, { number: 21, width: -0.43 }, { number: 31, width: -0.43 },
      { number: 41, width: -0.43 }, { number: 51, width: -0.43 }, { number: 61, width: -0.43 },
      { number: 71, width: -0.43 }, { number: 81, width: -0.43 }, { number: 91, width: -0.43 }
    ]
  },
  'UCF_Jersey_2023_NUM_Array': {
    numberSpacing: -0.57,
    playerNumberAdjust: [
      { number: 10, width: -0.65 }, { number: 11, width: -0.67 }, { number: 12, width: -0.65 },
      { number: 13, width: -0.65 }, { number: 14, width: -0.65 }, { number: 15, width: -0.65 },
      { number: 16, width: -0.65 }, { number: 17, width: -0.65 }, { number: 18, width: -0.65 },
      { number: 19, width: -0.65 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'UCF_Jersey_2024_NUM_Array': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.69 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'UCF_Jersey_2024_SPACE_NUM_Array': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.69 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'UCF_Jersey_2025_4_NUM_Array': {
    numberSpacing: -0.41,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.69 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'UCF_Jersey_2025_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.67 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'UCF_Jersey_2025_Space_NUM_Array': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.62 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'UCLA_Jersey_2021_NUM_Array': {
    numberSpacing: -0.43,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.64 }, { number: 12, width: -0.54 },
      { number: 13, width: -0.54 }, { number: 14, width: -0.59 }, { number: 15, width: -0.54 },
      { number: 16, width: -0.54 }, { number: 17, width: -0.59 }, { number: 18, width: -0.54 },
      { number: 19, width: -0.54 }, { number: 21, width: -0.51 }, { number: 31, width: -0.51 },
      { number: 41, width: -0.51 }, { number: 51, width: -0.54 }, { number: 61, width: -0.51 },
      { number: 71, width: -0.51 }, { number: 81, width: -0.51 }, { number: 91, width: -0.51 }
    ]
  },
  'UCLA_Jersey_2023_ALT_NUM_Array': {
    numberSpacing: -0.445,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.63 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'UGA_JERSEY_2023_RED': {
    numberSpacing: -0.408723861,
    playerNumberAdjust: [
      { number: 10, width: -0.54 }, { number: 11, width: -0.66 }, { number: 12, width: -0.54 },
      { number: 13, width: -0.54 }, { number: 14, width: -0.54 }, { number: 15, width: -0.54 },
      { number: 16, width: -0.54 }, { number: 17, width: -0.54 }, { number: 18, width: -0.54 },
      { number: 19, width: -0.54 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'UK_JERSEY_2023_BLUE': {
    numberSpacing: -0.56,
    playerNumberAdjust: [
      { number: 10, width: -0.65 }, { number: 11, width: -0.73 }, { number: 12, width: -0.65 },
      { number: 13, width: -0.65 }, { number: 14, width: -0.65 }, { number: 15, width: -0.65 },
      { number: 16, width: -0.65 }, { number: 17, width: -0.65 }, { number: 18, width: -0.65 },
      { number: 19, width: -0.65 }, { number: 21, width: -0.65 }, { number: 31, width: -0.65 },
      { number: 41, width: -0.65 }, { number: 51, width: -0.65 }, { number: 61, width: -0.65 },
      { number: 71, width: -0.65 }, { number: 81, width: -0.65 }, { number: 91, width: -0.65 }
    ]
  },
  'ULL_JERSEY_2023_THROWBACK': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.69 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.62 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.62 }, { number: 51, width: -0.62 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.62 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'ULL_Jersey_2021_NUM_Array': {
    numberSpacing: -0.39,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.73 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'ULL_Jersey_2025_BLOCKSHADOW_NUM_Array': {
    numberSpacing: -0.43,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.71 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'ULM_JERSEY_2025_GRAY': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.47 }, { number: 11, width: -0.57 }, { number: 12, width: -0.47 },
      { number: 13, width: -0.47 }, { number: 14, width: -0.47 }, { number: 15, width: -0.47 },
      { number: 16, width: -0.47 }, { number: 17, width: -0.47 }, { number: 18, width: -0.47 },
      { number: 19, width: -0.47 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  },
  'ULM_Jersey_2016_NUM_Array': {
    numberSpacing: -0.55,
    playerNumberAdjust: [
      { number: 10, width: -0.66 }, { number: 11, width: -0.75 }, { number: 12, width: -0.66 },
      { number: 13, width: -0.66 }, { number: 14, width: -0.66 }, { number: 15, width: -0.66 },
      { number: 16, width: -0.66 }, { number: 17, width: -0.66 }, { number: 18, width: -0.66 },
      { number: 19, width: -0.66 }, { number: 21, width: -0.66 }, { number: 31, width: -0.66 },
      { number: 40, width: -0.54 }, { number: 41, width: -0.66 }, { number: 42, width: -0.54 },
      { number: 43, width: -0.54 }, { number: 44, width: -0.5 }, { number: 45, width: -0.54 },
      { number: 46, width: -0.54 }, { number: 47, width: -0.54 }, { number: 48, width: -0.54 },
      { number: 49, width: -0.54 }, { number: 51, width: -0.66 }, { number: 61, width: -0.66 },
      { number: 71, width: -0.66 }, { number: 81, width: -0.66 }, { number: 91, width: -0.66 }
    ]
  },
  'ULM_Jersey_2021_NUM_Array': {
    numberSpacing: -0.57,
    playerNumberAdjust: [
      { number: 10, width: -0.66 }, { number: 11, width: -0.75 }, { number: 12, width: -0.66 },
      { number: 13, width: -0.66 }, { number: 14, width: -0.66 }, { number: 15, width: -0.66 },
      { number: 16, width: -0.66 }, { number: 17, width: -0.66 }, { number: 18, width: -0.66 },
      { number: 19, width: -0.66 }, { number: 21, width: -0.66 }, { number: 31, width: -0.66 },
      { number: 41, width: -0.66 }, { number: 51, width: -0.66 }, { number: 61, width: -0.66 },
      { number: 71, width: -0.66 }, { number: 81, width: -0.66 }, { number: 91, width: -0.66 }
    ]
  },
  'UMASS_JERSEY_2023_MAROON': {
    numberSpacing: -0.53,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.69 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.62 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.62 }, { number: 51, width: -0.62 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.62 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'UMD_Jersey_2025_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.72 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.62 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.62 }, { number: 51, width: -0.62 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.62 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'UMD_Jersey_Away_2023_NUM_Array': {
    numberSpacing: -0.46,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.68 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.58 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'UNC_Jersey_2021_NUM_Array': {
    numberSpacing: -0.26,
    playerNumberAdjust: [
      { number: 10, width: -0.41 }, { number: 11, width: -0.58 }, { number: 12, width: -0.41 },
      { number: 13, width: -0.41 }, { number: 14, width: -0.41 }, { number: 15, width: -0.41 },
      { number: 16, width: -0.41 }, { number: 17, width: -0.41 }, { number: 18, width: -0.41 },
      { number: 19, width: -0.41 }, { number: 21, width: -0.41 }, { number: 31, width: -0.41 },
      { number: 41, width: -0.41 }, { number: 51, width: -0.41 }, { number: 61, width: -0.41 },
      { number: 71, width: -0.41 }, { number: 81, width: -0.41 }, { number: 91, width: -0.41 }
    ]
  },
  'UNC_Jersey_2022_NUM_Array': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.64 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'UNLV_JERSEY_2023_RED': {
    numberSpacing: -0.34,
    playerNumberAdjust: [
      { number: 10, width: -0.46 }, { number: 11, width: -0.56 }, { number: 12, width: -0.46 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.43 }, { number: 15, width: -0.46 },
      { number: 16, width: -0.46 }, { number: 17, width: -0.46 }, { number: 18, width: -0.46 },
      { number: 19, width: -0.46 }, { number: 21, width: -0.46 }, { number: 31, width: -0.46 },
      { number: 41, width: -0.44 }, { number: 42, width: -0.31 }, { number: 43, width: -0.31 },
      { number: 44, width: -0.28 }, { number: 45, width: -0.31 }, { number: 46, width: -0.31 },
      { number: 47, width: -0.31 }, { number: 48, width: -0.31 }, { number: 49, width: -0.31 },
      { number: 51, width: -0.46 }, { number: 61, width: -0.46 }, { number: 71, width: -0.46 },
      { number: 81, width: -0.46 }, { number: 91, width: -0.46 }
    ]
  },
  'UNM_Jersey_2021_NUM_Array': {
    numberSpacing: -0.36,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.63 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.52 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.5 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.45 }, { number: 22, width: -0.35 },
      { number: 23, width: -0.3 }, { number: 24, width: -0.32 }, { number: 25, width: -0.3 },
      { number: 26, width: -0.32 }, { number: 27, width: -0.32 }, { number: 28, width: -0.32 },
      { number: 29, width: -0.32 }, { number: 31, width: -0.46 }, { number: 41, width: -0.45 },
      { number: 42, width: -0.32 }, { number: 43, width: -0.3 }, { number: 44, width: -0.32 },
      { number: 45, width: -0.3 }, { number: 46, width: -0.32 }, { number: 47, width: -0.35 },
      { number: 48, width: -0.32 }, { number: 49, width: -0.32 }, { number: 51, width: -0.45 },
      { number: 61, width: -0.45 }, { number: 71, width: -0.48 }, { number: 81, width: -0.45 },
      { number: 91, width: -0.46 }
    ]
  },
  'UNM_Jersey_2025_NUM_Array': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.69 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.56 }, { number: 51, width: -0.56 }, { number: 61, width: -0.56 },
      { number: 71, width: -0.56 }, { number: 81, width: -0.56 }, { number: 91, width: -0.56 }
    ]
  },
  'UNT_JERSEY_2022_HAYDENFRY': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.65 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.565 }, { number: 31, width: -0.565 },
      { number: 41, width: -0.565 }, { number: 51, width: -0.565 }, { number: 61, width: -0.565 },
      { number: 71, width: -0.565 }, { number: 81, width: -0.565 }, { number: 91, width: -0.565 }
    ]
  },
  'UNT_JERSEY_2023_GREEN': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.59 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'USA_Jersey_2021_NUM_Array': {
    numberSpacing: -0.49,
    playerNumberAdjust: [
      { number: 10, width: -0.63 }, { number: 11, width: -0.71 }, { number: 12, width: -0.65 },
      { number: 13, width: -0.69 }, { number: 14, width: -0.6 }, { number: 15, width: -0.65 },
      { number: 16, width: -0.68 }, { number: 17, width: -0.65 }, { number: 18, width: -0.65 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.57 }, { number: 30, width: -0.53 },
      { number: 31, width: -0.62 }, { number: 32, width: -0.54 }, { number: 33, width: -0.58 },
      { number: 34, width: -0.49 }, { number: 35, width: -0.53 }, { number: 36, width: -0.57 },
      { number: 37, width: -0.53 }, { number: 38, width: -0.53 }, { number: 39, width: -0.5 },
      { number: 41, width: -0.61 }, { number: 44, width: -0.42 }, { number: 51, width: -0.59 },
      { number: 61, width: -0.62 }, { number: 71, width: -0.59 }, { number: 81, width: -0.59 },
      { number: 91, width: -0.63 }
    ]
  },
  'USC_Jersey_2024_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.51 }, { number: 11, width: -0.61 }, { number: 12, width: -0.51 },
      { number: 13, width: -0.51 }, { number: 14, width: -0.51 }, { number: 15, width: -0.51 },
      { number: 16, width: -0.51 }, { number: 17, width: -0.51 }, { number: 18, width: -0.51 },
      { number: 19, width: -0.51 }, { number: 21, width: -0.51 }, { number: 31, width: -0.51 },
      { number: 41, width: -0.51 }, { number: 51, width: -0.51 }, { number: 61, width: -0.51 },
      { number: 71, width: -0.51 }, { number: 81, width: -0.51 }, { number: 91, width: -0.51 }
    ]
  },
  'USC_Jersey_2024_Throwback_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.51 }, { number: 11, width: -0.61 }, { number: 12, width: -0.51 },
      { number: 13, width: -0.51 }, { number: 14, width: -0.51 }, { number: 15, width: -0.51 },
      { number: 16, width: -0.51 }, { number: 17, width: -0.51 }, { number: 18, width: -0.51 },
      { number: 19, width: -0.51 }, { number: 21, width: -0.51 }, { number: 31, width: -0.51 },
      { number: 41, width: -0.51 }, { number: 51, width: -0.51 }, { number: 61, width: -0.51 },
      { number: 71, width: -0.51 }, { number: 81, width: -0.51 }, { number: 91, width: -0.51 }
    ]
  },
  'USF_Jersey_2023_NUM_Array': {
    numberSpacing: -0.39,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.64 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.53 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.57 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'USM_Jersey_2025_NUM_Array': {
    numberSpacing: -0.51,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.75 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.62 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.62 }, { number: 51, width: -0.62 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.62 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'USU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.71 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.56 }, { number: 51, width: -0.56 }, { number: 61, width: -0.56 },
      { number: 71, width: -0.56 }, { number: 81, width: -0.56 }, { number: 91, width: -0.56 }
    ]
  },
  'UTAH_Jersey_2021_02_NUM_Array': {
    numberSpacing: -0.453665555,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.6 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.52 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'UTAH_Jersey_2022_NUM_Array': {
    numberSpacing: -0.55,
    playerNumberAdjust: [
      { number: 10, width: -0.66 }, { number: 11, width: -0.72 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.66 }, { number: 14, width: -0.66 }, { number: 15, width: -0.66 },
      { number: 16, width: -0.66 }, { number: 17, width: -0.66 }, { number: 18, width: -0.66 },
      { number: 19, width: -0.66 }, { number: 21, width: -0.62 }, { number: 31, width: -0.65 },
      { number: 41, width: -0.65 }, { number: 51, width: -0.65 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.63 }, { number: 81, width: -0.65 }, { number: 91, width: -0.65 }
    ]
  },
  'UTEP_JERSEY_2026_BLUE': {
    numberSpacing: -0.58,
    playerNumberAdjust: [
      { number: 10, width: -0.64 }, { number: 11, width: -0.72 }, { number: 12, width: -0.64 },
      { number: 13, width: -0.64 }, { number: 14, width: -0.64 }, { number: 15, width: -0.64 },
      { number: 16, width: -0.64 }, { number: 17, width: -0.64 }, { number: 18, width: -0.64 },
      { number: 19, width: -0.64 }, { number: 21, width: -0.64 }, { number: 31, width: -0.64 },
      { number: 41, width: -0.64 }, { number: 51, width: -0.64 }, { number: 61, width: -0.64 },
      { number: 71, width: -0.64 }, { number: 81, width: -0.64 }, { number: 91, width: -0.64 }
    ]
  },
  'UTEP_Jersey_2021_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.57 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.48 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.48 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.48 }, { number: 31, width: -0.48 },
      { number: 41, width: -0.48 }, { number: 51, width: -0.48 }, { number: 61, width: -0.48 },
      { number: 71, width: -0.48 }, { number: 81, width: -0.48 }, { number: 91, width: -0.48 }
    ]
  },
  'UTSA_Jersey_2025_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.69 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.58 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'UVA_Jersey_2021_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.74 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.52 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'VAN_Jersey_2021_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.55 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.48 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.48 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.48 }, { number: 31, width: -0.48 },
      { number: 41, width: -0.48 }, { number: 51, width: -0.48 }, { number: 61, width: -0.48 },
      { number: 71, width: -0.48 }, { number: 81, width: -0.48 }, { number: 91, width: -0.48 }
    ]
  },
  'VT_Jersey_2023_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.67 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.49 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.52 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.52 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'VT_Jersey_2024_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.67 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.49 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.52 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.52 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'WAKE_Jersey_2022_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.72 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'WASH_JERSEY_2021_THROWBACK': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.68 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.58 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.64 }, { number: 31, width: -0.64 },
      { number: 41, width: -0.64 }, { number: 51, width: -0.64 }, { number: 61, width: -0.63 },
      { number: 71, width: -0.64 }, { number: 81, width: -0.64 }, { number: 91, width: -0.64 }
    ]
  },
  'WASH_Jersey_2021_NUM_Array': {
    numberSpacing: -0.404939115,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.63 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'WASH_Jersey_2023_NUM_Array': {
    numberSpacing: -0.404939115,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.63 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'WASH_Jersey_2024_NUM_Array': {
    numberSpacing: -0.404939115,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.63 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'WASH_Jersey_2025_Camo_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.6 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'WASH_Jersey_2025_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.6 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'WIS_Jersey_2021_NUM_Array': {
    numberSpacing: -0.51,
    playerNumberAdjust: [
      { number: 10, width: -0.63 }, { number: 11, width: -0.73 }, { number: 12, width: -0.63 },
      { number: 13, width: -0.63 }, { number: 14, width: -0.63 }, { number: 15, width: -0.63 },
      { number: 16, width: -0.63 }, { number: 17, width: -0.63 }, { number: 18, width: -0.63 },
      { number: 19, width: -0.63 }, { number: 21, width: -0.63 }, { number: 31, width: -0.63 },
      { number: 41, width: -0.63 }, { number: 51, width: -0.63 }, { number: 61, width: -0.63 },
      { number: 71, width: -0.63 }, { number: 81, width: -0.63 }, { number: 91, width: -0.63 }
    ]
  },
  'WIS_Jersey_2025_Throwback_NUM_Array': {
    numberSpacing: -0.43,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.61 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.52 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.52 }, { number: 31, width: -0.52 },
      { number: 41, width: -0.52 }, { number: 51, width: -0.52 }, { number: 61, width: -0.52 },
      { number: 71, width: -0.52 }, { number: 81, width: -0.52 }, { number: 91, width: -0.52 }
    ]
  },
  'WKU_JERSEY_2023_RED': {
    numberSpacing: -0.465,
    playerNumberAdjust: [
      { number: 10, width: -0.61 }, { number: 11, width: -0.7 }, { number: 12, width: -0.61 },
      { number: 13, width: -0.61 }, { number: 14, width: -0.61 }, { number: 15, width: -0.61 },
      { number: 16, width: -0.61 }, { number: 17, width: -0.61 }, { number: 18, width: -0.61 },
      { number: 19, width: -0.61 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.56 }, { number: 51, width: -0.56 }, { number: 61, width: -0.56 },
      { number: 71, width: -0.56 }, { number: 81, width: -0.56 }, { number: 91, width: -0.56 }
    ]
  },
  'WMU_Jersey_2024_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.6 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'WSU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.7 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.56 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.6 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.6 }, { number: 24, width: -0.41 },
      { number: 31, width: -0.6 }, { number: 34, width: -0.41 }, { number: 41, width: -0.6 },
      { number: 42, width: -0.47 }, { number: 43, width: -0.47 }, { number: 44, width: -0.41 },
      { number: 45, width: -0.47 }, { number: 46, width: -0.47 }, { number: 47, width: -0.5 },
      { number: 48, width: -0.47 }, { number: 49, width: -0.47 }, { number: 51, width: -0.6 },
      { number: 54, width: -0.41 }, { number: 61, width: -0.6 }, { number: 64, width: -0.41 },
      { number: 71, width: -0.6 }, { number: 74, width: -0.41 }, { number: 81, width: -0.6 },
      { number: 84, width: -0.41 }, { number: 91, width: -0.6 }, { number: 94, width: -0.41 }
    ]
  },
  'WVU_JERSEY_2025_THROWBACK': {
    numberSpacing: -0.36,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.58 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.48 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.48 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.48 }, { number: 31, width: -0.48 },
      { number: 41, width: -0.48 }, { number: 51, width: -0.48 }, { number: 61, width: -0.48 },
      { number: 71, width: -0.48 }, { number: 81, width: -0.48 }, { number: 91, width: -0.48 }
    ]
  },
  'WVU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.375,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.73 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.53 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'WYO_Jersey_2021_NUM_Array': {
    numberSpacing: -0.396063447,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.6 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.52 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.54 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  }
};
// Which offsetScaleSpacing sub-objects get cloned wholesale alongside the
// font. Each is written as one atomic object replace (never a partial x/y/z/w
// merge), same reasoning as playerNumberAdjust: a stale leftover component
// from the previous font is worse than a clean full swap.
const NUMBER_OFFSET_SCALE_FIELDS = [
  'chestNumberOffsetScale', 'backNumberOffsetScale', 'shoulderNumberOffsetScale', 'sleeveNumberOffsetScale'
];

// v1 scope: only fields confirmed to actually work in-game. Helmet number font and
// name font are left out entirely -- both are still unverified (see the prompt doc),
// and weren't wanted in this pass regardless.
const FIELD_GROUPS = [
  {
    key: 'jerseyNumberFont', label: 'Jersey Number Font', status: 'ok', partKind: 'jersey',
    subfields: [
      {
        key: 'font', label: '',
        options: () => [...CATALOG.numberFonts.jersey, ...CATALOG.numberFonts.alts]
          .filter(e => isUsableFontPath(e.path) && !/_name_array$/i.test(e.path)),
        // Optional: when the picked font has a confirmed entry here, applyField
        // also writes its full number layout (spacing, 4 offset/scale blocks,
        // playerNumberAdjust) in the same action. Fonts with no entry behave
        // exactly as before -- this is additive.
        numberLayoutProfiles: NUMBER_LAYOUT_PROFILES,
        // Confirmed: arrayTexture.textureId can't be left blank, and once set, both
        // it and the overlay's textureId use the identical non-/comp/ path.
        targets: [
          { label: 'arrayTexture', path: ['numberComp', 'arrayTexture', 'textureId'], transform: stripCompSegment },
          { label: 'overlay', path: ['numberComp', 'overlays', 0, 'textures', 'color', 'textureId'], transform: stripCompSegment }
        ]
      }
    ]
  },
  {
    key: 'helmetMaterials', label: 'Helmet Materials', status: 'ok', partKind: 'helmet',
    subfields: [
      {
        key: 'shell', label: 'Shell',
        hint: 'Also sets the matching accessory automatically.',
        options: () => CATALOG.helmetMaterials.shell,
        targets: [
          { label: 'shell', path: ['shellMaterial'] },
          { label: 'accessory (auto)', path: ['accMaterial'], lookupCatalog: () => CATALOG.helmetMaterials.accessory }
        ]
      }
    ]
  }
];
const STATUS_BADGE = {
  ok: '<span class="badge ok">confirmed</span>',
  warn: '<span class="badge warn">unverified</span>',
  off: '<span class="badge off">out of scope</span>'
};

// ---------- editor rendering ----------
function renderEditor() {
  const out = document.getElementById('editorOut');
  if (!state.payload || !state.variants.length) {
    out.innerHTML = '<div class="empty-state">No uniform variants found in this payload — check it actually has teamData.frostbiteData.uniformParts.</div>';
    return;
  }
  const variantOptions = state.variants.map((v, i) => `<option value="${i}"${i === state.selectedVariantIdx ? ' selected' : ''}>${escapeHtml(v.label)}</option>`).join('');

  out.innerHTML = `
    <div class="row">
      <div class="field">
        <label for="variantSel">Uniform variant</label>
        <select id="variantSel">${variantOptions}</select>
      </div>
    </div>
    <div id="fieldsOut"></div>
    <div id="decalOut" style="margin-top:12px;"></div>
    <div id="spacingOut" style="margin-top:12px;"></div>
  `;
  document.getElementById('variantSel').addEventListener('change', (e) => {
    state.selectedVariantIdx = +e.target.value;
    state.lastSelections = {};
    renderFields();
    renderDecalSection();
    renderSpacingSection();
  });
  renderFields();
  renderDecalSection();
  renderSpacingSection();
}

function renderFields() {
  const variant = state.variants[state.selectedVariantIdx];
  const fieldsEl = document.getElementById('fieldsOut');

  fieldsEl.innerHTML = FIELD_GROUPS.map(group => {
    const part = getPart(group);

    const subfieldsHtml = !part ? '' : group.subfields.map(sub => {
      const gsKey = group.key + ':' + sub.key;
      const listId = 'dl-' + gsKey;
      const opts = sub.options();
      const datalist = opts.length ? `<datalist id="${listId}">${opts.map(o => `<option value="${escapeHtml(o.label || o.displayName)}">`).join('')}</datalist>` : '';

      const currentValsHtml = sub.targets.map(t => {
        const v = getDeep(part, t.path);
        const tag = sub.targets.length > 1 ? ` (${escapeHtml(t.label)})` : '';
        return `<div class="current-val"><b>current${tag} — what's already there:</b> ${escapeHtml(v || '(unset)')}</div>`;
      }).join('');

      const lastValue = state.lastSelections[gsKey] || '';

      return `
        <div${group.subfields.length > 1 ? ' style="margin-top:14px; padding-top:14px; border-top:1px solid var(--line);"' : ''}>
          ${sub.label ? `<div style="font-weight:600; font-size:12.5px; margin-bottom:6px;">${escapeHtml(sub.label)}</div>` : ''}
          ${sub.hint ? `<div class="hint" style="margin-bottom:6px;">${escapeHtml(sub.hint)}</div>` : ''}
          <div class="row" style="align-items:flex-start;">
            <div class="field">
              <input type="text" list="${listId}" data-key="${gsKey}" value="${escapeHtml(lastValue)}" placeholder="${opts.length ? 'Pick from catalog' : 'Paste a raw path'} — sets ${sub.targets.length > 1 ? 'all fields' : 'this field'} at once">
            </div>
            <button type="button" data-clear-key="${gsKey}" title="Clear this field">Clear</button>
          </div>
          ${datalist}
          ${currentValsHtml}
        </div>`;
    }).join('');

    return `
      <div class="fieldblock">
        <div class="head">
          <div class="name">${escapeHtml(group.label)}</div>
          ${STATUS_BADGE[group.status]}
        </div>
        ${!part ? `<div class="hint">No ${group.partKind} part found for this variant.</div>` : subfieldsHtml}
      </div>`;
  }).join('');

  FIELD_GROUPS.forEach(group => {
    group.subfields.forEach(sub => {
      const gsKey = group.key + ':' + sub.key;
      const input = fieldsEl.querySelector(`input[data-key="${gsKey}"]`);
      if (input) {
        input.addEventListener('change', () => applyField(group, sub, input.value));
        // Select all existing text on focus, so typing immediately overwrites
        // instead of requiring a manual select-all-and-delete first.
        input.addEventListener('focus', () => input.select());
      }
      const clearBtn = fieldsEl.querySelector(`button[data-clear-key="${gsKey}"]`);
      if (clearBtn && input) {
        clearBtn.addEventListener('click', () => {
          input.value = '';
          input.focus();
        });
      }
    });
  });
}

function getPart(group) {
  const variant = state.variants[state.selectedVariantIdx];
  const partKey = group.partKind === 'helmet' ? variant.helmetKey : variant.jerseyKey;
  if (!partKey) return null;
  const basePath = ['teamData', 'frostbiteData', 'uniformParts', group.partKind === 'helmet' ? 'helmets' : 'jerseys', partKey];
  return getDeep(state.payload, basePath);
}

// ---------- vendor decal swapper (jersey + pants + socks together) ----------
// Confirmed working in-game across multiple brands/materials. Finds the vendor
// logo overlay(s) structurally -- by checking which overlay's own texture
// already points into .../decals/vendors/... -- rather than searching by
// info.label, since the label text itself changes to match whichever brand is
// currently equipped (confirmed: "Nike Logo" vs "Adidas Logo" on different
// default teams). That makes label text unreliable as a search key, but a
// fine thing to display for confirmation once found.
//
// Returns ALL matching indices, not just the first -- confirmed some templates
// (Nike socks specifically) carry two separate decal overlays (mirrored left/
// right sides), and updating only one would leave the other on the old brand.
function findVendorDecalOverlays(part) {
  const overlays = part?.layerCompTexture?.overlays;
  if (!Array.isArray(overlays)) return [];
  const out = [];
  overlays.forEach((o, i) => {
    const tid = o?.textures?.color?.textureId;
    if (typeof tid === 'string' && tid.toLowerCase().includes('/decals/vendors/')) out.push(i);
  });
  return out;
}

const DECAL_PIECES = [
  { kind: 'jersey', plural: 'jerseys', keyField: 'jerseyKey' },
  { kind: 'pants', plural: 'pants', keyField: 'pantsKey' },
  { kind: 'socks', plural: 'socks', keyField: 'socksKey' }
];

// Placement defaults per brand, per piece -- pulled from confirmed real team
// recipes. Nike, Jumpman, UA, and Adidas each now have 2 confirmed schools
// with matching values across jersey/pants/socks -- consistent enough that
// per-brand (not per-template) placement looks like the right model after all.
// Still examples from specific teams, not guaranteed universal constants.
//
// Only applied when a piece has exactly ONE decal overlay. A multi-overlay
// piece (Nike's two-sided socks are the only confirmed case) gets its texture
// updated on every matching overlay, but placement is left alone -- no
// confirmed per-side data to apply safely there.
const BRAND_PIECE_TRANSFORM = {
  'Nike': {
    jersey: { scaleU: 0.05, scaleV: 0.05, offsetU: 0.0745, offsetV: -0.1085, rotate: 350 },
    // Confirmed via two independent schools (FSU, and this exact team via
    // Frosty Editor) -- essentially identical values both times. The earlier
    // "Nike is broken" report was very likely the same cross-brand layout
    // contamination diagnosed for Nike Plastic, not bad reference numbers.
    // layout: null is itself confirmed -- Nike's pants overlay has no fourth
    // UV-set texture slot in Frosty, unlike Jumpman/Adidas. Explicitly
    // resetting it (not just leaving it alone) actively undoes contamination
    // from a prior Jumpman/Adidas test instead of silently inheriting it.
    pants: { scaleU: 0.06, scaleV: 0.12, offsetU: 0.154, offsetV: 0.234, rotate: 7.5, layout: null }
    // socks intentionally omitted -- two mirrored overlays, no safe single value
  },
  'Jumpman': {
    jersey: { scaleU: 0.03, scaleV: 0.03, offsetU: 0.0745, offsetV: -0.094, rotate: 0 },
    pants: {
      scaleU: 0.069, scaleV: 0.085, offsetU: 0.222, offsetV: 0.339, rotate: 5.0,
      layout: 'ContentShared/characters/player/parts/uniforms/uvsets/Pants_UVSet_front'
    },
    socks: { scaleU: 0.07, scaleV: 0.07, offsetU: 0, offsetV: 0.315, rotate: 0 }
  },
  'Under Armour': {
    jersey: { scaleU: 0.035, scaleV: 0.036, offsetU: 0, offsetV: -0.1325, rotate: 0 },
    // Pants confirmed via a fresh, provably untouched team's raw JSON export --
    // not Frosty. Frosty's Georgia Tech reading (0.04/0.07, offset -0.155/0.255,
    // rotate 354) disagreed meaningfully with this direct JSON pull, especially
    // on offset.u (opposite sign) and rotate (near-mirrored angle) -- a real
    // discrepancy, not rounding noise. Going with the direct JSON value as the
    // more trustworthy source, per the same reasoning already validated for
    // Nike/Jumpman/Adidas (all confirmed via raw JSON, not Frosty alone).
    // layout: null confirmed on this same fresh export -- consistent with what
    // Frosty showed (no fourth UV-set slot), so that part of the picture holds.
    pants: { scaleU: 0.04, scaleV: 0.08, offsetU: 0.138, offsetV: 0.265, rotate: 7.2, layout: null },
    socks: { scaleU: 0.1, scaleV: 0.08, offsetU: 0, offsetV: 0.3, rotate: 0 }
  },
  'Adidas': {
    jersey: { scaleU: 0.042, scaleV: 0.042, offsetU: 0.07, offsetV: -0.124, rotate: 358 },
    pants: {
      scaleU: 0.04, scaleV: 0.08, offsetU: 0.16, offsetV: 0.265, rotate: 7,
      layout: 'ContentShared/characters/player/parts/uniforms/uvsets/Pants_UVSet_maddenOld'
    },
    socks: { scaleU: 0.13, scaleV: 0.13, offsetU: 0, offsetV: 0.29, rotate: 0 }
  }
};

// Per-material overrides, layered on top of the brand-level defaults above.
// Only needed when a specific material genuinely differs from its brand's
// baseline -- confirmed here for Adidas WithText specifically (bigger scale,
// different offset than base Adidas), verified via an actual in-game Team
// Builder render, not just a raw-JSON comparison. Keyed by the exact catalog
// label. Jumpman's Cotton vs. Diamond were confirmed to NOT need this --
// same placement, brand-level default was already correct for both.
const MATERIAL_PIECE_OVERRIDES = {
  'Adidas WithText (2023)': {
    pants: {
      scaleU: 0.056, scaleV: 0.112, offsetU: 0.16, offsetV: 0.33, rotate: 7,
      layout: 'ContentShared/characters/player/parts/uniforms/uvsets/Pants_UVSet_maddenOld'
    }
  }
};

function decalPieceStatus() {
  const variant = state.variants[state.selectedVariantIdx];
  return DECAL_PIECES.map(pd => {
    const partKey = variant?.[pd.keyField];
    if (!partKey) return { ...pd, found: false, note: 'no part for this variant' };
    const part = getDeep(state.payload, ['teamData', 'frostbiteData', 'uniformParts', pd.plural, partKey]);
    const idxs = findVendorDecalOverlays(part);
    if (!idxs.length) return { ...pd, found: false, note: 'no vendor decal overlay found' };
    const overlay = part.layerCompTexture.overlays[idxs[0]];
    const label = idxs.length > 1 ? `${overlay?.info?.label || '(unlabeled)'} +${idxs.length - 1} more` : (overlay?.info?.label || '(unlabeled)');
    return { ...pd, found: true, idxs, label, current: overlay?.textures?.color?.textureId || '' };
  });
}

function renderDecalSection() {
  const out = document.getElementById('decalOut');
  if (!out) return;
  if (!state.payload || !state.variants.length) { out.innerHTML = ''; return; }

  const opts = CATALOG.decals || [];
  const listId = 'dl-decal';
  const datalist = `<datalist id="${listId}">${opts.map(o => `<option value="${escapeHtml(o.label)}">`).join('')}</datalist>`;
  const statuses = decalPieceStatus();
  const rows = statuses.map(s => {
    if (!s.found) return `<div class="current-val"><b>${s.kind}:</b> ${escapeHtml(s.note)}</div>`;
    return `<div class="current-val"><b>${s.kind} (overlay "${escapeHtml(s.label)}"):</b> ${escapeHtml(s.current)}</div>`;
  }).join('');

  // If the jersey's current decal matches a known catalog entry, prefill the picker
  // with it -- so the box shows what's actually equipped, not just a blank prompt.
  const jerseyStatus = statuses.find(s => s.kind === 'jersey');
  let currentValue = state.lastSelections['decal'] || '';
  if (!currentValue && jerseyStatus?.found) {
    const match = opts.find(o => o.col === jerseyStatus.current);
    if (match) currentValue = match.label;
  }

  out.innerHTML = `
    <div class="fieldblock">
      <div class="head">
        <div class="name">Vendor Decal</div>
        <span class="badge ok">confirmed</span>
      </div>
      <div class="hint">Updates jersey, pants, and socks together -- brands can be mixed and matched freely, regardless of what's currently equipped. Placement (scale/offset/rotate) auto-adjusts to the brand's known value per piece where one exists.</div>
      <div class="row" style="align-items:flex-start;">
        <div class="field">
          <input type="text" list="${listId}" id="decalInput" value="${escapeHtml(currentValue)}" placeholder="Pick a brand + material — updates all three pieces at once">
        </div>
        <button type="button" id="decalClearBtn" title="Clear this field">Clear</button>
      </div>
      ${datalist}
      ${rows}
    </div>`;

  const input = document.getElementById('decalInput');
  if (input) {
    input.addEventListener('change', () => applyDecalPick(input.value));
    input.addEventListener('focus', () => input.select());
  }
  const clearBtn = document.getElementById('decalClearBtn');
  if (clearBtn && input) {
    clearBtn.addEventListener('click', () => {
      input.value = '';
      input.focus();
    });
  }
}

function applyDecalPick(typed) {
  const opts = CATALOG.decals || [];
  const match = opts.find(o => o.label === typed);
  if (!match) { log(`No catalog entry for "${typed}".`, 'err'); return; }

  const variant = state.variants[state.selectedVariantIdx];
  const updated = [];
  const skipped = [];
  const brandTransforms = BRAND_PIECE_TRANSFORM[match.brand] || {};

  DECAL_PIECES.forEach(pd => {
    const partKey = variant?.[pd.keyField];
    if (!partKey) { skipped.push(pd.kind + ' (no part)'); return; }
    const part = getDeep(state.payload, ['teamData', 'frostbiteData', 'uniformParts', pd.plural, partKey]);
    const idxs = findVendorDecalOverlays(part);
    if (!idxs.length) { skipped.push(pd.kind + ' (no vendor decal overlay)'); return; }

    idxs.forEach(idx => {
      const overlay = part.layerCompTexture.overlays[idx];
      setDeep(overlay, ['textures', 'color', 'textureId'], match.col);
      setDeep(overlay, ['textures', 'rsm', 'textureId'], match.rsm);
      setDeep(overlay, ['textures', 'normal', 'textureId'], match.norm);
    });

    // Placement only auto-applies when there's exactly one decal overlay on
    // this piece -- a multi-overlay piece (mirrored sides) has no confirmed
    // per-side data to apply safely, so texture updates but placement doesn't.
    // Material-specific override takes priority over the brand-level default,
    // when one exists (confirmed cases only -- most materials share their
    // brand's baseline, e.g. Jumpman Cotton/Diamond).
    const pieceTransform = MATERIAL_PIECE_OVERRIDES[match.label]?.[pd.kind] || brandTransforms[pd.kind];
    let placementNote = '';
    if (idxs.length === 1 && pieceTransform) {
      const overlay = part.layerCompTexture.overlays[idxs[0]];
      setDeep(overlay, ['transform', 'scale', 'u'], pieceTransform.scaleU);
      setDeep(overlay, ['transform', 'scale', 'v'], pieceTransform.scaleV);
      setDeep(overlay, ['transform', 'offset', 'u'], pieceTransform.offsetU);
      setDeep(overlay, ['transform', 'offset', 'v'], pieceTransform.offsetV);
      setDeep(overlay, ['transform', 'rotate'], pieceTransform.rotate);
      // scaledTransform is a separate cached copy of scale/offset (x=scale.u,
      // y=scale.v, z=offset.u, w=offset.v) that does NOT recompute itself --
      // confirmed from a real payload where scale/offset updated correctly
      // but scaledTransform stayed frozen at the old brand's values, which is
      // very likely why placement changes weren't visible in-game at all.
      setDeep(overlay, ['transform', 'scaledTransform', 'x'], pieceTransform.scaleU);
      setDeep(overlay, ['transform', 'scaledTransform', 'y'], pieceTransform.scaleV);
      setDeep(overlay, ['transform', 'scaledTransform', 'z'], pieceTransform.offsetU);
      setDeep(overlay, ['transform', 'scaledTransform', 'w'], pieceTransform.offsetV);
      // Confirmed root cause of the pants-specific placement bug: textures.layout
      // was null on the affected pants overlay, while Florida's own
      // (correctly-rendering) pants overlay had it set. This is brand-specific,
      // not a shared mesh constant -- Jumpman needs a set UV path, Nike is
      // confirmed to need explicit null, Adidas needs its own different UV
      // path. Whenever a brand has a KNOWN policy (the 'layout' key is present
      // at all, whether its value is a string or null), enforce it
      // unconditionally -- overwriting whatever's there, since we now know
      // what's correct and don't need to preserve potentially-contaminated
      // leftover state from a different brand's earlier test.
      if (pd.kind === 'pants' && 'layout' in pieceTransform) {
        const layoutValue = pieceTransform.layout === null
          ? null
          : { textureId: pieceTransform.layout, sourceType: 0 };
        setDeep(overlay, ['textures', 'layout'], layoutValue);
        placementNote = pieceTransform.layout ? ' +placement +layout' : ' +placement (layout reset to native null)';
      } else {
        placementNote = ' +placement';
      }
    } else if (idxs.length > 1) {
      placementNote = ' (multiple overlays, placement left unchanged)';
    } else if (!pieceTransform) {
      // This brand has no confirmed placement of its own for this piece, so
      // nothing gets written -- but check whether what's already there is
      // actually a DIFFERENT brand's known signature left over from an
      // earlier test in this session, rather than this team's true native
      // state. Detecting it doesn't fix it (we have no confirmed correct
      // value to fall back to), but it turns a silent wrong guess into a
      // visible warning instead of another round of screenshots.
      const overlay = idxs.length === 1 ? part.layerCompTexture.overlays[idxs[0]] : null;
      const currentLayoutId = overlay?.textures?.layout?.textureId;
      const contaminant = Object.entries(BRAND_PIECE_TRANSFORM).find(([brandName, pieces]) => {
        if (brandName === match.brand) return false;
        const t = pieces[pd.kind];
        return t?.layout && currentLayoutId && t.layout === currentLayoutId;
      });
      if (contaminant) {
        placementNote = ` (placement left unchanged, but currently carries ${contaminant[0]}'s layout -- likely leftover from testing that brand, not this team's native state)`;
      } else {
        placementNote = ' (no placement default for this brand/piece)';
      }
    }
    updated.push(pd.kind + placementNote);
  });

  document.getElementById('rawText').value = JSON.stringify(state.payload, null, 2);
  state.lastSelections['decal'] = typed;
  const parts = [`Set Vendor Decal (${variant.label}) → ${typed}.`];
  if (updated.length) parts.push(`Updated: ${updated.join(', ')}.`);
  if (skipped.length) parts.push(`Skipped: ${skipped.join(', ')}.`);
  log(parts.join(' '), updated.length ? 'ok' : 'err');
  renderDecalSection();
}

// ---------- number spacing slider ----------
// Confirmed path: numberComp.numberMaterialSettings.offsetScaleSpacing.numberSpacing.x
// Only x is exposed -- y/z/w were confirmed to stay 0 and untouched. Range
// (-0.6 to -0.3) is a user-confirmed comfortable range, not the field's full
// technical bounds -- values outside it may still be valid, just untested.
const NUMBER_SPACING_PATH = ['numberMaterialSettings', 'offsetScaleSpacing', 'numberSpacing', 'x'];
const NUMBER_SPACING_MIN = -0.6;
const NUMBER_SPACING_MAX = -0.3;

function renderSpacingSection() {
  const out = document.getElementById('spacingOut');
  if (!out) return;
  if (!state.payload || !state.variants.length) { out.innerHTML = ''; return; }

  const variant = state.variants[state.selectedVariantIdx];
  const jerseyKey = variant?.jerseyKey;
  const part = jerseyKey ? getDeep(state.payload, ['teamData', 'frostbiteData', 'uniformParts', 'jerseys', jerseyKey]) : null;
  const current = part ? getDeep(part, NUMBER_SPACING_PATH) : undefined;

  if (!part || current === undefined) {
    out.innerHTML = `
      <div class="fieldblock">
        <div class="head"><div class="name">Number Spacing</div>${STATUS_BADGE.warn}</div>
        <div class="hint">No numberSpacing field found on this variant's jersey.</div>
      </div>`;
    return;
  }

  // Capture the starting value the first time this jersey is seen -- never
  // overwritten by later slider drags, so there's always a fixed point to
  // get back to no matter how much experimenting happens in between.
  if (!(jerseyKey in state.spacingOriginals)) {
    state.spacingOriginals[jerseyKey] = current;
  }
  const original = state.spacingOriginals[jerseyKey];

  out.innerHTML = `
    <div class="fieldblock">
      <div class="head">
        <div class="name">Number Spacing</div>
        ${STATUS_BADGE.ok}
      </div>
      <div class="hint">Confirmed range is ${NUMBER_SPACING_MIN} to ${NUMBER_SPACING_MAX} -- values outside that haven't been tested.</div>
      <div class="row" style="align-items:center;">
        <input type="range" id="spacingSlider" min="${NUMBER_SPACING_MIN}" max="${NUMBER_SPACING_MAX}" step="0.01" value="${current}" style="flex:1;">
        <div id="spacingValue" style="font-family:var(--mono); font-size:13px; min-width:56px; text-align:right;">${Number(current).toFixed(2)}</div>
      </div>
      <div class="row" style="align-items:center; margin-top:6px;">
        <div class="current-val" style="margin-top:0;"><b>started at:</b> ${escapeHtml(String(original))} -- fixed, doesn't change as you drag</div>
        <button type="button" id="spacingResetBtn" title="Jump back to the starting value">Reset</button>
      </div>
    </div>`;

  const slider = document.getElementById('spacingSlider');
  const valueLabel = document.getElementById('spacingValue');
  slider.addEventListener('input', () => {
    valueLabel.textContent = Number(slider.value).toFixed(2);
  });
  slider.addEventListener('change', () => {
    applyNumberSpacing(Number(slider.value));
  });

  document.getElementById('spacingResetBtn').addEventListener('click', () => {
    applyNumberSpacing(original);
  });
}

function applyNumberSpacing(value) {
  const variant = state.variants[state.selectedVariantIdx];
  const jerseyKey = variant?.jerseyKey;
  if (!jerseyKey) return;
  const part = getDeep(state.payload, ['teamData', 'frostbiteData', 'uniformParts', 'jerseys', jerseyKey]);
  if (!part) return;

  const ok = setDeep(part, NUMBER_SPACING_PATH, value);
  if (!ok) { log('Could not set Number Spacing — expected structure missing on this variant.', 'err'); return; }

  document.getElementById('rawText').value = JSON.stringify(state.payload, null, 2);
  log(`Set Number Spacing (${variant.label}) → ${value.toFixed(2)}`, 'ok');
  renderSpacingSection();
}

function applyField(group, sub, typed) {
  const part = getPart(group);
  if (!part) return;
  const variant = state.variants[state.selectedVariantIdx];
  const label = group.label + (sub.label ? ' ' + sub.label : '');

  let value = typed;
  const opts = sub.options();
  const match = opts.find(o => (o.label || o.displayName) === typed);
  if (match) value = match.path;
  const resolvedLabel = match ? (match.label || match.displayName) : typed;
  // else: treat typed text as a raw path override (must contain a slash to be sane)

  let allOk = true;
  const skipped = [];
  sub.targets.forEach(t => {
    let v;
    if (t.lookupCatalog) {
      // Pull this target's value from a different catalog, matched by the same
      // resolved label -- e.g. picking a shell also looks up the accessory with
      // the identical label. If nothing matches there, leave this target alone
      // rather than writing something wrong.
      const hit = t.lookupCatalog().find(o => (o.label || o.displayName) === resolvedLabel);
      if (!hit) { skipped.push(t.label); return; }
      v = hit.path;
    } else {
      v = t.transform ? t.transform(value) : value;
    }
    if (!setDeep(part, t.path, v)) allOk = false;
  });
  if (!allOk) {
    log(`Could not fully set ${label} — expected structure missing on this variant for at least one of its ${sub.targets.length} target field(s).`, 'err');
    return;
  }
  if (skipped.length) {
    log(`No matching ${skipped.join(', ')} found for "${resolvedLabel}" — left unchanged.`, 'err');
  }

  // Number Layout Profile: some fonts have confirmed layout data -- flat
  // spacing, per-number kerning, chest/back/shoulder/sleeve offset+scale,
  // and/or numberSpacingOverrides -- that should travel with the font pick
  // instead of being left to whatever the target variant's own leftover
  // values are. Every category is independently optional per profile: a
  // profile can define just spacing + playerNumberAdjust and skip the rest
  // entirely (Arizona currently does, after the offset/scale + overrides
  // fields caused real in-game errors in testing and were pulled out in
  // v0.27). Fonts with no profile at all behave exactly as before this
  // system existed.
  let profileNote = '';
  if (sub.numberLayoutProfiles && match && match.displayName) {
    const profile = sub.numberLayoutProfiles[match.displayName];
    if (profile) {
      let allProfileOk = true;
      const applied = [];

      if (profile.numberSpacing !== undefined) {
        allProfileOk = setDeep(part, NUMBER_SPACING_PATH, profile.numberSpacing) && allProfileOk;
        applied.push(`numberSpacing=${profile.numberSpacing}`);
      }
      NUMBER_OFFSET_SCALE_FIELDS.forEach(f => {
        if (!profile[f]) return; // profile may not define every offset/scale field
        const ok = setDeep(part, ['numberMaterialSettings', 'offsetScaleSpacing', f], JSON.parse(JSON.stringify(profile[f])));
        allProfileOk = ok && allProfileOk;
        applied.push(f);
      });
      if (profile.playerNumberAdjust) {
        const ok = setDeep(
          part,
          ['numberMaterialSettings', 'playerNumberAdjust'],
          JSON.parse(JSON.stringify(profile.playerNumberAdjust)) // deep copy -- never share array/object refs across parts
        );
        allProfileOk = ok && allProfileOk;
        applied.push(`${profile.playerNumberAdjust.length} playerNumberAdjust entries`);
      }
      if (profile.numberSpacingOverrides) {
        const ok = setDeep(
          part,
          ['numberMaterialSettings', 'offsetScaleSpacing', 'numberSpacingOverrides'],
          JSON.parse(JSON.stringify(profile.numberSpacingOverrides))
        );
        allProfileOk = ok && allProfileOk;
        applied.push('numberSpacingOverrides (unconfirmed key)');
      }

      profileNote = allProfileOk
        ? ` + applied its Number Layout profile (${applied.join(', ')} — NOT YET CONFIRMED IN-GAME)`
        : ' [profile found but expected numberMaterialSettings structure missing on this variant -- layout profile NOT fully applied]';
    }
  }

  document.getElementById('rawText').value = JSON.stringify(state.payload, null, 2);
  state.lastSelections[group.key + ':' + sub.key] = typed;
  const writeNote = sub.targets.length > 1 ? ` [written to ${sub.targets.length} fields: ${sub.targets.map(t => t.label).join(', ')}]` : '';
  log(`Set ${label} (${variant.label}) → ${value}${writeNote}${profileNote}`, 'ok');
  renderFields();
  renderSpacingSection();
}


// ---------- push / status / clear ----------
document.getElementById('btnPush').addEventListener('click', async () => {
  if (!state.selectedUrl) { log('No URL selected — fetch a payload first.', 'err'); return; }
  const text = document.getElementById('rawText').value;
  try {
    JSON.parse(text);
  } catch (err) { log('Current text is not valid JSON: ' + err.message, 'err'); return; }
  try {
    const teamName = state.payload?.teamData?.teamInfos?.TEAM_NAME || '';
    const r = await sendToExtension('TB_SET_MOCK', { url: state.selectedUrl, text, teamName });
    log('Pushed mock for ' + (teamName || state.selectedUrl) + '. Reload the Team Builder tab to see it.', 'ok');
  } catch (err) {
    log('Push failed: ' + err.message, 'err');
  }
});

document.getElementById('btnCheck').addEventListener('click', refreshStatus);

document.getElementById('btnClear').addEventListener('click', async () => {
  if (!state.selectedUrl) { log('No URL selected.', 'err'); return; }
  try {
    await sendToExtension('TB_CLEAR_MOCK', { url: state.selectedUrl });
    log('Mock cleared.', 'ok');
    await refreshStatus(); // the connection panel above won't visibly change otherwise
  } catch (err) {
    log('Clear failed: ' + err.message, 'err');
  }
});

document.getElementById('btnReset').addEventListener('click', () => {
  if (!state.originalRawText) { log('Nothing loaded yet to reset to.', 'err'); return; }
  document.getElementById('rawText').value = state.originalRawText;
  loadFromRawText();
  log('Reset to the payload as originally loaded — all edits this session are discarded.', 'ok');
});

document.getElementById('versionTag').textContent = EDITOR_VERSION;
log('Ready (' + EDITOR_VERSION + '). Click "Refresh status" to connect to the helper extension.');
