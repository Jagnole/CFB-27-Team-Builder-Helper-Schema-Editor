# Number Layout Profile Checklist

Tracks which fonts in `CATALOG.numberFonts.jersey` have a confirmed entry in
`NUMBER_LAYOUT_PROFILES` in `editor.js`. Update this alongside every profile
added -- this is the source of truth for progress, not memory across sessions.

**Catalog size: 321**, alphabetized by label (v0.32). 5 helmet-font
entries and 3 pure duplicate entries were removed in v0.32 -- see CHANGELOG.

**Per-font, we need two independent pieces (do not assume one file gives both):**
1. `playerNumberAdjust` -- from a **JerseyPartItem**-style Frosty export.
2. `numberSpacing` -- default to the file's `numberspacing.x` value (Arizona was
   the one confirmed exception so far, not the norm).

**Since v0.31**: teams sharing a font each get their own catalog entry (same
`path`, unique `displayName`) rather than one shared entry -- unless it turns out
to be a pure same-team duplicate (same team, same font, different color only),
in which case it gets merged to one entry, as happened for a few in v0.32.

**Status legend:** ✅ Done · 🟡 Flagged (see `BATCH_IMPORT_FLAGS.md`) · ⬜ Not started

| Status | Label | displayName | numberSpacing | playerNumberAdjust | Notes |
|---|---|---|---|---|---|
| ✅ | Air Force (2021) | `AFA_Jersey_2021_NUM_Array` | -0.334362 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Air Force (2025, Alt) | `AFA_Jersey_2025_Alt_NUM_Array` | -0.65 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Akron (2021) | `AKR_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Akron (2025) | `AKR_Jersey_2025_NUM_Array` | -0.424 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Appalachian State (2021) | `APP_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Appalachian State (2023, Black) | `APP_JERSEY_2023_BLACK` | -0.46 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Arizona (2021) | `ARIZ_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Arizona (2026) | `ARIZ_Jersey_2026_NUM_Array` | -0.48 (in-game, not file) | 18 entries | Custom -- see CHANGELOG v0.27 |
| ⬜ | Arizona State (2021) | `ASU_Jersey_2021_NUM_Array` |  |  |  |
| ⬜ | Arizona State (2023) | `ASU_Jersey_2023_NUM_Array` |  |  |  |
| ⬜ | Arizona State (2024) | `ASU_Jersey_2024_NUM_Array` |  |  |  |
| ✅ | Arizona State (2025, 02) | `ASU_Jersey_2025_02_NUM_Array` | -0.37 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Arizona State (2025, Throwback) | `ASU_JERSEY_2025_THROWBACK` | -0.47 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Arizona State (2025) | `ASU_JERSEY_2025_BLACK` | -0.42 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Arkansas (2021) | `ARK_Jersey_2021_NUM_Array` | -0.44 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Arkansas (2023) | `ARK_Jersey_2023_NUM_Array` | -0.39 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Arkansas State (2023, 02) | `ARST_Jersey_2023_02_NUM_Array` |  |  |  |
| ✅ | Arkansas State (2023) | `ARST_Jersey_2023_NUM_Array` | -0.45 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Army (2021) | `ARMY_Jersey_2021_NUM_Array` | -0.404939115 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Army (2024) | `ARMY_Jersey_2024_NUM_Array` | -0.52 | 27 entries | From All_uniforms_TB.zip |
| ✅ | Army (2025) | `ARMY_Jersey_2025_NUM_Array` | -0.38 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Auburn (2023) | `AUB_Jersey_2023_NUM_Array` | -0.45 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Ball State (2024, Black) | `BALL_JERSEY_2024_BLACK` | -0.45 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Baylor (2021) | `BAY_Jersey_2021_NUM_Array` | -0.44 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Boise State (2021) | `BSU_Jersey_2021_NUM_Array` | -0.48 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Boston College (2021) | `BC_Jersey_2021_NUM_Array` |  |  |  |
| ⬜ | Boston College (2024) | `BC_Jersey_2024_NUM_Array` |  |  |  |
| ✅ | Boston College (2025) | `BC_Jersey_2025_NUM_Array` | -0.45 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Bowling Green (2023, Brown) | `BGSU_JERSEY_2023_BROWN` | -0.42 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Buffalo (2023, Blue) | `BUFF_JERSEY_2023_BLUE` | -0.45 | 18 entries | From All_uniforms_TB.zip |
| ✅ | BYU (2023) | `BYU_JERSEY_2023_BLACK` | -0.49 | 18 entries | From All_uniforms_TB.zip |
| ✅ | BYU (2024) | `BYU_Jersey_2024_NUM_Array` | -0.48 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | California (2021) | `CAL_Jersey_2021_NUM_Array` |  |  |  |
| 🟡 | Central Michigan (2021) | `CMU_Jersey_2021_NUM_Array` |  |  | See BATCH_IMPORT_FLAGS.md |
| ✅ | Central Michigan (2023, Maroon) | `CMU_JERSEY_2023_MAROON` | -0.365 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Central Michigan (2023) | `CMU_Jersey_2023_NUM_Array` | -0.56 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Central Michigan (2025, Sleeve Maroon) | `CMU_Jersey_2025_Sleeve_MAROON_NUM_Array` |  |  |  |
| ⬜ | Central Michigan (2025, Sleeve WHI) | `CMU_Jersey_2025_Sleeve_WHI_NUM_Array` |  |  |  |
| ⬜ | Charlotte (2021) | `CHAR_Jersey_2021_NUM_Array` |  |  |  |
| ⬜ | Charlotte (2023) | `CHAR_Jersey_2023_NUM_Array` |  |  |  |
| ✅ | Charlotte (2025) | `CHAR_Jersey_2025_NUM_Array` | -0.38 | 26 entries | From All_uniforms_TB.zip |
| ⬜ | Cincinnati (2021) | `CIN_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Cincinnati (2025) | `CIN_Jersey_2025_NUM_Array` | -0.39 | 41 entries | From All_uniforms_TB.zip |
| ✅ | Clemson (2023, Orange) | `CLEM_JERSEY_2023_ORANGE` | -0.39 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Coastal Carolina (2021, 02) | `CCAR_Jersey_2021_02_NUM_Array` | -0.45 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Coastal Carolina (2021) | `CCAR_Jersey_2021_NUM_Array` |  |  |  |
| ⬜ | Coastal Carolina (2022) | `CCAR_Jersey_2022_NUM_Array` |  |  |  |
| ✅ | Colorado (2024) | `COLO_Jersey_2024_NUM_Array` | -0.45 | 34 entries | From All_uniforms_TB.zip |
| ✅ | Colorado State (2021) | `CSU_Jersey_2021_NUM_Array` | -0.4 | 33 entries | From All_uniforms_TB.zip |
| ⬜ | Colorado State (2024) | `CSU_Jersey_2024_NUM_Array` |  |  |  |
| ⬜ | Delaware (2024, 02) | `DEL_Jersey_2024_02_NUM_Array` |  |  |  |
| ⬜ | Delaware (2024, 03) | `DEL_Jersey_2024_03_NUM_Array` |  |  |  |
| ✅ | Delaware (2024) | `DEL_Jersey_2024_NUM_Array` | -0.59 | 49 entries | From All_uniforms_TB.zip |
| ✅ | Duke (2023, Black) | `DUKE_JERSEY_2023_BLACK` | -0.48 | 18 entries | From All_uniforms_TB.zip |
| ✅ | East Carolina (2021) | `ECU_Jersey_2021_NUM_Array` | -0.5 | 18 entries | From All_uniforms_TB.zip |
| ✅ | East Carolina (2023) | `ECU_Jersey_2023_NUM_Array` | -0.48 | 26 entries | From All_uniforms_TB.zip |
| 🟡 | Eastern Michigan (2021) | `EMU_Jersey_2021_NUM_Array` |  |  | See BATCH_IMPORT_FLAGS.md |
| ✅ | Eastern Michigan (2025, Black) | `EMU_JERSEY_2025_BLACK` | -0.38 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Florida (2021) | `FLA_Jersey_2021_NUM_Array` | -0.4 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Florida (2023, Throwback) | `FLA_JERSEY_2023_THROWBACK` | -0.42 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Florida Atlantic (2021) | `FAU_Jersey_2021_NUM_Array` | -0.35 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Florida Atlantic (2025, v2) | `FAU_Jersey_2025-2_NUM_Array` | -0.44 | 19 entries | From All_uniforms_TB.zip |
| ✅ | Florida Atlantic (2025) | `FAU_Jersey_2025_NUM_Array` | -0.42 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Florida International (2021) | `FIU_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Florida International (2023, Navy) | `FIU_JERSEY_2023_NAVY` | -0.4 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Florida International (2024) | `FIU_Jersey_2024_NUM_Array` | -0.4 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Florida International (2025, Vice) | `FIU_Jersey_2025_Vice_NUM_Array` | -0.42 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Florida State (2021) | `FSU_Jersey_2021_NUM_Array` | -0.46 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Fresno State (2021) | `FRES_Jersey_2021_NUM_Array` | -0.38 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Georgia (2021) | `UGA_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Georgia (2023, Red) | `UGA_JERSEY_2023_RED` | -0.408723861 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Georgia Southern (2023, Blue) | `GASO_JERSEY_2023_BLUE` | -0.44 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Georgia State (2021) | `GSU_Jersey_2021_NUM_Array` |  |  |  |
| ⬜ | Georgia State (2022) | `GSU_Jersey_2022_NUM_Array` |  |  |  |
| ✅ | Georgia State (2023) | `GSU_Jersey_2023_NUM_Array` | -0.52 | 27 entries | From All_uniforms_TB.zip |
| ⬜ | Georgia Tech (2022) | `GT_Jersey_2022_NUM_Array` |  |  |  |
| ✅ | Georgia Tech (2026, White) | `GT_Jersey_2026_White_NUM_Array` | -0.41 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Georgia Tech (2026) | `GT_Jersey_2026_NUM_Array` | -0.41 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Hawaii (2021) | `HAW_Jersey_2021_NUM_Array` | -0.41 | 34 entries | From All_uniforms_TB.zip |
| ⬜ | Hawaii (2023) | `HAW_Jersey_2023_NUM_Array` |  |  |  |
| ✅ | Houston (2023, Red) | `HOU_JERSEY_2023_RED` | -0.36 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Houston (2025, Sleeve) | `HOU_Jersey_2025_Sleeve_NUM_Array` |  |  |  |
| ✅ | Illinois (2021) | `ILL_Jersey_2021_NUM_Array` | -0.404939115 | 33 entries | From All_uniforms_TB.zip |
| ✅ | Illinois (2023, Trhowback) | `ILL_JERSEY_2023_TRHOWBACK` | -0.45 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Indiana (2022) | `IND_Jersey_2022_NUM_Array` | -0.39 | 33 entries | From All_uniforms_TB.zip |
| ⬜ | Indiana (2023) | `IND_Jersey_2023_NUM_Array` |  |  |  |
| ✅ | Iowa (2021) | `IOWA_Jersey_2021_NUM_Array` | -0.39 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Iowa State (2021) | `ISU_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Iowa State (2023) | `ISU_Jersey_2023_NUM_Array` | -0.28 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Iowa State (2024, Throwback) | `ISU_JERSEY_2024_THROWBACK` | -0.53 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Iowa State (2024) | `ISU_Jersey_2024_NUM_Array` | -0.26 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Iowa State (2025) | `ISU_Jersey_2025_NUM_Array` |  |  |  |
| ✅ | Jacksonville State (2023, Red) | `JVST_JERSEY_2023_RED` | -0.5 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Jacksonville State (2023) | `JVST_Jersey_2023_NUM_Array` |  |  |  |
| ✅ | James Madison (2023, Purple) | `JMU_JERSEY_2023_PURPLE` | -0.52 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Kansas (2021) | `KU_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Kansas (2023) | `KU_Jersey_2023_NUM_Array` | -0.55 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Kansas (2024) | `KU_Jersey_2024_NUM_Array` | -0.41 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Kansas (2025, Shoulders) | `KU_Jersey_2025_Shoulders_NUM_Array` |  |  |  |
| ⬜ | Kansas (2025) | `KU_Jersey_2025_NUM_Array` |  |  |  |
| ✅ | Kansas State (2023) | `KSU_JERSEY_2023_PURPLE` | -0.44 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Kennesaw State (2021) | `KENN_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Kennesaw State (2025) | `KENN_Jersey_2025_NUM_Array` | -0.49 | 45 entries | From All_uniforms_TB.zip |
| ⬜ | Kent State (2021) | `KENT_Jersey_2021_NUM_Array` |  |  |  |
| ⬜ | Kent State (2022) | `KENT_Jersey_2022_NUM_Array` |  |  |  |
| ✅ | Kent State (2023) | `KENT_Jersey_2023_NUM_Array` | -0.43 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Kent State (2025) | `KENT_Jersey_2025_NUM_Array` | -0.41 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Kentucky (2021) | `UK_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Kentucky (2023, Blue) | `UK_JERSEY_2023_BLUE` | -0.56 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Liberty (2023) | `LIB_Jersey_2023_Num_Array` |  |  |  |
| ✅ | Louisiana (2021) | `ULL_Jersey_2021_NUM_Array` | -0.39 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Louisiana (2023, Throwback) | `ULL_JERSEY_2023_THROWBACK` | -0.5 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Louisiana (2024) | `ULL_Jersey_2024_NUM_Array` |  |  |  |
| ✅ | Louisiana (2025, Blockshadow) | `ULL_Jersey_2025_BLOCKSHADOW_NUM_Array` | -0.43 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Louisiana Tech (2021) | `LT_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Louisiana Tech (2023) | `LT_Jersey_2023_NUM_Array` | -0.43 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Louisiana-Monroe (2016) | `ULM_Jersey_2016_NUM_Array` | -0.55 | 27 entries | From All_uniforms_TB.zip |
| ✅ | Louisiana-Monroe (2021) | `ULM_Jersey_2021_NUM_Array` | -0.57 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Louisiana-Monroe (2024) | `ULM_Jersey_2024_NUM_Array` |  |  |  |
| ✅ | Louisiana-Monroe (2025, Gray) | `ULM_JERSEY_2025_GRAY` | -0.37 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Louisville (2021) | `LOU_Jersey_2021_NUM_Array` |  |  |  |
| ⬜ | Louisville (2024, 02) | `LOU_Jersey_2024_02_NUM_Array` |  |  |  |
| ✅ | Louisville (2024) | `LOU_Jersey_2024_NUM_Array` | -0.5 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Louisville (2025) | `LOU_Jersey_2025_NUM_Array` | -0.55 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | LSU (2021) | `LSU_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | LSU (2023, Gold) | `LSU_JERSEY_2023_GOLD` | -0.37 | 18 entries | From All_uniforms_TB.zip |
| ✅ | LSU (2023) | `LSU_Jersey_2023_NUM_Array` | -0.45 | 18 entries | From All_uniforms_TB.zip |
| 🟡 | LSU (2024) | `LSU_Jersey_2024_NUM_Array` |  |  | See BATCH_IMPORT_FLAGS.md |
| ✅ | Marshall (2023, Black) | `MRSH_JERSEY_2023_BLACK` | -0.4 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Marshall (2025) | `MRSH_Jersey_2025_NUM_Array` | -0.5 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Maryland (2021) | `UMD_Jersey_2021_NUM_Array` |  |  |  |
| ⬜ | Maryland (2024, Chrome) | `UMD_Jersey_2024_CHROME_NUM_Array` |  |  |  |
| ✅ | Maryland (2025) | `UMD_Jersey_2025_NUM_Array` | -0.48 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Maryland (Away 2023) | `UMD_Jersey_Away_2023_NUM_Array` | -0.46 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Massachusetts (2023, Maroon) | `UMASS_JERSEY_2023_MAROON` | -0.53 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Memphis (2023, Blue) | `MEM_JERSEY_2023_BLUE` | -0.334046632 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Miami (FL) (2024) | `MIA_Jersey_2024_NUM_Array` | -0.43 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Miami (FL) (2025, Camo) | `MIA_Jersey_2025_Camo_NUM_Array` | -0.37 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Miami (FL) (2025) | `MIA_Jersey_2025_NUM_Array` | -0.445 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Miami (OH) (2021) | `MIAOH_Jersey_2021_NUM_Array` | -0.53 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Miami (OH) (2024) | `MIAOH_Jersey_2024_NUM_Array` |  |  |  |
| ⬜ | Miami (OH) (2025) | `MIAOH_Jersey_2025_NUM_Array` |  |  |  |
| ✅ | Michigan (2023, Blue) | `MICH_JERSEY_2023_BLUE` | -0.47 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Michigan State (2023, Green) | `MSU_JERSEY_2023_GREEN` | -0.33 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Middle Tennessee (2023) | `MTSU_Jersey_2023_NUM_Array` | -0.45 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Minnesota (2021) | `MINN_Jersey_2021_NUM_Array` | -0.37 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Minnesota (2024) | `MINN_Jersey_2024_NUM_Array` |  |  |  |
| ✅ | Mississippi State (2021) | `MSST_Jersey_2021_NUM_Array` | -0.381234229 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Mississippi State (2024) | `MSST_Jersey_2024_NUM_Array` | -0.381234229 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Mississippi State (2025, Throwback) | `MSST_Jersey_2025_Throwback_NUM_Array` | -0.42 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Missouri (2021) | `MIZZ_Jersey_2021_NUM_Array` | -0.47 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Missouri State (2024) | `MIST_Jersey_2024_NUM_Array` | -0.47 | 54 entries | From All_uniforms_TB.zip |
| ⬜ | Mountain Dew (non-school / branded) (2025, Shoulder) | `MTDEW_Jersey_2025_Shoulder_NUM_Array` |  |  |  |
| ⬜ | Mountain Dew (non-school / branded) (2025) | `MTDEW_Jersey_2025_NUM_Array` |  |  |  |
| ✅ | Navy (2021) | `NAVY_Jersey_2021_NUM_Array` | -0.36 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Navy (2023) | `NAVY_Jersey_2023_NUM_Array` | -0.48 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Navy (2024) | `NAVY_Jersey_2024_NUM_Array` | -0.49 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Navy (2025) | `NAVY_Jersey_2025_NUM_Array` | -0.46 | 18 entries | From All_uniforms_TB.zip |
| ✅ | NC State (2021) | `NCST_Jersey_2021_NUM_Array` | -0.44 | 26 entries | From All_uniforms_TB.zip |
| ✅ | NC State (2025) | `NCST_Jersey_2025_NUM_Array` | -0.47 | 34 entries | From All_uniforms_TB.zip |
| ✅ | Nebraska (2024, Red) | `NEB_JERSEY_2024_RED` | -0.5 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Nebraska (2025, Shoulder) | `NEB_Jersey_2025_Shoulder_NUM_Array` |  |  |  |
| ✅ | Nebraska (2026) | `NEB_Jersey_2026_NUM_Array` | -0.37 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Nevada (2021) | `NEV_Jersey_2021_NUM_Array` | -0.32 | 26 entries | From All_uniforms_TB.zip |
| ✅ | New Mexico (2021) | `UNM_Jersey_2021_NUM_Array` | -0.36 | 34 entries | From All_uniforms_TB.zip |
| ✅ | New Mexico (2025) | `UNM_Jersey_2025_NUM_Array` | -0.42 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | New Mexico State (2021) | `NMSU_Jersey_2021_NUM_Array` |  |  |  |
| ⬜ | New Mexico State (2022) | `NMSU_Jersey_2022_NUM_Array` |  |  |  |
| ⬜ | New Mexico State (2023) | `NMSU_Jersey_2023_NUM_Array` |  |  |  |
| ✅ | North Carolina (2021) | `UNC_Jersey_2021_NUM_Array` | -0.26 | 18 entries | From All_uniforms_TB.zip |
| ✅ | North Carolina (2022) | `UNC_Jersey_2022_NUM_Array` | -0.42 | 18 entries | From All_uniforms_TB.zip |
| ✅ | North Dakota State (2026) | `NDSU_Jersey_2026_NUM_Array` | -0.24 | 27 entries | From All_uniforms_TB.zip |
| ⬜ | North Texas (2021) | `UNT_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | North Texas (2022, Haydenfry) | `UNT_JERSEY_2022_HAYDENFRY` | -0.45 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | North Texas (2022) | `UNT_Jersey_2022_NUM_Array` |  |  |  |
| ✅ | North Texas (2023, Green) | `UNT_JERSEY_2023_GREEN` | -0.42 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Northern Illinois (2021) | `NIU_Jersey_2021_NUM_Array` | -0.37 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Northern Illinois (2023) | `NIU_Jersey_2023_NUM_Array` | -0.37 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Northwestern (2021) | `NW_Jersey_2021_NUM_Array` | -0.48 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Northwestern (2022) | `NW_Jersey_2022_NUM_Array` | -0.53 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Notre Dame (2021) | `ND_Jersey_2021_NUM_Array` | -0.52 | 26 entries | From All_uniforms_TB.zip |
| ⬜ | Notre Dame (2023) | `ND_Jersey_2023_NUM_Array` |  |  |  |
| ✅ | Notre Dame (2024, Shamrock) | `ND_Jersey_2024_Shamrock_NUM_Array` | -0.58 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Ohio (2023) | `OHIO_Jersey_2023_NUM_Array` | -0.49 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Ohio (2024) | `OHIO_Jersey_2024_NUM_Array` | -0.44 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Ohio State (2023, 02) | `OSU_Jersey_2023_02_NUM_Array` | -0.45 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Ohio State (2023, Scarlett) | `OSU_JERSEY_2023_SCARLETT` | -0.49 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Ohio State (2024) | `OSU_Jersey_2024_NUM_Array` |  |  |  |
| ✅ | Oklahoma (2022) | `OU_Jersey_2022_NUM_Array` | -0.3667013 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Oklahoma (2023) | `OU_Jersey_2023_NUM_Array` | -0.3667013 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Oklahoma (2024, 02) | `OU_Jersey_2024_02_NUM_Array` | -0.495 | 34 entries | From All_uniforms_TB.zip |
| ✅ | Oklahoma (2024) | `OU_Jersey_2024_NUM_Array` | -0.3667013 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Oklahoma State (2021) | `OKST_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Oklahoma State (2023, Black) | `OKST_JERSEY_2023_BLACK` | -0.38 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Old Dominion (2021) | `ODU_Jersey_2021_NUM_Array` | -0.5 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Ole Miss (2021) | `MISS_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Ole Miss (2024, Blue) | `MISS_JERSEY_2024_BLUE` | -0.42 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Oregon (2021) | `ORE_Jersey_2021_NUM_Array` | -0.438335419 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Oregon (2024) | `ORE_Jersey_2024_NUM_Array` | -0.52 | 34 entries | From All_uniforms_TB.zip |
| ✅ | Oregon (2025, Shoeduck) | `ORE_Jersey_2025_ShoeDuck_NUM_Array` | -0.4 | 19 entries | From All_uniforms_TB.zip |
| ✅ | Oregon State (2021) | `ORST_Jersey_2021_NUM_Array` | -0.39 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Oregon State (2025, Camo) | `ORST_Jersey_2025_Camo_NUM_Array` | -0.34 | 27 entries | From All_uniforms_TB.zip |
| ⬜ | Penn State (2021) | `PSU_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Penn State (2023, Bluestripe) | `PSU_JERSEY_2023_BLUESTRIPE` | -0.38 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Penn State (2023) | `PSU_Jersey_2023_NUM_Array` | -0.38 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Pittsburgh (2021) | `PITT_Jersey_2021_NUM_Array` | -0.54 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Purdue (2021) | `PUR_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Purdue (2023) | `PUR_Jersey_2023_NUM_Array` | -0.48 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Rice (2021) | `RICE_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Rice (2023, Lightblue) | `RICE_JERSEY_2023_LIGHTBLUE` | -0.48 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Rice (2023) | `RICE_Jersey_2023_NUM_Array` |  |  |  |
| ✅ | Rice (2026) | `RICE_Jersey_2026_NUM_Array` | -0.4 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Rutgers (2021) | `RUTG_Jersey_2021_NUM_Array` | -0.383319438 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Sacramento State (2026) | `SACST_Jersey_2026_NUM_Array` | -0.42 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Sam Houston State (2021, v2) | `SHSU_Jersey_2021_NUM_Array_2` |  |  |  |
| ⬜ | Sam Houston State (2021) | `SHSU_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Sam Houston State (2025) | `SHSU_Jersey_2025_NUM_Array` | -0.37 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | San Diego State (2021) | `SDSU_Jersey_2021_NUM_Array` |  |  |  |
| ⬜ | San Jose State (2021) | `SJSU_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | San Jose State (2023) | `SJSU_Jersey_2023_NUM_Array` | -0.5 | 18 entries | From All_uniforms_TB.zip |
| ✅ | SMU (2021) | `SMU_Jersey_2021_NUM_Array` | -0.48 | 18 entries | From All_uniforms_TB.zip |
| ✅ | SMU (2022) | `SMU_Jersey_2022_NUM_Array` | -0.52 | 18 entries | From All_uniforms_TB.zip |
| ✅ | SMU (2023, Blue) | `SMU_JERSEY_2023_BLUE` | -0.47 | 18 entries | From All_uniforms_TB.zip |
| ✅ | South Alabama (2021) | `USA_Jersey_2021_NUM_Array` | -0.49 | 28 entries | From All_uniforms_TB.zip |
| ⬜ | South Alabama (2025) | `USA_Jersey_2025_NUM_Array` |  |  |  |
| ⬜ | South Carolina (2021, 02) | `SC_Jersey_2021_02_NUM_Array` |  |  |  |
| ✅ | South Carolina (2021) | `SC_Jersey_2021_NUM_Array` | -0.47 | 26 entries | From All_uniforms_TB.zip |
| ⬜ | South Carolina (2024) | `SC_Jersey_2024_NUM_Array` |  |  |  |
| ⬜ | South Florida (2021) | `USF_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | South Florida (2023) | `USF_Jersey_2023_NUM_Array` | -0.39 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Southern Miss (2021) | `USM_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Southern Miss (2025) | `USM_Jersey_2025_NUM_Array` | -0.51 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Stanford (2023, Black) | `STAN_JERSEY_2023_BLACK` | -0.36 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Syracuse (2021) | `SYR_Jersey_2021_NUM_Array` | -0.45 | 18 entries | From All_uniforms_TB.zip |
| ✅ | TCU (2021) | `TCU_Jersey_2021_NUM_Array` | -0.38 | 18 entries | From All_uniforms_TB.zip |
| ✅ | TCU (2026) | `TCU_Jersey_2026_NUM_Array` | -0.36 | 34 entries | From All_uniforms_TB.zip |
| ✅ | Temple (2021) | `TEM_Jersey_2021_NUM_Array` | -0.4 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Temple (2025, Red) | `TEMP_JERSEY_2025_RED` | -0.38 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Tennessee (2021, 02) | `TENN_Jersey_2021_02_NUM_Array` |  |  |  |
| ✅ | Tennessee (2021) | `TENN_Jersey_2021_NUM_Array` | -0.52 | 33 entries | From All_uniforms_TB.zip |
| ✅ | Tennessee (2025, Smokey) | `TENN_Jersey_2025_Smokey_NUM_Array` | -0.41 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Tennessee (2026) | `TENN_Jersey_2026_NUM_Array` | -0.4 | 34 entries | From All_uniforms_TB.zip |
| ⬜ | Texas (2021) | `TEX_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Texas (2024) | `TEX_Jersey_2024_NUM_Array` | -0.404939115 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Texas A&M (2021) | `TAMU_Jersey_2021_NUM_Array` | -0.37 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Texas A&M (2024) | `TAMU_Jersey_2024_NUM_Array` | -0.45 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Texas A&M (2025, Throwback) | `TAMU_JERSEY_2025_THROWBACK` | -0.46 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Texas State (2021) | `TXST_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Texas State (2023) | `TXST_Jersey_2023_NUM_Array` | -0.38 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Texas State (2024) | `TXST_Jersey_2024_NUM_Array` | -0.36 | 34 entries | From All_uniforms_TB.zip |
| ⬜ | Texas Tech (2021) | `TTU_Jersey_2021_NUM_Array` |  |  |  |
| ⬜ | Texas Tech (2024, Mahomes) | `TTU_Jersey_2024_Mahomes_NUM_Array` |  |  |  |
| ✅ | Texas Tech (2025, Mahomes) | `TTU_Jersey_2025_Mahomes_NUM_Array` | -0.42 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Texas Tech (2025) | `TTU_Jersey_2025_NUM_Array` | -0.3 | 27 entries | From All_uniforms_TB.zip |
| ✅ | Texas Tech (2026) | `TTU_Jersey_2026_NUM_Array` | -0.45 | 27 entries | From All_uniforms_TB.zip |
| ✅ | Toledo (2023, Black) | `TOL_JERSEY_2023_BLACK` | -0.3938529 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Toledo (2023, Blue) | `TOL_JERSEY_2023_BLUE` | -0.52 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Toledo (2023, Shoulders) | `TOL_Jersey_2023_Shoulders_NUM_Array` |  |  |  |
| ⬜ | Troy (2021) | `TROY_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Troy (2023) | `TROY_Jersey_2023_NUM_Array` | -0.54 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Tulane (2021) | `TULN_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Tulane (2023, Blue) | `TULN_JERSEY_2023_BLUE` | -0.38 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Tulane (2025, CITY Edition) | `TULN_Jersey_2025_CITY_EDITION_NUM_Array` | -0.4 | 27 entries | From All_uniforms_TB.zip |
| ✅ | Tulsa (2021) | `TLSA_Jersey_2021_NUM_Array` | -0.36 | 18 entries | From All_uniforms_TB.zip |
| ✅ | UAB (2021) | `UAB_Jersey_2021_NUM_Array` | -0.35 | 18 entries | From All_uniforms_TB.zip |
| ✅ | UCF (2023) | `UCF_Jersey_2023_NUM_Array` | -0.57 | 18 entries | From All_uniforms_TB.zip |
| ✅ | UCF (2024, Space) | `UCF_Jersey_2024_SPACE_NUM_Array` | -0.44 | 18 entries | From All_uniforms_TB.zip |
| ✅ | UCF (2024) | `UCF_Jersey_2024_NUM_Array` | -0.44 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | UCF (2025, 2) | `UCF_Jersey_2025_2_NUM_Array` |  |  |  |
| ⬜ | UCF (2025, 3) | `UCF_Jersey_2025_3_NUM_Array` |  |  |  |
| ✅ | UCF (2025, 4) | `UCF_Jersey_2025_4_NUM_Array` | -0.41 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | UCF (2025, Space Gray) | `UCF_Jersey_2025_Space_Gray_NUM_Array` |  |  |  |
| ✅ | UCF (2025, Space) | `UCF_Jersey_2025_Space_NUM_Array` | -0.37 | 18 entries | From All_uniforms_TB.zip |
| ✅ | UCF (2025) | `UCF_Jersey_2025_NUM_Array` | -0.4 | 18 entries | From All_uniforms_TB.zip |
| ✅ | UCLA (2021) | `UCLA_Jersey_2021_NUM_Array` | -0.43 | 18 entries | From All_uniforms_TB.zip |
| ✅ | UCLA (2023, ALT) | `UCLA_Jersey_2023_ALT_NUM_Array` | -0.445 | 18 entries | From All_uniforms_TB.zip |
| ✅ | UConn (2021) | `CONN_Jersey_2021_NUM_Array` | -0.4 | 18 entries | From All_uniforms_TB.zip |
| ✅ | UNLV (2023, Red) | `UNLV_JERSEY_2023_RED` | -0.34 | 26 entries | From All_uniforms_TB.zip |
| ⬜ | UNLV (2023, Sleeves) | `UNLV_Jersey_2023_Sleeves_NUM_Array` |  |  |  |
| ⬜ | USC (2021) | `USC_Jersey_2021_NUM_Array` |  |  |  |
| ⬜ | USC (2023) | `USC_Jersey_2023_NUM_Array` |  |  |  |
| ✅ | USC (2024, Throwback) | `USC_Jersey_2024_Throwback_NUM_Array` | -0.4 | 18 entries | From All_uniforms_TB.zip |
| ✅ | USC (2024) | `USC_Jersey_2024_NUM_Array` | -0.38 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Utah (2021, 02) | `UTAH_Jersey_2021_02_NUM_Array` | -0.453665555 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Utah (2021) | `UTAH_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Utah (2022) | `UTAH_Jersey_2022_NUM_Array` | -0.55 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Utah State (2021) | `USU_Jersey_2021_NUM_Array` | -0.4 | 18 entries | From All_uniforms_TB.zip |
| ✅ | UTEP (2021) | `UTEP_Jersey_2021_NUM_Array` | -0.38 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | UTEP (2025) | `UTEP_Jersey_2025_NUM_Array` |  |  |  |
| ✅ | UTEP (2026, Blue) | `UTEP_JERSEY_2026_BLUE` | -0.58 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | UTSA (2021) | `UTSA_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | UTSA (2025) | `UTSA_Jersey_2025_NUM_Array` | -0.48 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Vanderbilt (2021) | `VAN_Jersey_2021_NUM_Array` | -0.38 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Virginia (2021) | `UVA_Jersey_2021_NUM_Array` | -0.38 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Virginia Tech (2019) | `VT_Jersey_2019_NUM_Array` |  |  |  |
| ⬜ | Virginia Tech (2020, 02) | `VT_Jersey_2020_02_NUM_Array` |  |  |  |
| ⬜ | Virginia Tech (2020) | `VT_Jersey_2020_NUM_Array` |  |  |  |
| ⬜ | Virginia Tech (2021) | `VT_Jersey_2021_NUM_Array` |  |  |  |
| ⬜ | Virginia Tech (2022) | `VT_Jersey_2022_NUM_Array` |  |  |  |
| ✅ | Virginia Tech (2023) | `VT_Jersey_2023_NUM_Array` | -0.38 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Virginia Tech (2024) | `VT_Jersey_2024_NUM_Array` | -0.38 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Wake Forest (2022) | `WAKE_Jersey_2022_NUM_Array` | -0.45 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Washington (2021, Throwback) | `WASH_JERSEY_2021_THROWBACK` | -0.5 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Washington (2021) | `WASH_Jersey_2021_NUM_Array` | -0.404939115 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Washington (2023) | `WASH_Jersey_2023_NUM_Array` | -0.404939115 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Washington (2024, Sleeves) | `WASH_Jersey_2024_Sleeves_NUM_Array` |  |  |  |
| ✅ | Washington (2024) | `WASH_Jersey_2024_NUM_Array` | -0.404939115 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Washington (2025, Camo) | `WASH_Jersey_2025_Camo_NUM_Array` | -0.38 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Washington (2025, WHI) | `WASH_Jersey_2025_WHI_NUM_Array` |  |  |  |
| ✅ | Washington (2025) | `WASH_Jersey_2025_NUM_Array` | -0.38 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Washington State (2023) | `WSU_Jersey_2023_NUM_Array` | -0.44 | 33 entries | From All_uniforms_TB.zip |
| ⬜ | Washington State (2024) | `WSU_Jersey_2024_NUM_Array` |  |  |  |
| ✅ | West Virginia (2021) | `WVU_Jersey_2021_NUM_Array` | -0.375 | 18 entries | From All_uniforms_TB.zip |
| ✅ | West Virginia (2025, Throwback) | `WVU_JERSEY_2025_THROWBACK` | -0.36 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Western Kentucky (2021) | `WKU_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Western Kentucky (2023, Red) | `WKU_JERSEY_2023_RED` | -0.465 | 18 entries | From All_uniforms_TB.zip |
| ⬜ | Western Michigan (2021) | `WMU_Jersey_2021_NUM_Array` |  |  |  |
| ✅ | Western Michigan (2024) | `WMU_Jersey_2024_NUM_Array` | -0.4 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Wisconsin (2021) | `WIS_Jersey_2021_NUM_Array` | -0.51 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Wisconsin (2025, Throwback) | `WIS_Jersey_2025_Throwback_NUM_Array` | -0.43 | 18 entries | From All_uniforms_TB.zip |
| ✅ | Wyoming (2021) | `WYO_Jersey_2021_NUM_Array` | -0.396063447 | 18 entries | From All_uniforms_TB.zip |
