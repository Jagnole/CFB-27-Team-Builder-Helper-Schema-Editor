const CATALOG = {"_meta":{"description":"Known font-array texture paths for CFB 27 Team Builder name/number fonts. Not exhaustive -- grow this as more real teams get captured.","generatedFrom":"user-supplied reference lists, not verified against every entry in-game","knownIssues":["[numberFonts.jersey] DUPLICATE PATH used by 5 display names: ['Air Sports Space Force', 'Akron', 'Ball State', 'BYU throwback', 'Clemson'] -> content/characters/player/parts/uniforms/comp/jerseys/numbers/","[numberFonts.jersey] DUPLICATE PATH used by 2 display names: ['EMU_Jersey_2021_NUM_Array', 'FIU_Jersey_2021_NUM_Array'] -> content/characters/player/parts/uniforms/comp/jerseys/numbers/EMU_Jersey_2021_NUM_Array","[numberFonts.jersey] DUPLICATE PATH used by 2 display names: ['FIU Vice 2024', 'FIU Vice 2023'] -> content/characters/player/parts/uniforms/comp/jerseys/numbers/FIU_Jersey_2024_NUM_Array","[numberFonts.jersey] Case mismatch in path root for 'AFA_Jersey_2021_NUM_Array': Content/characters/Player/parts/uniforms/comp/jerseys/numbers/AFA_Jersey_2021_NUM_Array","[numberFonts.jersey] BLANK/placeholder path for 'Air Sports Space Force': content/characters/player/parts/uniforms/comp/jerseys/numbers/","[numberFonts.jersey] BLANK/placeholder path for 'Akron': content/characters/player/parts/uniforms/comp/jerseys/numbers/","[numberFonts.jersey] BLANK/placeholder path for 'Ball State': content/characters/player/parts/uniforms/comp/jerseys/numbers/","[numberFonts.jersey] BLANK/placeholder path for 'BYU throwback': content/characters/player/parts/uniforms/comp/jerseys/numbers/","[numberFonts.jersey] BLANK/placeholder path for 'Clemson': content/characters/player/parts/uniforms/comp/jerseys/numbers/","[numberFonts.jersey] SUSPICIOUS: number-font entry 'FCS West' points at a _NAME_Array path: content/characters/player/parts/uniforms/comp/jerseys/numbers/STANDARD_Jersey_2022_Blocky_NAME_Array","Confirmed by in-game testing: /comp/ is not required. Both the arrayTexture field and the overlay field take the identical path (with /comp/ stripped, if the catalog entry had it). The tool normalizes automatically -- this note is just so the catalog's raw path values (mostly still /comp/-form, as scraped) aren't misread as the literal in-game requirement.","Number-font entries now carry a human-readable 'label' field (e.g. 'Boston College (2021)') built from a code->school mapping, confirmed with the user except: BGH was dropped (unidentifiable), MTDEW is intentionally not a school (branded/promo jersey). The old separate 'alts' bucket was folded into 'jersey' since the label itself now conveys special/throwback/alt status.","numberFonts.jersey replaced wholesale with the user's manually reviewed Label/Reference table (276 entries) -- not merged or re-derived. Paths were generated fresh using the confirmed working pattern (content/characters/player/parts/uniforms/jerseys/numbers/<reference>), not carried over from any prior catalog version.","helmetMaterials.{shell,facemask,accessory} built from the user's reviewed helmet-material-labels.xlsx (wide format). All three use the same path prefix: content/characters/player/parts/uniforms/helmets/helmet_presets/<reference>. Facemask is included but expected to be rarely used.","decals: path prefix is source-aware, not a blanket rule -- entries whose original source path had /comp/ use ContentShared/... with comp stripped (confirmed for Nike Cotton, Nike Plastic, UA via screenshots); entries that never had /comp/ keep plain content/... unchanged (confirmed for Nike ShoeDuck via actual in-game test). Do not force one prefix onto all entries -- that was the bug that shipped in v0.03/v0.04's initial catalog.","decals: New Balance Cotton (2025)'s ContentShared/ prefix confirmed correct via a real in-game/XML path for col and norm -- guess from v0.60 verified, not just pattern-matched from Nike Cotton. Adidas Trefoil (2025) still unconfirmed.","decals: Adidas Trefoil (2025)'s path prefix corrected from a wrong ContentShared/ guess (pattern-matched off Adidas Plastic) to the confirmed real content/ prefix (matches Nike ShoeDuck's pattern instead) -- fixed after user supplied the real in-game path. The v0.60 guess was wrong; don't assume same-brand entries share a prefix pattern."]},"nameFonts":[{"displayName":"AFA_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/AFA_Jersey_2021_NAME_Array"},{"displayName":"ASU_Jersey_2021_Name_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/ASU_Jersey_2021_Name_Array"},{"displayName":"ASU_Jersey_2023_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/ASU_Jersey_2023_NAME_Array"},{"displayName":"BC_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/BC_Jersey_2021_NAME_Array"},{"displayName":"BSU_Jersey_2022_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/BSU_Jersey_2022_NAME_Array"},{"displayName":"BYU_Jersey_2022_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/BYU_Jersey_2022_NAME_Array"},{"displayName":"CCAR_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/CCAR_Jersey_2021_NAME_Array"},{"displayName":"CIN_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/CIN_Jersey_2021_NAME_Array"},{"displayName":"EMU_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/EMU_Jersey_2021_NAME_Array"},{"displayName":"GASO_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/GASO_Jersey_2021_NAME_Array"},{"displayName":"ILL_Jersey_2022_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/ILL_Jersey_2022_NAME_Array"},{"displayName":"IND_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/IND_Jersey_2021_NAME_Array"},{"displayName":"LOU_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/LOU_Jersey_2021_NAME_Array"},{"displayName":"MSST_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/MSST_Jersey_2021_NAME_Array"},{"displayName":"NEB_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/NEB_Jersey_2021_NAME_Array"},{"displayName":"NMSU_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/NMSU_Jersey_2021_NAME_Array"},{"displayName":"NW_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/NW_Jersey_2021_NAME_Array"},{"displayName":"PUR_Jersey_2023_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/PUR_Jersey_2023_NAME_Array"},{"displayName":"STAN_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/STAN_Jersey_2021_NAME_Array"},{"displayName":"Standard_Jersey_2022_Blocky_02_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_Blocky_02_NAME_Array"},{"displayName":"STANDARD_Jersey_2022_Blocky_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/STANDARD_Jersey_2022_Blocky_NAME_Array"},{"displayName":"Standard_Jersey_2022_BlockyS_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_BlockyS_NAME_Array"},{"displayName":"Standard_Jersey_2022_BlockyS02_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_BlockyS02_NAME_Array"},{"displayName":"Standard_Jersey_2022_BlockySerif_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_BlockySerif_NAME_Array"},{"displayName":"Standard_Jersey_2022_BlockySerifS_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_BlockySerifS_NAME_Array"},{"displayName":"Standard_Jersey_2022_BlockyStroke_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_BlockyStroke_NAME_Array"},{"displayName":"Standard_Jersey_2022_BlockyStrokeS_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_BlockyStrokeS_NAME_Array"},{"displayName":"Standard_Jersey_2022_BlockyStrokeS02_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_BlockyStrokeS02_NAME_Array"},{"displayName":"Standard_Jersey_2022_Smooth_01_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_Smooth_01_NAME_Array"},{"displayName":"Standard_Jersey_2022_Smooth_02_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_Smooth_02_NAME_Array"},{"displayName":"Standard_Jersey_2022_Smooth_03_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/Standard_Jersey_2022_Smooth_03_NAME_Array"},{"displayName":"TAMU_Jersey_2023_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/TAMU_Jersey_2023_NAME_Array"},{"displayName":"TOL_Jersey_2023_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/TOL_Jersey_2023_NAME_Array"},{"displayName":"UAB_Jersey_2024_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/UAB_Jersey_2024_NAME_Array"},{"displayName":"UCF_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/UCF_Jersey_2021_NAME_Array"},{"displayName":"UMD_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/UMD_Jersey_2021_NAME_Array"},{"displayName":"UNLV_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/UNLV_Jersey_2021_NAME_Array"},{"displayName":"UNM_Jersey_2023_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/UNM_Jersey_2023_NAME_Array"},{"displayName":"USA_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/USA_Jersey_2021_NAME_Array"},{"displayName":"USF_Jersey_2023_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/USF_Jersey_2023_NAME_Array"},{"displayName":"USM_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/USM_Jersey_2021_NAME_Array"},{"displayName":"USU_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/USU_Jersey_2021_NAME_Array"},{"displayName":"VT_Jersey_2023_Blocky_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/VT_Jersey_2023_Blocky_NAME_Array"},{"displayName":"WASH_Jersey_2023_Blocky_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/WASH_Jersey_2023_Blocky_NAME_Array"},{"displayName":"WIS_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/WIS_Jersey_2021_NAME_Array"},{"displayName":"WVU_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/WVU_Jersey_2021_NAME_Array"},{"displayName":"WYO_Jersey_2021_NAME_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/name_fonts/WYO_Jersey_2021_NAME_Array"}],"numberFonts":{"jersey":[{"displayName":"AFA_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/AFA_Jersey_2021_NUM_Array","label":"Air Force (2021)"},{"displayName":"AFA_Jersey_2025_Alt_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/AFA_Jersey_2025_Alt_NUM_Array","label":"Air Force (Space Force Alternate)"},{"displayName":"AKR_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/AKR_Jersey_2025_NUM_Array","label":"Akron (Current Home)"},{"displayName":"ALA_JERSEY_2023_CRIMSON","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedFullBlock_NUM_Array","label":"Alabama (Current Home)"},{"displayName":"APP_JERSEY_2023_BLACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedAllLeague2_NUM_Array","label":"Appalachian State (Current Home)"},{"displayName":"ARIZ_Jersey_2026_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ARIZ_Jersey_2026_NUM_Array","label":"Arizona (Current Alternate)"},{"displayName":"ASU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ASU_Jersey_2024_NUM_Array","label":"Arizona State (Current 2nd Alternate)"},{"displayName":"ASU_JERSEY_2025_BLACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/ASU_Jersey_2025_NUM_Array","label":"Arizona State (Current Alternate)"},{"displayName":"ASU_Jersey_2025_02_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ASU_Jersey_2025_02_NUM_Array","label":"Arizona State (Current Home)"},{"displayName":"ASU_JERSEY_2025_THROWBACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedFullBlock3_NUM_Array","label":"Arizona State (Current Throwback)"},{"displayName":"ARK_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ARK_Jersey_2023_NUM_Array","label":"Arkansas (Current Home)"},{"displayName":"ARST_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ARST_Jersey_2023_NUM_Array","label":"Arkansas State (Current Home)"},{"displayName":"ARMY_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ARMY_Jersey_2024_NUM_Array","label":"Army (101 Airborne Alternate)"},{"displayName":"ARMY_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ARMY_Jersey_2025_NUM_Array","label":"Army (250 Alternate)"},{"displayName":"ARMY_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ARMY_Jersey_2021_NUM_Array","label":"Army (Current Home)"},{"displayName":"AUB_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/AUB_Jersey_2023_NUM_Array","label":"Auburn (Current Home)"},{"displayName":"BALL_JERSEY_2024_BLACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_BALL_NUM_Array","label":"Ball State (Current Home)"},{"displayName":"BAY_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/BAY_Jersey_2021_NUM_Array","label":"Baylor (Current Home)"},{"displayName":"BSU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/BSU_Jersey_2021_NUM_Array","label":"Boise State (Current Home)"},{"displayName":"BC_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/BC_Jersey_2025_NUM_Array","label":"Boston College (Current Home)"},{"displayName":"BGSU_JERSEY_2023_BROWN","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_MISS_NUM_Array","label":"Bowling Green (Current Home)"},{"displayName":"BUFF_JERSEY_2023_BLUE","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedBoulder3_NUM_Array","label":"Buffalo (Current Home)"},{"displayName":"BYU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/BYU_Jersey_2024_NUM_Array","label":"BYU (Current Alternate)"},{"displayName":"BYU_JERSEY_2023_BLACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedFullBlock_NUM_Array","label":"BYU (Current Home)"},{"displayName":"CAL_JERSEY_2025_HOME","path":"content/characters/player/parts/uniforms/jerseys/numbers/ARK_Jersey_2023_NUM_Array","label":"California (Current Home)"},{"displayName":"CMU_JERSEY_2023_MAROON","path":"content/characters/player/parts/uniforms/jerseys/numbers/LSU_Jersey_2024_NUM_Array","label":"Central Michigan (Current Home)"},{"displayName":"CHAR_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CHAR_Jersey_2025_NUM_Array","label":"Charlotte (Current Home)"},{"displayName":"CIN_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CIN_Jersey_2025_NUM_Array","label":"Cincinnati (Current Home)"},{"displayName":"CLEM_JERSEY_2025_HOME","path":"content/characters/player/parts/uniforms/jerseys/numbers/CMU_Jersey_2021_NUM_Array","label":"Clemson (Current Home)"},{"displayName":"CCAR_Jersey_2021_02_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CCAR_Jersey_2021_02_NUM_Array","label":"Coastal Carolina (Current Alternate)"},{"displayName":"COLO_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/COLO_Jersey_2024_NUM_Array","label":"Colorado (Current Home)"},{"displayName":"CSU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CSU_Jersey_2021_NUM_Array","label":"Colorado State (Current Home)"},{"displayName":"DEL_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/DEL_Jersey_2024_NUM_Array","label":"Delaware (Current Home)"},{"displayName":"DUKE_JERSEY_2023_BLACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_DUKE_NUM_Array","label":"Duke (Current Home)"},{"displayName":"ECU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ECU_Jersey_2021_NUM_Array","label":"East Carolina (Current Away)"},{"displayName":"ECU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ECU_Jersey_2023_NUM_Array","label":"East Carolina (Current Home)"},{"displayName":"EMU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/EMU_Jersey_2021_NUM_Array","label":"Eastern Michigan (Current Home)"},{"displayName":"FLA_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/FLA_Jersey_2021_NUM_Array","label":"Florida (Current Home)"},{"displayName":"FAU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/FAU_Jersey_2021_NUM_Array","label":"Florida Atlantic (2024 2nd Alternate)"},{"displayName":"FAU_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/FAU_Jersey_2025_NUM_Array","label":"Florida Atlantic (2024 Alternate)"},{"displayName":"FAU_Jersey_2025-2_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/FAU_Jersey_2025-2_NUM_Array","label":"Florida Atlantic (Current Home)"},{"displayName":"FIU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/FIU_Jersey_2024_NUM_Array","label":"Florida International (2023/2024 Vice Alternate)"},{"displayName":"FIU_Jersey_2025_Vice_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/FIU_Jersey_2025_Vice_NUM_Array","label":"Florida International (2025 Vice Alternate)"},{"displayName":"FIU_JERSEY_2025_HOME","path":"content/characters/player/parts/uniforms/jerseys/numbers/EMU_Jersey_2021_NUM_Array","label":"Florida International (Current Home)"},{"displayName":"FSU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/FSU_Jersey_2021_NUM_Array","label":"Florida State (Current Home)"},{"displayName":"FRES_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/FRES_Jersey_2021_NUM_Array","label":"Fresno State (Current Home)"},{"displayName":"UGA_JERSEY_2023_RED","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedWideFullBlock_NUM_Array","label":"Georgia (Current Home)"},{"displayName":"GASO_JERSEY_2023_HOME","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_DUKE_NUM_Array","label":"Georgia Southern (Current Home)"},{"displayName":"GSU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/GSU_Jersey_2023_NUM_Array","label":"Georgia State (Current Home)"},{"displayName":"GT_Jersey_2026_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/GT_Jersey_2026_NUM_Array","label":"Georgia Tech (Current Home)"},{"displayName":"HAW_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/HAW_Jersey_2021_NUM_Array","label":"Hawaii (Current Home)"},{"displayName":"HOU_JERSEY_2023_RED","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_WideFullBlock2_NUM_Array","label":"Houston (Current Home)"},{"displayName":"MUSHS_JERSEY_2025_HOME","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_1960_JET_NUM_Array","label":"HS Mustangs (Current Home)"},{"displayName":"RATHS_JERSEY_2025_HOME","path":"content/characters/player/parts/uniforms/jerseys/numbers/TENN_Jersey_2021_NUM_Array","label":"HS Rattlers (Current Home)"},{"displayName":"ILL_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ILL_Jersey_2021_NUM_Array","label":"Illinois (Current Home)"},{"displayName":"IND_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/IND_Jersey_2022_NUM_Array","label":"Indiana (Current Home)"},{"displayName":"IOWA_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/IOWA_Jersey_2021_NUM_Array","label":"Iowa (Current Home)"},{"displayName":"ISU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ISU_Jersey_2023_NUM_Array","label":"Iowa State (2023 Home)"},{"displayName":"ISU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ISU_Jersey_2024_NUM_Array","label":"Iowa State (Current Home)"},{"displayName":"ISU_JERSEY_2024_THROWBACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_UMASS_NUM_Array","label":"Iowa State (Current Throwback)"},{"displayName":"JVST_JERSEY_2023_RED","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_UMASS_NUM_Array","label":"Jacksonville State (Current Home)"},{"displayName":"JMU_JERSEY_2023_PURPLE","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedVapor_Strike_NUM_Array","label":"James Madison (Current Home)"},{"displayName":"KU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/KU_Jersey_2024_NUM_Array","label":"Kansas (Current Alternate)"},{"displayName":"KU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/KU_Jersey_2023_NUM_Array","label":"Kansas (Current Home)"},{"displayName":"KSU_JERSEY_2023_PURPLE","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_KSU_NUM_Array","label":"Kansas State (Current Home)"},{"displayName":"KENN_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/KENN_Jersey_2025_NUM_Array","label":"Kennesaw State (Current Home)"},{"displayName":"KENT_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/KENT_Jersey_2023_NUM_Array","label":"Kent State (Current Home)"},{"displayName":"UK_JERSEY_2023_BLUE","path":"content/characters/player/parts/uniforms/jerseys/numbers/TROY_Jersey_2023_NUM_Array","label":"Kentucky (Current Home)"},{"displayName":"LIB_JERSEY_SHARE_16","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_BALL_NUM_Array","label":"Liberty (Current Home)"},{"displayName":"ULL_Jersey_2025_BLOCKSHADOW_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ULL_Jersey_2025_BLOCKSHADOW_NUM_Array","label":"Louisiana (Current Alternate)"},{"displayName":"ULL_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ULL_Jersey_2021_NUM_Array","label":"Louisiana (Current Home)"},{"displayName":"LT_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/LT_Jersey_2023_NUM_Array","label":"Louisiana Tech (Current Home)"},{"displayName":"ULM_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ULM_Jersey_2024_NUM_Array","label":"Louisiana-Monroe (Current Alternate)"},{"displayName":"ULM_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ULM_Jersey_2021_NUM_Array","label":"Louisiana-Monroe (Current Home)"},{"displayName":"ULM_Jersey_2016_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ULM_Jersey_2016_NUM_Array","label":"Louisiana-Monroe (P-40 Warhawk Alternate)"},{"displayName":"LOU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/LOU_Jersey_2024_NUM_Array","label":"Louisville (Champions Gold Ali)"},{"displayName":"LOU2_JERSEY_SHARE_17","path":"content/characters/player/parts/uniforms/jerseys/numbers/SMU_Jersey_2021_NUM_Array","label":"Louisville (Current Alternate)"},{"displayName":"LOU_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/LOU_Jersey_2025_NUM_Array","label":"Louisville (Current Home)"},{"displayName":"LSU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/LSU_Jersey_2023_NUM_Array","label":"LSU (Current Home)"},{"displayName":"MRSH_JERSEY_2023_BLACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_MRSH_NUM_Array","label":"Marshall (2023 Home)"},{"displayName":"MRSH_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MRSH_Jersey_2025_NUM_Array","label":"Marshall (Current Home)"},{"displayName":"UMD_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UMD_Jersey_2025_NUM_Array","label":"Maryland (Current Away Alternate)"},{"displayName":"UMD_Jersey_Away_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UMD_Jersey_Away_2023_NUM_Array","label":"Maryland (Current Home)"},{"displayName":"MEM_JERSEY_2023_BLUE","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2023_MSU_Stroked_NUM_Array","label":"Memphis (Current Home)"},{"displayName":"MIA_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MIA_Jersey_2024_NUM_Array","label":"Miami (FL) (2024 Alternate)"},{"displayName":"MIA_Jersey_2025_Camo_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MIA_Jersey_2025_Camo_NUM_Array","label":"Miami (FL) (Current Camo Alternate)"},{"displayName":"MIA_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MIA_Jersey_2025_NUM_Array","label":"Miami (FL) (Current Home)"},{"displayName":"MIAOH_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MIAOH_Jersey_2021_NUM_Array","label":"Miami (OH) (Current Home)"},{"displayName":"MICH_JERSEY_2023_BLUE","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_MICH_NUM_Array","label":"Michigan (Current Home)"},{"displayName":"MSU_JERSEY_2023_GREEN","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2023_MSU_Stroked_NUM_Array","label":"Michigan State (Current Home)"},{"displayName":"MTSU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MTSU_Jersey_2023_NUM_Array","label":"Middle Tennessee (Current Home)"},{"displayName":"MINN_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MINN_Jersey_2021_NUM_Array","label":"Minnesota (Current Home)"},{"displayName":"MSST_Jersey_2025_Throwback_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MSST_Jersey_2025_Throwback_NUM_Array","label":"Mississippi State (2023 Throwback)"},{"displayName":"MSST_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MSST_Jersey_2024_NUM_Array","label":"Mississippi State (Current Away Alternate)"},{"displayName":"MSST_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MSST_Jersey_2021_NUM_Array","label":"Mississippi State (Current Home)"},{"displayName":"MIZZ_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MIZZ_Jersey_2021_NUM_Array","label":"Missouri (Current Home)"},{"displayName":"MIST_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/MIST_Jersey_2024_NUM_Array","label":"Missouri State (Current Home)"},{"displayName":"NAVY_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NAVY_Jersey_2023_NUM_Array","label":"Navy (Current Home)"},{"displayName":"NAVY_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NAVY_Jersey_2024_NUM_Array","label":"Navy (Jolly Rogers Altema)"},{"displayName":"NAVY_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NAVY_Jersey_2025_NUM_Array","label":"Navy (Navy 250 Alternate)"},{"displayName":"NCST_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NCST_Jersey_2025_NUM_Array","label":"NC State (2025 City of Oaks v)"},{"displayName":"NCST_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NCST_Jersey_2021_NUM_Array","label":"NC State (Current Home)"},{"displayName":"NEB_JERSEY_2024_RED","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_NEB_NUM_Array","label":"Nebraska (2025 Home)"},{"displayName":"NEB_Jersey_2026_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NEB_Jersey_2026_NUM_Array","label":"Nebraska (Current Home)"},{"displayName":"NEV_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NEV_Jersey_2021_NUM_Array","label":"Nevada (Current Home)"},{"displayName":"UNM_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UNM_Jersey_2021_NUM_Array","label":"New Mexico (2021 Alternate)"},{"displayName":"UNM_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UNM_Jersey_2025_NUM_Array","label":"New Mexico (Current Home)"},{"displayName":"NMSU_JERSEY_SHARE_20","path":"content/characters/player/parts/uniforms/jerseys/numbers/LT_Jersey_2023_NUM_Array","label":"New Mexico State (Current Home)"},{"displayName":"UNC_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UNC_Jersey_2022_NUM_Array","label":"North Carolina (Current Home Throwback)"},{"displayName":"UNC_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UNC_Jersey_2021_NUM_Array","label":"North Carolina (Current Home)"},{"displayName":"NDSU2_JERSEY_SHARE_19","path":"content/characters/player/parts/uniforms/jerseys/numbers/NAVY_Jersey_2021_NUM_Array","label":"North Dakota State (Current Away Alternate)"},{"displayName":"NDSU_Jersey_2026_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NDSU_Jersey_2026_NUM_Array","label":"North Dakota State (Current Home)"},{"displayName":"UNT_JERSEY_2023_GREEN","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_MISS_NUM_Array","label":"North Texas (Current Home)"},{"displayName":"NIU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NIU_Jersey_2023_NUM_Array","label":"Northern Illinois (Current Alternate)"},{"displayName":"NIU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NIU_Jersey_2021_NUM_Array","label":"Northern Illinois (Current Home)"},{"displayName":"NW_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NW_Jersey_2022_NUM_Array","label":"Northwestern (Current Gothic Alternate)"},{"displayName":"NW_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NW_Jersey_2021_NUM_Array","label":"Northwestern (Current Home)"},{"displayName":"NW_Jersey_2026_Gothic_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/NW_Jersey_2026_Gothic_NUM_Array","label":"Northwestern Purple Gothic"},{"displayName":"ND_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ND_Jersey_2021_NUM_Array","label":"Notre Dame (Current Home)"},{"displayName":"ND_Jersey_2024_Shamrock_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ND_Jersey_2024_Shamrock_NUM_Array","label":"Notre Dame (Current Shamrock Alternate)"},{"displayName":"ND_Jersey_2026_Shamrock_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ND_Jersey_2026_Shamrock_NUM_Array","label":"Notre Dame Shamrock 2026"},{"displayName":"OHIO_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/OHIO_Jersey_2024_NUM_Array","label":"Ohio (Current Alternate)"},{"displayName":"OHIO_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/OHIO_Jersey_2023_NUM_Array","label":"Ohio (Current Home)"},{"displayName":"OSU_JERSEY_2023_SCARLETT","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedFullBlock3_NUM_Array","label":"Ohio State (Current Home)"},{"displayName":"OU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/OU_Jersey_2023_NUM_Array","label":"Oklahoma (Current Home)"},{"displayName":"OU_Jersey_2024_02_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/OU_Jersey_2024_02_NUM_Array","label":"Oklahoma (Current Throwback)"},{"displayName":"OKST_JERSEY_2023_BLACK","path":"content/characters/player/parts/uniforms/jerseys/numbers/CMU_Jersey_2021_NUM_Array","label":"Oklahoma State (Current Home)"},{"displayName":"ODU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ODU_Jersey_2021_NUM_Array","label":"Old Dominion (Current Home)"},{"displayName":"MISS_JERSEY_2024_BLUE","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_MISS_NUM_Array","label":"Ole Miss (Current Home)"},{"displayName":"ORE_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ORE_Jersey_2021_NUM_Array","label":"Oregon (2023 Home)"},{"displayName":"ORE_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ORE_Jersey_2024_NUM_Array","label":"Oregon (Home Fly Era)"},{"displayName":"ORE_JERSEY_2025_GANGGREEN","path":"content/characters/player/parts/uniforms/jerseys/numbers/OSU_Jersey_2023_02_NUM_Array","label":"Oregon (Home Gang Green)"},{"displayName":"ORE_Jersey_2025_ShoeDuck_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ORE_Jersey_2025_ShoeDuck_NUM_Array","label":"Oregon (Shoe Duck Alternate)"},{"displayName":"ORST_Jersey_2025_Camo_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ORST_Jersey_2025_Camo_NUM_Array","label":"Oregon State (Current Camo Alternate)"},{"displayName":"ORST_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/ORST_Jersey_2021_NUM_Array","label":"Oregon State (Current Home)"},{"displayName":"PSU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/PSU_Jersey_2023_NUM_Array","label":"Penn State (Current Home)"},{"displayName":"PITT_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/PITT_Jersey_2021_NUM_Array","label":"Pittsburgh (Current Home)"},{"displayName":"PUR_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/PUR_Jersey_2023_NUM_Array","label":"Purdue (Current Home)"},{"displayName":"RICE_Jersey_2026_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/RICE_Jersey_2026_NUM_Array","label":"Rice (Current Home)"},{"displayName":"RUTG_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/RUTG_Jersey_2021_NUM_Array","label":"Rutgers (Current Home)"},{"displayName":"SACST_Jersey_2026_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SACST_Jersey_2026_NUM_Array","label":"Sacramento State (Current Home)"},{"displayName":"SHSU_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SHSU_Jersey_2025_NUM_Array","label":"Sam Houston State (Current Home)"},{"displayName":"SDSU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SDSU_Jersey_2021_NUM_Array","label":"San Diego State (Current Home)"},{"displayName":"SJSU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SJSU_Jersey_2023_NUM_Array","label":"San Jose State (Current Home)"},{"displayName":"SMU_JERSEY_2023_BLUE","path":"content/characters/player/parts/uniforms/jerseys/numbers/MTSU_Jersey_2023_NUM_Array","label":"SMU (Current Home)"},{"displayName":"SMU_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SMU_Jersey_2022_NUM_Array","label":"SMU (Dallas Home)"},{"displayName":"USA_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/USA_Jersey_2021_NUM_Array","label":"South Alabama (Current Home)"},{"displayName":"SC_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SC_Jersey_2021_NUM_Array","label":"South Carolina (Current Home)"},{"displayName":"USF_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/USF_Jersey_2023_NUM_Array","label":"South Florida (Current Home)"},{"displayName":"USM_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/USM_Jersey_2025_NUM_Array","label":"Southern Miss (Current Home)"},{"displayName":"STAN2_JERSEY_SHARE_6","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_STAN_NUM_Array","label":"Stanford (Current Home)"},{"displayName":"SYR_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/SYR_Jersey_2021_NUM_Array","label":"Syracuse (Current Home)"},{"displayName":"TCU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TCU_Jersey_2021_NUM_Array","label":"TCU (Current Home)"},{"displayName":"TCU_Jersey_2026_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TCU_Jersey_2026_NUM_Array","label":"TCU (Dublin Alternate)"},{"displayName":"TEMP_JERSEY_2025_RED","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_1960_BRO_NUM_Array","label":"Temple (Current Home)"},{"displayName":"TENN_Jersey_2026_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TENN_Jersey_2026_NUM_Array","label":"Tennessee (Current Home)"},{"displayName":"TEX_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TEX_Jersey_2024_NUM_Array","label":"Texas (Current Home)"},{"displayName":"TAMU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TAMU_Jersey_2021_NUM_Array","label":"Texas A&M (Current Home)"},{"displayName":"TAMU_JERSEY_2025_THROWBACK","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedFullBlock3_NUM_Array","label":"Texas A&M (Current Throwback)"},{"displayName":"TTU_Jersey_2025_Mahomes_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TTU_Jersey_2025_Mahomes_NUM_Array","label":"Texas Tech (Current 2nd Alternate)"},{"displayName":"TTU_Jersey_2026_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TTU_Jersey_2026_NUM_Array","label":"Texas Tech (Current Home)"},{"displayName":"TTU_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TTU_Jersey_2025_NUM_Array","label":"Texas Tech (Current Throwback)"},{"displayName":"TOL_JERSEY_2023_BLUE","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedMichiganState3_NUM_Array","label":"Toledo (Current Home)"},{"displayName":"TROY_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TROY_Jersey_2023_NUM_Array","label":"Troy (Current Home)"},{"displayName":"TULN_Jersey_2025_CITY_EDITION_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TULN_Jersey_2025_CITY_EDITION_NUM_Array","label":"Tulane (City Edition Alternate)"},{"displayName":"TULN_JERSEY_2023_BLUE","path":"content/characters/player/parts/uniforms/jerseys/numbers/CMU_Jersey_2021_NUM_Array","label":"Tulane (Current Home)"},{"displayName":"TLSA_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/TLSA_Jersey_2021_NUM_Array","label":"Tulsa (Current Home)"},{"displayName":"UAB_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UAB_Jersey_2021_NUM_Array","label":"UAB (Current Home)"},{"displayName":"UCF_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCF_Jersey_2023_NUM_Array","label":"UCF (2023 Light Mode)"},{"displayName":"UCF_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCF_Jersey_2024_NUM_Array","label":"UCF (2023 Space U)"},{"displayName":"UCF_Jersey_2024_SPACE_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCF_Jersey_2024_SPACE_NUM_Array","label":"UCF (2024 Space U)"},{"displayName":"UCF_Jersey_2025_Space_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCF_Jersey_2025_Space_NUM_Array","label":"UCF (2025 Space U)"},{"displayName":"UCF_Jersey_2025_4_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCF_Jersey_2025_4_NUM_Array","label":"UCF (Current Home Alternate)"},{"displayName":"UCF_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCF_Jersey_2025_NUM_Array","label":"UCF (Current Home)"},{"displayName":"UCLA_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCLA_Jersey_2021_NUM_Array","label":"UCLA (Current Home)"},{"displayName":"UCLA_Jersey_2023_ALT_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UCLA_Jersey_2023_ALT_NUM_Array","label":"UCLA (Current Throwback)"},{"displayName":"CONN_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/CONN_Jersey_2021_NUM_Array","label":"UConn (Current Home)"},{"displayName":"UMASS_JERSEY_2023_MAROON","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2021_UMASS_NUM_Array","label":"UMass (Current Home)"},{"displayName":"UNLV_JERSEY_2023_RED","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Standard_Jersey_2023_MSU_Stroked_NUM_Array","label":"UNLV (Current Home)"},{"displayName":"USC_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/USC_Jersey_2024_NUM_Array","label":"USC (Current Home)"},{"displayName":"UTAH_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UTAH_Jersey_2022_NUM_Array","label":"Utah (Current Home Throwback)"},{"displayName":"UTAH_Jersey_2021_02_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UTAH_Jersey_2021_02_NUM_Array","label":"Utah (Current Home)"},{"displayName":"USU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/USU_Jersey_2021_NUM_Array","label":"Utah State (Current Home)"},{"displayName":"UTEP_JERSEY_2026_BLUE","path":"content/characters/player/parts/uniforms/jerseys/numbers/KU_Jersey_2023_NUM_Array","label":"UTEP (Current Home)"},{"displayName":"UTEP2_JERSEY_SHARE_12","path":"content/characters/player/parts/uniforms/jerseys/numbers/CMU_Jersey_2023_NUM_Array","label":"UTEP (Current Throwback)"},{"displayName":"UTSA_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UTSA_Jersey_2025_NUM_Array","label":"UTSA (Current Home)"},{"displayName":"VAN_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/VAN_Jersey_2021_NUM_Array","label":"Vanderbilt (Current Home)"},{"displayName":"UVA_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/UVA_Jersey_2021_NUM_Array","label":"Virginia (Current Home)"},{"displayName":"UVA2_JERSEY_SHARE_13","path":"content/characters/player/parts/uniforms/jerseys/numbers/UTEP_Jersey_2021_NUM_Array","label":"Virginia (Current Throwback)"},{"displayName":"VT_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/VT_Jersey_2023_NUM_Array","label":"Virginia Tech (2023)"},{"displayName":"VT_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/VT_Jersey_2024_NUM_Array","label":"Virginia Tech (2024)"},{"displayName":"WAKE_Jersey_2022_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WAKE_Jersey_2022_NUM_Array","label":"Wake Forest (Current Home)"},{"displayName":"WASH_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WASH_Jersey_2024_NUM_Array","label":"Washington (Current 2nd Alternate)"},{"displayName":"WASH_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WASH_Jersey_2023_NUM_Array","label":"Washington (Current Alternate)"},{"displayName":"WASH_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WASH_Jersey_2021_NUM_Array","label":"Washington (Current Away Alternate)"},{"displayName":"WASH_Jersey_2025_Camo_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WASH_Jersey_2025_Camo_NUM_Array","label":"Washington (Current Camo Alternate)"},{"displayName":"WASH_Jersey_2025_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WASH_Jersey_2025_NUM_Array","label":"Washington (Current Home)"},{"displayName":"WSU_Jersey_2023_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WSU_Jersey_2023_NUM_Array","label":"Washington State (Current Home)"},{"displayName":"WVU_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WVU_Jersey_2021_NUM_Array","label":"West Virginia (Current Home)"},{"displayName":"WKU_JERSEY_2023_RED","path":"ContentShared/characters/player/parts/uniforms/jerseys/numbers/Nike_Jersey_2025_StrokedAllLeagueShadow_NUM_Array","label":"Western Kentucky (Current Home)"},{"displayName":"WMU_Jersey_2024_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WMU_Jersey_2024_NUM_Array","label":"Western Michigan (Current Home)"},{"displayName":"WIS_Jersey_2025_Throwback_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WIS_Jersey_2025_Throwback_NUM_Array","label":"Wisconsin (Current 1980's Throwback)"},{"displayName":"WIS_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WIS_Jersey_2021_NUM_Array","label":"Wisconsin (Current Home)"},{"displayName":"WIS_Jersey_2026_Shamrock_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WIS_Jersey_2026_Shamrock_NUM_Array","label":"Wisconsin Shamrock 2026"},{"displayName":"WYO_Jersey_2021_NUM_Array","path":"content/characters/player/parts/uniforms/jerseys/numbers/WYO_Jersey_2021_NUM_Array","label":"Wyoming (Current Home)"}],"helmetDedicated":[{"displayName":"ALA_Helmet_2021_NUM_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/numbers/ALA_Helmet_2021_NUM_Array","label":"Alabama (2021, Helmet)"},{"displayName":"FAU_Helmet_2023_NUM_Array","path":"content/characters/player/parts/uniforms/comp/helmets/numbers/FAU_Helmet_2023_NUM_Array","label":"Florida Atlantic (2023, Helmet)"},{"displayName":"FAU_Helmet_2025_NUM_Array","path":"content/characters/player/parts/uniforms/comp/helmets/numbers/FAU_Helmet_2025_NUM_Array","label":"Florida Atlantic (2025, Helmet)"},{"displayName":"GASO_Helmet_2025_NUM_Array","path":"content/characters/player/parts/uniforms/comp/helmets/numbers/GASO_Helmet_2025_NUM_Array","label":"Georgia Southern (2025, Helmet)"},{"displayName":"MINN_Helmet_2024_NUM_Array","path":"content/characters/player/parts/uniforms/comp/helmets/numbers/MINN_Helmet_2024_NUM_Array","label":"Minnesota (2024, Helmet)"},{"displayName":"NMSU_Helmet_2021_NUM_Array","path":"content/characters/player/parts/uniforms/comp/jerseys/numbers/NMSU_Helmet_2021_NUM_Array","label":"New Mexico State (2021, Helmet)"},{"displayName":"MISS_Helmet_2023_NUM_Array","path":"content/characters/player/parts/uniforms/comp/helmets/numbers/MISS_Helmet_2023_NUM_Array","label":"Ole Miss (2023, Helmet)"},{"displayName":"TEX_Helmet_2023_NUM_Array","path":"content/characters/player/parts/uniforms/comp/helmets/numbers/TEX_Helmet_2023_NUM_Array","label":"Texas (2023, Helmet)"}],"alts":[]},"helmetMaterials":{"shell":[{"displayName":"AFA_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2021_BLUE_preset","label":"Air Force (2021, BLUE)"},{"displayName":"AFA_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2021_WHITE_preset","label":"Air Force (2021, White)"},{"displayName":"AFA_HELMET_2024_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2024_BLACK_preset","label":"Air Force (2024, Black)"},{"displayName":"AFA_HELMET_2025_ALT_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2025_ALT_preset","label":"Air Force (2025, ALT)"},{"displayName":"AKR_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AKR_HELMET_2021_GOLD_preset","label":"Akron (2021, GOLD)"},{"displayName":"AKR_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AKR_HELMET_2021_WHITE_preset","label":"Akron (2021, White)"},{"displayName":"ALA_HELMET_2021_CRIMSON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ALA_HELMET_2021_CRIMSON_preset","label":"Alabama (2021, Crimson)"},{"displayName":"APP_HELMET_2016_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2016_BLACK_preset","label":"Appalachian State (2016, Black)"},{"displayName":"APP_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2021_BLACK_preset","label":"Appalachian State (2021, Black)"},{"displayName":"APP_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2021_WHITE_preset","label":"Appalachian State (2021, White)"},{"displayName":"APP_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2021_YELLOW_preset","label":"Appalachian State (2021, Yellow)"},{"displayName":"ARIZ_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARIZ_HELMET_2021_RED_preset","label":"Arizona (2021, RED)"},{"displayName":"ARIZ_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARIZ_HELMET_2021_WHITE_preset","label":"Arizona (2021, White)"},{"displayName":"ASU_HELMET_2014_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2014_YELLOW_preset","label":"Arizona State (2014, Yellow)"},{"displayName":"ASU_HELMET_2021_MAROON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2021_MAROON_preset","label":"Arizona State (2021, Maroon)"},{"displayName":"ASU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2021_WHITE_preset","label":"Arizona State (2021, White)"},{"displayName":"ASU_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2021_YELLOW_preset","label":"Arizona State (2021, Yellow)"},{"displayName":"ASU_HELMET_2022_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2022_YELLOW_preset","label":"Arizona State (2022, Yellow)"},{"displayName":"ARK_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARK_HELMET_2021_RED_preset","label":"Arkansas (2021, RED)"},{"displayName":"ARK_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARK_HELMET_2021_WHITE_preset","label":"Arkansas (2021, White)"},{"displayName":"ARST_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARST_HELMET_2021_WHITE_preset","label":"Arkansas State (2021, White)"},{"displayName":"ARST_HELMET_2023_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARST_HELMET_2023_BLACK_preset","label":"Arkansas State (2023, Black)"},{"displayName":"ARMY_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARMY_HELMET_2021_BLACK_preset","label":"Army (2021, Black)"},{"displayName":"ARMY_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARMY_HELMET_2021_GOLD_preset","label":"Army (2021, GOLD)"},{"displayName":"ARMY_HELMET_2025_AN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARMY_HELMET_2025_AN_preset","label":"Army (2025, AN)"},{"displayName":"AUB_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AUB_HELMET_2021_WHITE_preset","label":"Auburn (2021, White)"},{"displayName":"BYU_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2021_BLUE_preset","label":"BYU (2021, BLUE)"},{"displayName":"BYU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2021_WHITE_preset","label":"BYU (2021, White)"},{"displayName":"BYU_HELMET_2022_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2022_BLACK_preset","label":"BYU (2022, Black)"},{"displayName":"BYU_HELMET_2022_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2022_NAVY_preset","label":"BYU (2022, NAVY)"},{"displayName":"BYU_HELMET_2022_NAVYSATIN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2022_NAVYSATIN_preset","label":"BYU (2022, Navysatin)"},{"displayName":"BYU_HELMET_2022_WHITENAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2022_WHITENAVY_preset","label":"BYU (2022, Whitenavy)"},{"displayName":"BALL_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BALL_HELMET_2021_BLACK_preset","label":"Ball State (2021, Black)"},{"displayName":"BALL_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BALL_HELMET_2021_WHITE_preset","label":"Ball State (2021, White)"},{"displayName":"BAY_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_BLACK_preset","label":"Baylor (2021, Black)"},{"displayName":"BAY_HELMET_2021_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_GREEN_preset","label":"Baylor (2021, Green)"},{"displayName":"BAY_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_WHITE_preset","label":"Baylor (2021, White)"},{"displayName":"BAY_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_YELLOW_preset","label":"Baylor (2021, Yellow)"},{"displayName":"BSU_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_BLUE_preset","label":"Boise State (2021, BLUE)"},{"displayName":"BSU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_BLACK_preset","label":"Boise State (2021, Black)"},{"displayName":"BSU_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_ORANGE_preset","label":"Boise State (2021, Orange)"},{"displayName":"BSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_WHITE_preset","label":"Boise State (2021, White)"},{"displayName":"BSU_HELMET_2025_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2025_BLUE_preset","label":"Boise State (2025, BLUE)"},{"displayName":"BC_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BC_HELMET_2021_GOLD_preset","label":"Boston College (2021, GOLD)"},{"displayName":"BGSU_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BGSU_HELMET_2021_ORANGE_preset","label":"Bowling Green (2021, Orange)"},{"displayName":"BGSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BGSU_HELMET_2021_WHITE_preset","label":"Bowling Green (2021, White)"},{"displayName":"BUFF_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BUFF_HELMET_2021_BLUE_preset","label":"Buffalo (2021, BLUE)"},{"displayName":"BUFF_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BUFF_HELMET_2021_BLACK_preset","label":"Buffalo (2021, Black)"},{"displayName":"BUFF_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BUFF_HELMET_2021_WHITE_preset","label":"Buffalo (2021, White)"},{"displayName":"CAL_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CAL_HELMET_2021_YELLOW_preset","label":"California (2021, Yellow)"},{"displayName":"CAL_HELMET_2022_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CAL_HELMET_2022_YELLOW_preset","label":"California (2022, Yellow)"},{"displayName":"CAL_HELMET_2023_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CAL_HELMET_2023_NAVY_preset","label":"California (2023, NAVY)"},{"displayName":"CMU_HELMET_2021_MAROON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CMU_HELMET_2021_MAROON_preset","label":"Central Michigan (2021, Maroon)"},{"displayName":"CMU_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CMU_HELMET_2021_YELLOW_preset","label":"Central Michigan (2021, Yellow)"},{"displayName":"CHAR_HELMET_2021_CHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_CHROME_preset","label":"Charlotte (2021, Chrome)"},{"displayName":"CHAR_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_GOLD_preset","label":"Charlotte (2021, GOLD)"},{"displayName":"CHAR_HELMET_2021_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_GREEN_preset","label":"Charlotte (2021, Green)"},{"displayName":"CHAR_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_WHITE_preset","label":"Charlotte (2021, White)"},{"displayName":"CHAR_HELMET_2025_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2025_WHITE_preset","label":"Charlotte (2025, White)"},{"displayName":"CIN_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CIN_HELMET_2021_BLACK_preset","label":"Cincinnati (2021, Black)"},{"displayName":"CIN_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CIN_HELMET_2021_RED_preset","label":"Cincinnati (2021, RED)"},{"displayName":"CIN_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CIN_HELMET_2021_WHITE_preset","label":"Cincinnati (2021, White)"},{"displayName":"CLEM_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CLEM_HELMET_2021_ORANGE_preset","label":"Clemson (2021, Orange)"},{"displayName":"CCAR_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CCAR_HELMET_2021_BLACK_preset","label":"Coastal Carolina (2021, Black)"},{"displayName":"CCAR_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CCAR_HELMET_2021_WHITE_preset","label":"Coastal Carolina (2021, White)"},{"displayName":"CCAR_HELMET_2022_TEAL_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CCAR_HELMET_2022_TEAL_preset","label":"Coastal Carolina (2022, TEAL)"},{"displayName":"COLO_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2021_BLACK_preset","label":"Colorado (2021, Black)"},{"displayName":"COLO_HELMET_2021_BLACK2_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2021_BLACK2_preset","label":"Colorado (2021, Black2)"},{"displayName":"COLO_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2021_GOLD_preset","label":"Colorado (2021, GOLD)"},{"displayName":"COLO_HELMET_2023_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2023_WHITE_preset","label":"Colorado (2023, White)"},{"displayName":"CSU_HELMET_2021_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CSU_HELMET_2021_GREEN_preset","label":"Colorado State (2021, Green)"},{"displayName":"CSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CSU_HELMET_2021_WHITE_preset","label":"Colorado State (2021, White)"},{"displayName":"DEL_HELMET_2024_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DEL_HELMET_2024_BLUE_preset","label":"Delaware (2024, BLUE)"},{"displayName":"DUKE_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2021_BLUE_preset","label":"Duke (2021, BLUE)"},{"displayName":"DUKE_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2021_BLACK_preset","label":"Duke (2021, Black)"},{"displayName":"DUKE_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2021_WHITE_preset","label":"Duke (2021, White)"},{"displayName":"ECU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2021_BLACK_preset","label":"East Carolina (2021, Black)"},{"displayName":"ECU_HELMET_2021_PURPLEPURPLE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2021_PURPLEPURPLE_preset","label":"East Carolina (2021, Purplepurple)"},{"displayName":"ECU_HELMET_2021_PURPLEYELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2021_PURPLEYELLOW_preset","label":"East Carolina (2021, Purpleyellow)"},{"displayName":"ECU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2021_WHITE_preset","label":"East Carolina (2021, White)"},{"displayName":"EMU_HELMET_2021_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/EMU_HELMET_2021_GREEN_preset","label":"Eastern Michigan (2021, Green)"},{"displayName":"EMU_HELMET_2021_SILVER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/EMU_HELMET_2021_SILVER_preset","label":"Eastern Michigan (2021, Silver)"},{"displayName":"FLA_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_BLUE_preset","label":"Florida (2021, BLUE)"},{"displayName":"FLA_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_ORANGE_preset","label":"Florida (2021, Orange)"},{"displayName":"FLA_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_WHITE_preset","label":"Florida (2021, White)"},{"displayName":"FLA_HELMET_2023_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2023_BLACK_preset","label":"Florida (2023, Black)"},{"displayName":"FAU_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2021_BLUE_preset","label":"Florida Atlantic (2021, BLUE)"},{"displayName":"FAU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2021_BLACK_preset","label":"Florida Atlantic (2021, Black)"},{"displayName":"FAU_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2021_RED_preset","label":"Florida Atlantic (2021, RED)"},{"displayName":"FAU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2021_WHITE_preset","label":"Florida Atlantic (2021, White)"},{"displayName":"FAU_HELMET_2023_WHITEALT_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2023_WHITEALT_preset","label":"Florida Atlantic (2023, Whitealt)"},{"displayName":"FAU_HELMET_2025_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2025_BLUE_preset","label":"Florida Atlantic (2025, BLUE)"},{"displayName":"FIU_HELMET_2021_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2021_NAVY_preset","label":"Florida International (2021, NAVY)"},{"displayName":"FIU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2021_WHITE_preset","label":"Florida International (2021, White)"},{"displayName":"FIU_HELMET_2024_MIAMI_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2024_MIAMI_preset","label":"Florida International (2024, Miami)"},{"displayName":"FIU_HELMET_2025_ViceCity_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2025_ViceCity_preset","label":"Florida International (2025, Vicecity)"},{"displayName":"FSU_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FSU_HELMET_2021_GOLD_preset","label":"Florida State (2021, GOLD)"},{"displayName":"FSU_HELMET_2023_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FSU_HELMET_2023_WHITE_preset","label":"Florida State (2023, White)"},{"displayName":"FRES_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FRES_HELMET_2021_BLACK_preset","label":"Fresno State (2021, Black)"},{"displayName":"FRES_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FRES_HELMET_2021_RED_preset","label":"Fresno State (2021, RED)"},{"displayName":"FRES_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FRES_HELMET_2021_WHITE_preset","label":"Fresno State (2021, White)"},{"displayName":"UGA_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UGA_HELMET_2021_RED_preset","label":"Georgia (2021, RED)"},{"displayName":"GASO_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GASO_HELMET_2021_BLUE_preset","label":"Georgia Southern (2021, BLUE)"},{"displayName":"GASO_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GASO_HELMET_2021_WHITE_preset","label":"Georgia Southern (2021, White)"},{"displayName":"GASO_HELMET_2025_TACKLINGFORCURE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GASO_HELMET_2025_TACKLINGFORCURE_preset","label":"Georgia Southern (2025, Tacklingforcure)"},{"displayName":"GSU_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GSU_HELMET_2021_BLUE_preset","label":"Georgia State (2021, BLUE)"},{"displayName":"GSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GSU_HELMET_2021_WHITE_preset","label":"Georgia State (2021, White)"},{"displayName":"GT_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GT_HELMET_2021_GOLD_preset","label":"Georgia Tech (2021, GOLD)"},{"displayName":"GT_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GT_HELMET_2021_WHITE_preset","label":"Georgia Tech (2021, White)"},{"displayName":"HAW_HELMET_2021_BLACK_02_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_BLACK_02_preset","label":"Hawaii (2021, Black 02)"},{"displayName":"HAW_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_BLACK_preset","label":"Hawaii (2021, Black)"},{"displayName":"HAW_HELMET_2021_WHITE_02_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_WHITE_02_preset","label":"Hawaii (2021, White 02)"},{"displayName":"HAW_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_WHITE_preset","label":"Hawaii (2021, White)"},{"displayName":"HOU_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HOU_HELMET_2021_RED_preset","label":"Houston (2021, RED)"},{"displayName":"HOU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HOU_HELMET_2021_WHITE_preset","label":"Houston (2021, White)"},{"displayName":"HOU_HELMET_2021_WHITEBLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HOU_HELMET_2021_WHITEBLACK_preset","label":"Houston (2021, Whiteblack)"},{"displayName":"ILL_HELMET_2021_LEATHER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ILL_HELMET_2021_LEATHER_preset","label":"Illinois (2021, Leather)"},{"displayName":"ILL_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ILL_HELMET_2021_ORANGE_preset","label":"Illinois (2021, Orange)"},{"displayName":"IND_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/IND_HELMET_2021_RED_preset","label":"Indiana (2021, RED)"},{"displayName":"IOWA_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/IOWA_HELMET_2021_BLACK_preset","label":"Iowa (2021, Black)"},{"displayName":"ISU_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ISU_HELMET_2021_RED_preset","label":"Iowa State (2021, RED)"},{"displayName":"ISU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ISU_HELMET_2021_WHITE_preset","label":"Iowa State (2021, White)"},{"displayName":"ISU_HELMET_2022_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ISU_HELMET_2022_BLACK_preset","label":"Iowa State (2022, Black)"},{"displayName":"JVST_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JVST_HELMET_2021_RED_preset","label":"Jacksonville State (2021, RED)"},{"displayName":"JVST_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JVST_HELMET_2021_WHITE_preset","label":"Jacksonville State (2021, White)"},{"displayName":"JMU_HELMET_2023_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JMU_HELMET_2023_GOLD_preset","label":"James Madison (2023, GOLD)"},{"displayName":"JMU_HELMET_2023_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JMU_HELMET_2023_WHITE_preset","label":"James Madison (2023, White)"},{"displayName":"KU_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_BLUE_preset","label":"Kansas (2021, BLUE)"},{"displayName":"KU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_BLACK_preset","label":"Kansas (2021, Black)"},{"displayName":"KU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_WHITE_preset","label":"Kansas (2021, White)"},{"displayName":"KU_HELMET_2025_Blue_Alt_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2025_Blue_Alt_preset","label":"Kansas (2025, Blue Alt)"},{"displayName":"KSU_HELMET_2021_SILVER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KSU_HELMET_2021_SILVER_preset","label":"Kansas State (2021, Silver)"},{"displayName":"KSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KSU_HELMET_2021_WHITE_preset","label":"Kansas State (2021, White)"},{"displayName":"KENN_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENN_HELMET_2021_BLACK_preset","label":"Kennesaw State (2021, Black)"},{"displayName":"KENN_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENN_HELMET_2021_YELLOW_preset","label":"Kennesaw State (2021, Yellow)"},{"displayName":"KENT_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2021_BLACK_preset","label":"Kent State (2021, Black)"},{"displayName":"KENT_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2021_GOLD_preset","label":"Kent State (2021, GOLD)"},{"displayName":"KENT_HELMET_2023_Navy_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2023_Navy_preset","label":"Kent State (2023, Navy)"},{"displayName":"UK_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2021_BLUE_preset","label":"Kentucky (2021, BLUE)"},{"displayName":"UK_HELMET_2022_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2022_BLACK_preset","label":"Kentucky (2022, Black)"},{"displayName":"UK_HELMET_2022_CHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2022_CHROME_preset","label":"Kentucky (2022, Chrome)"},{"displayName":"UK_HELMET_2022_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2022_WHITE_preset","label":"Kentucky (2022, White)"},{"displayName":"LSU_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LSU_HELMET_2021_GOLD_preset","label":"LSU (2021, GOLD)"},{"displayName":"LSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LSU_HELMET_2021_WHITE_preset","label":"LSU (2021, White)"},{"displayName":"LIB_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LIB_HELMET_2021_BLUE_preset","label":"Liberty (2021, BLUE)"},{"displayName":"LIB_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LIB_HELMET_2021_RED_preset","label":"Liberty (2021, RED)"},{"displayName":"LIB_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LIB_HELMET_2021_WHITE_preset","label":"Liberty (2021, White)"},{"displayName":"ULL_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULL_HELMET_2021_RED_preset","label":"Louisiana (2021, RED)"},{"displayName":"ULL_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULL_HELMET_2021_WHITE_preset","label":"Louisiana (2021, White)"},{"displayName":"LT_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LT_HELMET_2021_RED_preset","label":"Louisiana Tech (2021, RED)"},{"displayName":"LT_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LT_HELMET_2021_WHITE_preset","label":"Louisiana Tech (2021, White)"},{"displayName":"ULM_HELMET_2016_CAMO_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULM_HELMET_2016_CAMO_preset","label":"Louisiana-Monroe (2016, CAMO)"},{"displayName":"ULM_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULM_HELMET_2021_WHITE_preset","label":"Louisiana-Monroe (2021, White)"},{"displayName":"ULM_HELMET_2025_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULM_HELMET_2025_BLACK_preset","label":"Louisiana-Monroe (2025, Black)"},{"displayName":"LOU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LOU_HELMET_2021_BLACK_preset","label":"Louisville (2021, Black)"},{"displayName":"LOU_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LOU_HELMET_2021_RED_preset","label":"Louisville (2021, RED)"},{"displayName":"LOU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LOU_HELMET_2021_WHITE_preset","label":"Louisville (2021, White)"},{"displayName":"MRSH_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MRSH_HELMET_2021_WHITE_preset","label":"Marshall (2021, White)"},{"displayName":"MRSH_HELMET_2025_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MRSH_HELMET_2025_GREEN_preset","label":"Marshall (2025, Green)"},{"displayName":"UMD_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMD_HELMET_2021_BLACK_preset","label":"Maryland (2021, Black)"},{"displayName":"UMD_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMD_HELMET_2021_RED_preset","label":"Maryland (2021, RED)"},{"displayName":"UMD_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMD_HELMET_2021_WHITE_preset","label":"Maryland (2021, White)"},{"displayName":"MEM_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2021_BLUE_preset","label":"Memphis (2021, BLUE)"},{"displayName":"MEM_HELMET_2021_GRAY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2021_GRAY_preset","label":"Memphis (2021, GRAY)"},{"displayName":"MEM_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2021_WHITE_preset","label":"Memphis (2021, White)"},{"displayName":"MEM_HELMET_2022_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2022_WHITE_preset","label":"Memphis (2022, White)"},{"displayName":"MEM_HELMET_2022_WHITEBLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2022_WHITEBLACK_preset","label":"Memphis (2022, Whiteblack)"},{"displayName":"MIA_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIA_HELMET_2021_WHITE_preset","label":"Miami (FL) (2021, White)"},{"displayName":"MIA_HELMET_2025_CAMO_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIA_HELMET_2025_CAMO_preset","label":"Miami (FL) (2025, CAMO)"},{"displayName":"MIAOH_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIAOH_HELMET_2021_RED_preset","label":"Miami (OH) (2021, RED)"},{"displayName":"MIAOH_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIAOH_HELMET_2021_WHITE_preset","label":"Miami (OH) (2021, White)"},{"displayName":"MICH_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MICH_HELMET_2021_BLUE_preset","label":"Michigan (2021, BLUE)"},{"displayName":"MSU_HELMET_2015_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2015_GREEN_preset","label":"Michigan State (2015, Green)"},{"displayName":"MSU_HELMET_2017_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2017_WHITE_preset","label":"Michigan State (2017, White)"},{"displayName":"MSU_HELMET_2021_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2021_GREEN_preset","label":"Michigan State (2021, Green)"},{"displayName":"MSU_HELMET_2023_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2023_BLACK_preset","label":"Michigan State (2023, Black)"},{"displayName":"MTSU_HELMET_2021_GREY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTSU_HELMET_2021_GREY_preset","label":"Middle Tennessee (2021, GREY)"},{"displayName":"MTSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTSU_HELMET_2021_WHITE_preset","label":"Middle Tennessee (2021, White)"},{"displayName":"MINN_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2021_RED_preset","label":"Minnesota (2021, RED)"},{"displayName":"MINN_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2021_YELLOW_preset","label":"Minnesota (2021, Yellow)"},{"displayName":"MINN_HELMET_2022_CHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2022_CHROME_preset","label":"Minnesota (2022, Chrome)"},{"displayName":"MINN_HELMET_2022_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2022_WHITE_preset","label":"Minnesota (2022, White)"},{"displayName":"MINN_HELMET_2023_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2023_BLACK_preset","label":"Minnesota (2023, Black)"},{"displayName":"MSST_HELMET_2021_MAROON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSST_HELMET_2021_MAROON_preset","label":"Mississippi State (2021, Maroon)"},{"displayName":"MSST_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSST_HELMET_2021_WHITE_preset","label":"Mississippi State (2021, White)"},{"displayName":"MSST_HELMET_2025_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSST_HELMET_2025_BLACK_preset","label":"Mississippi State (2025, Black)"},{"displayName":"MIZZ_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIZZ_HELMET_2021_BLACK_preset","label":"Missouri (2021, Black)"},{"displayName":"MIZZ_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIZZ_HELMET_2021_YELLOW_preset","label":"Missouri (2021, Yellow)"},{"displayName":"MIZZ_HELMET_2023_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIZZ_HELMET_2023_WHITE_preset","label":"Missouri (2023, White)"},{"displayName":"MIST_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIST_HELMET_2021_BLACK_preset","label":"Missouri State (2021, Black)"},{"displayName":"MTDEW_HELMET_2025_Alt_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTDEW_HELMET_2025_Alt_preset","label":"Mountain Dew (non-school / branded) (2025, Alt)"},{"displayName":"MTDEW_HELMET_2025_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTDEW_HELMET_2025_GREEN_preset","label":"Mountain Dew (non-school / branded) (2025, Green)"},{"displayName":"MTDEW_HELMET_2025_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTDEW_HELMET_2025_WHITE_preset","label":"Mountain Dew (non-school / branded) (2025, White)"},{"displayName":"NCST_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NCST_HELMET_2021_BLACK_preset","label":"NC State (2021, Black)"},{"displayName":"NCST_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NCST_HELMET_2021_RED_preset","label":"NC State (2021, RED)"},{"displayName":"NCST_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NCST_HELMET_2021_WHITE_preset","label":"NC State (2021, White)"},{"displayName":"NAVY_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NAVY_HELMET_2021_GOLD_preset","label":"Navy (2021, GOLD)"},{"displayName":"NAVY_HELMET_2021_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NAVY_HELMET_2021_NAVY_preset","label":"Navy (2021, NAVY)"},{"displayName":"NAVY_HELMET_2025_AN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NAVY_HELMET_2025_AN_preset","label":"Navy (2025, AN)"},{"displayName":"NEB_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEB_HELMET_2021_WHITE_preset","label":"Nebraska (2021, White)"},{"displayName":"NEV_HELMET_2021_SILVER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEV_HELMET_2021_SILVER_preset","label":"Nevada (2021, Silver)"},{"displayName":"NEV_Helmet_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEV_Helmet_2021_WHITE_preset","label":"Nevada (2021, White)"},{"displayName":"NEV_HELMET_2023_NAVYBLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEV_HELMET_2023_NAVYBLUE_preset","label":"Nevada (2023, Navyblue)"},{"displayName":"UNM_HELMET_2021_GRAY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_GRAY_preset","label":"New Mexico (2021, GRAY)"},{"displayName":"UNM_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_RED_preset","label":"New Mexico (2021, RED)"},{"displayName":"UNM_HELMET_2021_SILVER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_SILVER_preset","label":"New Mexico (2021, Silver)"},{"displayName":"UNM_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_WHITE_preset","label":"New Mexico (2021, White)"},{"displayName":"UNM_HELMET_2023_SILVER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2023_SILVER_preset","label":"New Mexico (2023, Silver)"},{"displayName":"NMSU_HELMET_2021_CRIMSON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NMSU_HELMET_2021_CRIMSON_preset","label":"New Mexico State (2021, Crimson)"},{"displayName":"NMSU_HELMET_2023_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NMSU_HELMET_2023_WHITE_preset","label":"New Mexico State (2023, White)"},{"displayName":"UNC_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNC_HELMET_2021_BLUE_preset","label":"North Carolina (2021, BLUE)"},{"displayName":"UNC_HELMET_2021_CHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNC_HELMET_2021_CHROME_preset","label":"North Carolina (2021, Chrome)"},{"displayName":"UNC_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNC_HELMET_2021_WHITE_preset","label":"North Carolina (2021, White)"},{"displayName":"UNT_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_BLACK_preset","label":"North Texas (2021, Black)"},{"displayName":"UNT_HELMET_2021_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_GREEN_preset","label":"North Texas (2021, Green)"},{"displayName":"UNT_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_WHITE_preset","label":"North Texas (2021, White)"},{"displayName":"NIU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NIU_HELMET_2021_BLACK_preset","label":"Northern Illinois (2021, Black)"},{"displayName":"NW_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2021_BLACK_preset","label":"Northwestern (2021, Black)"},{"displayName":"NW_HELMET_2021_PURPLE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2021_PURPLE_preset","label":"Northwestern (2021, Purple)"},{"displayName":"NW_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2021_WHITE_preset","label":"Northwestern (2021, White)"},{"displayName":"NW_HELMET_2022_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2022_BLACK_preset","label":"Northwestern (2022, Black)"},{"displayName":"ND_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ND_HELMET_2021_GOLD_preset","label":"Notre Dame (2021, GOLD)"},{"displayName":"OHIO_HELMET_2023_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OHIO_HELMET_2023_GREEN_preset","label":"Ohio (2023, Green)"},{"displayName":"OHIO_HELMET_2023_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OHIO_HELMET_2023_WHITE_preset","label":"Ohio (2023, White)"},{"displayName":"OSU_Helmet_2021_Black_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OSU_Helmet_2021_Black_preset","label":"Ohio State (2021, Black)"},{"displayName":"OSU_Helmet_2021_Grey_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OSU_Helmet_2021_Grey_preset","label":"Ohio State (2021, GREY)"},{"displayName":"OU_Helmet_2021_CRIMSON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_Helmet_2021_CRIMSON_preset","label":"Oklahoma (2021, Crimson)"},{"displayName":"OU_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_RED_preset","label":"Oklahoma (2021, RED)"},{"displayName":"OU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_WHITE_preset","label":"Oklahoma (2021, White)"},{"displayName":"OU_Helmet_2021_WOODCREAM_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_Helmet_2021_WOODCREAM_preset","label":"Oklahoma (2021, Woodcream)"},{"displayName":"OU_HELMET_2021_WOODCRIMSON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_WOODCRIMSON_preset","label":"Oklahoma (2021, Woodcrimson)"},{"displayName":"OKST_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2021_BLACK_preset","label":"Oklahoma State (2021, Black)"},{"displayName":"OKST_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2021_ORANGE_preset","label":"Oklahoma State (2021, Orange)"},{"displayName":"OKST_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2021_WHITE_preset","label":"Oklahoma State (2021, White)"},{"displayName":"ODU_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ODU_HELMET_2021_BLUE_preset","label":"Old Dominion (2021, BLUE)"},{"displayName":"ODU_HELMET_2021_LIGHTBLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ODU_HELMET_2021_LIGHTBLUE_preset","label":"Old Dominion (2021, Lightblue)"},{"displayName":"ODU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ODU_HELMET_2021_WHITE_preset","label":"Old Dominion (2021, White)"},{"displayName":"ODU_HELMET_2024_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ODU_HELMET_2024_WHITE_preset","label":"Old Dominion (2024, White)"},{"displayName":"MISS_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_BLUE_preset","label":"Ole Miss (2021, BLUE)"},{"displayName":"MISS_HELMET_2021_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_NAVY_preset","label":"Ole Miss (2021, NAVY)"},{"displayName":"MISS_HELMET_2021_SPLATTER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_SPLATTER_preset","label":"Ole Miss (2021, Splatter)"},{"displayName":"MISS_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_WHITE_preset","label":"Ole Miss (2021, White)"},{"displayName":"ORE_HELMET_2021_WHITEGREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2021_WHITEGREEN_preset","label":"Oregon (2021, Whitegreen)"},{"displayName":"ORE_HELMET_2021_YELLOWSTEEL_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2021_YELLOWSTEEL_preset","label":"Oregon (2021, Yellowsteel)"},{"displayName":"ORE_HELMET_2023_BLACKCARBON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2023_BLACKCARBON_preset","label":"Oregon (2023, Blackcarbon)"},{"displayName":"ORE_HELMET_2023_CHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2023_CHROME_preset","label":"Oregon (2023, Chrome)"},{"displayName":"ORE_HELMET_2023_EGGSHELL_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2023_EGGSHELL_preset","label":"Oregon (2023, Eggshell)"},{"displayName":"ORE_HELMET_2023_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2023_GREEN_preset","label":"Oregon (2023, Green)"},{"displayName":"ORE_HELMET_2024_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2024_GREEN_preset","label":"Oregon (2024, Green)"},{"displayName":"ORE_HELMET_2024_THROWBACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2024_THROWBACK_preset","label":"Oregon (2024, Throwback)"},{"displayName":"ORST_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORST_HELMET_2021_BLACK_preset","label":"Oregon State (2021, Black)"},{"displayName":"ORST_HELMET_2023_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORST_HELMET_2023_ORANGE_preset","label":"Oregon State (2023, Orange)"},{"displayName":"PSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PSU_HELMET_2021_WHITE_preset","label":"Penn State (2021, White)"},{"displayName":"PSU_HELMET_2022_WHITESTRIPE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PSU_HELMET_2022_WHITESTRIPE_preset","label":"Penn State (2022, Whitestripe)"},{"displayName":"PITT_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PITT_HELMET_2021_YELLOW_preset","label":"Pittsburgh (2021, Yellow)"},{"displayName":"PITT_HELMET_2023_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PITT_HELMET_2023_WHITE_preset","label":"Pittsburgh (2023, White)"},{"displayName":"PUR_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2021_BLACK_preset","label":"Purdue (2021, Black)"},{"displayName":"PUR_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2021_GOLD_preset","label":"Purdue (2021, GOLD)"},{"displayName":"PUR_HELMET_2023_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2023_GOLD_preset","label":"Purdue (2023, GOLD)"},{"displayName":"RICE_HELMET_2021_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RICE_HELMET_2021_NAVY_preset","label":"Rice (2021, NAVY)"},{"displayName":"RICE_HELMET_2021_SILVER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RICE_HELMET_2021_SILVER_preset","label":"Rice (2021, Silver)"},{"displayName":"RUTG_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RUTG_HELMET_2021_RED_preset","label":"Rutgers (2021, RED)"},{"displayName":"SMU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SMU_HELMET_2021_BLACK_preset","label":"SMU (2021, Black)"},{"displayName":"SMU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SMU_HELMET_2021_WHITE_preset","label":"SMU (2021, White)"},{"displayName":"SMU_HELMET_2021_WHITEALT_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SMU_HELMET_2021_WHITEALT_preset","label":"SMU (2021, Whitealt)"},{"displayName":"SHSU_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SHSU_HELMET_2021_ORANGE_preset","label":"Sam Houston State (2021, Orange)"},{"displayName":"SHSU_HELMET_2023_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SHSU_HELMET_2023_ORANGE_preset","label":"Sam Houston State (2023, Orange)"},{"displayName":"SDSU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SDSU_HELMET_2021_BLACK_preset","label":"San Diego State (2021, Black)"},{"displayName":"SJSU_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SJSU_HELMET_2021_BLUE_preset","label":"San Jose State (2021, BLUE)"},{"displayName":"SJSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SJSU_HELMET_2021_WHITE_preset","label":"San Jose State (2021, White)"},{"displayName":"USA_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USA_HELMET_2021_WHITE_preset","label":"South Alabama (2021, White)"},{"displayName":"SC_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SC_HELMET_2021_BLACK_preset","label":"South Carolina (2021, Black)"},{"displayName":"SC_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SC_HELMET_2021_RED_preset","label":"South Carolina (2021, RED)"},{"displayName":"SC_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SC_HELMET_2021_WHITE_preset","label":"South Carolina (2021, White)"},{"displayName":"USF_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USF_HELMET_2021_GOLD_preset","label":"South Florida (2021, GOLD)"},{"displayName":"USF_HELMET_2021_WHITEGREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USF_HELMET_2021_WHITEGREEN_preset","label":"South Florida (2021, Whitegreen)"},{"displayName":"USF_HELMET_2024_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USF_HELMET_2024_BLACK_preset","label":"South Florida (2024, Black)"},{"displayName":"USM_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USM_HELMET_2021_BLACK_preset","label":"Southern Miss (2021, Black)"},{"displayName":"USM_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USM_HELMET_2021_WHITE_preset","label":"Southern Miss (2021, White)"},{"displayName":"STAN_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2021_WHITE_preset","label":"Stanford (2021, White)"},{"displayName":"STAN_HELMET_2021_WHITEBLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2021_WHITEBLACK_preset","label":"Stanford (2021, Whiteblack)"},{"displayName":"STAN_HELMET_2023_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2023_BLACK_preset","label":"Stanford (2023, Black)"},{"displayName":"STAN_HELMET_2023_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2023_RED_preset","label":"Stanford (2023, RED)"},{"displayName":"STAN_HELMET_2023_REDSCRIPT_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2023_REDSCRIPT_preset","label":"Stanford (2023, Redscript)"},{"displayName":"SYR_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SYR_HELMET_2021_ORANGE_preset","label":"Syracuse (2021, Orange)"},{"displayName":"SYR_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SYR_HELMET_2021_WHITE_preset","label":"Syracuse (2021, White)"},{"displayName":"TCU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TCU_HELMET_2021_BLACK_preset","label":"TCU (2021, Black)"},{"displayName":"TCU_HELMET_2021_PURPLE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TCU_HELMET_2021_PURPLE_preset","label":"TCU (2021, Purple)"},{"displayName":"TCU_HELMET_2023_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TCU_HELMET_2023_WHITE_preset","label":"TCU (2023, White)"},{"displayName":"TCU_HELMET_2024_CHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TCU_HELMET_2024_CHROME_preset","label":"TCU (2024, Chrome)"},{"displayName":"TEMP_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2021_RED_preset","label":"Temple (2021, RED) [TEMP]"},{"displayName":"TEM_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEM_HELMET_2021_RED_preset","label":"Temple (2021, RED) [TEM]"},{"displayName":"TEM_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEM_HELMET_2021_WHITE_preset","label":"Temple (2021, White)"},{"displayName":"TEMP_HELMET_2025_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2025_RED_preset","label":"Temple (2025, RED)"},{"displayName":"TEMP_HELMET_2025_WHI_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2025_WHI_preset","label":"Temple (2025, WHI)"},{"displayName":"TENN_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2021_ORANGE_preset","label":"Tennessee (2021, Orange)"},{"displayName":"TENN_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2021_WHITE_preset","label":"Tennessee (2021, White)"},{"displayName":"TENN_HELMET_2022_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2022_BLACK_preset","label":"Tennessee (2022, Black)"},{"displayName":"TENN_HELMET_2024_GRAY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2024_GRAY_preset","label":"Tennessee (2024, GRAY)"},{"displayName":"TENN_HELMET_2025_Smokey_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2025_Smokey_preset","label":"Tennessee (2025, Smokey)"},{"displayName":"TEX_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEX_HELMET_2021_WHITE_preset","label":"Texas (2021, White)"},{"displayName":"TAMU_HELMET_2021_MAROON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TAMU_HELMET_2021_MAROON_preset","label":"Texas A&M (2021, Maroon)"},{"displayName":"TAMU_HELMET_2023_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TAMU_HELMET_2023_BLACK_preset","label":"Texas A&M (2023, Black)"},{"displayName":"TXST_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TXST_HELMET_2021_GOLD_preset","label":"Texas State (2021, GOLD)"},{"displayName":"TXST_HELMET_2021_MAROON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TXST_HELMET_2021_MAROON_preset","label":"Texas State (2021, Maroon)"},{"displayName":"TXST_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TXST_HELMET_2021_WHITE_preset","label":"Texas State (2021, White)"},{"displayName":"TTU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2021_BLACK_preset","label":"Texas Tech (2021, Black)"},{"displayName":"TTU_HELMET_2021_GRAY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2021_GRAY_preset","label":"Texas Tech (2021, GRAY)"},{"displayName":"TTU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2021_WHITE_preset","label":"Texas Tech (2021, White)"},{"displayName":"TTU_HELMET_2025_WHIMAHOMES_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2025_WHIMAHOMES_preset","label":"Texas Tech (2025, Whimahomes)"},{"displayName":"TOL_HELMET_2021_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TOL_HELMET_2021_NAVY_preset","label":"Toledo (2021, NAVY)"},{"displayName":"TOL_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TOL_HELMET_2021_YELLOW_preset","label":"Toledo (2021, Yellow)"},{"displayName":"TOL_HELMET_2025_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TOL_HELMET_2025_WHITE_preset","label":"Toledo (2025, White)"},{"displayName":"TROY_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TROY_HELMET_2021_RED_preset","label":"Troy (2021, RED)"},{"displayName":"TROY_HELMET_2021_SILVER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TROY_HELMET_2021_SILVER_preset","label":"Troy (2021, Silver)"},{"displayName":"TROY_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TROY_HELMET_2021_WHITE_preset","label":"Troy (2021, White)"},{"displayName":"TULN_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2021_BLUE_preset","label":"Tulane (2021, BLUE)"},{"displayName":"TULN_HELMET_2021_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2021_GREEN_preset","label":"Tulane (2021, Green)"},{"displayName":"TULN_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2021_WHITE_preset","label":"Tulane (2021, White)"},{"displayName":"TULN_HELMET_2025_CITY_EDITION_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2025_CITY_EDITION_preset","label":"Tulane (2025, CITY Edition)"},{"displayName":"TULN_HELMET_2025_Wumbu_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2025_Wumbu_preset","label":"Tulane (2025, Wumbu)"},{"displayName":"TLSA_HELMET_2023_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TLSA_HELMET_2023_GOLD_preset","label":"Tulsa (2023, GOLD)"},{"displayName":"TLSA_HELMET_2023_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TLSA_HELMET_2023_WHITE_preset","label":"Tulsa (2023, White)"},{"displayName":"UAB_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UAB_HELMET_2021_GOLD_preset","label":"UAB (2021, GOLD)"},{"displayName":"UAB_HELMET_2021_GREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UAB_HELMET_2021_GREEN_preset","label":"UAB (2021, Green)"},{"displayName":"UAB_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UAB_HELMET_2021_WHITE_preset","label":"UAB (2021, White)"},{"displayName":"UAB_HELMET_2021_WHITELIMEGREEN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UAB_HELMET_2021_WHITELIMEGREEN_preset","label":"UAB (2021, Whitelimegreen)"},{"displayName":"UCF_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2021_GOLD_preset","label":"UCF (2021, GOLD)"},{"displayName":"UCF_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2021_WHITE_preset","label":"UCF (2021, White)"},{"displayName":"UCF_HELMET_2023_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2023_BLACK_preset","label":"UCF (2023, Black)"},{"displayName":"UCF_HELMET_2023_SPACE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2023_SPACE_preset","label":"UCF (2023, Space)"},{"displayName":"UCF_HELMET_2024_SPACE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2024_SPACE_preset","label":"UCF (2024, Space)"},{"displayName":"UCF_HELMET_2025_SPACE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2025_SPACE_preset","label":"UCF (2025, Space)"},{"displayName":"UCLA_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCLA_HELMET_2021_GOLD_preset","label":"UCLA (2021, GOLD)"},{"displayName":"UCLA_HELMET_2023_GOLDALT_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCLA_HELMET_2023_GOLDALT_preset","label":"UCLA (2023, Goldalt)"},{"displayName":"CONN_HELMET_2021_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CONN_HELMET_2021_NAVY_preset","label":"UConn (2021, NAVY)"},{"displayName":"CONN_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CONN_HELMET_2021_WHITE_preset","label":"UConn (2021, White)"},{"displayName":"CONN_HELMET_2025_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CONN_HELMET_2025_NAVY_preset","label":"UConn (2025, NAVY)"},{"displayName":"UMASS_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMASS_HELMET_2021_RED_preset","label":"UMass (2021, RED)"},{"displayName":"UMASS_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMASS_HELMET_2021_WHITE_preset","label":"UMass (2021, White)"},{"displayName":"UNLV_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2021_BLACK_preset","label":"UNLV (2021, Black)"},{"displayName":"UNLV_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2021_RED_preset","label":"UNLV (2021, RED)"},{"displayName":"UNLV_HELMET_2021_SILVER_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2021_SILVER_preset","label":"UNLV (2021, Silver)"},{"displayName":"UNLV_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2021_WHITE_preset","label":"UNLV (2021, White)"},{"displayName":"USC_HELMET_2021_CARDINAL_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USC_HELMET_2021_CARDINAL_preset","label":"USC (2021, Cardinal)"},{"displayName":"USC_HELMET_2021_CARDINALCHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USC_HELMET_2021_CARDINALCHROME_preset","label":"USC (2021, Cardinalchrome)"},{"displayName":"UTEP_HELMET_2021_ORANGE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTEP_HELMET_2021_ORANGE_preset","label":"UTEP (2021, Orange)"},{"displayName":"UTEP_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTEP_HELMET_2021_WHITE_preset","label":"UTEP (2021, White)"},{"displayName":"UTEP_HELMET_2025_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTEP_HELMET_2025_BLUE_preset","label":"UTEP (2025, BLUE)"},{"displayName":"UTSA_HELMET_2021_NAVY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTSA_HELMET_2021_NAVY_preset","label":"UTSA (2021, NAVY)"},{"displayName":"UTSA_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTSA_HELMET_2021_WHITE_preset","label":"UTSA (2021, White)"},{"displayName":"UTAH_HELMET_2020_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2020_WHITE_preset","label":"Utah (2020, White)"},{"displayName":"UTAH_HELMET_2021_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2021_RED_preset","label":"Utah (2021, RED)"},{"displayName":"UTAH_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2021_WHITE_preset","label":"Utah (2021, White)"},{"displayName":"UTAH_HELMET_2023_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2023_BLACK_preset","label":"Utah (2023, Black)"},{"displayName":"UTAH_HELMET_2025_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2025_RED_preset","label":"Utah (2025, RED)"},{"displayName":"USU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USU_HELMET_2021_BLACK_preset","label":"Utah State (2021, Black)"},{"displayName":"USU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USU_HELMET_2021_WHITE_preset","label":"Utah State (2021, White)"},{"displayName":"VAN_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VAN_HELMET_2021_GOLD_preset","label":"Vanderbilt (2021, GOLD)"},{"displayName":"VAN_HELMET_2022_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VAN_HELMET_2022_BLACK_preset","label":"Vanderbilt (2022, Black)"},{"displayName":"VAN_HELMET_2022_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VAN_HELMET_2022_WHITE_preset","label":"Vanderbilt (2022, White)"},{"displayName":"UVA_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UVA_HELMET_2021_BLUE_preset","label":"Virginia (2021, BLUE)"},{"displayName":"UVA_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UVA_HELMET_2021_WHITE_preset","label":"Virginia (2021, White)"},{"displayName":"VT_HELMET_2016_MAROON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2016_MAROON_preset","label":"Virginia Tech (2016, Maroon)"},{"displayName":"VT_HELMET_2016_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2016_WHITE_preset","label":"Virginia Tech (2016, White)"},{"displayName":"VT_HELMET_2021_MAROON_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2021_MAROON_preset","label":"Virginia Tech (2021, Maroon)"},{"displayName":"VT_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2021_WHITE_preset","label":"Virginia Tech (2021, White)"},{"displayName":"WAKE_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WAKE_HELMET_2021_BLACK_preset","label":"Wake Forest (2021, Black)"},{"displayName":"WAKE_HELMET_2022_CHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WAKE_HELMET_2022_CHROME_preset","label":"Wake Forest (2022, Chrome)"},{"displayName":"WASH_HELMET_2021_GOLD_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2021_GOLD_preset","label":"Washington (2021, GOLD)"},{"displayName":"WASH_HELMET_2021_GOLDCHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2021_GOLDCHROME_preset","label":"Washington (2021, Goldchrome)"},{"displayName":"WASH_HELMET_2023_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2023_BLACK_preset","label":"Washington (2023, Black)"},{"displayName":"WASH_HELMET_2023_PURPLECHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2023_PURPLECHROME_preset","label":"Washington (2023, Purplechrome)"},{"displayName":"WSU_HELMET_2021_DARKGRAY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WSU_HELMET_2021_DARKGRAY_preset","label":"Washington State (2021, Darkgray)"},{"displayName":"WSU_HELMET_2021_GRAY_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WSU_HELMET_2021_GRAY_preset","label":"Washington State (2021, GRAY)"},{"displayName":"WSU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WSU_HELMET_2021_WHITE_preset","label":"Washington State (2021, White)"},{"displayName":"WSU_HELMET_2022_RED_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WSU_HELMET_2022_RED_preset","label":"Washington State (2022, RED)"},{"displayName":"WVU_HELMET_2021_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2021_BLUE_preset","label":"West Virginia (2021, BLUE)"},{"displayName":"WVU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2021_BLACK_preset","label":"West Virginia (2021, Black)"},{"displayName":"WVU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2021_WHITE_preset","label":"West Virginia (2021, White)"},{"displayName":"WVU_HELMET_2021_YELLOW_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2021_YELLOW_preset","label":"West Virginia (2021, Yellow)"},{"displayName":"WVU_HELMET_2025_BLUE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2025_BLUE_preset","label":"West Virginia (2025, BLUE)"},{"displayName":"WKU_HELMET_2021_BLACK_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2021_BLACK_preset","label":"Western Kentucky (2021, Black)"},{"displayName":"WKU_HELMET_2021_CHROME_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2021_CHROME_preset","label":"Western Kentucky (2021, Chrome)"},{"displayName":"WKU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2021_WHITE_preset","label":"Western Kentucky (2021, White)"},{"displayName":"WMU_HELMET_2021_BROWN_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WMU_HELMET_2021_BROWN_preset","label":"Western Michigan (2021, Brown)"},{"displayName":"WMU_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WMU_HELMET_2021_WHITE_preset","label":"Western Michigan (2021, White)"},{"displayName":"WIS_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WIS_HELMET_2021_WHITE_preset","label":"Wisconsin (2021, White)"},{"displayName":"WYO_HELMET_2021_WHITE_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WYO_HELMET_2021_WHITE_preset","label":"Wyoming (2021, White)"}],"facemask":[{"displayName":"AFA_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2021_BLUE_Facemask_preset","label":"Air Force (2021, BLUE)"},{"displayName":"AFA_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2021_WHITE_Facemask_preset","label":"Air Force (2021, White)"},{"displayName":"AFA_HELMET_2023_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2023_BLUE_Facemask_preset","label":"Air Force (2023, BLUE)"},{"displayName":"AFA_HELMET_2024_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2024_BLUE_Facemask_preset","label":"Air Force (2024, BLUE)"},{"displayName":"AFA_HELMET_2024_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2024_BLACK_Facemask_preset","label":"Air Force (2024, Black)"},{"displayName":"AFA_HELMET_2025_ALT_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2025_ALT_Facemask_preset","label":"Air Force (2025, ALT)"},{"displayName":"AKR_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AKR_HELMET_2021_GOLD_Facemask_preset","label":"Akron (2021, GOLD)"},{"displayName":"AKR_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AKR_HELMET_2021_WHITE_Facemask_preset","label":"Akron (2021, White)"},{"displayName":"ALA_HELMET_2021_CRIMSON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ALA_HELMET_2021_CRIMSON_Facemask_preset","label":"Alabama (2021, Crimson)"},{"displayName":"APP_HELMET_2016_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2016_BLACK_Facemask_preset","label":"Appalachian State (2016, Black)"},{"displayName":"APP_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2021_BLACK_Facemask_preset","label":"Appalachian State (2021, Black)"},{"displayName":"APP_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2021_WHITE_Facemask_preset","label":"Appalachian State (2021, White)"},{"displayName":"APP_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2021_YELLOW_Facemask_preset","label":"Appalachian State (2021, Yellow)"},{"displayName":"ARIZ_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARIZ_HELMET_2021_NAVY_Facemask_preset","label":"Arizona (2021, NAVY)"},{"displayName":"ARIZ_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARIZ_HELMET_2021_RED_Facemask_preset","label":"Arizona (2021, RED)"},{"displayName":"ARIZ_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARIZ_HELMET_2021_WHITE_Facemask_preset","label":"Arizona (2021, White)"},{"displayName":"ASU_HELMET_2014_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2014_YELLOW_Facemask_preset","label":"Arizona State (2014, Yellow)"},{"displayName":"ASU_HELMET_2021_MAROON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2021_MAROON_Facemask_preset","label":"Arizona State (2021, Maroon)"},{"displayName":"ASU_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2021_YELLOW_Facemask_preset","label":"Arizona State (2021, Yellow)"},{"displayName":"ASU_HELMET_2022_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2022_YELLOW_Facemask_preset","label":"Arizona State (2022, Yellow)"},{"displayName":"ASU_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2023_BLACK_Facemask_preset","label":"Arizona State (2023, Black)"},{"displayName":"ASU_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2023_WHITE_Facemask_preset","label":"Arizona State (2023, White)"},{"displayName":"ARK_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARK_HELMET_2021_RED_Facemask_preset","label":"Arkansas (2021, RED)"},{"displayName":"ARK_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARK_HELMET_2021_WHITE_Facemask_preset","label":"Arkansas (2021, White)"},{"displayName":"ARST_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARST_HELMET_2021_WHITE_Facemask_preset","label":"Arkansas State (2021, White)"},{"displayName":"ARST_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARST_HELMET_2023_BLACK_Facemask_preset","label":"Arkansas State (2023, Black)"},{"displayName":"ARMY_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARMY_HELMET_2021_GOLD_Facemask_preset","label":"Army (2021, GOLD)"},{"displayName":"ARMY_HELMET_2025_AN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARMY_HELMET_2025_AN_Facemask_preset","label":"Army (2025, AN)"},{"displayName":"AUB_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AUB_HELMET_2021_NAVY_Facemask_preset","label":"Auburn (2021, NAVY)"},{"displayName":"AUB_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AUB_HELMET_2021_ORANGE_Facemask_preset","label":"Auburn (2021, Orange)"},{"displayName":"AUB_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AUB_HELMET_2021_WHITE_Facemask_preset","label":"Auburn (2021, White)"},{"displayName":"BYU_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2021_BLUE_Facemask_preset","label":"BYU (2021, BLUE)"},{"displayName":"BYU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2021_WHITE_Facemask_preset","label":"BYU (2021, White)"},{"displayName":"BYU_HELMET_2022_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2022_BLACK_Facemask_preset","label":"BYU (2022, Black)"},{"displayName":"BYU_HELMET_2022_WHITENAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2022_WHITENAVY_Facemask_preset","label":"BYU (2022, Whitenavy)"},{"displayName":"BYU_HELMET_2023_CHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2023_CHROME_Facemask_preset","label":"BYU (2023, Chrome)"},{"displayName":"BYU_HELMET_2023_THROWBACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2023_THROWBACK_Facemask_preset","label":"BYU (2023, Throwback)"},{"displayName":"BYU_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2023_WHITE_Facemask_preset","label":"BYU (2023, White)"},{"displayName":"BALL_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BALL_HELMET_2021_BLACK_Facemask_preset","label":"Ball State (2021, Black)"},{"displayName":"BALL_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BALL_HELMET_2021_WHITE_Facemask_preset","label":"Ball State (2021, White)"},{"displayName":"BAY_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_BLACK_Facemask_preset","label":"Baylor (2021, Black)"},{"displayName":"BAY_HELMET_2021_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_GREEN_Facemask_preset","label":"Baylor (2021, Green)"},{"displayName":"BAY_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_WHITE_Facemask_preset","label":"Baylor (2021, White)"},{"displayName":"BAY_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_YELLOW_Facemask_preset","label":"Baylor (2021, Yellow)"},{"displayName":"BAY_HELMET_2025_CHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2025_CHROME_Facemask_preset","label":"Baylor (2025, Chrome)"},{"displayName":"BSU_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_BLUE_Facemask_preset","label":"Boise State (2021, BLUE)"},{"displayName":"BSU_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_ORANGE_Facemask_preset","label":"Boise State (2021, Orange)"},{"displayName":"BSU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_WHITE_Facemask_preset","label":"Boise State (2021, White)"},{"displayName":"BSU_HELMET_2023_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2023_ORANGE_Facemask_preset","label":"Boise State (2023, Orange)"},{"displayName":"BC_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BC_HELMET_2021_GOLD_Facemask_preset","label":"Boston College (2021, GOLD)"},{"displayName":"BGSU_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BGSU_HELMET_2021_ORANGE_Facemask_preset","label":"Bowling Green (2021, Orange)"},{"displayName":"BGSU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BGSU_HELMET_2021_WHITE_Facemask_preset","label":"Bowling Green (2021, White)"},{"displayName":"BUFF_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BUFF_HELMET_2021_BLUE_Facemask_preset","label":"Buffalo (2021, BLUE)"},{"displayName":"BUFF_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BUFF_HELMET_2021_BLACK_Facemask_preset","label":"Buffalo (2021, Black)"},{"displayName":"BUFF_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BUFF_HELMET_2021_WHITE_Facemask_preset","label":"Buffalo (2021, White)"},{"displayName":"BUFF_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BUFF_HELMET_2023_BLACK_Facemask_preset","label":"Buffalo (2023, Black)"},{"displayName":"CAL_HELMET_2022_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CAL_HELMET_2022_YELLOW_Facemask_preset","label":"California (2022, Yellow)"},{"displayName":"CAL_HELMET_2023_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CAL_HELMET_2023_NAVY_Facemask_preset","label":"California (2023, NAVY)"},{"displayName":"CMU_HELMET_2021_MAROON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CMU_HELMET_2021_MAROON_Facemask_preset","label":"Central Michigan (2021, Maroon)"},{"displayName":"CMU_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CMU_HELMET_2021_YELLOW_Facemask_preset","label":"Central Michigan (2021, Yellow)"},{"displayName":"CHAR_HELMET_2021_CHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_CHROME_Facemask_preset","label":"Charlotte (2021, Chrome)"},{"displayName":"CHAR_HELMET_2021_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_GREEN_Facemask_preset","label":"Charlotte (2021, Green)"},{"displayName":"CHAR_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_WHITE_Facemask_preset","label":"Charlotte (2021, White)"},{"displayName":"CHAR_HELMET_2025_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2025_WHITE_Facemask_preset","label":"Charlotte (2025, White)"},{"displayName":"CIN_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CIN_HELMET_2021_BLACK_Facemask_preset","label":"Cincinnati (2021, Black)"},{"displayName":"CIN_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CIN_HELMET_2021_RED_Facemask_preset","label":"Cincinnati (2021, RED)"},{"displayName":"CIN_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CIN_HELMET_2021_WHITE_Facemask_preset","label":"Cincinnati (2021, White)"},{"displayName":"CLEM_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CLEM_HELMET_2021_ORANGE_Facemask_preset","label":"Clemson (2021, Orange)"},{"displayName":"CCAR_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CCAR_HELMET_2021_BLACK_Facemask_preset","label":"Coastal Carolina (2021, Black)"},{"displayName":"CCAR_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CCAR_HELMET_2021_WHITE_Facemask_preset","label":"Coastal Carolina (2021, White)"},{"displayName":"COLO_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2021_BLACK_Facemask_preset","label":"Colorado (2021, Black)"},{"displayName":"COLO_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2021_GOLD_Facemask_preset","label":"Colorado (2021, GOLD)"},{"displayName":"COLO_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2021_WHITE_Facemask_preset","label":"Colorado (2021, White)"},{"displayName":"COLO_HELMET_2023_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2023_GOLD_Facemask_preset","label":"Colorado (2023, GOLD)"},{"displayName":"CSU_HELMET_2021_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CSU_HELMET_2021_GREEN_Facemask_preset","label":"Colorado State (2021, Green)"},{"displayName":"CSU_HELMET_2021_PRIDE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CSU_HELMET_2021_PRIDE_Facemask_preset","label":"Colorado State (2021, Pride)"},{"displayName":"CSU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CSU_HELMET_2021_WHITE_Facemask_preset","label":"Colorado State (2021, White)"},{"displayName":"DEL_HELMET_2024_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DEL_HELMET_2024_BLUE_Facemask_preset","label":"Delaware (2024, BLUE)"},{"displayName":"DUKE_HELMET_2019_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2019_BLUE_Facemask_preset","label":"Duke (2019, BLUE)"},{"displayName":"DUKE_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2021_BLUE_Facemask_preset","label":"Duke (2021, BLUE)"},{"displayName":"DUKE_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2021_BLACK_Facemask_preset","label":"Duke (2021, Black)"},{"displayName":"DUKE_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2021_WHITE_Facemask_preset","label":"Duke (2021, White)"},{"displayName":"Duke_HELMET_2022_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/Duke_HELMET_2022_BLUE_Facemask_preset","label":"Duke (2022, BLUE)"},{"displayName":"ECU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2021_BLACK_Facemask_preset","label":"East Carolina (2021, Black)"},{"displayName":"ECU_HELMET_2021_PURPLEPURPLE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2021_PURPLEPURPLE_Facemask_preset","label":"East Carolina (2021, Purplepurple)"},{"displayName":"ECU_HELMET_2021_PURPLEYELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2021_PURPLEYELLOW_Facemask_preset","label":"East Carolina (2021, Purpleyellow)"},{"displayName":"ECU_HELMET_2025_PURPLE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2025_PURPLE_Facemask_preset","label":"East Carolina (2025, Purple)"},{"displayName":"EMU_HELMET_2021_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/EMU_HELMET_2021_GREEN_Facemask_preset","label":"Eastern Michigan (2021, Green)"},{"displayName":"EMU_HELMET_2021_SILVER_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/EMU_HELMET_2021_SILVER_Facemask_preset","label":"Eastern Michigan (2021, Silver)"},{"displayName":"FCSE_HELMET_2023_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FCSE_HELMET_2023_BLUE_Facemask_preset","label":"FCS East (generic) (2023, BLUE)"},{"displayName":"FCSMW_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FCSMW_HELMET_2023_BLACK_Facemask_preset","label":"FCS Midwest (generic) (2023, Black)"},{"displayName":"FCSSE_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FCSSE_HELMET_2023_BLACK_Facemask_preset","label":"FCS Southeast (generic) (2023, Black)"},{"displayName":"FCSW_HELMET_2023_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FCSW_HELMET_2023_GOLD_Facemask_preset","label":"FCS West (generic) (2023, GOLD)"},{"displayName":"FLA_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_BLUE_Facemask_preset","label":"Florida (2021, BLUE)"},{"displayName":"FLA_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_ORANGE_Facemask_preset","label":"Florida (2021, Orange)"},{"displayName":"FLA_HELMET_2021_THROWBACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_THROWBACK_Facemask_preset","label":"Florida (2021, Throwback)"},{"displayName":"FLA_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_WHITE_Facemask_preset","label":"Florida (2021, White)"},{"displayName":"FLA_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2023_BLACK_Facemask_preset","label":"Florida (2023, Black)"},{"displayName":"FAU_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2021_BLUE_Facemask_preset","label":"Florida Atlantic (2021, BLUE)"},{"displayName":"FAU_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2021_RED_Facemask_preset","label":"Florida Atlantic (2021, RED)"},{"displayName":"FAU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2021_WHITE_Facemask_preset","label":"Florida Atlantic (2021, White)"},{"displayName":"FAU_HELMET_2023_WHITEALT_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2023_WHITEALT_Facemask_preset","label":"Florida Atlantic (2023, Whitealt)"},{"displayName":"FIU_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2021_NAVY_Facemask_preset","label":"Florida International (2021, NAVY)"},{"displayName":"FIU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2021_WHITE_Facemask_preset","label":"Florida International (2021, White)"},{"displayName":"FIU_HELMET_2025_ViceCity_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2025_ViceCity_Facemask_preset","label":"Florida International (2025, Vicecity)"},{"displayName":"FSU_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FSU_HELMET_2021_GOLD_Facemask_preset","label":"Florida State (2021, GOLD)"},{"displayName":"FSU_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FSU_HELMET_2023_WHITE_Facemask_preset","label":"Florida State (2023, White)"},{"displayName":"FRES_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FRES_HELMET_2021_BLACK_Facemask_preset","label":"Fresno State (2021, Black)"},{"displayName":"FRES_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FRES_HELMET_2021_RED_Facemask_preset","label":"Fresno State (2021, RED)"},{"displayName":"FRES_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FRES_HELMET_2021_WHITE_Facemask_preset","label":"Fresno State (2021, White)"},{"displayName":"UGA_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UGA_HELMET_2021_RED_Facemask_preset","label":"Georgia (2021, RED)"},{"displayName":"GASO_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GASO_HELMET_2021_BLUE_Facemask_preset","label":"Georgia Southern (2021, BLUE)"},{"displayName":"GSU_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GSU_HELMET_2021_BLUE_Facemask_preset","label":"Georgia State (2021, BLUE)"},{"displayName":"GSU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GSU_HELMET_2021_BLACK_Facemask_preset","label":"Georgia State (2021, Black)"},{"displayName":"GSU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GSU_HELMET_2021_WHITE_Facemask_preset","label":"Georgia State (2021, White)"},{"displayName":"GT_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GT_HELMET_2021_GOLD_Facemask_preset","label":"Georgia Tech (2021, GOLD)"},{"displayName":"GT_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GT_HELMET_2021_WHITE_Facemask_preset","label":"Georgia Tech (2021, White)"},{"displayName":"GT_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GT_HELMET_2023_BLACK_Facemask_preset","label":"Georgia Tech (2023, Black)"},{"displayName":"GT_HELMET_2023_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GT_HELMET_2023_GOLD_Facemask_preset","label":"Georgia Tech (2023, GOLD)"},{"displayName":"GT_HELMET_2025_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GT_HELMET_2025_GOLD_Facemask_preset","label":"Georgia Tech (2025, GOLD)"},{"displayName":"HAW_HELMET_2021_BLACK_02_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_BLACK_02_Facemask_preset","label":"Hawaii (2021, Black 02)"},{"displayName":"HAW_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_BLACK_Facemask_preset","label":"Hawaii (2021, Black)"},{"displayName":"HAW_HELMET_2021_WHITE_02_Facemask","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_WHITE_02_Facemask","label":"Hawaii (2021, White 02)"},{"displayName":"HAW_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_WHITE_Facemask_preset","label":"Hawaii (2021, White)"},{"displayName":"HOU_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HOU_HELMET_2021_RED_Facemask_preset","label":"Houston (2021, RED)"},{"displayName":"HOU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HOU_HELMET_2021_WHITE_Facemask_preset","label":"Houston (2021, White)"},{"displayName":"HOU_HELMET_2021_WHITEBLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HOU_HELMET_2021_WHITEBLACK_Facemask_preset","label":"Houston (2021, Whiteblack)"},{"displayName":"ILL_HELMET_2021_GRAY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ILL_HELMET_2021_GRAY_Facemask_preset","label":"Illinois (2021, GRAY)"},{"displayName":"ILL_HELMET_2021_LEATHER_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ILL_HELMET_2021_LEATHER_Facemask_preset","label":"Illinois (2021, Leather)"},{"displayName":"ILL_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ILL_HELMET_2021_ORANGE_Facemask_preset","label":"Illinois (2021, Orange)"},{"displayName":"ILL_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ILL_HELMET_2021_WHITE_Facemask_preset","label":"Illinois (2021, White)"},{"displayName":"IND_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/IND_HELMET_2021_RED_Facemask_preset","label":"Indiana (2021, RED)"},{"displayName":"IOWA_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/IOWA_HELMET_2021_BLACK_Facemask_preset","label":"Iowa (2021, Black)"},{"displayName":"ISU_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ISU_HELMET_2021_RED_Facemask_preset","label":"Iowa State (2021, RED)"},{"displayName":"ISU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ISU_HELMET_2021_WHITE_Facemask_preset","label":"Iowa State (2021, White)"},{"displayName":"ISU_HELMET_2022_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ISU_HELMET_2022_BLACK_Facemask_preset","label":"Iowa State (2022, Black)"},{"displayName":"ISU_HELMET_2024_THROWBACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ISU_HELMET_2024_THROWBACK_Facemask_preset","label":"Iowa State (2024, Throwback)"},{"displayName":"JVST_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JVST_HELMET_2021_RED_Facemask_preset","label":"Jacksonville State (2021, RED)"},{"displayName":"JVST_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JVST_HELMET_2021_WHITE_Facemask_preset","label":"Jacksonville State (2021, White)"},{"displayName":"JMU_HELMET_2023_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JMU_HELMET_2023_GOLD_Facemask_preset","label":"James Madison (2023, GOLD)"},{"displayName":"JMU_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JMU_HELMET_2023_WHITE_Facemask_preset","label":"James Madison (2023, White)"},{"displayName":"KU_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_BLUE_Facemask_preset","label":"Kansas (2021, BLUE)"},{"displayName":"KU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_BLACK_Facemask_preset","label":"Kansas (2021, Black)"},{"displayName":"KU_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_RED_Facemask_preset","label":"Kansas (2021, RED)"},{"displayName":"KU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_WHITE_Facemask_preset","label":"Kansas (2021, White)"},{"displayName":"KU_HELMET_2025_Blue_Alt_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2025_Blue_Alt_Facemask_preset","label":"Kansas (2025, Blue Alt)"},{"displayName":"KSU_HELMET_2021_SILVER_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KSU_HELMET_2021_SILVER_Facemask_preset","label":"Kansas State (2021, Silver)"},{"displayName":"KENN_HELMET_2021_CHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENN_HELMET_2021_CHROME_Facemask_preset","label":"Kennesaw State (2021, Chrome)"},{"displayName":"KENN_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENN_HELMET_2021_YELLOW_Facemask_preset","label":"Kennesaw State (2021, Yellow)"},{"displayName":"KENT_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2021_BLACK_Facemask_preset","label":"Kent State (2021, Black)"},{"displayName":"KENT_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2021_GOLD_Facemask_preset","label":"Kent State (2021, GOLD)"},{"displayName":"KENT_HELMET_2023_Navy_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2023_Navy_Facemask_preset","label":"Kent State (2023, Navy)"},{"displayName":"KENT_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2023_WHITE_Facemask_preset","label":"Kent State (2023, White)"},{"displayName":"UK_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2021_BLUE_Facemask_preset","label":"Kentucky (2021, BLUE)"},{"displayName":"UK_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2021_WHITE_Facemask_preset","label":"Kentucky (2021, White)"},{"displayName":"UK_HELMET_2022_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2022_BLACK_Facemask_preset","label":"Kentucky (2022, Black)"},{"displayName":"UK_HELMET_2022_CHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2022_CHROME_Facemask_preset","label":"Kentucky (2022, Chrome)"},{"displayName":"UK_HELMET_2022_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2022_WHITE_Facemask_preset","label":"Kentucky (2022, White)"},{"displayName":"LSU_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LSU_HELMET_2021_GOLD_Facemask_preset","label":"LSU (2021, GOLD)"},{"displayName":"LSU_HELMET_2021_PURPLE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LSU_HELMET_2021_PURPLE_Facemask_preset","label":"LSU (2021, Purple)"},{"displayName":"LSU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LSU_HELMET_2021_WHITE_Facemask_preset","label":"LSU (2021, White)"},{"displayName":"LIB_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LIB_HELMET_2021_BLUE_Facemask_preset","label":"Liberty (2021, BLUE)"},{"displayName":"LIB_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LIB_HELMET_2021_RED_Facemask_preset","label":"Liberty (2021, RED)"},{"displayName":"LIB_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LIB_HELMET_2021_WHITE_Facemask_preset","label":"Liberty (2021, White)"},{"displayName":"ULL_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULL_HELMET_2021_BLACK_Facemask_preset","label":"Louisiana (2021, Black)"},{"displayName":"ULL_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULL_HELMET_2021_RED_Facemask_preset","label":"Louisiana (2021, RED)"},{"displayName":"ULL_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULL_HELMET_2023_WHITE_Facemask_preset","label":"Louisiana (2023, White)"},{"displayName":"LT_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LT_HELMET_2021_RED_Facemask_preset","label":"Louisiana Tech (2021, RED)"},{"displayName":"LT_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LT_HELMET_2021_WHITE_Facemask_preset","label":"Louisiana Tech (2021, White)"},{"displayName":"ULM_HELMET_2016_CAMO_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULM_HELMET_2016_CAMO_Facemask_preset","label":"Louisiana-Monroe (2016, CAMO)"},{"displayName":"ULM_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULM_HELMET_2021_WHITE_Facemask_preset","label":"Louisiana-Monroe (2021, White)"},{"displayName":"LOU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LOU_HELMET_2021_BLACK_Facemask_preset","label":"Louisville (2021, Black)"},{"displayName":"LOU_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LOU_HELMET_2021_RED_Facemask_preset","label":"Louisville (2021, RED)"},{"displayName":"LOU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LOU_HELMET_2021_WHITE_Facemask_preset","label":"Louisville (2021, White)"},{"displayName":"MRSH_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MRSH_HELMET_2021_WHITE_Facemask_preset","label":"Marshall (2021, White)"},{"displayName":"UMD_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMD_HELMET_2021_BLACK_Facemask_preset","label":"Maryland (2021, Black)"},{"displayName":"UMD_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMD_HELMET_2021_RED_Facemask_preset","label":"Maryland (2021, RED)"},{"displayName":"UMD_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMD_HELMET_2021_WHITE_Facemask_preset","label":"Maryland (2021, White)"},{"displayName":"MEM_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2021_BLUE_Facemask_preset","label":"Memphis (2021, BLUE)"},{"displayName":"MEM_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2021_WHITE_Facemask_preset","label":"Memphis (2021, White)"},{"displayName":"MEM_HELMET_2022_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2022_WHITE_Facemask_preset","label":"Memphis (2022, White)"},{"displayName":"MEM_HELMET_2022_WHITEBLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2022_WHITEBLACK_Facemask_preset","label":"Memphis (2022, Whiteblack)"},{"displayName":"MEM_HELMET_2023_GRAY_facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2023_GRAY_facemask_preset","label":"Memphis (2023, GRAY)"},{"displayName":"MIA_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIA_HELMET_2021_BLACK_Facemask_preset","label":"Miami (FL) (2021, Black)"},{"displayName":"MIA_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIA_HELMET_2021_WHITE_Facemask_preset","label":"Miami (FL) (2021, White)"},{"displayName":"MIAOH_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIAOH_HELMET_2021_RED_Facemask_preset","label":"Miami (OH) (2021, RED)"},{"displayName":"MIAOH_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIAOH_HELMET_2021_WHITE_Facemask_preset","label":"Miami (OH) (2021, White)"},{"displayName":"MIAOH_HELMET_2021_WHITEALT_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIAOH_HELMET_2021_WHITEALT_Facemask_preset","label":"Miami (OH) (2021, Whitealt)"},{"displayName":"MIAOH_HELMET_2025_REDALT_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIAOH_HELMET_2025_REDALT_Facemask_preset","label":"Miami (OH) (2025, Redalt)"},{"displayName":"MICH_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MICH_HELMET_2021_BLUE_Facemask_preset","label":"Michigan (2021, BLUE)"},{"displayName":"MSU_HELMET_2015_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2015_GREEN_Facemask_preset","label":"Michigan State (2015, Green)"},{"displayName":"MSU_HELMET_2017_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2017_WHITE_Facemask_preset","label":"Michigan State (2017, White)"},{"displayName":"MSU_HELMET_2021_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2021_GREEN_Facemask_preset","label":"Michigan State (2021, Green)"},{"displayName":"MSU_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2023_BLACK_Facemask_preset","label":"Michigan State (2023, Black)"},{"displayName":"MTSU_HELMET_2021_GREY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTSU_HELMET_2021_GREY_Facemask_preset","label":"Middle Tennessee (2021, GREY)"},{"displayName":"MTSU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTSU_HELMET_2021_WHITE_Facemask_preset","label":"Middle Tennessee (2021, White)"},{"displayName":"MINN_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2021_RED_Facemask_preset","label":"Minnesota (2021, RED)"},{"displayName":"MINN_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2021_YELLOW_Facemask_preset","label":"Minnesota (2021, Yellow)"},{"displayName":"MINN_HELMET_2022_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2022_BLACK_Facemask_preset","label":"Minnesota (2022, Black)"},{"displayName":"MINN_HELMET_2022_CHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2022_CHROME_Facemask_preset","label":"Minnesota (2022, Chrome)"},{"displayName":"MINN_HELMET_2022_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2022_YELLOW_Facemask_preset","label":"Minnesota (2022, Yellow)"},{"displayName":"MINN_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2023_WHITE_Facemask_preset","label":"Minnesota (2023, White)"},{"displayName":"MSST_HELMET_2021_MAROON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSST_HELMET_2021_MAROON_Facemask_preset","label":"Mississippi State (2021, Maroon)"},{"displayName":"MSST_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSST_HELMET_2021_WHITE_Facemask_preset","label":"Mississippi State (2021, White)"},{"displayName":"MIZZ_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIZZ_HELMET_2021_BLACK_Facemask_preset","label":"Missouri (2021, Black)"},{"displayName":"MIZZ_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIZZ_HELMET_2021_YELLOW_Facemask_preset","label":"Missouri (2021, Yellow)"},{"displayName":"MIST_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIST_HELMET_2021_BLACK_Facemask_preset","label":"Missouri State (2021, Black)"},{"displayName":"MIST_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIST_HELMET_2021_WHITE_Facemask_preset","label":"Missouri State (2021, White)"},{"displayName":"MTDEW_HELMET_2025_Alt_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTDEW_HELMET_2025_Alt_Facemask_preset","label":"Mountain Dew (non-school / branded) (2025, Alt)"},{"displayName":"MTDEW_HELMET_2025_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTDEW_HELMET_2025_GREEN_Facemask_preset","label":"Mountain Dew (non-school / branded) (2025, Green)"},{"displayName":"MTDEW_HELMET_2025_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTDEW_HELMET_2025_WHITE_Facemask_preset","label":"Mountain Dew (non-school / branded) (2025, White)"},{"displayName":"NCST_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NCST_HELMET_2021_BLACK_Facemask_preset","label":"NC State (2021, Black)"},{"displayName":"NCST_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NCST_HELMET_2021_RED_Facemask_preset","label":"NC State (2021, RED)"},{"displayName":"NCST_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NCST_HELMET_2021_WHITE_Facemask_preset","label":"NC State (2021, White)"},{"displayName":"NAVY_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NAVY_HELMET_2021_GOLD_Facemask_preset","label":"Navy (2021, GOLD)"},{"displayName":"NAVY_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NAVY_HELMET_2021_NAVY_Facemask_preset","label":"Navy (2021, NAVY)"},{"displayName":"NEB_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEB_HELMET_2021_WHITE_Facemask_preset","label":"Nebraska (2021, White)"},{"displayName":"NEV_HELMET_2021_SILVER_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEV_HELMET_2021_SILVER_Facemask_preset","label":"Nevada (2021, Silver)"},{"displayName":"NEV_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEV_HELMET_2021_WHITE_Facemask_preset","label":"Nevada (2021, White)"},{"displayName":"NEV_HELMET_2023_NAVYBLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEV_HELMET_2023_NAVYBLUE_Facemask_preset","label":"Nevada (2023, Navyblue)"},{"displayName":"UNM_HELMET_2021_GRAY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_GRAY_Facemask_preset","label":"New Mexico (2021, GRAY)"},{"displayName":"UNM_HELMET_2021_SILVER_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_SILVER_Facemask_preset","label":"New Mexico (2021, Silver)"},{"displayName":"UNM_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_WHITE_Facemask_preset","label":"New Mexico (2021, White)"},{"displayName":"UNM_HELMET_2023_SILVER_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2023_SILVER_Facemask_preset","label":"New Mexico (2023, Silver)"},{"displayName":"NMSU_HELMET_2021_CHROMECRIMSON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NMSU_HELMET_2021_CHROMECRIMSON_Facemask_preset","label":"New Mexico State (2021, Chromecrimson)"},{"displayName":"NMSU_HELMET_2021_CRIMSON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NMSU_HELMET_2021_CRIMSON_Facemask_preset","label":"New Mexico State (2021, Crimson)"},{"displayName":"NMSU_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NMSU_HELMET_2023_WHITE_Facemask_preset","label":"New Mexico State (2023, White)"},{"displayName":"UNC_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNC_HELMET_2021_BLUE_Facemask_preset","label":"North Carolina (2021, BLUE)"},{"displayName":"UNC_HELMET_2021_CHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNC_HELMET_2021_CHROME_Facemask_preset","label":"North Carolina (2021, Chrome)"},{"displayName":"UNC_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNC_HELMET_2021_WHITE_Facemask_preset","label":"North Carolina (2021, White)"},{"displayName":"UNT_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_BLACK_Facemask_preset","label":"North Texas (2021, Black)"},{"displayName":"UNT_HELMET_2021_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_GREEN_Facemask_preset","label":"North Texas (2021, Green)"},{"displayName":"UNT_HELMET_2021_THROWBACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_THROWBACK_Facemask_preset","label":"North Texas (2021, Throwback)"},{"displayName":"UNT_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_WHITE_Facemask_preset","label":"North Texas (2021, White)"},{"displayName":"NIU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NIU_HELMET_2021_BLACK_Facemask_preset","label":"Northern Illinois (2021, Black)"},{"displayName":"NW_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2021_BLACK_Facemask_preset","label":"Northwestern (2021, Black)"},{"displayName":"NW_HELMET_2021_PURPLE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2021_PURPLE_Facemask_preset","label":"Northwestern (2021, Purple)"},{"displayName":"NW_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2021_WHITE_Facemask_preset","label":"Northwestern (2021, White)"},{"displayName":"NW_HELMET_2022_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2022_BLACK_Facemask_preset","label":"Northwestern (2022, Black)"},{"displayName":"ND_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ND_HELMET_2021_GOLD_Facemask_preset","label":"Notre Dame (2021, GOLD)"},{"displayName":"OHIO_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OHIO_HELMET_2023_BLACK_Facemask_preset","label":"Ohio (2023, Black)"},{"displayName":"OHIO_HELMET_2023_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OHIO_HELMET_2023_GREEN_Facemask_preset","label":"Ohio (2023, Green)"},{"displayName":"OHIO_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OHIO_HELMET_2023_WHITE_Facemask_preset","label":"Ohio (2023, White)"},{"displayName":"OSU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OSU_HELMET_2021_BLACK_Facemask_preset","label":"Ohio State (2021, Black)"},{"displayName":"OSU_HELMET_2021_GREY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OSU_HELMET_2021_GREY_Facemask_preset","label":"Ohio State (2021, GREY)"},{"displayName":"OU_HELMET_2021_CRIMSON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_CRIMSON_Facemask_preset","label":"Oklahoma (2021, Crimson)"},{"displayName":"OU_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_RED_Facemask_preset","label":"Oklahoma (2021, RED)"},{"displayName":"OU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_WHITE_Facemask_preset","label":"Oklahoma (2021, White)"},{"displayName":"OU_HELMET_2021_WOODCREAM_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_WOODCREAM_Facemask_preset","label":"Oklahoma (2021, Woodcream)"},{"displayName":"OU_HELMET_2021_WOODCRIMSON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_WOODCRIMSON_Facemask_preset","label":"Oklahoma (2021, Woodcrimson)"},{"displayName":"OKST_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2021_BLACK_Facemask_preset","label":"Oklahoma State (2021, Black)"},{"displayName":"OKST_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2021_ORANGE_Facemask_preset","label":"Oklahoma State (2021, Orange)"},{"displayName":"OKST_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2021_WHITE_Facemask_preset","label":"Oklahoma State (2021, White)"},{"displayName":"OKST_HELMET_2023_GRAY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2023_GRAY_Facemask_preset","label":"Oklahoma State (2023, GRAY)"},{"displayName":"ODU_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ODU_HELMET_2021_BLUE_Facemask_preset","label":"Old Dominion (2021, BLUE)"},{"displayName":"ODU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ODU_HELMET_2021_WHITE_Facemask_preset","label":"Old Dominion (2021, White)"},{"displayName":"MISS_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_BLUE_Facemask_preset","label":"Ole Miss (2021, BLUE)"},{"displayName":"MISS_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_NAVY_Facemask_preset","label":"Ole Miss (2021, NAVY)"},{"displayName":"MISS_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_WHITE_Facemask_preset","label":"Ole Miss (2021, White)"},{"displayName":"ORE_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2021_WHITE_Facemask_preset","label":"Oregon (2021, White)"},{"displayName":"ORE_HELMET_2021_WHITEGREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2021_WHITEGREEN_Facemask_preset","label":"Oregon (2021, Whitegreen)"},{"displayName":"ORE_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2021_YELLOW_Facemask_preset","label":"Oregon (2021, Yellow)"},{"displayName":"ORE_HELMET_2021_YELLOWSTEEL_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2021_YELLOWSTEEL_Facemask_preset","label":"Oregon (2021, Yellowsteel)"},{"displayName":"ORE_HELMET_2023_BLACKCARBON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2023_BLACKCARBON_Facemask_preset","label":"Oregon (2023, Blackcarbon)"},{"displayName":"ORE_HELMET_2023_CHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2023_CHROME_Facemask_preset","label":"Oregon (2023, Chrome)"},{"displayName":"ORE_HELMET_2023_EGGSHELL_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2023_EGGSHELL_Facemask_preset","label":"Oregon (2023, Eggshell)"},{"displayName":"ORE_HELMET_2024_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2024_GREEN_Facemask_preset","label":"Oregon (2024, Green)"},{"displayName":"ORE_HELMET_2024_THROWBACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2024_THROWBACK_Facemask_preset","label":"Oregon (2024, Throwback)"},{"displayName":"ORE_HELMET_2025_SHOEDUCK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2025_SHOEDUCK_Facemask_preset","label":"Oregon (2025, Shoeduck)"},{"displayName":"ORST_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORST_HELMET_2021_BLACK_Facemask_preset","label":"Oregon State (2021, Black)"},{"displayName":"PSU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PSU_HELMET_2021_WHITE_Facemask_preset","label":"Penn State (2021, White)"},{"displayName":"PSU_HELMET_2022_WHITESTRIPE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PSU_HELMET_2022_WHITESTRIPE_Facemask_preset","label":"Penn State (2022, Whitestripe)"},{"displayName":"PITT_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PITT_HELMET_2021_YELLOW_Facemask_preset","label":"Pittsburgh (2021, Yellow)"},{"displayName":"PITT_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PITT_HELMET_2023_WHITE_Facemask_preset","label":"Pittsburgh (2023, White)"},{"displayName":"PUR_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2021_BLACK_Facemask_preset","label":"Purdue (2021, Black)"},{"displayName":"PUR_HELMET_2021_BLACKALT_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2021_BLACKALT_Facemask_preset","label":"Purdue (2021, Blackalt)"},{"displayName":"PUR_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2021_GOLD_Facemask_preset","label":"Purdue (2021, GOLD)"},{"displayName":"PUR_HELMET_2023_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2023_GOLD_Facemask_preset","label":"Purdue (2023, GOLD)"},{"displayName":"RICE_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RICE_HELMET_2021_NAVY_Facemask_preset","label":"Rice (2021, NAVY)"},{"displayName":"RICE_HELMET_2021_SILVER_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RICE_HELMET_2021_SILVER_Facemask_preset","label":"Rice (2021, Silver)"},{"displayName":"RICE_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RICE_HELMET_2021_WHITE_Facemask_preset","label":"Rice (2021, White)"},{"displayName":"RICE_HELMET_2022_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RICE_HELMET_2022_NAVY_Facemask_preset","label":"Rice (2022, NAVY)"},{"displayName":"RUTG_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RUTG_HELMET_2021_BLACK_Facemask_preset","label":"Rutgers (2021, Black)"},{"displayName":"RUTG_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RUTG_HELMET_2021_RED_Facemask_preset","label":"Rutgers (2021, RED)"},{"displayName":"SMU_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SMU_HELMET_2021_BLUE_Facemask_preset","label":"SMU (2021, BLUE)"},{"displayName":"SMU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SMU_HELMET_2021_WHITE_Facemask_preset","label":"SMU (2021, White)"},{"displayName":"SMU_HELMET_2023_WHITEALT_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SMU_HELMET_2023_WHITEALT_Facemask_preset","label":"SMU (2023, Whitealt)"},{"displayName":"SHSU_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SHSU_HELMET_2021_ORANGE_Facemask_preset","label":"Sam Houston State (2021, Orange)"},{"displayName":"SHSU_HELMET_2023_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SHSU_HELMET_2023_ORANGE_Facemask_preset","label":"Sam Houston State (2023, Orange)"},{"displayName":"SDSU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SDSU_HELMET_2021_BLACK_Facemask_preset","label":"San Diego State (2021, Black)"},{"displayName":"SJSU_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SJSU_HELMET_2021_BLUE_Facemask_preset","label":"San Jose State (2021, BLUE)"},{"displayName":"SJSU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SJSU_HELMET_2021_WHITE_Facemask_preset","label":"San Jose State (2021, White)"},{"displayName":"USA_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USA_HELMET_2021_NAVY_Facemask_preset","label":"South Alabama (2021, NAVY)"},{"displayName":"USA_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USA_HELMET_2021_RED_Facemask_preset","label":"South Alabama (2021, RED)"},{"displayName":"USA_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USA_HELMET_2021_WHITE_Facemask_preset","label":"South Alabama (2021, White)"},{"displayName":"USA_HELMET_2022_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USA_HELMET_2022_RED_Facemask_preset","label":"South Alabama (2022, RED)"},{"displayName":"SC_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SC_HELMET_2021_BLACK_Facemask_preset","label":"South Carolina (2021, Black)"},{"displayName":"SC_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SC_HELMET_2021_RED_Facemask_preset","label":"South Carolina (2021, RED)"},{"displayName":"SC_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SC_HELMET_2021_WHITE_Facemask_preset","label":"South Carolina (2021, White)"},{"displayName":"USF_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USF_HELMET_2021_GOLD_Facemask_preset","label":"South Florida (2021, GOLD)"},{"displayName":"USF_HELMET_2021_WHITEGREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USF_HELMET_2021_WHITEGREEN_Facemask_preset","label":"South Florida (2021, Whitegreen)"},{"displayName":"USM_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USM_HELMET_2021_BLACK_Facemask_preset","label":"Southern Miss (2021, Black)"},{"displayName":"USM_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USM_HELMET_2021_WHITE_Facemask_preset","label":"Southern Miss (2021, White)"},{"displayName":"STAN_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2021_WHITE_Facemask_preset","label":"Stanford (2021, White)"},{"displayName":"STAN_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2023_BLACK_Facemask_preset","label":"Stanford (2023, Black)"},{"displayName":"STAN_HELMET_2023_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2023_RED_Facemask_preset","label":"Stanford (2023, RED)"},{"displayName":"SYR_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SYR_HELMET_2021_ORANGE_Facemask_preset","label":"Syracuse (2021, Orange)"},{"displayName":"SYR_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SYR_HELMET_2021_WHITE_Facemask_preset","label":"Syracuse (2021, White)"},{"displayName":"TCU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TCU_HELMET_2021_BLACK_Facemask_preset","label":"TCU (2021, Black)"},{"displayName":"TCU_HELMET_2021_PURPLE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TCU_HELMET_2021_PURPLE_Facemask_preset","label":"TCU (2021, Purple)"},{"displayName":"TCU_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TCU_HELMET_2023_WHITE_Facemask_preset","label":"TCU (2023, White)"},{"displayName":"TEMP_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2021_RED_Facemask_preset","label":"Temple (2021, RED) [TEMP]"},{"displayName":"TEM_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEM_HELMET_2021_RED_Facemask_preset","label":"Temple (2021, RED) [TEM]"},{"displayName":"TEMP_HELMET_2021_REDALT_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2021_REDALT_Facemask_preset","label":"Temple (2021, Redalt)"},{"displayName":"TEM_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEM_HELMET_2021_WHITE_Facemask_preset","label":"Temple (2021, White)"},{"displayName":"TEMP_HELMET_2025_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2025_RED_Facemask_preset","label":"Temple (2025, RED)"},{"displayName":"TEMP_HELMET_2025_WHI_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2025_WHI_Facemask_preset","label":"Temple (2025, WHI)"},{"displayName":"TENN_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2021_ORANGE_Facemask_preset","label":"Tennessee (2021, Orange)"},{"displayName":"TENN_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2021_WHITE_Facemask_preset","label":"Tennessee (2021, White)"},{"displayName":"TENN_HELMET_2022_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2022_BLACK_Facemask_preset","label":"Tennessee (2022, Black)"},{"displayName":"TENN_HELMET_2024_GRAY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2024_GRAY_Facemask_preset","label":"Tennessee (2024, GRAY)"},{"displayName":"TENN_HELMET_2025_Smokey_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2025_Smokey_Facemask_preset","label":"Tennessee (2025, Smokey)"},{"displayName":"TEX_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEX_HELMET_2021_WHITE_Facemask_preset","label":"Texas (2021, White)"},{"displayName":"TAMU_HELMET_2021_MAROON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TAMU_HELMET_2021_MAROON_Facemask_preset","label":"Texas A&M (2021, Maroon)"},{"displayName":"TAMU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TAMU_HELMET_2021_WHITE_Facemask_preset","label":"Texas A&M (2021, White)"},{"displayName":"TAMU_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TAMU_HELMET_2023_BLACK_Facemask_preset","label":"Texas A&M (2023, Black)"},{"displayName":"TXST_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TXST_HELMET_2021_BLACK_Facemask_preset","label":"Texas State (2021, Black)"},{"displayName":"TXST_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TXST_HELMET_2021_GOLD_Facemask_preset","label":"Texas State (2021, GOLD)"},{"displayName":"TXST_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TXST_HELMET_2021_WHITE_Facemask_preset","label":"Texas State (2021, White)"},{"displayName":"TXST_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TXST_HELMET_2023_WHITE_Facemask_preset","label":"Texas State (2023, White)"},{"displayName":"TTU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2021_BLACK_Facemask_preset","label":"Texas Tech (2021, Black)"},{"displayName":"TTU_HELMET_2021_GRAY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2021_GRAY_Facemask_preset","label":"Texas Tech (2021, GRAY)"},{"displayName":"TTU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2021_WHITE_Facemask_preset","label":"Texas Tech (2021, White)"},{"displayName":"TTU_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2023_WHITE_Facemask_preset","label":"Texas Tech (2023, White)"},{"displayName":"TOL_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TOL_HELMET_2021_NAVY_Facemask_preset","label":"Toledo (2021, NAVY)"},{"displayName":"TOL_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TOL_HELMET_2021_YELLOW_Facemask_preset","label":"Toledo (2021, Yellow)"},{"displayName":"TROY_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TROY_HELMET_2021_RED_Facemask_preset","label":"Troy (2021, RED)"},{"displayName":"TROY_HELMET_2021_SILVER_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TROY_HELMET_2021_SILVER_Facemask_preset","label":"Troy (2021, Silver)"},{"displayName":"TROY_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TROY_HELMET_2021_WHITE_Facemask_preset","label":"Troy (2021, White)"},{"displayName":"TROY_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TROY_HELMET_2023_BLACK_Facemask_preset","label":"Troy (2023, Black)"},{"displayName":"TULN_HELMET_2021_GREEN_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2021_GREEN_Facemask_preset","label":"Tulane (2021, Green)"},{"displayName":"TULN_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2021_WHITE_Facemask_preset","label":"Tulane (2021, White)"},{"displayName":"TULN_HELMET_2025_CITY_EDITION_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2025_CITY_EDITION_Facemask_preset","label":"Tulane (2025, CITY Edition)"},{"displayName":"TULN_HELMET_2025_Wumbu_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2025_Wumbu_Facemask_preset","label":"Tulane (2025, Wumbu)"},{"displayName":"TLSA_HELMET_2023_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TLSA_HELMET_2023_GOLD_Facemask_preset","label":"Tulsa (2023, GOLD)"},{"displayName":"TLSA_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TLSA_HELMET_2023_WHITE_Facemask_preset","label":"Tulsa (2023, White)"},{"displayName":"UAB_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UAB_HELMET_2021_GOLD_Facemask_preset","label":"UAB (2021, GOLD)"},{"displayName":"UAB_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UAB_HELMET_2021_WHITE_Facemask_preset","label":"UAB (2021, White)"},{"displayName":"UCF_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2021_GOLD_Facemask_preset","label":"UCF (2021, GOLD)"},{"displayName":"UCF_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2021_WHITE_Facemask_preset","label":"UCF (2021, White)"},{"displayName":"UCF_HELMET_2023_SPACE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2023_SPACE_Facemask_preset","label":"UCF (2023, Space)"},{"displayName":"UCF_HELMET_2024_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2024_GOLD_Facemask_preset","label":"UCF (2024, GOLD)"},{"displayName":"UCLA_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCLA_HELMET_2021_GOLD_Facemask_preset","label":"UCLA (2021, GOLD)"},{"displayName":"UCLA_HELMET_2023_GOLDALT_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCLA_HELMET_2023_GOLDALT_Facemask_preset","label":"UCLA (2023, Goldalt)"},{"displayName":"CONN_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CONN_HELMET_2021_NAVY_Facemask_preset","label":"UConn (2021, NAVY)"},{"displayName":"CONN_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CONN_HELMET_2021_WHITE_Facemask_preset","label":"UConn (2021, White)"},{"displayName":"CONN_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CONN_HELMET_2023_WHITE_Facemask_preset","label":"UConn (2023, White)"},{"displayName":"UMASS_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMASS_HELMET_2021_BLACK_Facemask_preset","label":"UMass (2021, Black)"},{"displayName":"UMASS_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMASS_HELMET_2021_RED_Facemask_preset","label":"UMass (2021, RED)"},{"displayName":"UMASS_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMASS_HELMET_2021_WHITE_Facemask_preset","label":"UMass (2021, White)"},{"displayName":"UNLV_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2021_BLACK_Facemask_preset","label":"UNLV (2021, Black)"},{"displayName":"UNLV_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2021_RED_Facemask_preset","label":"UNLV (2021, RED)"},{"displayName":"UNLV_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2021_WHITE_Facemask_preset","label":"UNLV (2021, White)"},{"displayName":"UNLV_HELMET_2023_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2023_WHITE_Facemask_preset","label":"UNLV (2023, White)"},{"displayName":"UNLV_HELMET_2024_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2024_RED_Facemask_preset","label":"UNLV (2024, RED)"},{"displayName":"USC_HELMET_2021_CARDINAL_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USC_HELMET_2021_CARDINAL_Facemask_preset","label":"USC (2021, Cardinal)"},{"displayName":"USC_HELMET_2021_CARDINALCHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USC_HELMET_2021_CARDINALCHROME_Facemask_preset","label":"USC (2021, Cardinalchrome)"},{"displayName":"UTEP_HELMET_2021_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTEP_HELMET_2021_ORANGE_Facemask_preset","label":"UTEP (2021, Orange)"},{"displayName":"UTEP_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTEP_HELMET_2021_WHITE_Facemask_preset","label":"UTEP (2021, White)"},{"displayName":"UTEP_HELMET_2025_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTEP_HELMET_2025_BLUE_Facemask_preset","label":"UTEP (2025, BLUE)"},{"displayName":"UTSA_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTSA_HELMET_2021_BLACK_Facemask_preset","label":"UTSA (2021, Black)"},{"displayName":"UTSA_HELMET_2021_NAVY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTSA_HELMET_2021_NAVY_Facemask_preset","label":"UTSA (2021, NAVY)"},{"displayName":"UTSA_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTSA_HELMET_2021_WHITE_Facemask_preset","label":"UTSA (2021, White)"},{"displayName":"UTAH_HELMET_2020_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2020_WHITE_Facemask_preset","label":"Utah (2020, White)"},{"displayName":"UTAH_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2021_RED_Facemask_preset","label":"Utah (2021, RED)"},{"displayName":"UTAH_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2021_WHITE_Facemask_preset","label":"Utah (2021, White)"},{"displayName":"UTAH_HELMET_2023_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2023_BLACK_Facemask_preset","label":"Utah (2023, Black)"},{"displayName":"USU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USU_HELMET_2021_BLACK_Facemask_preset","label":"Utah State (2021, Black)"},{"displayName":"USU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USU_HELMET_2021_WHITE_Facemask_preset","label":"Utah State (2021, White)"},{"displayName":"VAN_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VAN_HELMET_2021_GOLD_Facemask_preset","label":"Vanderbilt (2021, GOLD)"},{"displayName":"VAN_HELMET_2022_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VAN_HELMET_2022_WHITE_Facemask_preset","label":"Vanderbilt (2022, White)"},{"displayName":"UVA_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UVA_HELMET_2021_BLUE_Facemask_preset","label":"Virginia (2021, BLUE)"},{"displayName":"UVA_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UVA_HELMET_2021_WHITE_Facemask_preset","label":"Virginia (2021, White)"},{"displayName":"VT_HELMET_2016_MAROON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2016_MAROON_Facemask_preset","label":"Virginia Tech (2016, Maroon)"},{"displayName":"VT_HELMET_2016_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2016_WHITE_Facemask_preset","label":"Virginia Tech (2016, White)"},{"displayName":"VT_HELMET_2021_MAROON_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2021_MAROON_Facemask_preset","label":"Virginia Tech (2021, Maroon)"},{"displayName":"VT_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2021_WHITE_Facemask_preset","label":"Virginia Tech (2021, White)"},{"displayName":"VT_HELMET_2025_ORANGE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2025_ORANGE_Facemask_preset","label":"Virginia Tech (2025, Orange)"},{"displayName":"WAKE_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WAKE_HELMET_2021_BLACK_Facemask_preset","label":"Wake Forest (2021, Black)"},{"displayName":"WASH_HELMET_2021_GOLD_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2021_GOLD_Facemask_preset","label":"Washington (2021, GOLD)"},{"displayName":"WASH_HELMET_2021_GOLDCHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2021_GOLDCHROME_Facemask_preset","label":"Washington (2021, Goldchrome)"},{"displayName":"WASH_HELMET_2023_PURPLECHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2023_PURPLECHROME_Facemask_preset","label":"Washington (2023, Purplechrome)"},{"displayName":"WSU_HELMET_2021_DARKGRAY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WSU_HELMET_2021_DARKGRAY_Facemask_preset","label":"Washington State (2021, Darkgray)"},{"displayName":"WSU_HELMET_2021_GRAY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WSU_HELMET_2021_GRAY_Facemask_preset","label":"Washington State (2021, GRAY)"},{"displayName":"WSU_HELMET_2023_DARKGRAY_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WSU_HELMET_2023_DARKGRAY_Facemask_preset","label":"Washington State (2023, Darkgray)"},{"displayName":"WVU_HELMET_2021_BLUE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2021_BLUE_Facemask_preset","label":"West Virginia (2021, BLUE)"},{"displayName":"WVU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2021_BLACK_Facemask_preset","label":"West Virginia (2021, Black)"},{"displayName":"WVU_HELMET_2021_YELLOW_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2021_YELLOW_Facemask_preset","label":"West Virginia (2021, Yellow)"},{"displayName":"WKU_HELMET_2021_BLACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2021_BLACK_Facemask_preset","label":"Western Kentucky (2021, Black)"},{"displayName":"WKU_HELMET_2021_CHROME_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2021_CHROME_Facemask_preset","label":"Western Kentucky (2021, Chrome)"},{"displayName":"WKU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2021_WHITE_Facemask_preset","label":"Western Kentucky (2021, White)"},{"displayName":"WKU_HELMET_2024_THROWBACK_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2024_THROWBACK_Facemask_preset","label":"Western Kentucky (2024, Throwback)"},{"displayName":"WMU_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WMU_HELMET_2021_WHITE_Facemask_preset","label":"Western Michigan (2021, White)"},{"displayName":"WIS_HELMET_2021_RED_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WIS_HELMET_2021_RED_Facemask_preset","label":"Wisconsin (2021, RED)"},{"displayName":"WIS_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WIS_HELMET_2021_WHITE_Facemask_preset","label":"Wisconsin (2021, White)"},{"displayName":"WYO_HELMET_2021_WHITE_Facemask_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WYO_HELMET_2021_WHITE_Facemask_preset","label":"Wyoming (2021, White)"}],"accessory":[{"displayName":"AFA_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2021_BLUE_Acc_preset","label":"Air Force (2021, BLUE)"},{"displayName":"AFA_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2021_WHITE_Acc_preset","label":"Air Force (2021, White)"},{"displayName":"AFA_HELMET_2025_ALT_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AFA_HELMET_2025_ALT_Acc_preset","label":"Air Force (2025, ALT)"},{"displayName":"AKR_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AKR_HELMET_2021_GOLD_Acc_preset","label":"Akron (2021, GOLD)"},{"displayName":"AKR_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AKR_HELMET_2021_WHITE_Acc_preset","label":"Akron (2021, White)"},{"displayName":"ALA_HELMET_2021_CRIMSON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ALA_HELMET_2021_CRIMSON_Acc_preset","label":"Alabama (2021, Crimson)"},{"displayName":"APP_HELMET_2016_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2016_BLACK_Acc_preset","label":"Appalachian State (2016, Black)"},{"displayName":"APP_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2021_BLACK_Acc_preset","label":"Appalachian State (2021, Black)"},{"displayName":"APP_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2021_WHITE_Acc_preset","label":"Appalachian State (2021, White)"},{"displayName":"APP_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/APP_HELMET_2021_YELLOW_Acc_preset","label":"Appalachian State (2021, Yellow)"},{"displayName":"ARIZ_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARIZ_HELMET_2021_WHITE_Acc_preset","label":"Arizona (2021, White)"},{"displayName":"ASU_HELMET_2014_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2014_YELLOW_Acc_preset","label":"Arizona State (2014, Yellow)"},{"displayName":"ASU_HELMET_2021_MAROON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2021_MAROON_Acc_preset","label":"Arizona State (2021, Maroon)"},{"displayName":"ASU_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2021_YELLOW_Acc_preset","label":"Arizona State (2021, Yellow)"},{"displayName":"ASU_HELMET_2022_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ASU_HELMET_2022_YELLOW_Acc_preset","label":"Arizona State (2022, Yellow)"},{"displayName":"ARK_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARK_HELMET_2021_RED_Acc_preset","label":"Arkansas (2021, RED)"},{"displayName":"ARK_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARK_HELMET_2021_WHITE_Acc_preset","label":"Arkansas (2021, White)"},{"displayName":"ARST_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARST_HELMET_2021_WHITE_Acc_preset","label":"Arkansas State (2021, White)"},{"displayName":"ARST_HELMET_2023_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARST_HELMET_2023_BLACK_Acc_preset","label":"Arkansas State (2023, Black)"},{"displayName":"ARMY_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ARMY_HELMET_2021_GOLD_Acc_preset","label":"Army (2021, GOLD)"},{"displayName":"AUB_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/AUB_HELMET_2021_WHITE_Acc_preset","label":"Auburn (2021, White)"},{"displayName":"BYU_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2021_BLUE_Acc_preset","label":"BYU (2021, BLUE)"},{"displayName":"BYU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2021_WHITE_Acc_preset","label":"BYU (2021, White)"},{"displayName":"BYU_HELMET_2022_NAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2022_NAVY_Acc_preset","label":"BYU (2022, NAVY)"},{"displayName":"BYU_HELMET_2022_WHITENAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BYU_HELMET_2022_WHITENAVY_Acc_preset","label":"BYU (2022, Whitenavy)"},{"displayName":"BALL_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BALL_HELMET_2021_BLACK_Acc_preset","label":"Ball State (2021, Black)"},{"displayName":"BALL_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BALL_HELMET_2021_WHITE_Acc_preset","label":"Ball State (2021, White)"},{"displayName":"BAY_HELMET_2021_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_GREEN_Acc_preset","label":"Baylor (2021, Green)"},{"displayName":"BAY_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_WHITE_Acc_preset","label":"Baylor (2021, White)"},{"displayName":"BAY_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BAY_HELMET_2021_YELLOW_Acc_preset","label":"Baylor (2021, Yellow)"},{"displayName":"BSU_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_BLUE_Acc_preset","label":"Boise State (2021, BLUE)"},{"displayName":"BSU_HELMET_2021_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_ORANGE_Acc_preset","label":"Boise State (2021, Orange)"},{"displayName":"BSU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BSU_HELMET_2021_WHITE_Acc_preset","label":"Boise State (2021, White)"},{"displayName":"BC_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BC_HELMET_2021_GOLD_Acc_preset","label":"Boston College (2021, GOLD)"},{"displayName":"BGSU_HELMET_2021_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BGSU_HELMET_2021_ORANGE_Acc_preset","label":"Bowling Green (2021, Orange)"},{"displayName":"BGSU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BGSU_HELMET_2021_WHITE_Acc_preset","label":"Bowling Green (2021, White)"},{"displayName":"BUFF_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BUFF_HELMET_2021_BLUE_Acc_preset","label":"Buffalo (2021, BLUE)"},{"displayName":"BUFF_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/BUFF_HELMET_2021_WHITE_Acc_preset","label":"Buffalo (2021, White)"},{"displayName":"CAL_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CAL_HELMET_2021_YELLOW_Acc_preset","label":"California (2021, Yellow)"},{"displayName":"CAL_HELMET_2022_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CAL_HELMET_2022_YELLOW_Acc_preset","label":"California (2022, Yellow)"},{"displayName":"CAL_HELMET_2023_NAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CAL_HELMET_2023_NAVY_Acc_preset","label":"California (2023, NAVY)"},{"displayName":"CMU_HELMET_2021_MAROON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CMU_HELMET_2021_MAROON_Acc_preset","label":"Central Michigan (2021, Maroon)"},{"displayName":"CMU_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CMU_HELMET_2021_YELLOW_Acc_preset","label":"Central Michigan (2021, Yellow)"},{"displayName":"CHAR_HELMET_2021_CHROME_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_CHROME_Acc_preset","label":"Charlotte (2021, Chrome)"},{"displayName":"CHAR_HELMET_2021_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_GREEN_Acc_preset","label":"Charlotte (2021, Green)"},{"displayName":"CHAR_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2021_WHITE_Acc_preset","label":"Charlotte (2021, White)"},{"displayName":"CHAR_HELMET_2025_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CHAR_HELMET_2025_WHITE_Acc_preset","label":"Charlotte (2025, White)"},{"displayName":"CIN_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CIN_HELMET_2021_BLACK_Acc_preset","label":"Cincinnati (2021, Black)"},{"displayName":"CIN_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CIN_HELMET_2021_RED_Acc_preset","label":"Cincinnati (2021, RED)"},{"displayName":"CIN_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CIN_HELMET_2021_WHITE_Acc_preset","label":"Cincinnati (2021, White)"},{"displayName":"CLEM_HELMET_2021_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CLEM_HELMET_2021_ORANGE_Acc_preset","label":"Clemson (2021, Orange)"},{"displayName":"CCAR_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CCAR_HELMET_2021_BLACK_Acc_preset","label":"Coastal Carolina (2021, Black)"},{"displayName":"CCAR_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CCAR_HELMET_2021_WHITE_Acc_preset","label":"Coastal Carolina (2021, White)"},{"displayName":"COLO_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2021_BLACK_Acc_preset","label":"Colorado (2021, Black)"},{"displayName":"COLO_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/COLO_HELMET_2021_GOLD_Acc_preset","label":"Colorado (2021, GOLD)"},{"displayName":"CSU_HELMET_2021_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CSU_HELMET_2021_GREEN_Acc_preset","label":"Colorado State (2021, Green)"},{"displayName":"CSU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CSU_HELMET_2021_WHITE_Acc_preset","label":"Colorado State (2021, White)"},{"displayName":"DUKE_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2021_BLUE_Acc_preset","label":"Duke (2021, BLUE)"},{"displayName":"DUKE_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2021_BLACK_Acc_preset","label":"Duke (2021, Black)"},{"displayName":"DUKE_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/DUKE_HELMET_2021_WHITE_Acc_preset","label":"Duke (2021, White)"},{"displayName":"ECU_HELMET_2021_PURPLEPURPLE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2021_PURPLEPURPLE_Acc_preset","label":"East Carolina (2021, Purplepurple)"},{"displayName":"ECU_HELMET_2021_PURPLEYELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ECU_HELMET_2021_PURPLEYELLOW_Acc_preset","label":"East Carolina (2021, Purpleyellow)"},{"displayName":"EMU_HELMET_2021_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/EMU_HELMET_2021_GREEN_Acc_preset","label":"Eastern Michigan (2021, Green)"},{"displayName":"EMU_HELMET_2021_SILVER_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/EMU_HELMET_2021_SILVER_Acc_preset","label":"Eastern Michigan (2021, Silver)"},{"displayName":"FLA_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_BLUE_Acc_preset","label":"Florida (2021, BLUE)"},{"displayName":"FLA_HELMET_2021_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_ORANGE_Acc_preset","label":"Florida (2021, Orange)"},{"displayName":"FLA_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2021_WHITE_Acc_preset","label":"Florida (2021, White)"},{"displayName":"FLA_HELMET_2023_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FLA_HELMET_2023_BLACK_Acc_preset","label":"Florida (2023, Black)"},{"displayName":"FAU_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2021_RED_Acc_preset","label":"Florida Atlantic (2021, RED)"},{"displayName":"FAU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2021_WHITE_Acc_preset","label":"Florida Atlantic (2021, White)"},{"displayName":"FAU_HELMET_2023_WHITEALT_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FAU_HELMET_2023_WHITEALT_Acc_preset","label":"Florida Atlantic (2023, Whitealt)"},{"displayName":"FIU_HELMET_2021_NAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2021_NAVY_Acc_preset","label":"Florida International (2021, NAVY)"},{"displayName":"FIU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2021_WHITE_Acc_preset","label":"Florida International (2021, White)"},{"displayName":"FIU_HELMET_2025_ViceCity_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FIU_HELMET_2025_ViceCity_Acc_preset","label":"Florida International (2025, Vicecity)"},{"displayName":"FSU_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FSU_HELMET_2021_GOLD_Acc_preset","label":"Florida State (2021, GOLD)"},{"displayName":"FRES_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FRES_HELMET_2021_RED_Acc_preset","label":"Fresno State (2021, RED)"},{"displayName":"FRES_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/FRES_HELMET_2021_WHITE_Acc_preset","label":"Fresno State (2021, White)"},{"displayName":"UGA_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UGA_HELMET_2021_RED_Acc_preset","label":"Georgia (2021, RED)"},{"displayName":"GASO_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GASO_HELMET_2021_BLUE_Acc_preset","label":"Georgia Southern (2021, BLUE)"},{"displayName":"GSU_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GSU_HELMET_2021_BLUE_Acc_preset","label":"Georgia State (2021, BLUE)"},{"displayName":"GSU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GSU_HELMET_2021_WHITE_Acc_preset","label":"Georgia State (2021, White)"},{"displayName":"GT_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GT_HELMET_2021_GOLD_Acc_preset","label":"Georgia Tech (2021, GOLD)"},{"displayName":"GT_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/GT_HELMET_2021_WHITE_Acc_preset","label":"Georgia Tech (2021, White)"},{"displayName":"HAW_HELMET_2021_BLACK_02_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_BLACK_02_Acc_preset","label":"Hawaii (2021, Black 02)"},{"displayName":"HAW_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_BLACK_Acc_preset","label":"Hawaii (2021, Black)"},{"displayName":"HAW_HELMET_2021_WHITE_02_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_WHITE_02_Acc_preset","label":"Hawaii (2021, White 02)"},{"displayName":"HAW_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HAW_HELMET_2021_WHITE_Acc_preset","label":"Hawaii (2021, White)"},{"displayName":"HOU_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HOU_HELMET_2021_RED_Acc_preset","label":"Houston (2021, RED)"},{"displayName":"HOU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HOU_HELMET_2021_WHITE_Acc_preset","label":"Houston (2021, White)"},{"displayName":"HOU_HELMET_2021_WHITEBLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/HOU_HELMET_2021_WHITEBLACK_Acc_preset","label":"Houston (2021, Whiteblack)"},{"displayName":"ILL_HELMET_2021_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ILL_HELMET_2021_ORANGE_Acc_preset","label":"Illinois (2021, Orange)"},{"displayName":"IND_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/IND_HELMET_2021_RED_Acc_preset","label":"Indiana (2021, RED)"},{"displayName":"IOWA_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/IOWA_HELMET_2021_BLACK_Acc_preset","label":"Iowa (2021, Black)"},{"displayName":"ISU_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ISU_HELMET_2021_RED_Acc_preset","label":"Iowa State (2021, RED)"},{"displayName":"ISU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ISU_HELMET_2021_WHITE_Acc_preset","label":"Iowa State (2021, White)"},{"displayName":"JVST_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JVST_HELMET_2021_RED_Acc_preset","label":"Jacksonville State (2021, RED)"},{"displayName":"JMU_HELMET_2023_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/JMU_HELMET_2023_WHITE_Acc_preset","label":"James Madison (2023, White)"},{"displayName":"KU_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_BLUE_Acc_preset","label":"Kansas (2021, BLUE)"},{"displayName":"KU_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_BLACK_Acc_preset","label":"Kansas (2021, Black)"},{"displayName":"KU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2021_WHITE_Acc_preset","label":"Kansas (2021, White)"},{"displayName":"KU_HELMET_2025_Blue_Alt_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KU_HELMET_2025_Blue_Alt_Acc_preset","label":"Kansas (2025, Blue Alt)"},{"displayName":"KSU_HELMET_2021_SILVER_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KSU_HELMET_2021_SILVER_Acc_preset","label":"Kansas State (2021, Silver)"},{"displayName":"KENN_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENN_HELMET_2021_YELLOW_Acc_preset","label":"Kennesaw State (2021, Yellow)"},{"displayName":"KENT_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2021_BLACK_Acc_preset","label":"Kent State (2021, Black)"},{"displayName":"KENT_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2021_GOLD_Acc_preset","label":"Kent State (2021, GOLD)"},{"displayName":"KENT_HELMET_2023_Navy_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/KENT_HELMET_2023_Navy_Acc_preset","label":"Kent State (2023, Navy)"},{"displayName":"UK_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2021_BLUE_Acc_preset","label":"Kentucky (2021, BLUE)"},{"displayName":"UK_HELMET_2022_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2022_BLACK_Acc_preset","label":"Kentucky (2022, Black)"},{"displayName":"UK_HELMET_2022_CHROME_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2022_CHROME_Acc_preset","label":"Kentucky (2022, Chrome)"},{"displayName":"UK_HELMET_2022_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UK_HELMET_2022_WHITE_Acc_preset","label":"Kentucky (2022, White)"},{"displayName":"LSU_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LSU_HELMET_2021_GOLD_Acc_preset","label":"LSU (2021, GOLD)"},{"displayName":"LSU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LSU_HELMET_2021_WHITE_Acc_preset","label":"LSU (2021, White)"},{"displayName":"LIB_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LIB_HELMET_2021_BLUE_Acc_preset","label":"Liberty (2021, BLUE)"},{"displayName":"LIB_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LIB_HELMET_2021_RED_Acc_preset","label":"Liberty (2021, RED)"},{"displayName":"LIB_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LIB_HELMET_2021_WHITE_Acc_preset","label":"Liberty (2021, White)"},{"displayName":"ULL_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULL_HELMET_2021_RED_Acc_preset","label":"Louisiana (2021, RED)"},{"displayName":"LT_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LT_HELMET_2021_RED_Acc_preset","label":"Louisiana Tech (2021, RED)"},{"displayName":"LT_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LT_HELMET_2021_WHITE_Acc_preset","label":"Louisiana Tech (2021, White)"},{"displayName":"ULM_HELMET_2016_CAMO_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULM_HELMET_2016_CAMO_Acc_preset","label":"Louisiana-Monroe (2016, CAMO)"},{"displayName":"ULM_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ULM_HELMET_2021_WHITE_Acc_preset","label":"Louisiana-Monroe (2021, White)"},{"displayName":"LOU_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LOU_HELMET_2021_BLACK_Acc_preset","label":"Louisville (2021, Black)"},{"displayName":"LOU_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LOU_HELMET_2021_RED_Acc_preset","label":"Louisville (2021, RED)"},{"displayName":"LOU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/LOU_HELMET_2021_WHITE_Acc_preset","label":"Louisville (2021, White)"},{"displayName":"MRSH_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MRSH_HELMET_2021_WHITE_Acc_preset","label":"Marshall (2021, White)"},{"displayName":"UMD_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMD_HELMET_2021_RED_Acc_preset","label":"Maryland (2021, RED)"},{"displayName":"UMD_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMD_HELMET_2021_WHITE_Acc_preset","label":"Maryland (2021, White)"},{"displayName":"MEM_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2021_BLUE_Acc_preset","label":"Memphis (2021, BLUE)"},{"displayName":"MEM_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2021_WHITE_Acc_preset","label":"Memphis (2021, White)"},{"displayName":"MEM_HELMET_2022_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2022_WHITE_Acc_preset","label":"Memphis (2022, White)"},{"displayName":"MEM_HELMET_2022_WHITEBLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MEM_HELMET_2022_WHITEBLACK_Acc_preset","label":"Memphis (2022, Whiteblack)"},{"displayName":"MIA_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIA_HELMET_2021_WHITE_Acc_preset","label":"Miami (FL) (2021, White)"},{"displayName":"MIAOH_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIAOH_HELMET_2021_WHITE_Acc_preset","label":"Miami (OH) (2021, White)"},{"displayName":"MICH_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MICH_HELMET_2021_BLUE_Acc_preset","label":"Michigan (2021, BLUE)"},{"displayName":"MSU_HELMET_2015_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2015_GREEN_Acc_preset","label":"Michigan State (2015, Green)"},{"displayName":"MSU_HELMET_2017_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2017_WHITE_Acc_preset","label":"Michigan State (2017, White)"},{"displayName":"MSU_HELMET_2021_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2021_GREEN_Acc_preset","label":"Michigan State (2021, Green)"},{"displayName":"MSU_HELMET_2023_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSU_HELMET_2023_BLACK_Acc_preset","label":"Michigan State (2023, Black)"},{"displayName":"MTSU_HELMET_2021_GREY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTSU_HELMET_2021_GREY_Acc_preset","label":"Middle Tennessee (2021, GREY)"},{"displayName":"MTSU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTSU_HELMET_2021_WHITE_Acc_preset","label":"Middle Tennessee (2021, White)"},{"displayName":"MINN_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2021_RED_Acc_preset","label":"Minnesota (2021, RED)"},{"displayName":"MINN_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MINN_HELMET_2021_YELLOW_Acc_preset","label":"Minnesota (2021, Yellow)"},{"displayName":"MSST_HELMET_2021_MAROON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSST_HELMET_2021_MAROON_Acc_preset","label":"Mississippi State (2021, Maroon)"},{"displayName":"MSST_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MSST_HELMET_2021_WHITE_Acc_preset","label":"Mississippi State (2021, White)"},{"displayName":"MIZZ_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIZZ_HELMET_2021_BLACK_Acc_preset","label":"Missouri (2021, Black)"},{"displayName":"MIZZ_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MIZZ_HELMET_2021_YELLOW_Acc_preset","label":"Missouri (2021, Yellow)"},{"displayName":"MTDEW_HELMET_2025_Alt_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTDEW_HELMET_2025_Alt_Acc_preset","label":"Mountain Dew (non-school / branded) (2025, Alt)"},{"displayName":"MTDEW_HELMET_2025_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTDEW_HELMET_2025_GREEN_Acc_preset","label":"Mountain Dew (non-school / branded) (2025, Green)"},{"displayName":"MTDEW_HELMET_2025_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MTDEW_HELMET_2025_WHITE_Acc_preset","label":"Mountain Dew (non-school / branded) (2025, White)"},{"displayName":"NCST_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NCST_HELMET_2021_RED_Acc_preset","label":"NC State (2021, RED)"},{"displayName":"NCST_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NCST_HELMET_2021_WHITE_Acc_preset","label":"NC State (2021, White)"},{"displayName":"NAVY_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NAVY_HELMET_2021_GOLD_Acc_preset","label":"Navy (2021, GOLD)"},{"displayName":"NAVY_HELMET_2021_NAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NAVY_HELMET_2021_NAVY_Acc_preset","label":"Navy (2021, NAVY)"},{"displayName":"NEB_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEB_HELMET_2021_WHITE_Acc_preset","label":"Nebraska (2021, White)"},{"displayName":"NEV_HELMET_2021_SILVER_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEV_HELMET_2021_SILVER_Acc_preset","label":"Nevada (2021, Silver)"},{"displayName":"NEV_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEV_HELMET_2021_WHITE_Acc_preset","label":"Nevada (2021, White)"},{"displayName":"NEV_HELMET_2023_NAVYBLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NEV_HELMET_2023_NAVYBLUE_Acc_preset","label":"Nevada (2023, Navyblue)"},{"displayName":"UNM_HELMET_2021_GRAY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_GRAY_Acc_preset","label":"New Mexico (2021, GRAY)"},{"displayName":"UNM_HELMET_2021_SILVER_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_SILVER_Acc_preset","label":"New Mexico (2021, Silver)"},{"displayName":"UNM_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2021_WHITE_Acc_preset","label":"New Mexico (2021, White)"},{"displayName":"UNM_HELMET_2023_SILVER_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNM_HELMET_2023_SILVER_Acc_preset","label":"New Mexico (2023, Silver)"},{"displayName":"NMSU_HELMET_2021_CRIMSON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NMSU_HELMET_2021_CRIMSON_Acc_preset","label":"New Mexico State (2021, Crimson)"},{"displayName":"UNC_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNC_HELMET_2021_BLUE_Acc_preset","label":"North Carolina (2021, BLUE)"},{"displayName":"UNC_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNC_HELMET_2021_WHITE_Acc_preset","label":"North Carolina (2021, White)"},{"displayName":"UNT_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_BLACK_Acc_preset","label":"North Texas (2021, Black)"},{"displayName":"UNT_HELMET_2021_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_GREEN_Acc_preset","label":"North Texas (2021, Green)"},{"displayName":"UNT_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNT_HELMET_2021_WHITE_Acc_preset","label":"North Texas (2021, White)"},{"displayName":"NIU_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NIU_HELMET_2021_BLACK_Acc_preset","label":"Northern Illinois (2021, Black)"},{"displayName":"NW_HELMET_2021_PURPLE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2021_PURPLE_Acc_preset","label":"Northwestern (2021, Purple)"},{"displayName":"NW_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2021_WHITE_Acc_preset","label":"Northwestern (2021, White)"},{"displayName":"NW_HELMET_2022_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/NW_HELMET_2022_BLACK_Acc_preset","label":"Northwestern (2022, Black)"},{"displayName":"ND_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ND_HELMET_2021_GOLD_Acc_preset","label":"Notre Dame (2021, GOLD)"},{"displayName":"OHIO_HELMET_2023_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OHIO_HELMET_2023_GREEN_Acc_preset","label":"Ohio (2023, Green)"},{"displayName":"OSU_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OSU_HELMET_2021_BLACK_Acc_preset","label":"Ohio State (2021, Black)"},{"displayName":"OSU_HELMET_2021_GREY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OSU_HELMET_2021_GREY_Acc_preset","label":"Ohio State (2021, GREY)"},{"displayName":"OU_HELMET_2021_CRIMSON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_CRIMSON_Acc_preset","label":"Oklahoma (2021, Crimson)"},{"displayName":"OU_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_RED_Acc_preset","label":"Oklahoma (2021, RED)"},{"displayName":"OU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_WHITE_Acc_preset","label":"Oklahoma (2021, White)"},{"displayName":"OU_HELMET_2021_WOODCREAM_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_WOODCREAM_Acc_preset","label":"Oklahoma (2021, Woodcream)"},{"displayName":"OU_HELMET_2021_WOODCRIMSON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OU_HELMET_2021_WOODCRIMSON_Acc_preset","label":"Oklahoma (2021, Woodcrimson)"},{"displayName":"OKST_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2021_BLACK_Acc_preset","label":"Oklahoma State (2021, Black)"},{"displayName":"OKST_HELMET_2021_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2021_ORANGE_Acc_preset","label":"Oklahoma State (2021, Orange)"},{"displayName":"OKST_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/OKST_HELMET_2021_WHITE_Acc_preset","label":"Oklahoma State (2021, White)"},{"displayName":"ODU_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ODU_HELMET_2021_BLUE_Acc_preset","label":"Old Dominion (2021, BLUE)"},{"displayName":"ODU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ODU_HELMET_2021_WHITE_Acc_preset","label":"Old Dominion (2021, White)"},{"displayName":"MISS_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_BLUE_Acc_preset","label":"Ole Miss (2021, BLUE)"},{"displayName":"MISS_HELMET_2021_NAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_NAVY_Acc_preset","label":"Ole Miss (2021, NAVY)"},{"displayName":"MISS_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/MISS_HELMET_2021_WHITE_Acc_preset","label":"Ole Miss (2021, White)"},{"displayName":"ORE_HELMET_2021_WHITEGREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2021_WHITEGREEN_Acc_preset","label":"Oregon (2021, Whitegreen)"},{"displayName":"ORE_HELMET_2021_YELLOWSTEEL_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2021_YELLOWSTEEL_Acc_preset","label":"Oregon (2021, Yellowsteel)"},{"displayName":"ORE_HELMET_2023_EGGSHELL_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORE_HELMET_2023_EGGSHELL_Acc_preset","label":"Oregon (2023, Eggshell)"},{"displayName":"ORST_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORST_HELMET_2021_BLACK_Acc_preset","label":"Oregon State (2021, Black)"},{"displayName":"ORST_HELMET_2023_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/ORST_HELMET_2023_ORANGE_Acc_preset","label":"Oregon State (2023, Orange)"},{"displayName":"PSU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PSU_HELMET_2021_WHITE_Acc_preset","label":"Penn State (2021, White)"},{"displayName":"PSU_HELMET_2022_WHITESTRIPE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PSU_HELMET_2022_WHITESTRIPE_Acc_preset","label":"Penn State (2022, Whitestripe)"},{"displayName":"PITT_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PITT_HELMET_2021_YELLOW_Acc_preset","label":"Pittsburgh (2021, Yellow)"},{"displayName":"PUR_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2021_BLACK_Acc_preset","label":"Purdue (2021, Black)"},{"displayName":"PUR_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2021_GOLD_Acc_preset","label":"Purdue (2021, GOLD)"},{"displayName":"PUR_HELMET_2023_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/PUR_HELMET_2023_GOLD_Acc_preset","label":"Purdue (2023, GOLD)"},{"displayName":"RICE_HELMET_2021_NAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RICE_HELMET_2021_NAVY_Acc_preset","label":"Rice (2021, NAVY)"},{"displayName":"RICE_HELMET_2021_SILVER_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RICE_HELMET_2021_SILVER_Acc_preset","label":"Rice (2021, Silver)"},{"displayName":"RUTG_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/RUTG_HELMET_2021_RED_Acc_preset","label":"Rutgers (2021, RED)"},{"displayName":"SMU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SMU_HELMET_2021_WHITE_Acc_preset","label":"SMU (2021, White)"},{"displayName":"SMU_HELMET_2021_WHITEALT_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SMU_HELMET_2021_WHITEALT_Acc_preset","label":"SMU (2021, Whitealt)"},{"displayName":"SHSU_HELMET_2021_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SHSU_HELMET_2021_ORANGE_Acc_preset","label":"Sam Houston State (2021, Orange)"},{"displayName":"SHSU_HELMET_2023_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SHSU_HELMET_2023_ORANGE_Acc_preset","label":"Sam Houston State (2023, Orange)"},{"displayName":"SDSU_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SDSU_HELMET_2021_BLACK_Acc_preset","label":"San Diego State (2021, Black)"},{"displayName":"SJSU_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SJSU_HELMET_2021_BLUE_Acc_preset","label":"San Jose State (2021, BLUE)"},{"displayName":"SJSU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SJSU_HELMET_2021_WHITE_Acc_preset","label":"San Jose State (2021, White)"},{"displayName":"USA_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USA_HELMET_2021_WHITE_Acc_preset","label":"South Alabama (2021, White)"},{"displayName":"SC_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SC_HELMET_2021_BLACK_Acc_preset","label":"South Carolina (2021, Black)"},{"displayName":"SC_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SC_HELMET_2021_RED_Acc_preset","label":"South Carolina (2021, RED)"},{"displayName":"SC_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SC_HELMET_2021_WHITE_Acc_preset","label":"South Carolina (2021, White)"},{"displayName":"USF_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USF_HELMET_2021_GOLD_Acc_preset","label":"South Florida (2021, GOLD)"},{"displayName":"USF_HELMET_2021_WHITEGREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USF_HELMET_2021_WHITEGREEN_Acc_preset","label":"South Florida (2021, Whitegreen)"},{"displayName":"USM_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USM_HELMET_2021_BLACK_Acc_preset","label":"Southern Miss (2021, Black)"},{"displayName":"USM_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USM_HELMET_2021_WHITE_Acc_preset","label":"Southern Miss (2021, White)"},{"displayName":"STAN_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2021_WHITE_Acc_preset","label":"Stanford (2021, White)"},{"displayName":"STAN_HELMET_2023_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/STAN_HELMET_2023_BLACK_Acc_preset","label":"Stanford (2023, Black)"},{"displayName":"SYR_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/SYR_HELMET_2021_WHITE_Acc_preset","label":"Syracuse (2021, White)"},{"displayName":"TCU_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TCU_HELMET_2021_BLACK_Acc_preset","label":"TCU (2021, Black)"},{"displayName":"TCU_HELMET_2021_PURPLE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TCU_HELMET_2021_PURPLE_Acc_preset","label":"TCU (2021, Purple)"},{"displayName":"TEMP_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2021_RED_Acc_preset","label":"Temple (2021, RED) [TEMP]"},{"displayName":"TEM_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEM_HELMET_2021_RED_Acc_preset","label":"Temple (2021, RED) [TEM]"},{"displayName":"TEM_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEM_HELMET_2021_WHITE_Acc_preset","label":"Temple (2021, White)"},{"displayName":"TEMP_HELMET_2025_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2025_RED_Acc_preset","label":"Temple (2025, RED)"},{"displayName":"TEMP_HELMET_2025_WHI_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEMP_HELMET_2025_WHI_Acc_preset","label":"Temple (2025, WHI)"},{"displayName":"TENN_HELMET_2021_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2021_ORANGE_Acc_preset","label":"Tennessee (2021, Orange)"},{"displayName":"TENN_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2021_WHITE_Acc_preset","label":"Tennessee (2021, White)"},{"displayName":"TENN_HELMET_2022_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2022_BLACK_Acc_preset","label":"Tennessee (2022, Black)"},{"displayName":"TENN_HELMET_2025_Smokey_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TENN_HELMET_2025_Smokey_Acc_preset","label":"Tennessee (2025, Smokey)"},{"displayName":"TEX_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TEX_HELMET_2021_WHITE_Acc_preset","label":"Texas (2021, White)"},{"displayName":"TAMU_HELMET_2021_MAROON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TAMU_HELMET_2021_MAROON_Acc_preset","label":"Texas A&M (2021, Maroon)"},{"displayName":"TXST_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TXST_HELMET_2021_GOLD_Acc_preset","label":"Texas State (2021, GOLD)"},{"displayName":"TTU_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2021_BLACK_Acc_preset","label":"Texas Tech (2021, Black)"},{"displayName":"TTU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TTU_HELMET_2021_WHITE_Acc_preset","label":"Texas Tech (2021, White)"},{"displayName":"TOL_HELMET_2021_NAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TOL_HELMET_2021_NAVY_Acc_preset","label":"Toledo (2021, NAVY)"},{"displayName":"TOL_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TOL_HELMET_2021_YELLOW_Acc_preset","label":"Toledo (2021, Yellow)"},{"displayName":"TROY_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TROY_HELMET_2021_RED_Acc_preset","label":"Troy (2021, RED)"},{"displayName":"TROY_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TROY_HELMET_2021_WHITE_Acc_preset","label":"Troy (2021, White)"},{"displayName":"TULN_HELMET_2021_GREEN_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2021_GREEN_Acc_preset","label":"Tulane (2021, Green)"},{"displayName":"TULN_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2021_WHITE_Acc_preset","label":"Tulane (2021, White)"},{"displayName":"TULN_HELMET_2025_CITY_EDITION_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2025_CITY_EDITION_Acc_preset","label":"Tulane (2025, CITY Edition)"},{"displayName":"TULN_HELMET_2025_Wumbu_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TULN_HELMET_2025_Wumbu_Acc_preset","label":"Tulane (2025, Wumbu)"},{"displayName":"TLSA_HELMET_2023_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/TLSA_HELMET_2023_GOLD_Acc_preset","label":"Tulsa (2023, GOLD)"},{"displayName":"UAB_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UAB_HELMET_2021_GOLD_Acc_preset","label":"UAB (2021, GOLD)"},{"displayName":"UAB_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UAB_HELMET_2021_WHITE_Acc_preset","label":"UAB (2021, White)"},{"displayName":"UCF_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2021_GOLD_Acc_preset","label":"UCF (2021, GOLD)"},{"displayName":"UCF_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2021_WHITE_Acc_preset","label":"UCF (2021, White)"},{"displayName":"UCF_HELMET_2023_SPACE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCF_HELMET_2023_SPACE_Acc_preset","label":"UCF (2023, Space)"},{"displayName":"UCLA_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCLA_HELMET_2021_GOLD_Acc_preset","label":"UCLA (2021, GOLD)"},{"displayName":"UCLA_HELMET_2023_GOLDALT_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UCLA_HELMET_2023_GOLDALT_Acc_preset","label":"UCLA (2023, Goldalt)"},{"displayName":"CONN_HELMET_2021_NAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CONN_HELMET_2021_NAVY_Acc_preset","label":"UConn (2021, NAVY)"},{"displayName":"CONN_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/CONN_HELMET_2021_WHITE_Acc_preset","label":"UConn (2021, White)"},{"displayName":"UMASS_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMASS_HELMET_2021_RED_Acc_preset","label":"UMass (2021, RED)"},{"displayName":"UMASS_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UMASS_HELMET_2021_WHITE_Acc_preset","label":"UMass (2021, White)"},{"displayName":"UNLV_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2021_RED_Acc_preset","label":"UNLV (2021, RED)"},{"displayName":"UNLV_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UNLV_HELMET_2021_WHITE_Acc_preset","label":"UNLV (2021, White)"},{"displayName":"USC_HELMET_2021_CARDINAL_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USC_HELMET_2021_CARDINAL_Acc_preset","label":"USC (2021, Cardinal)"},{"displayName":"USC_HELMET_2021_CARDINALCHROME_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USC_HELMET_2021_CARDINALCHROME_Acc_preset","label":"USC (2021, Cardinalchrome)"},{"displayName":"UTEP_HELMET_2021_ORANGE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTEP_HELMET_2021_ORANGE_Acc_preset","label":"UTEP (2021, Orange)"},{"displayName":"UTEP_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTEP_HELMET_2021_WHITE_Acc_preset","label":"UTEP (2021, White)"},{"displayName":"UTEP_HELMET_2025_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTEP_HELMET_2025_BLUE_Acc_preset","label":"UTEP (2025, BLUE)"},{"displayName":"UTSA_HELMET_2021_NAVY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTSA_HELMET_2021_NAVY_Acc_preset","label":"UTSA (2021, NAVY)"},{"displayName":"UTSA_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTSA_HELMET_2021_WHITE_Acc_preset","label":"UTSA (2021, White)"},{"displayName":"UTAH_HELMET_2020_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2020_WHITE_Acc_preset","label":"Utah (2020, White)"},{"displayName":"UTAH_HELMET_2021_RED_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2021_RED_Acc_preset","label":"Utah (2021, RED)"},{"displayName":"UTAH_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UTAH_HELMET_2021_WHITE_Acc_preset","label":"Utah (2021, White)"},{"displayName":"USU_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USU_HELMET_2021_BLACK_Acc_preset","label":"Utah State (2021, Black)"},{"displayName":"USU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/USU_HELMET_2021_WHITE_Acc_preset","label":"Utah State (2021, White)"},{"displayName":"VAN_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VAN_HELMET_2021_GOLD_Acc_preset","label":"Vanderbilt (2021, GOLD)"},{"displayName":"VAN_HELMET_2022_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VAN_HELMET_2022_WHITE_Acc_preset","label":"Vanderbilt (2022, White)"},{"displayName":"UVA_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UVA_HELMET_2021_BLUE_Acc_preset","label":"Virginia (2021, BLUE)"},{"displayName":"UVA_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/UVA_HELMET_2021_WHITE_Acc_preset","label":"Virginia (2021, White)"},{"displayName":"VT_HELMET_2016_MAROON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2016_MAROON_Acc_preset","label":"Virginia Tech (2016, Maroon)"},{"displayName":"VT_HELMET_2016_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2016_WHITE_Acc_preset","label":"Virginia Tech (2016, White)"},{"displayName":"VT_HELMET_2021_MAROON_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2021_MAROON_Acc_preset","label":"Virginia Tech (2021, Maroon)"},{"displayName":"VT_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/VT_HELMET_2021_WHITE_Acc_preset","label":"Virginia Tech (2021, White)"},{"displayName":"WAKE_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WAKE_HELMET_2021_BLACK_Acc_preset","label":"Wake Forest (2021, Black)"},{"displayName":"WASH_HELMET_2021_GOLD_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2021_GOLD_Acc_preset","label":"Washington (2021, GOLD)"},{"displayName":"WASH_HELMET_2021_GOLDCHROME_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2021_GOLDCHROME_Acc_preset","label":"Washington (2021, Goldchrome)"},{"displayName":"WASH_HELMET_2023_PURPLECHROME_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WASH_HELMET_2023_PURPLECHROME_Acc_preset","label":"Washington (2023, Purplechrome)"},{"displayName":"WSU_HELMET_2021_DARKGRAY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WSU_HELMET_2021_DARKGRAY_Acc_preset","label":"Washington State (2021, Darkgray)"},{"displayName":"WSU_HELMET_2021_GRAY_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WSU_HELMET_2021_GRAY_Acc_preset","label":"Washington State (2021, GRAY)"},{"displayName":"WVU_HELMET_2021_BLUE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2021_BLUE_Acc_preset","label":"West Virginia (2021, BLUE)"},{"displayName":"WVU_HELMET_2021_YELLOW_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WVU_HELMET_2021_YELLOW_Acc_preset","label":"West Virginia (2021, Yellow)"},{"displayName":"WKU_HELMET_2021_BLACK_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2021_BLACK_Acc_preset","label":"Western Kentucky (2021, Black)"},{"displayName":"WKU_HELMET_2021_CHROME_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2021_CHROME_Acc_preset","label":"Western Kentucky (2021, Chrome)"},{"displayName":"WKU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WKU_HELMET_2021_WHITE_Acc_preset","label":"Western Kentucky (2021, White)"},{"displayName":"WMU_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WMU_HELMET_2021_WHITE_Acc_preset","label":"Western Michigan (2021, White)"},{"displayName":"WIS_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WIS_HELMET_2021_WHITE_Acc_preset","label":"Wisconsin (2021, White)"},{"displayName":"WYO_HELMET_2021_WHITE_Acc_preset","path":"content/characters/player/parts/uniforms/helmets/helmet_presets/WYO_HELMET_2021_WHITE_Acc_preset","label":"Wyoming (2021, White)"}]},"decals":[{"label":"Adidas (2022)","brand":"Adidas","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2022_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2022_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2022_rsm"},{"label":"Adidas (2023)","brand":"Adidas","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_rsm"},{"label":"Adidas Plastic (2023)","brand":"Adidas","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_Plastic_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_Plastic_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_Plastic_rsm"},{"label":"Adidas Shiny (2023)","brand":"Adidas","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_Shiny_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_Shiny_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_Shiny_rsm"},{"label":"Adidas Trefoil (2025)","brand":"Adidas","col":"content/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2025_trefoil_col","norm":"content/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2025_trefoil_norm","rsm":"content/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2025_trefoil_rsm"},{"label":"Adidas WithText (2023)","brand":"Adidas","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_WithText_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_WithText_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2023_WithText_rsm"},{"label":"Jumpman Cotton (2022)","brand":"Jumpman","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Jumpman_Decal_2022_Cotton_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Jumpman_Decal_2022_Cotton_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Jumpman_Decal_2022_Cotton_rsm"},{"label":"Jumpman Diamond (2022)","brand":"Jumpman","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Jumpman_Decal_2022_Diamond_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Jumpman_Decal_2022_Diamond_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Jumpman_Decal_2022_Diamond_rsm"},{"label":"New Balance Cotton (2025)","brand":"New Balance","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/NB_Decal_2025_Cotton_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/NB_Decal_2025_Cotton_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/NB_Decal_2025_Cotton_rsm"},{"label":"Nike Cotton (2022)","brand":"Nike","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Nike_Decal_2022_Cotton_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Nike_Decal_2022_Cotton_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Nike_Decal_2022_Cotton_rsm"},{"label":"Nike Diamond (2022)","brand":"Nike","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Nike_Decal_2022_Diamond_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Nike_Decal_2022_Diamond_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Nike_Decal_2022_Diamond_rsm"},{"label":"Nike Plastic (2023)","brand":"Nike","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/Nike_Decal_2023_Plastic_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Nike_Decal_2023_Plastic_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/Nike_Decal_2023_Plastic_rsm"},{"label":"Nike ShoeDuck (2025)","brand":"Nike","col":"content/characters/player/parts/uniforms/decals/vendors/NIKE_Decal_2025_ShoeDuck_col","norm":"content/characters/player/parts/uniforms/decals/vendors/NIKE_Decal_2025_ShoeDuck_norm","rsm":"content/characters/player/parts/uniforms/decals/vendors/NIKE_Decal_2025_ShoeDuck_rsm"},{"label":"Under Armour Cotton (2022)","brand":"Under Armour","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2022_Cotton_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2022_Cotton_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2022_Cotton_rsm"},{"label":"Under Armour Cotton (2023)","brand":"Under Armour","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2023_Cotton_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2023_Cotton_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2023_Cotton_rsm"},{"label":"Under Armour Metallic (2022)","brand":"Under Armour","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2022_Metallic_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2022_Metallic_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2022_Metallic_rsm"},{"label":"Under Armour Plastic (2023)","brand":"Under Armour","col":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2023_Plastic_col","norm":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2023_Plastic_norm","rsm":"ContentShared/characters/player/parts/uniforms/decals/vendors/UA_Decal_2023_Plastic_rsm"}]};

const state = {
  extensionId: null, // unused now -- this page is bundled in the extension, so messaging is internal
  urls: [],
  selectedUrl: null,
  payload: null,
  variants: [],
  selectedVariantIdx: 0,
  originalRawText: '', // snapshot taken when a payload is first fetched, for Reset to loaded
  spacingOriginals: {}, // jerseyKey -> the numberSpacing.x value seen the first time it was rendered, for the per-field reset button
  sizeOriginals: {}, // jerseyKey -> { chest: z, back: z, shoulder: z, sleeve: z } seen the first time, for per-field reset buttons
  lastSelections: {}, // gsKey -> last applied text, so the picker shows what was actually chosen
  tintSelectedPiece: 'jersey', // which piece "Apply" (single-piece) targets; switch via the piece selector
  conferenceTintPieces: { jersey: true, pants: true, socks: true }, // same, for the conference logo tint feature (parked, see v0.49)
  // ONE shared custom palette (v0.73) -- not per-piece, not per-decal. Replaced
  // the old per-piece decalPreviewOverride.values{jersey,pants,socks} model,
  // which caused real confusion: each piece silently remembering its OWN
  // preview colors meant "Apply All" could write jersey=red, pants=whatever
  // green it was last left at, pieces never intentionally synced, and there
  // was no obvious way to tell that was happening. Now there's exactly one
  // custom color set, editable in its own section, used by both Decal Tint
  // and Number Color. null per-channel means "not customized yet, use the
  // real team color."
  customPalette: { R: null, G: null, B: null },
  decalPreviewOverride: { enabled: false } // on/off only now -- no per-piece values
};

// Bump this with every round of changes to this tool. See CHANGELOG.md for what
// each version actually changed.
const EDITOR_VERSION = 'v0.75';

// ---------- logging ----------
function log(msg, level = '') {
  const el = document.getElementById('logOut');
  const div = document.createElement('div');
  div.className = 'entry' + (level ? ' ' + level : '');
  const ts = new Date().toLocaleTimeString();
  div.innerHTML = `<span class="ts">${ts}</span>${escapeHtml(msg)}`;
  el.appendChild(div);
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

// ---------- extension messaging ----------
// This page is bundled inside the extension itself (opened via the toolbar icon),
// so messages go through chrome.runtime.sendMessage() with no target ID -- that
// routes to this same extension's own background.js via chrome.runtime.onMessage,
// which now shares its handling logic with the external-facing API.
function sendToExtension(type, extra = {}) {
  return new Promise((resolve, reject) => {
    if (!window.chrome || !chrome.runtime || !chrome.runtime.sendMessage) {
      reject(new Error('chrome.runtime is unavailable. This page must be opened as chrome-extension://…/editor.html, not a regular file or web page.'));
      return;
    }
    try {
      chrome.runtime.sendMessage(Object.assign({ type }, extra), (response) => {
        if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
        if (!response) { reject(new Error('No response from background.js.')); return; }
        if (response.ok === false) { reject(new Error(response.error || 'Extension returned an error.')); return; }
        resolve(response);
      });
    } catch (err) { reject(err); }
  });
}

// ---------- status / urls ----------
document.getElementById('btnStatus').addEventListener('click', refreshStatus);
async function refreshStatus() {
  try {
    const r = await sendToExtension('TB_GET_STATUS');
    state.urls = r.urls || [];
    renderStatus(r);
    renderUrlList();
    log('Status refreshed — helper v' + r.helperVersion + ', ' + state.urls.length + ' known URL(s).', 'ok');
  } catch (err) {
    document.getElementById('statusOut').innerHTML = `<div class="badge err">error</div> ${escapeHtml(err.message)}`;
    log('Status refresh failed: ' + err.message, 'err');
  }
}

function renderStatus(r) {
  const s = r.status || {};
  const nm = s.networkMocking || {};
  const lastHit = s.lastMockHit;
  document.getElementById('statusOut').innerHTML = `
    <div class="status-grid">
      <div>Helper version: <b>${escapeHtml(r.helperVersion || '—')}</b></div>
      <div>Active page key: <b>${escapeHtml(r.activePage?.pageKey || '—')}</b></div>
      <div>Network mocking: <b>${nm.enabled ? 'enabled' : 'off'}</b></div>
      <div>Mocks stored: <b>${Object.keys(r.mocks || {}).length}</b></div>
      <div style="grid-column:1 / -1;">Last mock hit: <b>${lastHit ? escapeHtml(lastHit.teamName || lastHit.url) + ' @ ' + new Date(lastHit.usedAt).toLocaleTimeString() : '—'}</b></div>
    </div>`;
}

function renderUrlList() {
  const el = document.getElementById('urlListOut');
  if (!state.urls.length) { el.innerHTML = '<div class="hint">No nonce-primary.json URLs discovered yet — open a team in Team Builder, then refresh status.</div>'; return; }
  el.innerHTML = '<div class="urllist">' + state.urls.map((u, i) => `
    <div class="urlitem${u.url === state.selectedUrl ? ' selected' : ''}" data-idx="${i}">${escapeHtml(u.url)}</div>
  `).join('') + '</div>';
  el.querySelectorAll('.urlitem').forEach(node => {
    node.addEventListener('click', () => {
      state.selectedUrl = state.urls[+node.dataset.idx].url;
      document.getElementById('urlManual').value = state.selectedUrl;
      renderUrlList();
    });
  });
}

// ---------- fetch / parse payload ----------
document.getElementById('btnFetch').addEventListener('click', fetchPayload);
async function fetchPayload() {
  let url = document.getElementById('urlManual').value.trim();
  if (!url && state.urls.length) {
    url = state.urls[0].url;
    document.getElementById('urlManual').value = url;
    log('No URL selected — using the top discovered one automatically.');
  }
  if (!url) { log('No URL entered, and none discovered yet — click "Refresh status" first.', 'err'); return; }
  state.selectedUrl = url;
  try {
    const r = await sendToExtension('TB_FETCH_JSON', { url });
    document.getElementById('rawText').value = r.text;
    state.originalRawText = r.text;
    loadFromRawText();
    log('Fetched payload (' + r.text.length + ' chars).', 'ok');
  } catch (err) {
    log('Fetch failed: ' + err.message, 'err');
  }
}

document.getElementById('btnResync').addEventListener('click', loadFromRawText);
function loadFromRawText() {
  const raw = document.getElementById('rawText').value;
  try {
    state.payload = JSON.parse(raw);
  } catch (err) {
    log('Could not parse current text as JSON: ' + err.message, 'err');
    return;
  }
  state.variants = deriveVariants(state.payload);
  state.selectedVariantIdx = 0;
  state.lastSelections = {};
  state.spacingOriginals = {};
  const teamName = state.payload?.teamData?.teamInfos?.TEAM_NAME;
  document.getElementById('teamNameBadge').textContent = teamName ? ' — ' + teamName : '';
  renderEditor();
}

function deriveVariants(payload) {
  const helmets = payload?.teamData?.frostbiteData?.uniformParts?.helmets || {};
  const jerseys = payload?.teamData?.frostbiteData?.uniformParts?.jerseys || {};
  const pants = payload?.teamData?.frostbiteData?.uniformParts?.pants || {};
  const socks = payload?.teamData?.frostbiteData?.uniformParts?.socks || {};
  const suffixOf = (key, kind) => {
    // Was [A-Za-z0-9]+ -- too narrow. Confirmed real variant names contain
    // parentheses ("DarkMode(Home)", "1920s(Reimagined)") and possibly other
    // punctuation, which that pattern silently failed to match, dropping the
    // whole variant from the list. This is deliberately permissive (any
    // character) since there's no reliable way to enumerate every symbol a
    // team name might use -- the only real constraint is that it can't be
    // followed by another "-<kind>" later in the string, which greedy
    // matching against the trailing $ already handles correctly.
    const m = key.match(new RegExp('-(.+)-' + kind + '$', 'i'));
    return m ? m[1] : null;
  };
  const suffixes = new Set();
  Object.keys(helmets).forEach(k => { const s = suffixOf(k, 'helmet'); if (s) suffixes.add(s); });
  Object.keys(jerseys).forEach(k => { const s = suffixOf(k, 'jersey'); if (s) suffixes.add(s); });
  Object.keys(pants).forEach(k => { const s = suffixOf(k, 'pants'); if (s) suffixes.add(s); });
  Object.keys(socks).forEach(k => { const s = suffixOf(k, 'socks'); if (s) suffixes.add(s); });
  return [...suffixes].map(suffix => ({
    label: suffix.replace(/([a-z])([A-Z])/g, '$1 $2'),
    suffix,
    helmetKey: Object.keys(helmets).find(k => suffixOf(k, 'helmet') === suffix) || null,
    jerseyKey: Object.keys(jerseys).find(k => suffixOf(k, 'jersey') === suffix) || null,
    pantsKey: Object.keys(pants).find(k => suffixOf(k, 'pants') === suffix) || null,
    socksKey: Object.keys(socks).find(k => suffixOf(k, 'socks') === suffix) || null
  }));
}

// ---------- deep get/set ----------
function getDeep(obj, path) {
  let cur = obj;
  for (const p of path) { if (cur == null) return undefined; cur = cur[p]; }
  return cur;
}
function setDeep(obj, path, value) {
  let cur = obj;
  for (let i = 0; i < path.length - 1; i++) {
    if (cur[path[i]] == null) return false;
    cur = cur[path[i]];
  }
  cur[path[path.length - 1]] = value;
  return true;
}

// ---------- field definitions ----------
function isUsableFontPath(p) { return !!p && !/\/(numbers|name_fonts)\/?$/i.test(p); }

// Confirmed by testing: /comp/ isn't needed at all. Both arrayTexture.textureId and
// the overlay's textureId work fine set to the exact same non-/comp/ path. The real
// original bug was simply that arrayTexture can't be left blank -- it was never about
// the two fields needing different path shapes. This strips /comp/ from whatever the
// catalog has on record (most entries have it, a few newer ones don't), so both
// targets always get the same normalized, confirmed-working form.
function stripCompSegment(path) {
  return path.replace('/uniforms/comp/', '/uniforms/');
}

// ---------- per-font number layout profiles ----------
// A font isn't just a texture swap -- correctly rendering it also depends on
// fields the old font-picker never touched: the flat numberSpacing.x the
// slider exposes, a per-number kerning correction table
// (numberMaterialSettings.playerNumberAdjust), AND four offset/scale blocks
// (chest/back/shoulder/sleeve) that control where each number sits and how
// big it renders -- confirmed as the actual cause of numbers sitting too
// high/low or too big/small when a font is swapped without them, since those
// values were calibrated for whatever font was there before, not the new one.
//
// v0.24 shipped a first pass sourced from ARIZ_JERSEY_2023_BLUE.xml (base
// item, empty PlayerNumberAdjList) + ARIZ_MixAndMatch.xml (Mix & Match
// FootballMixMatchPart entry) stitched together. SUPERSEDED here --
// ARIZ_JERSEY_2026_PRABLUE.xml (a JerseyPartItem, matching the "Arizona
// (2026)" catalog entry by name) turned out to be a cleaner, more direct
// source: it carries numberMaterialSettings.PlayerNumberAdjList (and the four
// offset/scale blocks) directly on the base item itself, at the exact
// nesting level the live JSON uses (sibling to offsetScaleSpacing, no Mix &
// Match indirection needed). Corrected values below replace the v0.24 ones:
// numberSpacing -0.36 -> -0.41, Number 11 -0.59 -> -0.67, and a second real
// outlier surfaced that the empty v0.24 source couldn't show at all --
// Number 31 at -0.58, distinct from every other non-11 entry at -0.53.
//
// CAVEAT: this same source file has hasShoulder=false and hasSleeve=false --
// Arizona's own jersey doesn't use those number positions at all. Its
// shoulderNumberOffsetScale/sleeveNumberOffsetScale values below are
// structurally present but were never actually rendered or eyeballed for
// this font, unlike chest/back which Arizona's jersey does use. Worth
// specifically testing this font on a team whose jersey DOES have shoulder
// or sleeve numbers before trusting those two fields.
//
// This is a lookup, not hardcoded logic, on purpose: adding the next font
// once its reference data is confirmed is one more entry here, no code
// changes. Keyed by font displayName (matches CATALOG.numberFonts.jersey
// entries' own displayName field).
//
// STATUS: Arizona (2026) is the first entry -- still a test case, not yet
// confirmed in-game even in this corrected form. Don't add more until this
// one's confirmed to actually move things in Team Builder, not just write
// without error.
const NUMBER_LAYOUT_PROFILES = {
  // ---- All fonts below: batch-imported from All_uniforms_TB.zip (v0.30/v0.31) ----
  // Matched by resolving each file's numberComp ref -> TintArrayTexture instance
  // -> Overlay_1.textures.colorTexture ref -> font asset name, not by filename.
  // Teams sharing a font each keep their OWN entry+values (v0.31) rather than
  // one shared entry -- picking one team's font never changes another team's.
  // A few pure same-team/same-font duplicates were merged back into their
  // original catalog slot in this pass (see CHANGELOG v0.32).
  'AFA_Jersey_2021_NUM_Array': {
    numberSpacing: -0.334362,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.73 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'AFA_Jersey_2025_Alt_NUM_Array': {
    numberSpacing: -0.65,
    playerNumberAdjust: [
      { number: 10, width: -0.65 }, { number: 11, width: -0.65 }, { number: 12, width: -0.65 },
      { number: 13, width: -0.65 }, { number: 14, width: -0.65 }, { number: 15, width: -0.65 },
      { number: 16, width: -0.65 }, { number: 17, width: -0.68 }, { number: 18, width: -0.65 },
      { number: 19, width: -0.65 }, { number: 21, width: -0.65 }, { number: 31, width: -0.65 },
      { number: 41, width: -0.65 }, { number: 51, width: -0.65 }, { number: 61, width: -0.65 },
      { number: 71, width: -0.68 }, { number: 81, width: -0.65 }, { number: 91, width: -0.65 }
    ]
  },
  'AKR_Jersey_2025_NUM_Array': {
    numberSpacing: -0.424,
    playerNumberAdjust: [
      { number: 10, width: -0.49 }, { number: 11, width: -0.72 }, { number: 12, width: -0.49 },
      { number: 13, width: -0.49 }, { number: 14, width: -0.49 }, { number: 15, width: -0.49 },
      { number: 16, width: -0.49 }, { number: 17, width: -0.49 }, { number: 18, width: -0.49 },
      { number: 19, width: -0.49 }, { number: 21, width: -0.49 }, { number: 31, width: -0.49 },
      { number: 41, width: -0.49 }, { number: 51, width: -0.49 }, { number: 61, width: -0.49 },
      { number: 71, width: -0.49 }, { number: 81, width: -0.49 }, { number: 91, width: -0.49 }
    ]
  },
  'APP_JERSEY_2023_BLACK': {
    numberSpacing: -0.46,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.65 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.51 }, { number: 31, width: -0.51 },
      { number: 41, width: -0.51 }, { number: 51, width: -0.51 }, { number: 61, width: -0.51 },
      { number: 71, width: -0.51 }, { number: 81, width: -0.51 }, { number: 91, width: -0.51 }
    ]
  },
  // Reverted in v0.27: the four offset/scale blocks and numberSpacingOverrides
  // caused real in-game errors once tested and are pulled out entirely, not
  // just zeroed -- if either turns out to be needed later, treat it as a new
  // experiment on its own rather than restoring this. numberSpacing is set to
  // -0.48 here per direct in-game observation, overriding whatever any
  // reference XML said (-0.36 in v0.24, -0.41 in v0.25/26) -- this value
  // came from testing, not a file. playerNumberAdjust keeps the corrected
  // ARIZ_JERSEY_2026_PRABLUE.xml values (11 at -0.67, 31 at -0.58, everything
  // else at -0.53) since that part was never implicated in the errors.
  'ARIZ_Jersey_2026_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.67 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.53 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'ARK_Jersey_2021_NUM_Array': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.63 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'ARK_Jersey_2023_NUM_Array': {
    numberSpacing: -0.39,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.68 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.54 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'ARMY_Jersey_2021_NUM_Array': {
    numberSpacing: -0.404939115,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.66 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.59 }, { number: 15, width: -0.59 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'ARMY_Jersey_2024_NUM_Array': {
    numberSpacing: -0.52,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.64 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.59 }, { number: 15, width: -0.59 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 40, width: -0.47 }, { number: 41, width: -0.57 }, { number: 42, width: -0.49 },
      { number: 43, width: -0.47 }, { number: 44, width: -0.45 }, { number: 45, width: -0.47 },
      { number: 46, width: -0.47 }, { number: 47, width: -0.51 }, { number: 48, width: -0.47 },
      { number: 49, width: -0.51 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'ARMY_Jersey_2025_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.66 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'ARST_Jersey_2023_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.61 }, { number: 11, width: -0.69 }, { number: 12, width: -0.61 },
      { number: 13, width: -0.61 }, { number: 14, width: -0.61 }, { number: 15, width: -0.61 },
      { number: 16, width: -0.61 }, { number: 17, width: -0.61 }, { number: 18, width: -0.61 },
      { number: 19, width: -0.61 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.59 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'ASU_JERSEY_2025_BLACK': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.7 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.6 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.6 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.6 }, { number: 31, width: -0.6 },
      { number: 41, width: -0.6 }, { number: 51, width: -0.6 }, { number: 61, width: -0.6 },
      { number: 71, width: -0.6 }, { number: 81, width: -0.6 }, { number: 91, width: -0.6 }
    ]
  },
  'ASU_JERSEY_2025_THROWBACK': {
    numberSpacing: -0.47,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.68 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'ASU_Jersey_2025_02_NUM_Array': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.64 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  // Source: ASU_JERSEY_2023_YELLOW.xml (a JerseyPartItem), user-confirmed as
  // matching the "Arizona State (Current 2nd Alternate)" catalog entry.
  // numberSpacing corrected to -0.355 (user caught an accidental save in the
  // source file that had put it at -0.157 -- reverted and re-confirmed).
  // -0.355 sits comfortably in line with its Arizona State siblings (-0.37
  // to -0.47) and the general -0.6/-0.3 range used elsewhere in this file.
  'ASU_Jersey_2024_NUM_Array': {
    numberSpacing: -0.355,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.61 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.45 }, { number: 31, width: -0.45 },
      { number: 41, width: -0.45 }, { number: 51, width: -0.45 }, { number: 61, width: -0.45 },
      { number: 71, width: -0.45 }, { number: 81, width: -0.45 }, { number: 91, width: -0.45 }
    ]
  },
  'AUB_Jersey_2023_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.64 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.56 }, { number: 51, width: -0.56 }, { number: 61, width: -0.56 },
      { number: 71, width: -0.56 }, { number: 81, width: -0.56 }, { number: 91, width: -0.56 }
    ]
  },
  'BALL_JERSEY_2024_BLACK': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.62 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'BAY_Jersey_2021_NUM_Array': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.75 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.6 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.6 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.6 }, { number: 31, width: -0.6 },
      { number: 41, width: -0.6 }, { number: 51, width: -0.6 }, { number: 61, width: -0.6 },
      { number: 71, width: -0.6 }, { number: 81, width: -0.6 }, { number: 91, width: -0.6 }
    ]
  },
  'BC_Jersey_2025_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.75 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.6 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.6 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.6 }, { number: 31, width: -0.6 },
      { number: 41, width: -0.6 }, { number: 51, width: -0.6 }, { number: 61, width: -0.6 },
      { number: 71, width: -0.6 }, { number: 81, width: -0.6 }, { number: 91, width: -0.6 }
    ]
  },
  'BGSU_JERSEY_2023_BROWN': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.59 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'BSU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.68 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.6 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.55 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.62 }, { number: 51, width: -0.59 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.59 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'BUFF_JERSEY_2023_BLUE': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.7 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.56 }, { number: 15, width: -0.61 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'BYU_JERSEY_2023_BLACK': {
    numberSpacing: -0.49,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.66 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.56 }, { number: 51, width: -0.56 }, { number: 61, width: -0.56 },
      { number: 71, width: -0.56 }, { number: 81, width: -0.56 }, { number: 91, width: -0.56 }
    ]
  },
  'BYU_Jersey_2024_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.62 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'CCAR_Jersey_2021_02_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.63 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.54 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'CHAR_Jersey_2025_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.51 }, { number: 11, width: -0.62 }, { number: 12, width: -0.51 },
      { number: 13, width: -0.51 }, { number: 14, width: -0.51 }, { number: 15, width: -0.51 },
      { number: 16, width: -0.51 }, { number: 17, width: -0.51 }, { number: 18, width: -0.51 },
      { number: 19, width: -0.51 }, { number: 21, width: -0.51 }, { number: 31, width: -0.51 },
      { number: 40, width: -0.38 }, { number: 41, width: -0.51 }, { number: 42, width: -0.38 },
      { number: 43, width: -0.38 }, { number: 44, width: -0.32 }, { number: 45, width: -0.38 },
      { number: 46, width: -0.38 }, { number: 48, width: -0.38 }, { number: 49, width: -0.38 },
      { number: 51, width: -0.51 }, { number: 61, width: -0.51 }, { number: 71, width: -0.51 },
      { number: 81, width: -0.51 }, { number: 91, width: -0.51 }
    ]
  },
  'CIN_Jersey_2025_NUM_Array': {
    numberSpacing: -0.39,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.59 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.55 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.5 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.5 }, { number: 24, width: -0.35 },
      { number: 27, width: -0.35 }, { number: 31, width: -0.5 }, { number: 34, width: -0.35 },
      { number: 37, width: -0.35 }, { number: 40, width: -0.35 }, { number: 41, width: -0.45 },
      { number: 42, width: -0.35 }, { number: 43, width: -0.35 }, { number: 44, width: -0.33 },
      { number: 45, width: -0.35 }, { number: 46, width: -0.35 }, { number: 47, width: -0.35 },
      { number: 48, width: -0.35 }, { number: 49, width: -0.35 }, { number: 51, width: -0.5 },
      { number: 54, width: -0.35 }, { number: 57, width: -0.35 }, { number: 61, width: -0.5 },
      { number: 64, width: -0.35 }, { number: 67, width: -0.35 }, { number: 71, width: -0.48 },
      { number: 74, width: -0.42 }, { number: 77, width: -0.35 }, { number: 81, width: -0.5 },
      { number: 84, width: -0.35 }, { number: 87, width: -0.35 }, { number: 91, width: -0.5 },
      { number: 94, width: -0.35 }, { number: 97, width: -0.35 }
    ]
  },
  'CLEM_JERSEY_2023_ORANGE': {
    numberSpacing: -0.39,
    playerNumberAdjust: [
      { number: 10, width: -0.47 }, { number: 11, width: -0.57 }, { number: 12, width: -0.47 },
      { number: 13, width: -0.47 }, { number: 14, width: -0.47 }, { number: 15, width: -0.47 },
      { number: 16, width: -0.47 }, { number: 17, width: -0.47 }, { number: 18, width: -0.47 },
      { number: 19, width: -0.47 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  },
  'CMU_JERSEY_2023_MAROON': {
    numberSpacing: -0.365,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.57 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.48 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.48 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.48 }, { number: 31, width: -0.48 },
      { number: 41, width: -0.48 }, { number: 51, width: -0.48 }, { number: 61, width: -0.48 },
      { number: 71, width: -0.48 }, { number: 81, width: -0.48 }, { number: 91, width: -0.48 }
    ]
  },
  'CMU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.56,
    playerNumberAdjust: [
      { number: 10, width: -0.64 }, { number: 11, width: -0.71 }, { number: 12, width: -0.64 },
      { number: 13, width: -0.64 }, { number: 14, width: -0.64 }, { number: 15, width: -0.64 },
      { number: 16, width: -0.64 }, { number: 17, width: -0.64 }, { number: 18, width: -0.64 },
      { number: 19, width: -0.64 }, { number: 21, width: -0.64 }, { number: 31, width: -0.64 },
      { number: 41, width: -0.64 }, { number: 51, width: -0.64 }, { number: 61, width: -0.64 },
      { number: 71, width: -0.64 }, { number: 81, width: -0.64 }, { number: 91, width: -0.64 }
    ]
  },
  'COLO_Jersey_2024_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.65 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.57 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.49 }, { number: 24, width: -0.44 },
      { number: 31, width: -0.49 }, { number: 34, width: -0.44 }, { number: 40, width: -0.39 },
      { number: 41, width: -0.49 }, { number: 42, width: -0.39 }, { number: 43, width: -0.39 },
      { number: 44, width: -0.38 }, { number: 45, width: -0.4 }, { number: 46, width: -0.38 },
      { number: 47, width: -0.43 }, { number: 48, width: -0.39 }, { number: 49, width: -0.39 },
      { number: 51, width: -0.53 }, { number: 54, width: -0.41 }, { number: 61, width: -0.49 },
      { number: 64, width: -0.43 }, { number: 71, width: -0.52 }, { number: 74, width: -0.54 },
      { number: 81, width: -0.49 }, { number: 84, width: -0.43 }, { number: 91, width: -0.49 },
      { number: 94, width: -0.43 }
    ]
  },
  'CONN_Jersey_2021_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.67 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.52 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.52 }, { number: 31, width: -0.52 },
      { number: 41, width: -0.52 }, { number: 51, width: -0.52 }, { number: 61, width: -0.52 },
      { number: 71, width: -0.52 }, { number: 81, width: -0.52 }, { number: 91, width: -0.52 }
    ]
  },
  'CSU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.46 }, { number: 11, width: -0.58 }, { number: 12, width: -0.46 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.46 }, { number: 15, width: -0.46 },
      { number: 16, width: -0.46 }, { number: 17, width: -0.46 }, { number: 18, width: -0.46 },
      { number: 19, width: -0.46 }, { number: 21, width: -0.5 }, { number: 24, width: -0.32 },
      { number: 31, width: -0.5 }, { number: 34, width: -0.32 }, { number: 41, width: -0.46 },
      { number: 42, width: -0.3 }, { number: 43, width: -0.3 }, { number: 44, width: -0.27 },
      { number: 45, width: -0.3 }, { number: 46, width: -0.3 }, { number: 47, width: -0.42 },
      { number: 48, width: -0.3 }, { number: 49, width: -0.3 }, { number: 51, width: -0.5 },
      { number: 54, width: -0.32 }, { number: 61, width: -0.5 }, { number: 64, width: -0.32 },
      { number: 71, width: -0.5 }, { number: 74, width: -0.42 }, { number: 81, width: -0.5 },
      { number: 84, width: -0.32 }, { number: 91, width: -0.5 }, { number: 94, width: -0.32 }
    ]
  },
  'DEL_Jersey_2024_NUM_Array': {
    numberSpacing: -0.59,
    playerNumberAdjust: [
      { number: 10, width: -0.63 }, { number: 11, width: -0.73 }, { number: 12, width: -0.63 },
      { number: 13, width: -0.63 }, { number: 14, width: -0.63 }, { number: 15, width: -0.63 },
      { number: 16, width: -0.63 }, { number: 17, width: -0.57 }, { number: 18, width: -0.63 },
      { number: 19, width: -0.63 }, { number: 21, width: -0.69 }, { number: 27, width: -0.53 },
      { number: 31, width: -0.69 }, { number: 37, width: -0.53 }, { number: 40, width: -0.58 },
      { number: 41, width: -0.69 }, { number: 43, width: -0.58 }, { number: 44, width: -0.58 },
      { number: 45, width: -0.58 }, { number: 46, width: -0.58 }, { number: 47, width: -0.51 },
      { number: 48, width: -0.58 }, { number: 49, width: -0.58 }, { number: 50, width: -0.58 },
      { number: 51, width: -0.69 }, { number: 52, width: -0.58 }, { number: 53, width: -0.58 },
      { number: 54, width: -0.58 }, { number: 55, width: -0.58 }, { number: 56, width: -0.58 },
      { number: 57, width: -0.51 }, { number: 58, width: -0.58 }, { number: 59, width: -0.58 },
      { number: 61, width: -0.69 }, { number: 67, width: -0.53 }, { number: 70, width: -0.58 },
      { number: 71, width: -0.69 }, { number: 72, width: -0.59 }, { number: 73, width: -0.59 },
      { number: 74, width: -0.59 }, { number: 75, width: -0.58 }, { number: 76, width: -0.58 },
      { number: 77, width: -0.52 }, { number: 78, width: -0.58 }, { number: 79, width: -0.58 },
      { number: 81, width: -0.69 }, { number: 87, width: -0.53 }, { number: 91, width: -0.69 },
      { number: 97, width: -0.53 }
    ]
  },
  'DUKE_JERSEY_2023_BLACK': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.66 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'ECU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.72 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.62 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.69 }, { number: 31, width: -0.69 },
      { number: 41, width: -0.69 }, { number: 51, width: -0.69 }, { number: 61, width: -0.69 },
      { number: 71, width: -0.65 }, { number: 81, width: -0.69 }, { number: 91, width: -0.69 }
    ]
  },
  'ECU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.65 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.65 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.55 }, { number: 42, width: -0.43 }, { number: 43, width: -0.43 },
      { number: 45, width: -0.43 }, { number: 46, width: -0.43 }, { number: 47, width: -0.43 },
      { number: 48, width: -0.43 }, { number: 49, width: -0.43 }, { number: 51, width: -0.56 },
      { number: 54, width: -0.52 }, { number: 61, width: -0.56 }, { number: 71, width: -0.56 },
      { number: 81, width: -0.56 }, { number: 91, width: -0.56 }
    ]
  },
  'EMU_JERSEY_2025_BLACK': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.56 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'FAU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.35,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.57 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.41 }, { number: 31, width: -0.41 },
      { number: 41, width: -0.41 }, { number: 51, width: -0.41 }, { number: 61, width: -0.41 },
      { number: 71, width: -0.38 }, { number: 81, width: -0.41 }, { number: 91, width: -0.41 }
    ]
  },
  'FAU_Jersey_2025-2_NUM_Array': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.68 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 44, width: -0.42 }, { number: 51, width: -0.58 },
      { number: 61, width: -0.58 }, { number: 71, width: -0.58 }, { number: 81, width: -0.58 },
      { number: 91, width: -0.58 }
    ]
  },
  'FAU_Jersey_2025_NUM_Array': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.59 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.48 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.48 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.48 }, { number: 31, width: -0.48 },
      { number: 41, width: -0.48 }, { number: 51, width: -0.48 }, { number: 61, width: -0.48 },
      { number: 71, width: -0.48 }, { number: 81, width: -0.48 }, { number: 91, width: -0.48 }
    ]
  },
  'FIU_JERSEY_2023_NAVY': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.56 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'FIU_Jersey_2024_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.56 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'FIU_Jersey_2025_Vice_NUM_Array': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.61 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.52 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.52 }, { number: 31, width: -0.52 },
      { number: 41, width: -0.52 }, { number: 51, width: -0.52 }, { number: 61, width: -0.52 },
      { number: 71, width: -0.52 }, { number: 81, width: -0.52 }, { number: 91, width: -0.52 }
    ]
  },
  'FLA_JERSEY_2023_THROWBACK': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.59 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'FLA_Jersey_2021_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.68 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.57 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.51 }, { number: 31, width: -0.51 },
      { number: 41, width: -0.51 }, { number: 51, width: -0.51 }, { number: 61, width: -0.51 },
      { number: 71, width: -0.51 }, { number: 81, width: -0.51 }, { number: 91, width: -0.51 }
    ]
  },
  'FRES_Jersey_2021_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.47 }, { number: 11, width: -0.62 }, { number: 12, width: -0.47 },
      { number: 13, width: -0.47 }, { number: 14, width: -0.47 }, { number: 15, width: -0.47 },
      { number: 16, width: -0.47 }, { number: 17, width: -0.47 }, { number: 18, width: -0.47 },
      { number: 19, width: -0.47 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'FSU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.46,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.69 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.59 }, { number: 15, width: -0.59 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'GASO_JERSEY_2023_BLUE': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.66 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'GSU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.52,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.71 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.59 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.6 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 40, width: -0.48 }, { number: 41, width: -0.65 }, { number: 42, width: -0.48 },
      { number: 43, width: -0.48 }, { number: 44, width: -0.48 }, { number: 45, width: -0.5 },
      { number: 46, width: -0.48 }, { number: 47, width: -0.52 }, { number: 48, width: -0.48 },
      { number: 49, width: -0.48 }, { number: 51, width: -0.62 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.62 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'GT_Jersey_2026_NUM_Array': {
    numberSpacing: -0.41,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.62 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.56 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.52 }, { number: 31, width: -0.52 },
      { number: 41, width: -0.52 }, { number: 51, width: -0.52 }, { number: 61, width: -0.52 },
      { number: 71, width: -0.52 }, { number: 81, width: -0.52 }, { number: 91, width: -0.52 }
    ]
  },
  'GT_Jersey_2026_White_NUM_Array': {
    numberSpacing: -0.41,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.62 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.56 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.52 }, { number: 31, width: -0.52 },
      { number: 41, width: -0.52 }, { number: 51, width: -0.52 }, { number: 61, width: -0.52 },
      { number: 71, width: -0.52 }, { number: 81, width: -0.52 }, { number: 91, width: -0.52 }
    ]
  },
  'HAW_Jersey_2021_NUM_Array': {
    numberSpacing: -0.41,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.63 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.49 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.53 }, { number: 24, width: -0.37 },
      { number: 31, width: -0.53 }, { number: 34, width: -0.37 }, { number: 40, width: -0.35 },
      { number: 41, width: -0.53 }, { number: 42, width: -0.35 }, { number: 43, width: -0.35 },
      { number: 44, width: -0.32 }, { number: 45, width: -0.35 }, { number: 46, width: -0.35 },
      { number: 47, width: -0.35 }, { number: 48, width: -0.35 }, { number: 49, width: -0.35 },
      { number: 51, width: -0.53 }, { number: 54, width: -0.37 }, { number: 61, width: -0.53 },
      { number: 64, width: -0.37 }, { number: 71, width: -0.53 }, { number: 74, width: -0.37 },
      { number: 81, width: -0.53 }, { number: 84, width: -0.37 }, { number: 91, width: -0.53 },
      { number: 94, width: -0.37 }
    ]
  },
  'HOU_JERSEY_2023_RED': {
    numberSpacing: -0.36,
    playerNumberAdjust: [
      { number: 10, width: -0.45 }, { number: 11, width: -0.56 }, { number: 12, width: -0.45 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.52 }, { number: 15, width: -0.45 },
      { number: 16, width: -0.45 }, { number: 17, width: -0.45 }, { number: 18, width: -0.45 },
      { number: 19, width: -0.45 }, { number: 21, width: -0.42 }, { number: 31, width: -0.44 },
      { number: 41, width: -0.45 }, { number: 51, width: -0.42 }, { number: 61, width: -0.42 },
      { number: 71, width: -0.42 }, { number: 81, width: -0.42 }, { number: 91, width: -0.42 }
    ]
  },
  'ILL_JERSEY_2023_TRHOWBACK': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.62 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'ILL_Jersey_2021_NUM_Array': {
    numberSpacing: -0.404939115,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.62 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.53 }, { number: 23, width: -0.43 },
      { number: 31, width: -0.54 }, { number: 32, width: -0.46 }, { number: 33, width: -0.48 },
      { number: 34, width: -0.46 }, { number: 35, width: -0.46 }, { number: 36, width: -0.46 },
      { number: 37, width: -0.46 }, { number: 38, width: -0.46 }, { number: 39, width: -0.45 },
      { number: 41, width: -0.53 }, { number: 43, width: -0.43 }, { number: 51, width: -0.53 },
      { number: 53, width: -0.43 }, { number: 61, width: -0.53 }, { number: 63, width: -0.43 },
      { number: 71, width: -0.53 }, { number: 73, width: -0.43 }, { number: 81, width: -0.53 },
      { number: 83, width: -0.43 }, { number: 91, width: -0.53 }, { number: 93, width: -0.43 }
    ]
  },
  'IND_Jersey_2022_NUM_Array': {
    numberSpacing: -0.39,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.63 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 24, width: -0.35 },
      { number: 31, width: -0.5 }, { number: 34, width: -0.35 }, { number: 41, width: -0.47 },
      { number: 42, width: -0.35 }, { number: 43, width: -0.35 }, { number: 44, width: -0.35 },
      { number: 45, width: -0.35 }, { number: 46, width: -0.35 }, { number: 47, width: -0.35 },
      { number: 48, width: -0.35 }, { number: 49, width: -0.35 }, { number: 51, width: -0.5 },
      { number: 54, width: -0.35 }, { number: 61, width: -0.5 }, { number: 64, width: -0.35 },
      { number: 71, width: -0.5 }, { number: 74, width: -0.35 }, { number: 81, width: -0.5 },
      { number: 84, width: -0.35 }, { number: 91, width: -0.5 }, { number: 94, width: -0.35 }
    ]
  },
  'IOWA_Jersey_2021_NUM_Array': {
    numberSpacing: -0.39,
    playerNumberAdjust: [
      { number: 10, width: -0.47 }, { number: 11, width: -0.55 }, { number: 12, width: -0.47 },
      { number: 13, width: -0.47 }, { number: 14, width: -0.53 }, { number: 15, width: -0.47 },
      { number: 16, width: -0.47 }, { number: 17, width: -0.47 }, { number: 18, width: -0.47 },
      { number: 19, width: -0.47 }, { number: 21, width: -0.49 }, { number: 31, width: -0.49 },
      { number: 41, width: -0.49 }, { number: 51, width: -0.49 }, { number: 61, width: -0.49 },
      { number: 71, width: -0.49 }, { number: 81, width: -0.49 }, { number: 91, width: -0.49 }
    ]
  },
  'ISU_JERSEY_2024_THROWBACK': {
    numberSpacing: -0.53,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.69 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.62 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.62 }, { number: 51, width: -0.62 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.62 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'ISU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.28,
    playerNumberAdjust: [
      { number: 10, width: -0.43 }, { number: 11, width: -0.55 }, { number: 12, width: -0.43 },
      { number: 13, width: -0.43 }, { number: 14, width: -0.43 }, { number: 15, width: -0.43 },
      { number: 16, width: -0.43 }, { number: 17, width: -0.43 }, { number: 18, width: -0.43 },
      { number: 19, width: -0.43 }, { number: 21, width: -0.4 }, { number: 31, width: -0.4 },
      { number: 41, width: -0.4 }, { number: 51, width: -0.4 }, { number: 61, width: -0.4 },
      { number: 71, width: -0.4 }, { number: 81, width: -0.4 }, { number: 91, width: -0.4 }
    ]
  },
  'ISU_Jersey_2024_NUM_Array': {
    numberSpacing: -0.26,
    playerNumberAdjust: [
      { number: 10, width: -0.42 }, { number: 11, width: -0.54 }, { number: 12, width: -0.42 },
      { number: 13, width: -0.42 }, { number: 14, width: -0.42 }, { number: 15, width: -0.42 },
      { number: 16, width: -0.42 }, { number: 17, width: -0.42 }, { number: 18, width: -0.42 },
      { number: 19, width: -0.42 }, { number: 21, width: -0.4 }, { number: 31, width: -0.4 },
      { number: 41, width: -0.4 }, { number: 51, width: -0.4 }, { number: 61, width: -0.4 },
      { number: 71, width: -0.4 }, { number: 81, width: -0.4 }, { number: 91, width: -0.4 }
    ]
  },
  'JMU_JERSEY_2023_PURPLE': {
    numberSpacing: -0.52,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.7 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.62 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.6 }, { number: 31, width: -0.6 },
      { number: 41, width: -0.6 }, { number: 51, width: -0.6 }, { number: 61, width: -0.6 },
      { number: 71, width: -0.6 }, { number: 81, width: -0.6 }, { number: 91, width: -0.6 }
    ]
  },
  'JVST_JERSEY_2023_RED': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.66 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.59 }, { number: 15, width: -0.59 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.59 }, { number: 31, width: -0.59 },
      { number: 41, width: -0.59 }, { number: 51, width: -0.59 }, { number: 61, width: -0.59 },
      { number: 71, width: -0.59 }, { number: 81, width: -0.59 }, { number: 91, width: -0.59 }
    ]
  },
  'KENN_Jersey_2025_NUM_Array': {
    numberSpacing: -0.49,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 10, width: -0.58 }, { number: 11, width: -0.67 },
      { number: 12, width: -0.58 }, { number: 13, width: -0.58 }, { number: 14, width: -0.58 },
      { number: 15, width: -0.58 }, { number: 16, width: -0.58 }, { number: 17, width: -0.58 },
      { number: 18, width: -0.58 }, { number: 19, width: -0.58 }, { number: 21, width: -0.58 },
      { number: 31, width: -0.58 }, { number: 40, width: -0.45 }, { number: 41, width: -0.58 },
      { number: 42, width: -0.45 }, { number: 43, width: -0.45 }, { number: 44, width: -0.45 },
      { number: 45, width: -0.45 }, { number: 46, width: -0.45 }, { number: 47, width: -0.45 },
      { number: 48, width: -0.45 }, { number: 49, width: -0.45 }, { number: 50, width: -0.45 },
      { number: 51, width: -0.58 }, { number: 52, width: -0.45 }, { number: 53, width: -0.45 },
      { number: 54, width: -0.45 }, { number: 55, width: -0.45 }, { number: 56, width: -0.45 },
      { number: 57, width: -0.45 }, { number: 58, width: -0.45 }, { number: 59, width: -0.45 },
      { number: 61, width: -0.58 }, { number: 70, width: -0.45 }, { number: 71, width: -0.58 },
      { number: 72, width: -0.45 }, { number: 73, width: -0.45 }, { number: 74, width: -0.45 },
      { number: 75, width: -0.45 }, { number: 76, width: -0.45 }, { number: 77, width: -0.45 },
      { number: 78, width: -0.45 }, { number: 79, width: -0.45 }, { number: 81, width: -0.58 }
    ]
  },
  'KENT_Jersey_2023_NUM_Array': {
    numberSpacing: -0.43,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.57 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.44 }, { number: 31, width: -0.44 },
      { number: 41, width: -0.44 }, { number: 51, width: -0.44 }, { number: 61, width: -0.44 },
      { number: 71, width: -0.44 }, { number: 81, width: -0.44 }, { number: 91, width: -0.44 }
    ]
  },
  'KENT_Jersey_2025_NUM_Array': {
    numberSpacing: -0.41,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.56 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'KSU_JERSEY_2023_PURPLE': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.62 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'KU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.55,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.7 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.62 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.62 }, { number: 51, width: -0.62 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.62 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'KU_Jersey_2024_NUM_Array': {
    numberSpacing: -0.41,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.62 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'LOU_Jersey_2024_NUM_Array': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.68 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.62 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.62 }, { number: 51, width: -0.62 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.62 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'LOU_Jersey_2025_NUM_Array': {
    numberSpacing: -0.55,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.7 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.6 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.6 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.6 }, { number: 31, width: -0.6 },
      { number: 41, width: -0.6 }, { number: 51, width: -0.6 }, { number: 61, width: -0.6 },
      { number: 71, width: -0.6 }, { number: 81, width: -0.6 }, { number: 91, width: -0.6 }
    ]
  },
  'LSU_JERSEY_2023_GOLD': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.46 }, { number: 11, width: -0.55 }, { number: 12, width: -0.46 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.49 }, { number: 15, width: -0.46 },
      { number: 16, width: -0.46 }, { number: 17, width: -0.46 }, { number: 18, width: -0.46 },
      { number: 19, width: -0.46 }, { number: 21, width: -0.46 }, { number: 31, width: -0.46 },
      { number: 41, width: -0.46 }, { number: 51, width: -0.46 }, { number: 61, width: -0.46 },
      { number: 71, width: -0.46 }, { number: 81, width: -0.46 }, { number: 91, width: -0.46 }
    ]
  },
  'LSU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.69 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.56 }, { number: 51, width: -0.56 }, { number: 61, width: -0.56 },
      { number: 71, width: -0.56 }, { number: 81, width: -0.56 }, { number: 91, width: -0.56 }
    ]
  },
  'LT_Jersey_2023_NUM_Array': {
    numberSpacing: -0.43,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.6 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.59 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.52 }, { number: 31, width: -0.52 },
      { number: 41, width: -0.52 }, { number: 51, width: -0.52 }, { number: 61, width: -0.52 },
      { number: 71, width: -0.52 }, { number: 81, width: -0.52 }, { number: 91, width: -0.52 }
    ]
  },
  'MEM_JERSEY_2023_BLUE': {
    numberSpacing: -0.334046632,
    playerNumberAdjust: [
      { number: 10, width: -0.46 }, { number: 11, width: -0.56 }, { number: 12, width: -0.46 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.43 }, { number: 15, width: -0.46 },
      { number: 16, width: -0.46 }, { number: 17, width: -0.46 }, { number: 18, width: -0.46 },
      { number: 19, width: -0.46 }, { number: 21, width: -0.46 }, { number: 31, width: -0.46 },
      { number: 41, width: -0.44 }, { number: 51, width: -0.46 }, { number: 61, width: -0.46 },
      { number: 71, width: -0.46 }, { number: 81, width: -0.46 }, { number: 91, width: -0.46 }
    ]
  },
  'MIAOH_Jersey_2021_NUM_Array': {
    numberSpacing: -0.53,
    playerNumberAdjust: [
      { number: 10, width: -0.64 }, { number: 11, width: -0.66 }, { number: 12, width: -0.64 },
      { number: 13, width: -0.64 }, { number: 14, width: -0.64 }, { number: 15, width: -0.64 },
      { number: 16, width: -0.64 }, { number: 17, width: -0.64 }, { number: 18, width: -0.64 },
      { number: 19, width: -0.64 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'MIA_Jersey_2024_NUM_Array': {
    numberSpacing: -0.43,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.64 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'MIA_Jersey_2025_Camo_NUM_Array': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.46 }, { number: 11, width: -0.57 }, { number: 12, width: -0.46 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.46 }, { number: 15, width: -0.46 },
      { number: 16, width: -0.46 }, { number: 17, width: -0.46 }, { number: 18, width: -0.46 },
      { number: 19, width: -0.46 }, { number: 21, width: -0.46 }, { number: 31, width: -0.46 },
      { number: 41, width: -0.46 }, { number: 51, width: -0.46 }, { number: 61, width: -0.46 },
      { number: 71, width: -0.46 }, { number: 81, width: -0.46 }, { number: 91, width: -0.46 }
    ]
  },
  'MIA_Jersey_2025_NUM_Array': {
    numberSpacing: -0.445,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.54 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.48 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.48 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.48 }, { number: 31, width: -0.48 },
      { number: 41, width: -0.48 }, { number: 51, width: -0.48 }, { number: 61, width: -0.48 },
      { number: 71, width: -0.48 }, { number: 81, width: -0.48 }, { number: 91, width: -0.48 }
    ]
  },
  'MICH_JERSEY_2023_BLUE': {
    numberSpacing: -0.47,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.67 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.59 }, { number: 15, width: -0.59 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'MINN_Jersey_2021_NUM_Array': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.44 }, { number: 11, width: -0.57 }, { number: 12, width: -0.44 },
      { number: 13, width: -0.44 }, { number: 14, width: -0.44 }, { number: 15, width: -0.44 },
      { number: 16, width: -0.44 }, { number: 17, width: -0.44 }, { number: 18, width: -0.44 },
      { number: 19, width: -0.44 }, { number: 21, width: -0.44 }, { number: 31, width: -0.44 },
      { number: 41, width: -0.44 }, { number: 51, width: -0.44 }, { number: 61, width: -0.44 },
      { number: 71, width: -0.44 }, { number: 81, width: -0.44 }, { number: 91, width: -0.44 }
    ]
  },
  'MISS_JERSEY_2024_BLUE': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.59 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'MIST_Jersey_2024_NUM_Array': {
    numberSpacing: -0.47,
    playerNumberAdjust: [
      { number: 10, width: -0.63 }, { number: 11, width: -0.67 }, { number: 12, width: -0.63 },
      { number: 13, width: -0.65 }, { number: 14, width: -0.6 }, { number: 15, width: -0.64 },
      { number: 16, width: -0.63 }, { number: 17, width: -0.63 }, { number: 18, width: -0.63 },
      { number: 19, width: -0.63 }, { number: 21, width: -0.565 }, { number: 23, width: -0.53 },
      { number: 26, width: -0.53 }, { number: 30, width: -0.5 }, { number: 31, width: -0.59 },
      { number: 32, width: -0.5 }, { number: 33, width: -0.53 }, { number: 34, width: -0.5 },
      { number: 35, width: -0.5 }, { number: 36, width: -0.5 }, { number: 37, width: -0.5 },
      { number: 38, width: -0.5 }, { number: 39, width: -0.5 }, { number: 41, width: -0.565 },
      { number: 43, width: -0.53 }, { number: 46, width: -0.53 }, { number: 51, width: -0.59 },
      { number: 52, width: -0.5 }, { number: 53, width: -0.53 }, { number: 53, width: -0.53 },
      { number: 55, width: -0.5 }, { number: 56, width: -0.53 }, { number: 56, width: -0.5 },
      { number: 57, width: -0.5 }, { number: 59, width: -0.5 }, { number: 60, width: -0.5 },
      { number: 61, width: -0.59 }, { number: 62, width: -0.53 }, { number: 63, width: -0.53 },
      { number: 64, width: -0.5 }, { number: 65, width: -0.53 }, { number: 66, width: -0.53 },
      { number: 67, width: -0.53 }, { number: 68, width: -0.5 }, { number: 69, width: -0.5 },
      { number: 71, width: -0.61 }, { number: 73, width: -0.6 }, { number: 76, width: -0.6 },
      { number: 81, width: -0.565 }, { number: 83, width: -0.53 }, { number: 86, width: -0.51 },
      { number: 91, width: -0.565 }, { number: 93, width: -0.53 }, { number: 96, width: -0.51 }
    ]
  },
  'MIZZ_Jersey_2021_NUM_Array': {
    numberSpacing: -0.47,
    playerNumberAdjust: [
      { number: 10, width: -0.61 }, { number: 11, width: -0.66 }, { number: 12, width: -0.61 },
      { number: 13, width: -0.61 }, { number: 14, width: -0.61 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.59 }, { number: 18, width: -0.61 },
      { number: 19, width: -0.61 }, { number: 21, width: -0.51 }, { number: 31, width: -0.51 },
      { number: 41, width: -0.51 }, { number: 51, width: -0.51 }, { number: 61, width: -0.51 },
      { number: 71, width: -0.51 }, { number: 81, width: -0.51 }, { number: 91, width: -0.51 }
    ]
  },
  'MRSH_JERSEY_2023_BLACK': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.63 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.49 }, { number: 31, width: -0.49 },
      { number: 41, width: -0.49 }, { number: 51, width: -0.49 }, { number: 61, width: -0.49 },
      { number: 71, width: -0.49 }, { number: 81, width: -0.49 }, { number: 91, width: -0.49 }
    ]
  },
  'MRSH_Jersey_2025_NUM_Array': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.61 }, { number: 11, width: -0.7 }, { number: 12, width: -0.61 },
      { number: 13, width: -0.61 }, { number: 14, width: -0.61 }, { number: 15, width: -0.61 },
      { number: 16, width: -0.61 }, { number: 17, width: -0.61 }, { number: 18, width: -0.61 },
      { number: 19, width: -0.61 }, { number: 21, width: -0.61 }, { number: 31, width: -0.61 },
      { number: 41, width: -0.61 }, { number: 51, width: -0.61 }, { number: 61, width: -0.61 },
      { number: 71, width: -0.61 }, { number: 81, width: -0.61 }, { number: 91, width: -0.61 }
    ]
  },
  'MSST_Jersey_2021_NUM_Array': {
    numberSpacing: -0.381234229,
    playerNumberAdjust: [
      { number: 10, width: -0.49 }, { number: 11, width: -0.63 }, { number: 12, width: -0.49 },
      { number: 13, width: -0.49 }, { number: 14, width: -0.55 }, { number: 15, width: -0.49 },
      { number: 16, width: -0.49 }, { number: 17, width: -0.6 }, { number: 18, width: -0.49 },
      { number: 19, width: -0.49 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  },
  'MSST_Jersey_2024_NUM_Array': {
    numberSpacing: -0.381234229,
    playerNumberAdjust: [
      { number: 10, width: -0.49 }, { number: 11, width: -0.63 }, { number: 12, width: -0.49 },
      { number: 13, width: -0.49 }, { number: 14, width: -0.55 }, { number: 15, width: -0.49 },
      { number: 16, width: -0.49 }, { number: 17, width: -0.6 }, { number: 18, width: -0.49 },
      { number: 19, width: -0.49 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  },
  'MSST_Jersey_2025_Throwback_NUM_Array': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.54 }, { number: 11, width: -0.66 }, { number: 12, width: -0.54 },
      { number: 13, width: -0.54 }, { number: 14, width: -0.6 }, { number: 15, width: -0.54 },
      { number: 16, width: -0.54 }, { number: 17, width: -0.54 }, { number: 18, width: -0.54 },
      { number: 19, width: -0.54 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.54 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'MSU_JERSEY_2023_GREEN': {
    numberSpacing: -0.33,
    playerNumberAdjust: [
      { number: 10, width: -0.46 }, { number: 11, width: -0.56 }, { number: 12, width: -0.46 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.43 }, { number: 15, width: -0.46 },
      { number: 16, width: -0.46 }, { number: 17, width: -0.46 }, { number: 18, width: -0.46 },
      { number: 19, width: -0.46 }, { number: 21, width: -0.46 }, { number: 31, width: -0.46 },
      { number: 41, width: -0.44 }, { number: 51, width: -0.46 }, { number: 61, width: -0.46 },
      { number: 71, width: -0.46 }, { number: 81, width: -0.46 }, { number: 91, width: -0.46 }
    ]
  },
  'MTSU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.54 }, { number: 11, width: -0.62 }, { number: 12, width: -0.54 },
      { number: 13, width: -0.54 }, { number: 14, width: -0.58 }, { number: 15, width: -0.54 },
      { number: 16, width: -0.54 }, { number: 17, width: -0.54 }, { number: 18, width: -0.54 },
      { number: 19, width: -0.54 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.54 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'NAVY_Jersey_2021_NUM_Array': {
    numberSpacing: -0.36,
    playerNumberAdjust: [
      { number: 10, width: -0.46 }, { number: 11, width: -0.57 }, { number: 12, width: -0.46 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.46 }, { number: 15, width: -0.46 },
      { number: 16, width: -0.46 }, { number: 17, width: -0.46 }, { number: 18, width: -0.46 },
      { number: 19, width: -0.46 }, { number: 21, width: -0.46 }, { number: 31, width: -0.46 },
      { number: 41, width: -0.46 }, { number: 51, width: -0.46 }, { number: 61, width: -0.46 },
      { number: 71, width: -0.46 }, { number: 81, width: -0.46 }, { number: 91, width: -0.46 }
    ]
  },
  'NAVY_Jersey_2023_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.66 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'NAVY_Jersey_2024_NUM_Array': {
    numberSpacing: -0.49,
    playerNumberAdjust: [
      { number: 10, width: -0.66 }, { number: 11, width: -0.8 }, { number: 12, width: -0.66 },
      { number: 13, width: -0.66 }, { number: 14, width: -0.66 }, { number: 15, width: -0.66 },
      { number: 16, width: -0.66 }, { number: 17, width: -0.66 }, { number: 18, width: -0.66 },
      { number: 19, width: -0.66 }, { number: 21, width: -0.66 }, { number: 31, width: -0.66 },
      { number: 41, width: -0.66 }, { number: 51, width: -0.66 }, { number: 61, width: -0.66 },
      { number: 71, width: -0.66 }, { number: 81, width: -0.66 }, { number: 91, width: -0.66 }
    ]
  },
  'NAVY_Jersey_2025_NUM_Array': {
    numberSpacing: -0.46,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.52 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.52 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.48 }, { number: 31, width: -0.48 },
      { number: 41, width: -0.48 }, { number: 51, width: -0.48 }, { number: 61, width: -0.48 },
      { number: 71, width: -0.48 }, { number: 81, width: -0.48 }, { number: 91, width: -0.48 }
    ]
  },
  'NCST_Jersey_2021_NUM_Array': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.66 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.55 }, { number: 15, width: -0.59 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.52 }, { number: 42, width: -0.43 }, { number: 43, width: -0.43 },
      { number: 44, width: -0.4 }, { number: 45, width: -0.43 }, { number: 46, width: -0.43 },
      { number: 47, width: -0.43 }, { number: 48, width: -0.43 }, { number: 49, width: -0.43 },
      { number: 51, width: -0.54 }, { number: 61, width: -0.54 }, { number: 71, width: -0.54 },
      { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'NCST_Jersey_2025_NUM_Array': {
    numberSpacing: -0.47,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.71 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.55 }, { number: 15, width: -0.59 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.59 }, { number: 24, width: -0.42 },
      { number: 31, width: -0.59 }, { number: 34, width: -0.42 }, { number: 40, width: -0.42 },
      { number: 41, width: -0.54 }, { number: 42, width: -0.42 }, { number: 43, width: -0.42 },
      { number: 44, width: -0.38 }, { number: 45, width: -0.42 }, { number: 46, width: -0.42 },
      { number: 47, width: -0.42 }, { number: 48, width: -0.42 }, { number: 49, width: -0.42 },
      { number: 51, width: -0.59 }, { number: 54, width: -0.42 }, { number: 61, width: -0.59 },
      { number: 64, width: -0.42 }, { number: 71, width: -0.59 }, { number: 74, width: -0.5 },
      { number: 81, width: -0.59 }, { number: 84, width: -0.42 }, { number: 91, width: -0.59 },
      { number: 94, width: -0.42 }
    ]
  },
  'NDSU_Jersey_2026_NUM_Array': {
    numberSpacing: -0.24,
    playerNumberAdjust: [
      { number: 10, width: -0.28 }, { number: 11, width: -0.42 }, { number: 12, width: -0.28 },
      { number: 13, width: -0.28 }, { number: 14, width: -0.28 }, { number: 15, width: -0.28 },
      { number: 16, width: -0.28 }, { number: 17, width: -0.28 }, { number: 18, width: -0.28 },
      { number: 19, width: -0.28 }, { number: 21, width: -0.28 }, { number: 31, width: -0.28 },
      { number: 40, width: -0.15 }, { number: 41, width: -0.28 }, { number: 42, width: -0.22 },
      { number: 43, width: -0.22 }, { number: 44, width: -0.2 }, { number: 45, width: -0.22 },
      { number: 46, width: -0.22 }, { number: 47, width: -0.22 }, { number: 48, width: -0.17 },
      { number: 49, width: -0.22 }, { number: 51, width: -0.28 }, { number: 61, width: -0.28 },
      { number: 71, width: -0.28 }, { number: 81, width: -0.28 }, { number: 91, width: -0.28 }
    ]
  },
  'ND_Jersey_2021_NUM_Array': {
    numberSpacing: -0.52,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.7 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.64 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.63 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.6 }, { number: 42, width: -0.49 }, { number: 43, width: -0.49 },
      { number: 44, width: -0.46 }, { number: 45, width: -0.49 }, { number: 46, width: -0.49 },
      { number: 47, width: -0.54 }, { number: 48, width: -0.5 }, { number: 49, width: -0.49 },
      { number: 51, width: -0.62 }, { number: 61, width: -0.62 }, { number: 71, width: -0.62 },
      { number: 81, width: -0.61 }, { number: 91, width: -0.62 }
    ]
  },
  'ND_Jersey_2024_Shamrock_NUM_Array': {
    numberSpacing: -0.58,
    playerNumberAdjust: [
      { number: 10, width: -0.66 }, { number: 11, width: -0.77 }, { number: 12, width: -0.66 },
      { number: 13, width: -0.66 }, { number: 14, width: -0.66 }, { number: 15, width: -0.66 },
      { number: 16, width: -0.66 }, { number: 17, width: -0.7 }, { number: 18, width: -0.66 },
      { number: 19, width: -0.66 }, { number: 21, width: -0.64 }, { number: 31, width: -0.64 },
      { number: 41, width: -0.66 }, { number: 51, width: -0.64 }, { number: 61, width: -0.64 },
      { number: 71, width: -0.64 }, { number: 81, width: -0.64 }, { number: 91, width: -0.64 }
    ]
  },
  'ND_Jersey_2026_Shamrock_NUM_Array': {
    numberSpacing: -0.47,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.6 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.52 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.52 }, { number: 31, width: -0.52 },
      { number: 41, width: -0.52 }, { number: 51, width: -0.52 }, { number: 61, width: -0.52 },
      { number: 71, width: -0.52 }, { number: 81, width: -0.52 }, { number: 91, width: -0.52 }
    ]
  },
  'NEB_JERSEY_2024_RED': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.68 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.58 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.64 }, { number: 31, width: -0.64 },
      { number: 41, width: -0.64 }, { number: 51, width: -0.64 }, { number: 61, width: -0.63 },
      { number: 71, width: -0.64 }, { number: 81, width: -0.64 }, { number: 91, width: -0.64 }
    ]
  },
  'NEB_Jersey_2026_NUM_Array': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.69 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'NEV_Jersey_2021_NUM_Array': {
    numberSpacing: -0.32,
    playerNumberAdjust: [
      { number: 10, width: -0.44 }, { number: 11, width: -0.58 }, { number: 12, width: -0.44 },
      { number: 13, width: -0.44 }, { number: 14, width: -0.41 }, { number: 15, width: -0.44 },
      { number: 16, width: -0.44 }, { number: 17, width: -0.44 }, { number: 18, width: -0.44 },
      { number: 19, width: -0.44 }, { number: 21, width: -0.44 }, { number: 24, width: -0.27 },
      { number: 31, width: -0.44 }, { number: 34, width: -0.27 }, { number: 41, width: -0.44 },
      { number: 44, width: -0.27 }, { number: 51, width: -0.44 }, { number: 54, width: -0.27 },
      { number: 61, width: -0.44 }, { number: 64, width: -0.27 }, { number: 71, width: -0.44 },
      { number: 74, width: -0.32 }, { number: 81, width: -0.44 }, { number: 84, width: -0.27 },
      { number: 91, width: -0.44 }, { number: 94, width: -0.27 }
    ]
  },
  'NIU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.47 }, { number: 11, width: -0.62 }, { number: 12, width: -0.47 },
      { number: 13, width: -0.47 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'NIU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.62 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.48 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.48 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.42 }, { number: 31, width: -0.42 },
      { number: 41, width: -0.42 }, { number: 51, width: -0.42 }, { number: 61, width: -0.42 },
      { number: 71, width: -0.42 }, { number: 81, width: -0.42 }, { number: 91, width: -0.42 }
    ]
  },
  'NW_Jersey_2021_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.63 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'NW_Jersey_2022_NUM_Array': {
    numberSpacing: -0.53,
    playerNumberAdjust: [
      { number: 10, width: -0.63 }, { number: 11, width: -0.76 }, { number: 12, width: -0.63 },
      { number: 13, width: -0.63 }, { number: 14, width: -0.63 }, { number: 15, width: -0.63 },
      { number: 16, width: -0.63 }, { number: 17, width: -0.63 }, { number: 18, width: -0.63 },
      { number: 19, width: -0.63 }, { number: 21, width: -0.63 }, { number: 31, width: -0.63 },
      { number: 41, width: -0.63 }, { number: 51, width: -0.63 }, { number: 61, width: -0.63 },
      { number: 71, width: -0.63 }, { number: 81, width: -0.63 }, { number: 91, width: -0.63 }
    ]
  },
  'NW_Jersey_2026_Gothic_NUM_Array': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.73 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.6 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.6 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.6 }, { number: 31, width: -0.6 },
      { number: 41, width: -0.6 }, { number: 51, width: -0.6 }, { number: 61, width: -0.6 },
      { number: 71, width: -0.6 }, { number: 74, width: -0.65 }, { number: 81, width: -0.6 },
      { number: 91, width: -0.6 }
    ]
  },
  'ODU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.63 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.56 }, { number: 51, width: -0.56 }, { number: 61, width: -0.56 },
      { number: 71, width: -0.56 }, { number: 81, width: -0.56 }, { number: 91, width: -0.56 }
    ]
  },
  'OHIO_Jersey_2023_NUM_Array': {
    numberSpacing: -0.49,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.68 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.58 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.59 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'OHIO_Jersey_2024_NUM_Array': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.63 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.52 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'OKST_JERSEY_2023_BLACK': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.47 }, { number: 11, width: -0.57 }, { number: 12, width: -0.47 },
      { number: 13, width: -0.47 }, { number: 14, width: -0.47 }, { number: 15, width: -0.47 },
      { number: 16, width: -0.47 }, { number: 17, width: -0.47 }, { number: 18, width: -0.47 },
      { number: 19, width: -0.47 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  },
  'ORE_Jersey_2021_NUM_Array': {
    numberSpacing: -0.438335419,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.73 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.58 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'ORE_Jersey_2024_NUM_Array': {
    numberSpacing: -0.52,
    playerNumberAdjust: [
      { number: 10, width: -0.63 }, { number: 11, width: -0.74 }, { number: 12, width: -0.63 },
      { number: 13, width: -0.63 }, { number: 14, width: -0.61 }, { number: 15, width: -0.63 },
      { number: 16, width: -0.63 }, { number: 17, width: -0.63 }, { number: 18, width: -0.63 },
      { number: 19, width: -0.63 }, { number: 21, width: -0.63 }, { number: 24, width: -0.5 },
      { number: 31, width: -0.63 }, { number: 34, width: -0.5 }, { number: 40, width: -0.5 },
      { number: 41, width: -0.63 }, { number: 42, width: -0.5 }, { number: 43, width: -0.5 },
      { number: 44, width: -0.48 }, { number: 45, width: -0.5 }, { number: 46, width: -0.5 },
      { number: 47, width: -0.52 }, { number: 48, width: -0.5 }, { number: 49, width: -0.5 },
      { number: 51, width: -0.63 }, { number: 54, width: -0.5 }, { number: 61, width: -0.63 },
      { number: 64, width: -0.5 }, { number: 71, width: -0.63 }, { number: 74, width: -0.5 },
      { number: 81, width: -0.63 }, { number: 84, width: -0.5 }, { number: 91, width: -0.63 },
      { number: 94, width: -0.5 }
    ]
  },
  'ORE_Jersey_2025_ShoeDuck_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.68 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.52 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.56 }, { number: 44, width: -0.37 }, { number: 51, width: -0.56 },
      { number: 61, width: -0.56 }, { number: 71, width: -0.56 }, { number: 81, width: -0.56 },
      { number: 91, width: -0.56 }
    ]
  },
  'ORST_Jersey_2021_NUM_Array': {
    numberSpacing: -0.39,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.62 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.51 }, { number: 31, width: -0.51 },
      { number: 41, width: -0.51 }, { number: 51, width: -0.51 }, { number: 61, width: -0.51 },
      { number: 71, width: -0.51 }, { number: 81, width: -0.51 }, { number: 91, width: -0.51 }
    ]
  },
  'ORST_Jersey_2025_Camo_NUM_Array': {
    numberSpacing: -0.34,
    playerNumberAdjust: [
      { number: 10, width: -0.46 }, { number: 11, width: -0.6 }, { number: 12, width: -0.46 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.46 }, { number: 15, width: -0.46 },
      { number: 16, width: -0.46 }, { number: 17, width: -0.46 }, { number: 18, width: -0.46 },
      { number: 19, width: -0.46 }, { number: 21, width: -0.46 }, { number: 31, width: -0.46 },
      { number: 40, width: -0.31 }, { number: 41, width: -0.46 }, { number: 42, width: -0.31 },
      { number: 43, width: -0.31 }, { number: 44, width: -0.29 }, { number: 45, width: -0.31 },
      { number: 46, width: -0.31 }, { number: 47, width: -0.31 }, { number: 48, width: -0.31 },
      { number: 49, width: -0.31 }, { number: 51, width: -0.46 }, { number: 61, width: -0.46 },
      { number: 71, width: -0.46 }, { number: 81, width: -0.46 }, { number: 91, width: -0.46 }
    ]
  },
  'OSU_JERSEY_2023_SCARLETT': {
    numberSpacing: -0.49,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.67 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.59 }, { number: 15, width: -0.59 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'OSU_Jersey_2023_02_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.64 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'OU_Jersey_2022_NUM_Array': {
    numberSpacing: -0.3667013,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.61 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.48 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.48 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  },
  'OU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.3667013,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.63 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.49 }, { number: 31, width: -0.49 },
      { number: 41, width: -0.49 }, { number: 51, width: -0.49 }, { number: 61, width: -0.49 },
      { number: 71, width: -0.49 }, { number: 81, width: -0.49 }, { number: 91, width: -0.49 }
    ]
  },
  'OU_Jersey_2024_02_NUM_Array': {
    numberSpacing: -0.495,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.7 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.57 }, { number: 24, width: -0.44 },
      { number: 31, width: -0.57 }, { number: 34, width: -0.44 }, { number: 40, width: -0.42 },
      { number: 41, width: -0.53 }, { number: 42, width: -0.42 }, { number: 43, width: -0.42 },
      { number: 44, width: -0.36 }, { number: 45, width: -0.42 }, { number: 46, width: -0.42 },
      { number: 47, width: -0.42 }, { number: 48, width: -0.42 }, { number: 49, width: -0.42 },
      { number: 51, width: -0.57 }, { number: 54, width: -0.44 }, { number: 61, width: -0.57 },
      { number: 64, width: -0.44 }, { number: 71, width: -0.57 }, { number: 74, width: -0.5 },
      { number: 81, width: -0.57 }, { number: 84, width: -0.44 }, { number: 91, width: -0.57 },
      { number: 94, width: -0.44 }
    ]
  },
  'OU_Jersey_2024_NUM_Array': {
    numberSpacing: -0.3667013,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.63 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.49 }, { number: 31, width: -0.49 },
      { number: 41, width: -0.49 }, { number: 51, width: -0.49 }, { number: 61, width: -0.49 },
      { number: 71, width: -0.49 }, { number: 81, width: -0.49 }, { number: 91, width: -0.49 }
    ]
  },
  'PITT_Jersey_2021_NUM_Array': {
    numberSpacing: -0.54,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.69 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.6 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.64 }, { number: 31, width: -0.64 },
      { number: 41, width: -0.64 }, { number: 51, width: -0.64 }, { number: 61, width: -0.64 },
      { number: 71, width: -0.64 }, { number: 81, width: -0.64 }, { number: 91, width: -0.64 }
    ]
  },
  'PSU_JERSEY_2023_BLUESTRIPE': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.525 }, { number: 11, width: -0.655 }, { number: 12, width: -0.525 },
      { number: 13, width: -0.525 }, { number: 14, width: -0.525 }, { number: 15, width: -0.525 },
      { number: 16, width: -0.525 }, { number: 17, width: -0.525 }, { number: 18, width: -0.525 },
      { number: 19, width: -0.525 }, { number: 21, width: -0.525 }, { number: 31, width: -0.525 },
      { number: 41, width: -0.525 }, { number: 51, width: -0.525 }, { number: 61, width: -0.525 },
      { number: 71, width: -0.525 }, { number: 81, width: -0.525 }, { number: 91, width: -0.525 }
    ]
  },
  'PSU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.62 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'PUR_Jersey_2023_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.65 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.53 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.54 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'RICE_JERSEY_2023_LIGHTBLUE': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.66 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'RICE_Jersey_2026_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.72 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.58 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'RUTG_Jersey_2021_NUM_Array': {
    numberSpacing: -0.383319438,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.57 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.51 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.5 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.48 }, { number: 31, width: -0.48 },
      { number: 41, width: -0.48 }, { number: 51, width: -0.48 }, { number: 61, width: -0.48 },
      { number: 71, width: -0.48 }, { number: 81, width: -0.48 }, { number: 91, width: -0.48 }
    ]
  },
  'SACST_Jersey_2026_NUM_Array': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.68 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'SC_Jersey_2021_NUM_Array': {
    numberSpacing: -0.47,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.65 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.55 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 42, width: -0.44 }, { number: 43, width: -0.44 },
      { number: 44, width: -0.45 }, { number: 45, width: -0.44 }, { number: 46, width: -0.44 },
      { number: 47, width: -0.44 }, { number: 48, width: -0.44 }, { number: 49, width: -0.44 },
      { number: 51, width: -0.57 }, { number: 61, width: -0.57 }, { number: 71, width: -0.57 },
      { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'SHSU_Jersey_2025_NUM_Array': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.45 }, { number: 11, width: -0.52 }, { number: 12, width: -0.45 },
      { number: 13, width: -0.45 }, { number: 14, width: -0.45 }, { number: 15, width: -0.45 },
      { number: 16, width: -0.45 }, { number: 17, width: -0.45 }, { number: 18, width: -0.45 },
      { number: 19, width: -0.45 }, { number: 21, width: -0.45 }, { number: 31, width: -0.45 },
      { number: 41, width: -0.45 }, { number: 51, width: -0.45 }, { number: 61, width: -0.45 },
      { number: 71, width: -0.45 }, { number: 81, width: -0.45 }, { number: 91, width: -0.45 }
    ]
  },
  'SJSU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.68 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.6 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.6 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.6 }, { number: 31, width: -0.6 },
      { number: 41, width: -0.6 }, { number: 51, width: -0.6 }, { number: 61, width: -0.6 },
      { number: 71, width: -0.6 }, { number: 81, width: -0.6 }, { number: 91, width: -0.6 }
    ]
  },
  'SMU_JERSEY_2023_BLUE': {
    numberSpacing: -0.47,
    playerNumberAdjust: [
      { number: 10, width: -0.54 }, { number: 11, width: -0.62 }, { number: 12, width: -0.54 },
      { number: 13, width: -0.54 }, { number: 14, width: -0.58 }, { number: 15, width: -0.54 },
      { number: 16, width: -0.54 }, { number: 17, width: -0.54 }, { number: 18, width: -0.54 },
      { number: 19, width: -0.54 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.54 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'SMU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.67 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.58 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'SMU_Jersey_2022_NUM_Array': {
    numberSpacing: -0.52,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.7 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.6 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.6 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.62 }, { number: 51, width: -0.62 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.62 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'STAN_JERSEY_2023_BLACK': {
    numberSpacing: -0.36,
    playerNumberAdjust: [
      { number: 10, width: -0.45 }, { number: 11, width: -0.54 }, { number: 12, width: -0.45 },
      { number: 13, width: -0.45 }, { number: 14, width: -0.45 }, { number: 15, width: -0.45 },
      { number: 16, width: -0.45 }, { number: 17, width: -0.45 }, { number: 18, width: -0.45 },
      { number: 19, width: -0.45 }, { number: 21, width: -0.43 }, { number: 31, width: -0.43 },
      { number: 41, width: -0.43 }, { number: 51, width: -0.43 }, { number: 61, width: -0.43 },
      { number: 71, width: -0.43 }, { number: 81, width: -0.43 }, { number: 91, width: -0.43 }
    ]
  },
  'SYR_Jersey_2021_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.59 }, { number: 11, width: -0.7 }, { number: 12, width: -0.59 },
      { number: 13, width: -0.59 }, { number: 14, width: -0.59 }, { number: 15, width: -0.59 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.59 }, { number: 18, width: -0.59 },
      { number: 19, width: -0.59 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'TAMU_JERSEY_2025_THROWBACK': {
    numberSpacing: -0.46,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.68 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'TAMU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.51 }, { number: 11, width: -0.63 }, { number: 12, width: -0.51 },
      { number: 13, width: -0.51 }, { number: 14, width: -0.51 }, { number: 15, width: -0.51 },
      { number: 16, width: -0.51 }, { number: 17, width: -0.51 }, { number: 18, width: -0.51 },
      { number: 19, width: -0.51 }, { number: 21, width: -0.51 }, { number: 31, width: -0.51 },
      { number: 41, width: -0.51 }, { number: 51, width: -0.51 }, { number: 61, width: -0.51 },
      { number: 71, width: -0.51 }, { number: 81, width: -0.51 }, { number: 91, width: -0.51 }
    ]
  },
  'TAMU_Jersey_2024_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.63 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'TCU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.64 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.45 }, { number: 31, width: -0.45 },
      { number: 41, width: -0.45 }, { number: 51, width: -0.45 }, { number: 61, width: -0.45 },
      { number: 71, width: -0.45 }, { number: 81, width: -0.45 }, { number: 91, width: -0.45 }
    ]
  },
  'TCU_Jersey_2026_NUM_Array': {
    numberSpacing: -0.36,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.59 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.45 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.48 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.48 }, { number: 24, width: -0.32 },
      { number: 31, width: -0.48 }, { number: 34, width: -0.32 }, { number: 40, width: -0.31 },
      { number: 41, width: -0.48 }, { number: 42, width: -0.31 }, { number: 43, width: -0.31 },
      { number: 44, width: -0.29 }, { number: 46, width: -0.31 }, { number: 46, width: -0.31 },
      { number: 47, width: -0.31 }, { number: 48, width: -0.31 }, { number: 49, width: -0.31 },
      { number: 51, width: -0.48 }, { number: 54, width: -0.32 }, { number: 61, width: -0.48 },
      { number: 64, width: -0.32 }, { number: 71, width: -0.48 }, { number: 74, width: -0.36 },
      { number: 81, width: -0.48 }, { number: 84, width: -0.32 }, { number: 91, width: -0.48 },
      { number: 94, width: -0.32 }
    ]
  },
  'TEMP_JERSEY_2025_RED': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.45 }, { number: 11, width: -0.56 }, { number: 12, width: -0.45 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.52 }, { number: 15, width: -0.45 },
      { number: 16, width: -0.45 }, { number: 17, width: -0.45 }, { number: 18, width: -0.45 },
      { number: 19, width: -0.45 }, { number: 21, width: -0.42 }, { number: 31, width: -0.44 },
      { number: 41, width: -0.45 }, { number: 51, width: -0.42 }, { number: 61, width: -0.42 },
      { number: 71, width: -0.42 }, { number: 81, width: -0.42 }, { number: 91, width: -0.42 }
    ]
  },
  'TEM_Jersey_2021_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.4 }, { number: 11, width: -0.5 }, { number: 12, width: -0.4 },
      { number: 13, width: -0.4 }, { number: 14, width: -0.4 }, { number: 15, width: -0.4 },
      { number: 16, width: -0.4 }, { number: 17, width: -0.4 }, { number: 18, width: -0.4 },
      { number: 19, width: -0.4 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  },
  'TENN_Jersey_2021_NUM_Array': {
    numberSpacing: -0.52,
    playerNumberAdjust: [
      { number: 10, width: -0.61 }, { number: 11, width: -0.71 }, { number: 12, width: -0.61 },
      { number: 13, width: -0.61 }, { number: 14, width: -0.61 }, { number: 15, width: -0.61 },
      { number: 16, width: -0.61 }, { number: 17, width: -0.64 }, { number: 18, width: -0.61 },
      { number: 19, width: -0.61 }, { number: 21, width: -0.61 }, { number: 27, width: -0.54 },
      { number: 31, width: -0.61 }, { number: 37, width: -0.54 }, { number: 41, width: -0.61 },
      { number: 47, width: -0.54 }, { number: 51, width: -0.61 }, { number: 57, width: -0.54 },
      { number: 61, width: -0.61 }, { number: 67, width: -0.54 }, { number: 71, width: -0.64 },
      { number: 72, width: -0.54 }, { number: 73, width: -0.54 }, { number: 74, width: -0.54 },
      { number: 75, width: -0.54 }, { number: 76, width: -0.54 }, { number: 77, width: -0.56 },
      { number: 78, width: -0.54 }, { number: 79, width: -0.54 }, { number: 81, width: -0.61 },
      { number: 87, width: -0.54 }, { number: 91, width: -0.61 }, { number: 97, width: -0.54 }
    ]
  },
  'TENN_Jersey_2025_Smokey_NUM_Array': {
    numberSpacing: -0.41,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.63 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.52 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.52 }, { number: 31, width: -0.52 },
      { number: 41, width: -0.52 }, { number: 51, width: -0.52 }, { number: 61, width: -0.52 },
      { number: 71, width: -0.52 }, { number: 81, width: -0.52 }, { number: 91, width: -0.52 }
    ]
  },
  'TENN_Jersey_2026_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.68 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.51 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.55 }, { number: 24, width: -0.37 },
      { number: 31, width: -0.55 }, { number: 34, width: -0.37 }, { number: 40, width: -0.35 },
      { number: 41, width: -0.52 }, { number: 42, width: -0.35 }, { number: 43, width: -0.35 },
      { number: 44, width: -0.33 }, { number: 45, width: -0.35 }, { number: 46, width: -0.35 },
      { number: 47, width: -0.35 }, { number: 48, width: -0.35 }, { number: 49, width: -0.35 },
      { number: 51, width: -0.55 }, { number: 54, width: -0.37 }, { number: 61, width: -0.55 },
      { number: 64, width: -0.37 }, { number: 71, width: -0.55 }, { number: 74, width: -0.37 },
      { number: 81, width: -0.55 }, { number: 84, width: -0.37 }, { number: 91, width: -0.55 },
      { number: 94, width: -0.37 }
    ]
  },
  'TEX_Jersey_2024_NUM_Array': {
    numberSpacing: -0.404939115,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.63 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.54 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'TLSA_Jersey_2021_NUM_Array': {
    numberSpacing: -0.36,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.7 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.54 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'TOL_JERSEY_2023_BLACK': {
    numberSpacing: -0.3938529,
    playerNumberAdjust: [
      { number: 10, width: -0.47 }, { number: 11, width: -0.57 }, { number: 12, width: -0.47 },
      { number: 13, width: -0.47 }, { number: 14, width: -0.47 }, { number: 15, width: -0.47 },
      { number: 16, width: -0.47 }, { number: 17, width: -0.47 }, { number: 18, width: -0.47 },
      { number: 19, width: -0.47 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  },
  'TOL_JERSEY_2023_BLUE': {
    numberSpacing: -0.52,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.63 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.56 }, { number: 51, width: -0.56 }, { number: 61, width: -0.56 },
      { number: 71, width: -0.56 }, { number: 81, width: -0.56 }, { number: 91, width: -0.56 }
    ]
  },
  'TROY_Jersey_2023_NUM_Array': {
    numberSpacing: -0.54,
    playerNumberAdjust: [
      { number: 10, width: -0.63 }, { number: 11, width: -0.73 }, { number: 12, width: -0.63 },
      { number: 13, width: -0.63 }, { number: 14, width: -0.63 }, { number: 15, width: -0.63 },
      { number: 16, width: -0.63 }, { number: 17, width: -0.63 }, { number: 18, width: -0.63 },
      { number: 19, width: -0.63 }, { number: 21, width: -0.61 }, { number: 31, width: -0.61 },
      { number: 41, width: -0.61 }, { number: 51, width: -0.61 }, { number: 61, width: -0.61 },
      { number: 71, width: -0.61 }, { number: 81, width: -0.61 }, { number: 91, width: -0.61 }
    ]
  },
  'TTU_Jersey_2025_Mahomes_NUM_Array': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.66 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'TTU_Jersey_2025_NUM_Array': {
    numberSpacing: -0.3,
    playerNumberAdjust: [
      { number: 10, width: -0.44 }, { number: 11, width: -0.58 }, { number: 12, width: -0.44 },
      { number: 13, width: -0.44 }, { number: 14, width: -0.44 }, { number: 15, width: -0.44 },
      { number: 16, width: -0.44 }, { number: 17, width: -0.44 }, { number: 18, width: -0.44 },
      { number: 19, width: -0.44 }, { number: 21, width: -0.44 }, { number: 31, width: -0.44 },
      { number: 40, width: -0.27 }, { number: 41, width: -0.41 }, { number: 42, width: -0.27 },
      { number: 43, width: -0.27 }, { number: 44, width: -0.27 }, { number: 45, width: -0.27 },
      { number: 46, width: -0.27 }, { number: 47, width: -0.27 }, { number: 48, width: -0.27 },
      { number: 49, width: -0.27 }, { number: 51, width: -0.44 }, { number: 61, width: -0.44 },
      { number: 71, width: -0.44 }, { number: 81, width: -0.44 }, { number: 91, width: -0.44 }
    ]
  },
  'TTU_Jersey_2026_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.54 }, { number: 11, width: -0.69 }, { number: 12, width: -0.54 },
      { number: 13, width: -0.54 }, { number: 14, width: -0.54 }, { number: 15, width: -0.54 },
      { number: 16, width: -0.54 }, { number: 17, width: -0.54 }, { number: 18, width: -0.54 },
      { number: 19, width: -0.54 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 40, width: -0.41 }, { number: 41, width: -0.52 }, { number: 42, width: -0.41 },
      { number: 43, width: -0.41 }, { number: 44, width: -0.39 }, { number: 45, width: -0.41 },
      { number: 46, width: -0.41 }, { number: 47, width: -0.41 }, { number: 48, width: -0.41 },
      { number: 49, width: -0.41 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'TULN_JERSEY_2023_BLUE': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.47 }, { number: 11, width: -0.57 }, { number: 12, width: -0.47 },
      { number: 13, width: -0.47 }, { number: 14, width: -0.47 }, { number: 15, width: -0.47 },
      { number: 16, width: -0.47 }, { number: 17, width: -0.47 }, { number: 18, width: -0.47 },
      { number: 19, width: -0.47 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  },
  'TULN_Jersey_2025_CITY_EDITION_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.66 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.58 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.54 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 70, width: -0.46 }, { number: 71, width: -0.55 }, { number: 72, width: -0.46 },
      { number: 73, width: -0.46 }, { number: 74, width: -0.46 }, { number: 75, width: -0.46 },
      { number: 76, width: -0.46 }, { number: 77, width: -0.46 }, { number: 78, width: -0.46 },
      { number: 79, width: -0.46 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'TXST_Jersey_2023_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.44 }, { number: 11, width: -0.54 }, { number: 12, width: -0.44 },
      { number: 13, width: -0.44 }, { number: 14, width: -0.44 }, { number: 15, width: -0.44 },
      { number: 16, width: -0.44 }, { number: 17, width: -0.44 }, { number: 18, width: -0.44 },
      { number: 19, width: -0.44 }, { number: 21, width: -0.44 }, { number: 31, width: -0.44 },
      { number: 41, width: -0.44 }, { number: 51, width: -0.44 }, { number: 61, width: -0.44 },
      { number: 71, width: -0.44 }, { number: 81, width: -0.44 }, { number: 91, width: -0.44 }
    ]
  },
  'TXST_Jersey_2024_NUM_Array': {
    numberSpacing: -0.36,
    playerNumberAdjust: [
      { number: 10, width: -0.46 }, { number: 11, width: -0.58 }, { number: 12, width: -0.46 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.46 }, { number: 15, width: -0.46 },
      { number: 16, width: -0.46 }, { number: 17, width: -0.46 }, { number: 18, width: -0.46 },
      { number: 19, width: -0.46 }, { number: 21, width: -0.48 }, { number: 24, width: -0.34 },
      { number: 31, width: -0.48 }, { number: 34, width: -0.34 }, { number: 40, width: -0.33 },
      { number: 41, width: -0.48 }, { number: 42, width: -0.33 }, { number: 43, width: -0.33 },
      { number: 44, width: -0.33 }, { number: 45, width: -0.33 }, { number: 46, width: -0.33 },
      { number: 47, width: -0.33 }, { number: 48, width: -0.33 }, { number: 49, width: -0.33 },
      { number: 51, width: -0.48 }, { number: 54, width: -0.34 }, { number: 61, width: -0.48 },
      { number: 64, width: -0.34 }, { number: 71, width: -0.48 }, { number: 74, width: -0.44 },
      { number: 81, width: -0.48 }, { number: 84, width: -0.34 }, { number: 91, width: -0.48 },
      { number: 94, width: -0.34 }
    ]
  },
  'UAB_Jersey_2021_NUM_Array': {
    numberSpacing: -0.35,
    playerNumberAdjust: [
      { number: 10, width: -0.555 }, { number: 11, width: -0.6 }, { number: 12, width: -0.555 },
      { number: 13, width: -0.555 }, { number: 14, width: -0.555 }, { number: 15, width: -0.555 },
      { number: 16, width: -0.555 }, { number: 17, width: -0.555 }, { number: 18, width: -0.555 },
      { number: 19, width: -0.555 }, { number: 21, width: -0.43 }, { number: 31, width: -0.43 },
      { number: 41, width: -0.43 }, { number: 51, width: -0.43 }, { number: 61, width: -0.43 },
      { number: 71, width: -0.43 }, { number: 81, width: -0.43 }, { number: 91, width: -0.43 }
    ]
  },
  'UCF_Jersey_2023_NUM_Array': {
    numberSpacing: -0.57,
    playerNumberAdjust: [
      { number: 10, width: -0.65 }, { number: 11, width: -0.67 }, { number: 12, width: -0.65 },
      { number: 13, width: -0.65 }, { number: 14, width: -0.65 }, { number: 15, width: -0.65 },
      { number: 16, width: -0.65 }, { number: 17, width: -0.65 }, { number: 18, width: -0.65 },
      { number: 19, width: -0.65 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'UCF_Jersey_2024_NUM_Array': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.69 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'UCF_Jersey_2024_SPACE_NUM_Array': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.69 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'UCF_Jersey_2025_4_NUM_Array': {
    numberSpacing: -0.41,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.69 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'UCF_Jersey_2025_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.67 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'UCF_Jersey_2025_Space_NUM_Array': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.62 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'UCLA_Jersey_2021_NUM_Array': {
    numberSpacing: -0.43,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.64 }, { number: 12, width: -0.54 },
      { number: 13, width: -0.54 }, { number: 14, width: -0.59 }, { number: 15, width: -0.54 },
      { number: 16, width: -0.54 }, { number: 17, width: -0.59 }, { number: 18, width: -0.54 },
      { number: 19, width: -0.54 }, { number: 21, width: -0.51 }, { number: 31, width: -0.51 },
      { number: 41, width: -0.51 }, { number: 51, width: -0.54 }, { number: 61, width: -0.51 },
      { number: 71, width: -0.51 }, { number: 81, width: -0.51 }, { number: 91, width: -0.51 }
    ]
  },
  'UCLA_Jersey_2023_ALT_NUM_Array': {
    numberSpacing: -0.445,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.63 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'UGA_JERSEY_2023_RED': {
    numberSpacing: -0.408723861,
    playerNumberAdjust: [
      { number: 10, width: -0.54 }, { number: 11, width: -0.66 }, { number: 12, width: -0.54 },
      { number: 13, width: -0.54 }, { number: 14, width: -0.54 }, { number: 15, width: -0.54 },
      { number: 16, width: -0.54 }, { number: 17, width: -0.54 }, { number: 18, width: -0.54 },
      { number: 19, width: -0.54 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'UK_JERSEY_2023_BLUE': {
    numberSpacing: -0.56,
    playerNumberAdjust: [
      { number: 10, width: -0.65 }, { number: 11, width: -0.73 }, { number: 12, width: -0.65 },
      { number: 13, width: -0.65 }, { number: 14, width: -0.65 }, { number: 15, width: -0.65 },
      { number: 16, width: -0.65 }, { number: 17, width: -0.65 }, { number: 18, width: -0.65 },
      { number: 19, width: -0.65 }, { number: 21, width: -0.65 }, { number: 31, width: -0.65 },
      { number: 41, width: -0.65 }, { number: 51, width: -0.65 }, { number: 61, width: -0.65 },
      { number: 71, width: -0.65 }, { number: 81, width: -0.65 }, { number: 91, width: -0.65 }
    ]
  },
  'ULL_JERSEY_2023_THROWBACK': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.69 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.62 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.62 }, { number: 51, width: -0.62 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.62 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'ULL_Jersey_2021_NUM_Array': {
    numberSpacing: -0.39,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.73 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'ULL_Jersey_2025_BLOCKSHADOW_NUM_Array': {
    numberSpacing: -0.43,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.71 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'ULM_JERSEY_2025_GRAY': {
    numberSpacing: -0.37,
    playerNumberAdjust: [
      { number: 10, width: -0.47 }, { number: 11, width: -0.57 }, { number: 12, width: -0.47 },
      { number: 13, width: -0.47 }, { number: 14, width: -0.47 }, { number: 15, width: -0.47 },
      { number: 16, width: -0.47 }, { number: 17, width: -0.47 }, { number: 18, width: -0.47 },
      { number: 19, width: -0.47 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  },
  'ULM_Jersey_2016_NUM_Array': {
    numberSpacing: -0.55,
    playerNumberAdjust: [
      { number: 10, width: -0.66 }, { number: 11, width: -0.75 }, { number: 12, width: -0.66 },
      { number: 13, width: -0.66 }, { number: 14, width: -0.66 }, { number: 15, width: -0.66 },
      { number: 16, width: -0.66 }, { number: 17, width: -0.66 }, { number: 18, width: -0.66 },
      { number: 19, width: -0.66 }, { number: 21, width: -0.66 }, { number: 31, width: -0.66 },
      { number: 40, width: -0.54 }, { number: 41, width: -0.66 }, { number: 42, width: -0.54 },
      { number: 43, width: -0.54 }, { number: 44, width: -0.5 }, { number: 45, width: -0.54 },
      { number: 46, width: -0.54 }, { number: 47, width: -0.54 }, { number: 48, width: -0.54 },
      { number: 49, width: -0.54 }, { number: 51, width: -0.66 }, { number: 61, width: -0.66 },
      { number: 71, width: -0.66 }, { number: 81, width: -0.66 }, { number: 91, width: -0.66 }
    ]
  },
  'ULM_Jersey_2021_NUM_Array': {
    numberSpacing: -0.57,
    playerNumberAdjust: [
      { number: 10, width: -0.66 }, { number: 11, width: -0.75 }, { number: 12, width: -0.66 },
      { number: 13, width: -0.66 }, { number: 14, width: -0.66 }, { number: 15, width: -0.66 },
      { number: 16, width: -0.66 }, { number: 17, width: -0.66 }, { number: 18, width: -0.66 },
      { number: 19, width: -0.66 }, { number: 21, width: -0.66 }, { number: 31, width: -0.66 },
      { number: 41, width: -0.66 }, { number: 51, width: -0.66 }, { number: 61, width: -0.66 },
      { number: 71, width: -0.66 }, { number: 81, width: -0.66 }, { number: 91, width: -0.66 }
    ]
  },
  'UMASS_JERSEY_2023_MAROON': {
    numberSpacing: -0.53,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.69 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.62 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.62 }, { number: 51, width: -0.62 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.62 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'UMD_Jersey_2025_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.72 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.62 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.62 }, { number: 51, width: -0.62 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.62 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'UMD_Jersey_Away_2023_NUM_Array': {
    numberSpacing: -0.46,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.68 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.58 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'UNC_Jersey_2021_NUM_Array': {
    numberSpacing: -0.26,
    playerNumberAdjust: [
      { number: 10, width: -0.41 }, { number: 11, width: -0.58 }, { number: 12, width: -0.41 },
      { number: 13, width: -0.41 }, { number: 14, width: -0.41 }, { number: 15, width: -0.41 },
      { number: 16, width: -0.41 }, { number: 17, width: -0.41 }, { number: 18, width: -0.41 },
      { number: 19, width: -0.41 }, { number: 21, width: -0.41 }, { number: 31, width: -0.41 },
      { number: 41, width: -0.41 }, { number: 51, width: -0.41 }, { number: 61, width: -0.41 },
      { number: 71, width: -0.41 }, { number: 81, width: -0.41 }, { number: 91, width: -0.41 }
    ]
  },
  'UNC_Jersey_2022_NUM_Array': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.64 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'UNLV_JERSEY_2023_RED': {
    numberSpacing: -0.34,
    playerNumberAdjust: [
      { number: 10, width: -0.46 }, { number: 11, width: -0.56 }, { number: 12, width: -0.46 },
      { number: 13, width: -0.46 }, { number: 14, width: -0.43 }, { number: 15, width: -0.46 },
      { number: 16, width: -0.46 }, { number: 17, width: -0.46 }, { number: 18, width: -0.46 },
      { number: 19, width: -0.46 }, { number: 21, width: -0.46 }, { number: 31, width: -0.46 },
      { number: 41, width: -0.44 }, { number: 42, width: -0.31 }, { number: 43, width: -0.31 },
      { number: 44, width: -0.28 }, { number: 45, width: -0.31 }, { number: 46, width: -0.31 },
      { number: 47, width: -0.31 }, { number: 48, width: -0.31 }, { number: 49, width: -0.31 },
      { number: 51, width: -0.46 }, { number: 61, width: -0.46 }, { number: 71, width: -0.46 },
      { number: 81, width: -0.46 }, { number: 91, width: -0.46 }
    ]
  },
  'UNM_Jersey_2021_NUM_Array': {
    numberSpacing: -0.36,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.63 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.52 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.5 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.45 }, { number: 22, width: -0.35 },
      { number: 23, width: -0.3 }, { number: 24, width: -0.32 }, { number: 25, width: -0.3 },
      { number: 26, width: -0.32 }, { number: 27, width: -0.32 }, { number: 28, width: -0.32 },
      { number: 29, width: -0.32 }, { number: 31, width: -0.46 }, { number: 41, width: -0.45 },
      { number: 42, width: -0.32 }, { number: 43, width: -0.3 }, { number: 44, width: -0.32 },
      { number: 45, width: -0.3 }, { number: 46, width: -0.32 }, { number: 47, width: -0.35 },
      { number: 48, width: -0.32 }, { number: 49, width: -0.32 }, { number: 51, width: -0.45 },
      { number: 61, width: -0.45 }, { number: 71, width: -0.48 }, { number: 81, width: -0.45 },
      { number: 91, width: -0.46 }
    ]
  },
  'UNM_Jersey_2025_NUM_Array': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.69 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.56 }, { number: 51, width: -0.56 }, { number: 61, width: -0.56 },
      { number: 71, width: -0.56 }, { number: 81, width: -0.56 }, { number: 91, width: -0.56 }
    ]
  },
  'UNT_JERSEY_2022_HAYDENFRY': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.65 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.565 }, { number: 31, width: -0.565 },
      { number: 41, width: -0.565 }, { number: 51, width: -0.565 }, { number: 61, width: -0.565 },
      { number: 71, width: -0.565 }, { number: 81, width: -0.565 }, { number: 91, width: -0.565 }
    ]
  },
  'UNT_JERSEY_2023_GREEN': {
    numberSpacing: -0.42,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.59 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'USA_Jersey_2021_NUM_Array': {
    numberSpacing: -0.49,
    playerNumberAdjust: [
      { number: 10, width: -0.63 }, { number: 11, width: -0.71 }, { number: 12, width: -0.65 },
      { number: 13, width: -0.69 }, { number: 14, width: -0.6 }, { number: 15, width: -0.65 },
      { number: 16, width: -0.68 }, { number: 17, width: -0.65 }, { number: 18, width: -0.65 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.57 }, { number: 30, width: -0.53 },
      { number: 31, width: -0.62 }, { number: 32, width: -0.54 }, { number: 33, width: -0.58 },
      { number: 34, width: -0.49 }, { number: 35, width: -0.53 }, { number: 36, width: -0.57 },
      { number: 37, width: -0.53 }, { number: 38, width: -0.53 }, { number: 39, width: -0.5 },
      { number: 41, width: -0.61 }, { number: 44, width: -0.42 }, { number: 51, width: -0.59 },
      { number: 61, width: -0.62 }, { number: 71, width: -0.59 }, { number: 81, width: -0.59 },
      { number: 91, width: -0.63 }
    ]
  },
  'USC_Jersey_2024_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.51 }, { number: 11, width: -0.61 }, { number: 12, width: -0.51 },
      { number: 13, width: -0.51 }, { number: 14, width: -0.51 }, { number: 15, width: -0.51 },
      { number: 16, width: -0.51 }, { number: 17, width: -0.51 }, { number: 18, width: -0.51 },
      { number: 19, width: -0.51 }, { number: 21, width: -0.51 }, { number: 31, width: -0.51 },
      { number: 41, width: -0.51 }, { number: 51, width: -0.51 }, { number: 61, width: -0.51 },
      { number: 71, width: -0.51 }, { number: 81, width: -0.51 }, { number: 91, width: -0.51 }
    ]
  },
  'USC_Jersey_2024_Throwback_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.51 }, { number: 11, width: -0.61 }, { number: 12, width: -0.51 },
      { number: 13, width: -0.51 }, { number: 14, width: -0.51 }, { number: 15, width: -0.51 },
      { number: 16, width: -0.51 }, { number: 17, width: -0.51 }, { number: 18, width: -0.51 },
      { number: 19, width: -0.51 }, { number: 21, width: -0.51 }, { number: 31, width: -0.51 },
      { number: 41, width: -0.51 }, { number: 51, width: -0.51 }, { number: 61, width: -0.51 },
      { number: 71, width: -0.51 }, { number: 81, width: -0.51 }, { number: 91, width: -0.51 }
    ]
  },
  'USF_Jersey_2023_NUM_Array': {
    numberSpacing: -0.39,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.64 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.53 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.57 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'USM_Jersey_2025_NUM_Array': {
    numberSpacing: -0.51,
    playerNumberAdjust: [
      { number: 10, width: -0.62 }, { number: 11, width: -0.75 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.62 }, { number: 14, width: -0.62 }, { number: 15, width: -0.62 },
      { number: 16, width: -0.62 }, { number: 17, width: -0.62 }, { number: 18, width: -0.62 },
      { number: 19, width: -0.62 }, { number: 21, width: -0.62 }, { number: 31, width: -0.62 },
      { number: 41, width: -0.62 }, { number: 51, width: -0.62 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.62 }, { number: 81, width: -0.62 }, { number: 91, width: -0.62 }
    ]
  },
  'USU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.56 }, { number: 11, width: -0.71 }, { number: 12, width: -0.56 },
      { number: 13, width: -0.56 }, { number: 14, width: -0.56 }, { number: 15, width: -0.56 },
      { number: 16, width: -0.56 }, { number: 17, width: -0.56 }, { number: 18, width: -0.56 },
      { number: 19, width: -0.56 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.56 }, { number: 51, width: -0.56 }, { number: 61, width: -0.56 },
      { number: 71, width: -0.56 }, { number: 81, width: -0.56 }, { number: 91, width: -0.56 }
    ]
  },
  'UTAH_Jersey_2021_02_NUM_Array': {
    numberSpacing: -0.453665555,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.6 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.52 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.53 }, { number: 31, width: -0.53 },
      { number: 41, width: -0.53 }, { number: 51, width: -0.53 }, { number: 61, width: -0.53 },
      { number: 71, width: -0.53 }, { number: 81, width: -0.53 }, { number: 91, width: -0.53 }
    ]
  },
  'UTAH_Jersey_2022_NUM_Array': {
    numberSpacing: -0.55,
    playerNumberAdjust: [
      { number: 10, width: -0.66 }, { number: 11, width: -0.72 }, { number: 12, width: -0.62 },
      { number: 13, width: -0.66 }, { number: 14, width: -0.66 }, { number: 15, width: -0.66 },
      { number: 16, width: -0.66 }, { number: 17, width: -0.66 }, { number: 18, width: -0.66 },
      { number: 19, width: -0.66 }, { number: 21, width: -0.62 }, { number: 31, width: -0.65 },
      { number: 41, width: -0.65 }, { number: 51, width: -0.65 }, { number: 61, width: -0.62 },
      { number: 71, width: -0.63 }, { number: 81, width: -0.65 }, { number: 91, width: -0.65 }
    ]
  },
  'UTEP_JERSEY_2026_BLUE': {
    numberSpacing: -0.58,
    playerNumberAdjust: [
      { number: 10, width: -0.64 }, { number: 11, width: -0.72 }, { number: 12, width: -0.64 },
      { number: 13, width: -0.64 }, { number: 14, width: -0.64 }, { number: 15, width: -0.64 },
      { number: 16, width: -0.64 }, { number: 17, width: -0.64 }, { number: 18, width: -0.64 },
      { number: 19, width: -0.64 }, { number: 21, width: -0.64 }, { number: 31, width: -0.64 },
      { number: 41, width: -0.64 }, { number: 51, width: -0.64 }, { number: 61, width: -0.64 },
      { number: 71, width: -0.64 }, { number: 81, width: -0.64 }, { number: 91, width: -0.64 }
    ]
  },
  'UTEP_Jersey_2021_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.57 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.48 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.48 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.48 }, { number: 31, width: -0.48 },
      { number: 41, width: -0.48 }, { number: 51, width: -0.48 }, { number: 61, width: -0.48 },
      { number: 71, width: -0.48 }, { number: 81, width: -0.48 }, { number: 91, width: -0.48 }
    ]
  },
  'UTSA_Jersey_2025_NUM_Array': {
    numberSpacing: -0.48,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.69 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.58 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.58 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.58 }, { number: 31, width: -0.58 },
      { number: 41, width: -0.58 }, { number: 51, width: -0.58 }, { number: 61, width: -0.58 },
      { number: 71, width: -0.58 }, { number: 81, width: -0.58 }, { number: 91, width: -0.58 }
    ]
  },
  'UVA_Jersey_2021_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.74 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.52 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.55 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'VAN_Jersey_2021_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.55 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.48 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.48 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.48 }, { number: 31, width: -0.48 },
      { number: 41, width: -0.48 }, { number: 51, width: -0.48 }, { number: 61, width: -0.48 },
      { number: 71, width: -0.48 }, { number: 81, width: -0.48 }, { number: 91, width: -0.48 }
    ]
  },
  'VT_Jersey_2023_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.67 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.49 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.52 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.52 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'VT_Jersey_2024_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.67 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.49 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.52 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.52 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'WAKE_Jersey_2022_NUM_Array': {
    numberSpacing: -0.45,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.72 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'WASH_JERSEY_2021_THROWBACK': {
    numberSpacing: -0.5,
    playerNumberAdjust: [
      { number: 10, width: -0.58 }, { number: 11, width: -0.68 }, { number: 12, width: -0.58 },
      { number: 13, width: -0.58 }, { number: 14, width: -0.58 }, { number: 15, width: -0.58 },
      { number: 16, width: -0.59 }, { number: 17, width: -0.58 }, { number: 18, width: -0.58 },
      { number: 19, width: -0.58 }, { number: 21, width: -0.64 }, { number: 31, width: -0.64 },
      { number: 41, width: -0.64 }, { number: 51, width: -0.64 }, { number: 61, width: -0.63 },
      { number: 71, width: -0.64 }, { number: 81, width: -0.64 }, { number: 91, width: -0.64 }
    ]
  },
  'WASH_Jersey_2021_NUM_Array': {
    numberSpacing: -0.404939115,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.63 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'WASH_Jersey_2023_NUM_Array': {
    numberSpacing: -0.404939115,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.63 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'WASH_Jersey_2024_NUM_Array': {
    numberSpacing: -0.404939115,
    playerNumberAdjust: [
      { number: 10, width: -0.53 }, { number: 11, width: -0.63 }, { number: 12, width: -0.53 },
      { number: 13, width: -0.53 }, { number: 14, width: -0.53 }, { number: 15, width: -0.53 },
      { number: 16, width: -0.53 }, { number: 17, width: -0.53 }, { number: 18, width: -0.53 },
      { number: 19, width: -0.53 }, { number: 21, width: -0.54 }, { number: 31, width: -0.54 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.54 }, { number: 61, width: -0.54 },
      { number: 71, width: -0.54 }, { number: 81, width: -0.54 }, { number: 91, width: -0.54 }
    ]
  },
  'WASH_Jersey_2025_Camo_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.6 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'WASH_Jersey_2025_NUM_Array': {
    numberSpacing: -0.38,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.6 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'WIS_Jersey_2021_NUM_Array': {
    numberSpacing: -0.51,
    playerNumberAdjust: [
      { number: 10, width: -0.63 }, { number: 11, width: -0.73 }, { number: 12, width: -0.63 },
      { number: 13, width: -0.63 }, { number: 14, width: -0.63 }, { number: 15, width: -0.63 },
      { number: 16, width: -0.63 }, { number: 17, width: -0.63 }, { number: 18, width: -0.63 },
      { number: 19, width: -0.63 }, { number: 21, width: -0.63 }, { number: 31, width: -0.63 },
      { number: 41, width: -0.63 }, { number: 51, width: -0.63 }, { number: 61, width: -0.63 },
      { number: 71, width: -0.63 }, { number: 81, width: -0.63 }, { number: 91, width: -0.63 }
    ]
  },
  'WIS_Jersey_2026_Shamrock_NUM_Array': {
    numberSpacing: -0.49,
    playerNumberAdjust: [
      { number: 10, width: -0.57 }, { number: 11, width: -0.66 }, { number: 12, width: -0.57 },
      { number: 13, width: -0.57 }, { number: 14, width: -0.57 }, { number: 15, width: -0.57 },
      { number: 16, width: -0.57 }, { number: 17, width: -0.57 }, { number: 18, width: -0.57 },
      { number: 19, width: -0.57 }, { number: 21, width: -0.57 }, { number: 31, width: -0.57 },
      { number: 41, width: -0.57 }, { number: 51, width: -0.57 }, { number: 61, width: -0.57 },
      { number: 71, width: -0.57 }, { number: 81, width: -0.57 }, { number: 91, width: -0.57 }
    ]
  },
  'WIS_Jersey_2025_Throwback_NUM_Array': {
    numberSpacing: -0.43,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.61 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.52 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.52 }, { number: 21, width: -0.52 }, { number: 31, width: -0.52 },
      { number: 41, width: -0.52 }, { number: 51, width: -0.52 }, { number: 61, width: -0.52 },
      { number: 71, width: -0.52 }, { number: 81, width: -0.52 }, { number: 91, width: -0.52 }
    ]
  },
  'WKU_JERSEY_2023_RED': {
    numberSpacing: -0.465,
    playerNumberAdjust: [
      { number: 10, width: -0.61 }, { number: 11, width: -0.7 }, { number: 12, width: -0.61 },
      { number: 13, width: -0.61 }, { number: 14, width: -0.61 }, { number: 15, width: -0.61 },
      { number: 16, width: -0.61 }, { number: 17, width: -0.61 }, { number: 18, width: -0.61 },
      { number: 19, width: -0.61 }, { number: 21, width: -0.56 }, { number: 31, width: -0.56 },
      { number: 41, width: -0.56 }, { number: 51, width: -0.56 }, { number: 61, width: -0.56 },
      { number: 71, width: -0.56 }, { number: 81, width: -0.56 }, { number: 91, width: -0.56 }
    ]
  },
  'WMU_Jersey_2024_NUM_Array': {
    numberSpacing: -0.4,
    playerNumberAdjust: [
      { number: 10, width: -0.5 }, { number: 11, width: -0.6 }, { number: 12, width: -0.5 },
      { number: 13, width: -0.5 }, { number: 14, width: -0.5 }, { number: 15, width: -0.5 },
      { number: 16, width: -0.5 }, { number: 17, width: -0.5 }, { number: 18, width: -0.5 },
      { number: 19, width: -0.5 }, { number: 21, width: -0.5 }, { number: 31, width: -0.5 },
      { number: 41, width: -0.5 }, { number: 51, width: -0.5 }, { number: 61, width: -0.5 },
      { number: 71, width: -0.5 }, { number: 81, width: -0.5 }, { number: 91, width: -0.5 }
    ]
  },
  'WSU_Jersey_2023_NUM_Array': {
    numberSpacing: -0.44,
    playerNumberAdjust: [
      { number: 10, width: -0.6 }, { number: 11, width: -0.7 }, { number: 12, width: -0.6 },
      { number: 13, width: -0.6 }, { number: 14, width: -0.56 }, { number: 15, width: -0.6 },
      { number: 16, width: -0.6 }, { number: 17, width: -0.6 }, { number: 18, width: -0.6 },
      { number: 19, width: -0.6 }, { number: 21, width: -0.6 }, { number: 24, width: -0.41 },
      { number: 31, width: -0.6 }, { number: 34, width: -0.41 }, { number: 41, width: -0.6 },
      { number: 42, width: -0.47 }, { number: 43, width: -0.47 }, { number: 44, width: -0.41 },
      { number: 45, width: -0.47 }, { number: 46, width: -0.47 }, { number: 47, width: -0.5 },
      { number: 48, width: -0.47 }, { number: 49, width: -0.47 }, { number: 51, width: -0.6 },
      { number: 54, width: -0.41 }, { number: 61, width: -0.6 }, { number: 64, width: -0.41 },
      { number: 71, width: -0.6 }, { number: 74, width: -0.41 }, { number: 81, width: -0.6 },
      { number: 84, width: -0.41 }, { number: 91, width: -0.6 }, { number: 94, width: -0.41 }
    ]
  },
  'WVU_JERSEY_2025_THROWBACK': {
    numberSpacing: -0.36,
    playerNumberAdjust: [
      { number: 10, width: -0.48 }, { number: 11, width: -0.58 }, { number: 12, width: -0.48 },
      { number: 13, width: -0.48 }, { number: 14, width: -0.48 }, { number: 15, width: -0.48 },
      { number: 16, width: -0.48 }, { number: 17, width: -0.48 }, { number: 18, width: -0.48 },
      { number: 19, width: -0.48 }, { number: 21, width: -0.48 }, { number: 31, width: -0.48 },
      { number: 41, width: -0.48 }, { number: 51, width: -0.48 }, { number: 61, width: -0.48 },
      { number: 71, width: -0.48 }, { number: 81, width: -0.48 }, { number: 91, width: -0.48 }
    ]
  },
  'WVU_Jersey_2021_NUM_Array': {
    numberSpacing: -0.375,
    playerNumberAdjust: [
      { number: 10, width: -0.55 }, { number: 11, width: -0.73 }, { number: 12, width: -0.55 },
      { number: 13, width: -0.55 }, { number: 14, width: -0.55 }, { number: 15, width: -0.55 },
      { number: 16, width: -0.55 }, { number: 17, width: -0.53 }, { number: 18, width: -0.55 },
      { number: 19, width: -0.55 }, { number: 21, width: -0.55 }, { number: 31, width: -0.55 },
      { number: 41, width: -0.55 }, { number: 51, width: -0.55 }, { number: 61, width: -0.55 },
      { number: 71, width: -0.55 }, { number: 81, width: -0.55 }, { number: 91, width: -0.55 }
    ]
  },
  'WYO_Jersey_2021_NUM_Array': {
    numberSpacing: -0.396063447,
    playerNumberAdjust: [
      { number: 10, width: -0.52 }, { number: 11, width: -0.6 }, { number: 12, width: -0.52 },
      { number: 13, width: -0.52 }, { number: 14, width: -0.52 }, { number: 15, width: -0.52 },
      { number: 16, width: -0.52 }, { number: 17, width: -0.52 }, { number: 18, width: -0.52 },
      { number: 19, width: -0.54 }, { number: 21, width: -0.47 }, { number: 31, width: -0.47 },
      { number: 41, width: -0.47 }, { number: 51, width: -0.47 }, { number: 61, width: -0.47 },
      { number: 71, width: -0.47 }, { number: 81, width: -0.47 }, { number: 91, width: -0.47 }
    ]
  }
};
// Which offsetScaleSpacing sub-objects get cloned wholesale alongside the
// font. Each is written as one atomic object replace (never a partial x/y/z/w
// merge), same reasoning as playerNumberAdjust: a stale leftover component
// from the previous font is worse than a clean full swap.
const NUMBER_OFFSET_SCALE_FIELDS = [
  'chestNumberOffsetScale', 'backNumberOffsetScale', 'shoulderNumberOffsetScale', 'sleeveNumberOffsetScale'
];

// v1 scope: only fields confirmed to actually work in-game. Helmet number font and
// name font are left out entirely -- both are still unverified (see the prompt doc),
// and weren't wanted in this pass regardless.
const FIELD_GROUPS = [
  {
    key: 'jerseyNumberFont', label: 'Jersey Number Font', status: 'ok', partKind: 'jersey',
    subfields: [
      {
        key: 'font', label: '',
        options: () => [...CATALOG.numberFonts.jersey, ...CATALOG.numberFonts.alts]
          .filter(e => isUsableFontPath(e.path) && !/_name_array$/i.test(e.path)),
        // Optional: when the picked font has a confirmed entry here, applyField
        // also writes its full number layout (spacing, 4 offset/scale blocks,
        // playerNumberAdjust) in the same action. Fonts with no entry behave
        // exactly as before -- this is additive.
        numberLayoutProfiles: NUMBER_LAYOUT_PROFILES,
        // Confirmed: arrayTexture.textureId can't be left blank, and once set, both
        // it and the overlay's textureId use the identical non-/comp/ path.
        targets: [
          { label: 'arrayTexture', path: ['numberComp', 'arrayTexture', 'textureId'], transform: stripCompSegment },
          { label: 'overlay', path: ['numberComp', 'overlays', 0, 'textures', 'color', 'textureId'], transform: stripCompSegment }
        ]
      }
    ]
  },
  {
    key: 'helmetMaterials', label: 'Helmet Materials', status: 'ok', partKind: 'helmet',
    subfields: [
      {
        key: 'shell', label: 'Shell',
        hint: 'Also sets the matching accessory automatically.',
        options: () => CATALOG.helmetMaterials.shell,
        targets: [
          { label: 'shell', path: ['shellMaterial'] },
          { label: 'accessory (auto)', path: ['accMaterial'], lookupCatalog: () => CATALOG.helmetMaterials.accessory }
        ]
      }
    ]
  }
];
const STATUS_BADGE = {
  ok: '<span class="badge ok">confirmed</span>',
  warn: '<span class="badge warn">unverified</span>',
  off: '<span class="badge off">out of scope</span>'
};

// ---------- editor rendering ----------
function renderEditor() {
  const out = document.getElementById('editorOut');
  if (!state.payload || !state.variants.length) {
    out.innerHTML = '<div class="empty-state">No uniform variants found in this payload — check it actually has teamData.frostbiteData.uniformParts.</div>';
    return;
  }
  const variantOptions = state.variants.map((v, i) => `<option value="${i}"${i === state.selectedVariantIdx ? ' selected' : ''}>${escapeHtml(v.label)}</option>`).join('');

  out.innerHTML = `
    <div class="row">
      <div class="field">
        <label for="variantSel">Uniform variant</label>
        <select id="variantSel">${variantOptions}</select>
      </div>
    </div>
    <div id="fieldsOut"></div>
    <div id="teamColorsOut" style="margin-top:12px;"></div>
    <div id="decalOut" style="margin-top:12px;"></div>
    <div id="numberColorOut" style="margin-top:12px;"></div>
    <div id="spacingOut" style="margin-top:12px;"></div>
  `;
  document.getElementById('variantSel').addEventListener('change', (e) => {
    state.selectedVariantIdx = +e.target.value;
    state.lastSelections = {};
    renderFields();
    renderTeamColorsSection();
    renderDecalSection();
    renderNumberColorSection();
    // Conference Logo Tint parked as of v0.49 -- see comment at
    // renderConferenceTintSection for why. Not called here on purpose.
    // Number Size parked as of v0.74 -- see renderSizeSection. Not called here on purpose.
    renderSpacingSection();
  });
  renderFields();
  renderTeamColorsSection();
  renderDecalSection();
  renderNumberColorSection();
  // Conference Logo Tint parked as of v0.49 -- see renderConferenceTintSection.
  // Number Size parked as of v0.74 -- see renderSizeSection.
  renderSpacingSection();
}

function renderFields() {
  const variant = state.variants[state.selectedVariantIdx];
  const fieldsEl = document.getElementById('fieldsOut');

  fieldsEl.innerHTML = FIELD_GROUPS.map(group => {
    const part = getPart(group);

    const subfieldsHtml = !part ? '' : group.subfields.map(sub => {
      const gsKey = group.key + ':' + sub.key;
      const listId = 'dl-' + gsKey;
      const opts = sub.options();
      const datalist = opts.length ? `<datalist id="${listId}">${opts.map(o => `<option value="${escapeHtml(o.label || o.displayName)}">`).join('')}</datalist>` : '';

      const currentValsHtml = sub.targets.map(t => {
        const v = getDeep(part, t.path);
        const tag = sub.targets.length > 1 ? ` (${escapeHtml(t.label)})` : '';
        return `<div class="current-val"><b>current${tag} — what's already there:</b> ${escapeHtml(v || '(unset)')}</div>`;
      }).join('');

      const lastValue = state.lastSelections[gsKey] || '';

      return `
        <div${group.subfields.length > 1 ? ' style="margin-top:14px; padding-top:14px; border-top:1px solid var(--line);"' : ''}>
          ${sub.label ? `<div style="font-weight:600; font-size:12.5px; margin-bottom:6px;">${escapeHtml(sub.label)}</div>` : ''}
          ${sub.hint ? `<div class="hint" style="margin-bottom:6px;">${escapeHtml(sub.hint)}</div>` : ''}
          <div class="row" style="align-items:flex-start;">
            <div class="field">
              <input type="text" list="${listId}" data-key="${gsKey}" value="${escapeHtml(lastValue)}" placeholder="${opts.length ? 'Pick from catalog' : 'Paste a raw path'} — sets ${sub.targets.length > 1 ? 'all fields' : 'this field'} at once">
            </div>
            ${group.key === 'jerseyNumberFont' ? `<button type="button" data-gallery-key="${gsKey}" title="Browse with preview images">Gallery</button>` : ''}
            <button type="button" data-clear-key="${gsKey}" title="Clear this field">Clear</button>
          </div>
          ${datalist}
          ${currentValsHtml}
        </div>`;
    }).join('');

    return `
      <div class="fieldblock">
        <div class="head">
          <div class="name">${escapeHtml(group.label)}</div>
          ${STATUS_BADGE[group.status]}
        </div>
        ${!part ? `<div class="hint">No ${group.partKind} part found for this variant.</div>` : subfieldsHtml}
      </div>`;
  }).join('');

  FIELD_GROUPS.forEach(group => {
    group.subfields.forEach(sub => {
      const gsKey = group.key + ':' + sub.key;
      const input = fieldsEl.querySelector(`input[data-key="${gsKey}"]`);
      if (input) {
        input.addEventListener('change', () => applyField(group, sub, input.value));
        // Select all existing text on focus, so typing immediately overwrites
        // instead of requiring a manual select-all-and-delete first.
        input.addEventListener('focus', () => input.select());
      }
      const clearBtn = fieldsEl.querySelector(`button[data-clear-key="${gsKey}"]`);
      if (clearBtn && input) {
        clearBtn.addEventListener('click', () => {
          input.value = '';
          input.focus();
        });
      }
      const galleryBtn = fieldsEl.querySelector(`button[data-gallery-key="${gsKey}"]`);
      if (galleryBtn && input) {
        galleryBtn.addEventListener('click', () => openFontGallery(sub.options(), input));
      }
    });
  });
}

function openFontGallery(opts, input) {
  openGalleryPicker(opts, input, {
    title: 'Jersey Number Font',
    countNoun: 'fonts',
    thumbHtml: o => `<img src="previews/${encodeURIComponent(o.displayName)}.jpg" alt="">`,
    missingNote: 'entries without a screenshot yet show a placeholder',
    wireThumb: (tileEl) => {
      const img = tileEl.querySelector('img');
      if (img) img.addEventListener('error', () => {
        img.style.display = 'none';
        tileEl.querySelector('[data-thumb]').classList.add('no-preview');
      });
    }
  });
}

// Vendor Decal gallery -- same modal shell as the font gallery, but tiles
// render the actual traced PREVIEW_SVGS regions inline (colored with this
// team's colors when available, falling back to the same red/green/blue
// default swatch colors used elsewhere) instead of a screenshot file.
// Entries with no trace yet (Diamond-style decals, blocked pending an RSM
// export -- see CHANGELOG) show a plain placeholder, same spirit as an
// un-screenshotted font.
function openDecalGallery(opts, input) {
  const teamColors = getTeamColors();
  const regionColorFor = { R: '#ff3b30', G: '#34c759', B: '#0a84ff' };
  const regionTeamColorFor = { R: teamColors.primary, G: teamColors.secondary, B: teamColors.tertiary };

  function decalThumbSvg(label) {
    const entry = PREVIEW_SVGS[label];
    if (!entry) return null;
    const paths = Object.entries(entry.regions).map(([ch, d]) => {
      const teamC = regionTeamColorFor[ch];
      const fill = teamC ? colorToHex(teamC) : regionColorFor[ch];
      return `<path d="${d}" fill="${fill}"/>`;
    }).join('');
    return `<svg viewBox="${entry.viewBox}" xmlns="http://www.w3.org/2000/svg"><g transform="${entry.transform}">${paths}</g></svg>`;
  }

  openGalleryPicker(opts, input, {
    title: 'Vendor Decal',
    countNoun: 'decals',
    thumbHtml: o => decalThumbSvg(o.label) || '',
    missingNote: 'entries without a confirmed trace yet (Diamond-style, needs an RSM export) show a placeholder',
    wireThumb: (tileEl, o) => {
      if (!decalThumbSvg(o.label)) tileEl.querySelector('[data-thumb]').classList.add('no-preview');
    }
  });
}

// Shared gallery modal shell used by both the font and decal pickers.
// config: { title, countNoun, thumbHtml(o), missingNote, wireThumb(tileEl, o) }
function openGalleryPicker(opts, input, config) {
  let overlay = document.getElementById('galleryOverlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'galleryOverlay';
    overlay.className = 'gallery-overlay';
    document.body.appendChild(overlay);
  }
  let mode = 'gallery'; // 'gallery' | 'list'
  let query = '';

  function renderModal() {
    const filtered = opts.filter(o => {
      if (!query) return true;
      const hay = (o.label || o.displayName || '').toLowerCase();
      return hay.includes(query.toLowerCase());
    });

    const tilesHtml = mode === 'gallery'
      ? `<div class="gallery-grid">${filtered.map(o => `
          <div class="gallery-tile" data-pick="${escapeHtml(o.displayName || o.label)}" data-label="${escapeHtml(o.label || o.displayName)}">
            <div class="gallery-thumb" data-thumb>${config.thumbHtml(o)}</div>
            <div class="gallery-caption">${escapeHtml(o.label || o.displayName)}</div>
          </div>`).join('')}</div>`
      : `<div class="gallery-list">${filtered.map(o => `
          <div class="gallery-list-row" data-pick="${escapeHtml(o.displayName || o.label)}" data-label="${escapeHtml(o.label || o.displayName)}">
            ${escapeHtml(o.label || o.displayName)}
          </div>`).join('')}</div>`;

    overlay.innerHTML = `
      <div class="gallery-modal">
        <div class="gallery-toolbar">
          <div style="font-weight:600; font-size:13px;">${escapeHtml(config.title)}</div>
          <input type="text" id="galSearch" placeholder="Search ${opts.length} ${config.countNoun}…" value="${escapeHtml(query)}" style="flex:1;">
          <button type="button" id="galModeGallery" class="${mode === 'gallery' ? 'primary' : ''}">Gallery</button>
          <button type="button" id="galModeList" class="${mode === 'list' ? 'primary' : ''}">List</button>
          <button type="button" id="galClose" title="Close">✕</button>
        </div>
        <div class="gallery-status">${filtered.length} of ${opts.length} ${config.countNoun}${mode === 'gallery' ? ' — ' + config.missingNote : ''}</div>
        <div class="gallery-body">${tilesHtml}</div>
      </div>`;

    if (mode === 'gallery') {
      overlay.querySelectorAll('.gallery-tile').forEach((tileEl, i) => {
        config.wireThumb(tileEl, filtered[i]);
      });
    }
    overlay.querySelector('#galSearch').addEventListener('input', (e) => { query = e.target.value; renderModal(); overlay.querySelector('#galSearch').focus(); overlay.querySelector('#galSearch').selectionStart = overlay.querySelector('#galSearch').value.length; });
    overlay.querySelector('#galModeGallery').addEventListener('click', () => { mode = 'gallery'; renderModal(); });
    overlay.querySelector('#galModeList').addEventListener('click', () => { mode = 'list'; renderModal(); });
    overlay.querySelector('#galClose').addEventListener('click', closeGallery);
    overlay.querySelectorAll('[data-pick]').forEach(el => {
      el.addEventListener('click', () => {
        input.value = el.getAttribute('data-label');
        input.dispatchEvent(new Event('change'));
        closeGallery();
      });
    });
  }

  function closeGallery() {
    overlay.classList.remove('open');
    overlay.innerHTML = '';
  }

  overlay.classList.add('open');
  renderModal();
  setTimeout(() => overlay.querySelector('#galSearch')?.focus(), 0);
}

function getPart(group) {
  const variant = state.variants[state.selectedVariantIdx];
  const partKey = group.partKind === 'helmet' ? variant.helmetKey : variant.jerseyKey;
  if (!partKey) return null;
  const basePath = ['teamData', 'frostbiteData', 'uniformParts', group.partKind === 'helmet' ? 'helmets' : 'jerseys', partKey];
  return getDeep(state.payload, basePath);
}

// ---------- vendor decal swapper (jersey + pants + socks together) ----------
// Confirmed working in-game across multiple brands/materials. Finds the vendor
// logo overlay(s) structurally -- by checking which overlay's own texture
// already points into .../decals/vendors/... -- rather than searching by
// info.label, since the label text itself changes to match whichever brand is
// currently equipped (confirmed: "Nike Logo" vs "Adidas Logo" on different
// default teams). That makes label text unreliable as a search key, but a
// fine thing to display for confirmation once found.
//
// Returns ALL matching indices, not just the first -- confirmed some templates
// (Nike socks specifically) carry two separate decal overlays (mirrored left/
// right sides), and updating only one would leave the other on the old brand.
function findVendorDecalOverlays(part) {
  const overlays = part?.layerCompTexture?.overlays;
  if (!Array.isArray(overlays)) return [];
  const out = [];
  overlays.forEach((o, i) => {
    const tid = o?.textures?.color?.textureId;
    if (typeof tid === 'string' && tid.toLowerCase().includes('/decals/vendors/')) out.push(i);
  });
  return out;
}

const DECAL_PIECES = [
  { kind: 'jersey', plural: 'jerseys', keyField: 'jerseyKey' },
  { kind: 'pants', plural: 'pants', keyField: 'pantsKey' },
  { kind: 'socks', plural: 'socks', keyField: 'socksKey' }
];

// Placement defaults per brand, per piece -- pulled from confirmed real team
// recipes. Nike, Jumpman, UA, and Adidas each now have 2 confirmed schools
// with matching values across jersey/pants/socks -- consistent enough that
// per-brand (not per-template) placement looks like the right model after all.
// Still examples from specific teams, not guaranteed universal constants.
//
// Only applied when a piece has exactly ONE decal overlay. A multi-overlay
// piece (Nike's two-sided socks are the only confirmed case) gets its texture
// updated on every matching overlay, but placement is left alone -- no
// confirmed per-side data to apply safely there.
const BRAND_PIECE_TRANSFORM = {
  'Nike': {
    jersey: { scaleU: 0.05, scaleV: 0.05, offsetU: 0.0745, offsetV: -0.1085, rotate: 350 },
    // Confirmed via two independent schools (FSU, and this exact team via
    // Frosty Editor) -- essentially identical values both times. The earlier
    // "Nike is broken" report was very likely the same cross-brand layout
    // contamination diagnosed for Nike Plastic, not bad reference numbers.
    // layout: null is itself confirmed -- Nike's pants overlay has no fourth
    // UV-set texture slot in Frosty, unlike Jumpman/Adidas. Explicitly
    // resetting it (not just leaving it alone) actively undoes contamination
    // from a prior Jumpman/Adidas test instead of silently inheriting it.
    pants: { scaleU: 0.06, scaleV: 0.12, offsetU: 0.154, offsetV: 0.234, rotate: 7.5, layout: null }
    // socks intentionally omitted -- two mirrored overlays, no safe single value
  },
  'Jumpman': {
    jersey: { scaleU: 0.03, scaleV: 0.03, offsetU: 0.0745, offsetV: -0.094, rotate: 0 },
    pants: {
      scaleU: 0.069, scaleV: 0.085, offsetU: 0.222, offsetV: 0.339, rotate: 5.0,
      layout: 'ContentShared/characters/player/parts/uniforms/uvsets/Pants_UVSet_front'
    },
    socks: { scaleU: 0.07, scaleV: 0.07, offsetU: 0, offsetV: 0.315, rotate: 0 }
  },
  'Under Armour': {
    jersey: { scaleU: 0.035, scaleV: 0.036, offsetU: 0, offsetV: -0.1325, rotate: 0 },
    // Pants confirmed via a fresh, provably untouched team's raw JSON export --
    // not Frosty. Frosty's Georgia Tech reading (0.04/0.07, offset -0.155/0.255,
    // rotate 354) disagreed meaningfully with this direct JSON pull, especially
    // on offset.u (opposite sign) and rotate (near-mirrored angle) -- a real
    // discrepancy, not rounding noise. Going with the direct JSON value as the
    // more trustworthy source, per the same reasoning already validated for
    // Nike/Jumpman/Adidas (all confirmed via raw JSON, not Frosty alone).
    // layout: null confirmed on this same fresh export -- consistent with what
    // Frosty showed (no fourth UV-set slot), so that part of the picture holds.
    pants: { scaleU: 0.04, scaleV: 0.08, offsetU: 0.138, offsetV: 0.265, rotate: 7.2, layout: null },
    socks: { scaleU: 0.1, scaleV: 0.08, offsetU: 0, offsetV: 0.3, rotate: 0 }
  },
  'Adidas': {
    jersey: { scaleU: 0.042, scaleV: 0.042, offsetU: 0.07, offsetV: -0.124, rotate: 358 },
    // CORRECTED v0.68 -- previous values (scaleU 0.04, scaleV 0.08, offsetU
    // 0.16, offsetV 0.265, rotate 7, layout written) did not match a real
    // export from a genuinely untouched stock team (base Adidas Logo (2023)
    // on pants). That real overlay has NO layout field at all (null, not a
    // missing-but-needed slot) -- the v0.12-era "pants needs layout written"
    // finding was apparently specific to whatever team was tested then, not
    // a rule that holds for a fresh stock team. This was the wrong reference
    // point every Plastic/Shiny/Trefoil pants calculation in this file was
    // built against (see v0.66/v0.67) -- likely the real root cause of all
    // of it, not a per-material issue.
    pants: { scaleU: 0.05, scaleV: 0.095, offsetU: 0.167, offsetV: 0.242, rotate: 5 },
    socks: { scaleU: 0.13, scaleV: 0.13, offsetU: 0, offsetV: 0.29, rotate: 0 }
  }
};

// Per-material overrides, layered on top of the brand-level defaults above.
// Only needed when a specific material genuinely differs from its brand's
// baseline -- confirmed here for Adidas WithText specifically (bigger scale,
// different offset than base Adidas), verified via an actual in-game Team
// Builder render, not just a raw-JSON comparison. Keyed by the exact catalog
// label. Jumpman's Cotton vs. Diamond were confirmed to NOT need this --
// same placement, brand-level default was already correct for both.
//
// v0.45/v0.65 history on Adidas Plastic/Shiny, for context: v0.45 guessed the
// pants placement bug was a missing `layout` write and omitted it as a test;
// v0.65 found that backwards (confirmed-good Adidas (2023) DOES write layout
// with the same numbers) and reverted to the plain brand default. Still
// broken after that revert -- so the layout field was never the actual
// cause. See the TEST entries below for the real one.
//
// v0.66's computed overrides for Adidas Plastic/Shiny/Trefoil were tested
// in-game and found wrong in BOTH directions (too small AND too low) for
// all three -- not just Trefoil, confirmed the same symptom hits Plastic
// and Shiny too, despite each having a different computed value. That rules
// out a per-material measurement mistake: the shared flaw is in the
// calculation method itself. Re-checked the source art directly -- Adidas
// (2023)'s stripes (the confirmed-correct reference) are tilted at the same
// diagonal angle as Plastic/Shiny's, so the rotation itself wasn't an
// unaccounted variable in the CONTENT; it's in the TRANSFORM. The
// scale/offset math assumed a simple linear offset+scale with rotate=0,
// but the real `rotate: 7` field rotates around some pivot point this
// model never accounted for, and that pivot interacts with scale and
// offset in ways a flat linear estimate can't capture. Reverted all three
// to no override (falls through to the plain Adidas brand default) as a
// clean, known baseline rather than compounding more unverified guesses.
// Next real step: a stock/untouched team's direct JSON export with one of
// these materials already equipped, same gold-standard source used to
// confirm UA and Nike pants placement (v0.17/v0.18) -- or manual
// trial-and-error in Team Builder with a live visual feedback loop, since
// that's inherently more reliable than computing blind from a screenshot.
const MATERIAL_PIECE_OVERRIDES = {
  'Adidas WithText (2023)': {
    pants: {
      scaleU: 0.056, scaleV: 0.112, offsetU: 0.16, offsetV: 0.33, rotate: 7,
      layout: 'ContentShared/characters/player/parts/uniforms/uvsets/Pants_UVSet_maddenOld'
    }
  }
};

function decalPieceStatus() {
  const variant = state.variants[state.selectedVariantIdx];
  return DECAL_PIECES.map(pd => {
    const partKey = variant?.[pd.keyField];
    if (!partKey) return { ...pd, found: false, note: 'no part for this variant' };
    const part = getDeep(state.payload, ['teamData', 'frostbiteData', 'uniformParts', pd.plural, partKey]);
    const idxs = findVendorDecalOverlays(part);
    if (!idxs.length) return { ...pd, found: false, note: 'no vendor decal overlay found' };
    const overlay = part.layerCompTexture.overlays[idxs[0]];
    const label = idxs.length > 1 ? `${overlay?.info?.label || '(unlabeled)'} +${idxs.length - 1} more` : (overlay?.info?.label || '(unlabeled)');
    return { ...pd, found: true, idxs, label, current: overlay?.textures?.color?.textureId || '' };
  });
}


// Traced from real decal col-mask textures (potrace), same pipeline used
// to build the standalone staging gallery -- these are reference shapes,
// not pixel-exact reproductions (see trace_decal.py for the turdsize/smooth
// tuning that produced them). Keyed by exact catalog label; only the four
// vendor decals we've traced so far have an entry. Region letters (R/G/B)
// map directly to tint.colorR/colorG/colorB -- not every decal uses all
// three (Jumpman Cotton and Nike Plastic use R+G; Adidas Plastic and Under
// Armour Cotton use R+B, meaning colorG/secondary genuinely isn't read by
// those two, same "not every slot is used" pattern seen elsewhere).
const PREVIEW_SVGS = {
  "Jumpman Cotton (2022)": {
    viewBox: "0 0 512 512",
    transform: "translate(0.000000,512.000000) scale(0.100000,-0.100000)",
    regions: {
      R: "M2795 4806 c-65 -30 -189 -160 -205 -213 -8 -25 -11 -98 -8 -203 3\n-163 3 -166 37 -237 36 -77 37 -121 4 -171 -16 -26 -62 -176 -63 -205 0 -10\n-9 -35 -20 -57 -11 -22 -20 -56 -20 -76 0 -20 -5 -54 -11 -75 l-12 -38 -36 20\nc-31 16 -57 19 -182 19 -145 0 -146 0 -191 -30 -63 -42 -146 -132 -169 -185\n-17 -39 -20 -65 -18 -186 l1 -141 -35 -37 c-40 -41 -91 -119 -135 -206 -16\n-33 -39 -68 -50 -78 -10 -10 -27 -37 -37 -60 -23 -56 -21 -53 -98 -153 -37\n-49 -92 -139 -123 -200 -30 -62 -65 -123 -77 -136 -35 -37 -111 -69 -180 -75\n-56 -5 -66 -9 -104 -46 l-43 -41 0 -105 0 -106 133 -133 c148 -149 144 -130\n38 -191 -93 -53 -219 -151 -325 -255 l-98 -96 -87 0 -87 0 -39 -40 c-36 -37\n-41 -48 -45 -102 l-5 -60 -59 -19 c-33 -10 -85 -21 -115 -25 -52 -6 -60 -12\n-128 -78 l-73 -72 0 -110 c0 -107 1 -113 29 -150 16 -21 59 -68 95 -104 l67\n-65 143 -3 c116 -3 150 0 175 12 19 10 56 16 103 16 l73 0 130 127 c126 123\n196 173 242 173 12 0 75 40 140 88 65 49 159 110 208 137 104 56 243 143 300\n190 22 18 78 49 125 69 82 36 205 99 394 201 l89 48 66 -17 c66 -18 176 -60\n353 -135 52 -23 140 -50 194 -61 54 -11 110 -23 124 -28 61 -18 162 -81 297\n-183 80 -61 160 -116 177 -121 17 -6 72 -42 122 -80 59 -45 104 -71 128 -75\n29 -4 48 -19 95 -72 32 -36 71 -91 86 -121 15 -30 48 -76 73 -102 l46 -48 112\n0 112 0 48 44 c27 24 96 74 154 111 75 48 141 103 233 193 l127 126 0 101 0\n102 -59 56 -60 57 -108 0 -109 0 -35 36 -34 36 -130 -3 -130 -3 -46 34 c-25\n19 -99 80 -165 135 -208 175 -488 372 -564 396 -19 7 -66 40 -105 74 -89 79\n-154 125 -231 163 -51 26 -62 36 -67 62 -4 18 -29 54 -59 87 l-53 55 3 197 c4\n255 -6 348 -51 438 -49 98 -51 115 -26 181 12 32 25 91 29 132 10 103 27 191\n45 234 8 20 22 68 30 108 9 40 22 79 29 88 24 28 28 53 37 216 10 205 21 250\n63 268 17 7 67 51 112 98 96 100 104 123 104 293 0 170 -8 193 -104 293 -111\n116 -125 122 -311 122 -137 0 -154 -2 -200 -24z m315 -182 c88 -49 141 -157\n120 -249 -15 -66 -32 -95 -83 -142 -41 -38 -106 -63 -162 -63 -10 0 -13 -8 -9\n-27 3 -16 -1 -86 -10 -158 -8 -71 -12 -143 -9 -158 8 -43 -17 -177 -38 -196\n-9 -9 -20 -38 -25 -66 -4 -27 -16 -75 -27 -105 -22 -62 -32 -115 -47 -243 -7\n-53 -23 -118 -40 -163 -17 -41 -30 -92 -30 -114 0 -69 28 -176 66 -248 l37\n-71 5 -153 c4 -137 -1 -200 -24 -326 -10 -51 20 -107 72 -137 53 -31 68 -56\n61 -105 -5 -37 -5 -37 57 -66 141 -66 235 -130 350 -236 28 -26 61 -48 73 -48\n41 0 383 -239 578 -405 50 -42 112 -92 138 -112 38 -28 47 -41 43 -56 -6 -26\n10 -47 36 -47 10 0 30 -7 43 -16 24 -16 65 -12 65 7 0 5 7 9 15 9 20 0 36 -32\n24 -51 -5 -7 -9 -17 -9 -21 0 -5 48 -8 108 -8 105 0 109 0 179 37 l71 38 36\n-18 c20 -9 36 -23 36 -31 0 -23 -153 -166 -233 -218 -67 -44 -128 -87 -229\n-163 -39 -30 -40 -30 -55 -10 -8 11 -25 41 -37 67 -41 86 -215 267 -256 268\n-26 0 -75 29 -147 88 -23 18 -74 50 -112 70 -38 21 -129 83 -203 138 -155 118\n-223 154 -333 178 -147 31 -169 37 -260 76 -159 69 -218 91 -310 120 -49 15\n-111 38 -136 50 -29 14 -55 21 -70 17 -13 -4 -85 -40 -159 -82 -117 -66 -224\n-120 -450 -229 -30 -14 -82 -46 -115 -71 -68 -51 -213 -140 -294 -180 -29 -15\n-110 -70 -178 -121 -91 -69 -130 -93 -144 -89 -12 4 -29 -2 -45 -14 -15 -12\n-35 -21 -45 -21 -10 0 -42 -25 -71 -55 -29 -30 -61 -63 -71 -72 -9 -10 -46\n-46 -81 -81 l-64 -63 -62 7 c-52 6 -69 3 -110 -16 -71 -33 -111 -23 -177 46\n-40 40 -53 61 -53 83 0 37 46 78 98 86 73 11 143 29 148 37 3 4 14 8 24 8 32\n0 70 22 70 41 0 21 28 39 49 31 10 -3 12 0 7 13 -8 21 8 35 40 35 13 0 25 10\n33 26 9 21 17 25 38 21 36 -7 53 1 53 24 0 21 139 163 237 243 85 68 206 143\n334 207 54 27 102 55 106 63 10 18 67 46 92 46 12 0 30 17 47 44 42 66 305\n319 345 331 13 4 36 16 52 27 25 18 27 24 27 96 0 92 21 142 66 155 16 5 38\n22 50 38 20 28 20 31 5 91 -9 35 -24 74 -34 88 -9 13 -17 33 -17 43 0 23 -76\n127 -94 127 -7 0 -19 -11 -26 -25 -8 -14 -24 -28 -36 -31 -15 -4 -33 -27 -56\n-72 -40 -81 -82 -130 -164 -188 -109 -78 -157 -163 -152 -270 3 -63 5 -69 28\n-74 16 -4 25 -13 25 -25 0 -30 -77 -26 -109 4 l-25 23 -45 -47 c-56 -57 -86\n-54 -61 7 6 15 0 15 -58 -4 -62 -21 -97 -20 -97 2 0 5 18 17 40 26 55 22 50\n33 -9 20 -53 -10 -142 1 -148 20 -2 6 28 15 71 23 152 25 239 98 326 272 56\n111 118 210 173 273 19 21 40 55 47 75 6 20 24 52 39 71 15 19 54 84 87 144\n58 106 104 156 144 156 21 0 66 47 80 84 9 25 7 32 -24 67 -67 73 -78 113 -51\n190 22 62 60 106 115 134 78 40 144 29 218 -36 20 -17 50 -38 69 -45 23 -10\n33 -21 33 -37 0 -12 6 -30 13 -39 12 -15 16 -13 42 20 16 20 35 41 42 45 7 4\n13 14 13 21 0 6 16 59 35 117 19 57 35 121 35 142 0 21 9 55 20 77 11 22 20\n47 20 57 0 29 42 167 55 178 6 6 21 56 34 112 24 113 21 143 -24 233 -32 63\n-55 146 -55 199 0 97 85 208 176 230 56 14 132 4 184 -25z",
      G: "M2917 4643 c-127 -47 -188 -161 -157 -295 7 -29 28 -85 46 -124 19\n-39 37 -87 41 -107 6 -40 -34 -227 -51 -239 -10 -7 -55 -152 -56 -181 0 -10\n-9 -35 -20 -57 -11 -22 -20 -57 -20 -79 0 -22 -17 -90 -37 -153 -29 -90 -45\n-122 -77 -159 -44 -50 -54 -48 -69 11 -4 16 -20 31 -44 42 -21 10 -53 31 -72\n48 -40 35 -100 54 -144 45 -88 -19 -162 -94 -173 -177 -10 -70 2 -109 46 -158\n33 -36 40 -50 35 -70 -8 -30 -63 -90 -83 -90 -40 0 -80 -43 -142 -152 -35 -62\n-76 -129 -91 -148 -14 -19 -32 -52 -38 -73 -7 -21 -26 -52 -43 -70 -50 -53\n-123 -167 -178 -276 -88 -176 -179 -253 -323 -273 -47 -7 -76 -15 -74 -22 6\n-19 94 -31 148 -20 55 12 65 3 19 -16 -86 -36 -39 -63 53 -31 54 19 58 19 52\n3 -25 -61 5 -65 61 -7 l45 47 25 -23 c33 -31 109 -34 109 -4 0 12 -8 21 -20\n23 -34 7 -42 20 -43 74 -1 72 52 184 109 230 153 123 163 134 207 216 24 45\n50 82 57 82 7 0 25 14 38 30 14 17 32 30 39 30 17 0 88 -106 88 -130 0 -10 9\n-29 20 -43 11 -14 20 -32 20 -41 0 -8 7 -36 16 -61 15 -44 14 -47 -8 -74 -13\n-16 -33 -32 -45 -35 -49 -13 -63 -43 -63 -134 0 -80 -1 -85 -30 -112 -16 -15\n-42 -31 -57 -35 -15 -3 -44 -23 -63 -43 -20 -20 -77 -74 -127 -120 -50 -45\n-113 -110 -138 -145 -37 -48 -56 -65 -87 -74 -22 -6 -52 -23 -67 -37 -15 -14\n-79 -52 -143 -85 -133 -68 -232 -130 -315 -199 -92 -77 -223 -213 -223 -232 0\n-22 -18 -30 -52 -23 -22 4 -29 0 -43 -26 -9 -18 -21 -31 -28 -30 -37 5 -48 -1\n-42 -22 5 -16 3 -20 -6 -17 -21 8 -49 -10 -49 -31 0 -11 -11 -23 -28 -29 -64\n-26 -158 -52 -204 -58 -63 -9 -108 -44 -108 -85 0 -22 13 -43 53 -83 65 -68\n107 -79 174 -47 32 15 62 21 116 21 l72 0 57 58 c31 31 64 64 73 72 9 8 35 36\n58 62 46 51 151 111 179 102 11 -3 47 18 105 63 138 107 152 116 258 173 55\n29 146 85 203 124 114 79 146 96 312 175 63 30 165 83 225 117 149 83 231 124\n251 124 10 0 41 -11 70 -25 29 -14 76 -31 106 -39 49 -13 134 -43 183 -66 139\n-63 250 -102 355 -125 160 -35 217 -64 409 -209 84 -64 165 -119 180 -123 21\n-5 123 -73 141 -94 18 -21 89 -59 110 -59 44 0 215 -182 265 -282 36 -73 53\n-74 129 -8 31 27 78 62 104 77 26 14 70 42 97 61 63 44 215 192 215 210 0 7\n-14 19 -32 26 -37 16 -67 9 -130 -28 -41 -24 -54 -26 -156 -26 -62 0 -112 3\n-112 6 0 3 4 13 10 23 6 13 5 24 -3 35 -12 16 -15 16 -44 0 -29 -17 -32 -17\n-56 -1 -15 9 -35 17 -45 17 -26 0 -42 21 -36 47 4 16 -1 26 -23 39 -15 10 -59\n46 -98 80 -76 66 -232 190 -304 241 -162 116 -316 213 -337 213 -15 0 -43 19\n-76 51 -88 85 -176 146 -294 206 l-112 57 5 37 c7 48 -8 73 -61 104 -29 17\n-49 38 -61 65 -18 39 -18 44 0 145 14 81 17 139 13 254 l-5 149 -47 95 c-41\n84 -48 106 -53 180 -5 78 -4 90 25 161 17 42 34 104 37 139 10 101 26 188 50\n262 12 39 26 90 30 115 4 25 15 54 25 65 23 26 31 72 35 214 2 64 9 147 16\n185 6 37 9 83 6 101 -5 33 -5 33 41 40 87 13 165 73 198 151 19 44 18 136 -2\n182 -47 113 -185 176 -297 135z",
    }
  },
  "Nike Plastic (2023)": {
    viewBox: "0 0 512 512",
    transform: "translate(0.000000,512.000000) scale(0.100000,-0.100000)",
    regions: {
      R: "M1030 2924 c-126 -146 -224 -312 -255 -431 -19 -74 -19 -215 0 -281\n29 -98 108 -173 223 -214 44 -16 80 -20 163 -20 110 1 182 14 329 58 110 33\n855 280 1002 333 62 22 205 72 318 112 207 72 282 98 465 164 55 20 147 52\n205 72 101 34 154 60 100 49 -98 -20 -250 -49 -395 -76 -93 -17 -188 -35 -210\n-40 -22 -6 -69 -14 -105 -20 -36 -5 -132 -20 -215 -35 -440 -75 -998 -145\n-1164 -145 -119 0 -231 42 -300 112 -49 51 -77 106 -96 192 -18 79 -15 127 11\n224 11 38 -8 24 -76 -54z",
      G: "M1238 3251 c-93 -47 -263 -209 -369 -351 -154 -207 -220 -372 -220\n-551 1 -229 115 -391 321 -457 107 -35 285 -32 437 7 262 67 1421 464 2393\n819 657 240 670 246 670 292 0 50 -26 47 -437 -39 -1161 -244 -2144 -402\n-2508 -405 -134 -1 -142 0 -192 26 -91 48 -135 128 -137 248 -1 72 2 80 61\n205 68 143 78 174 68 204 -8 26 -39 27 -87 2z m-135 -290 c-24 -84 -15 -219\n21 -298 29 -64 96 -137 152 -166 68 -35 155 -49 269 -44 144 7 530 52 785 92\n256 40 425 68 520 85 58 11 157 29 220 40 199 36 321 60 444 86 65 14 120 23\n123 21 2 -3 -35 -18 -84 -35 -97 -34 -98 -34 -528 -187 -618 -220 -1294 -448\n-1610 -544 -89 -26 -259 -41 -345 -30 -136 19 -246 101 -291 218 -30 75 -32\n221 -5 301 37 109 111 245 187 342 44 57 152 178 156 175 1 -2 -5 -27 -14 -56z",
    }
  },
  "Adidas Plastic (2023)": {
    viewBox: "0 0 512 512",
    transform: "translate(0.000000,512.000000) scale(0.100000,-0.100000)",
    regions: {
      R: "M2805 3729 c-137 -83 -280 -170 -316 -193 -37 -22 -87 -53 -113 -68\nl-46 -27 282 -468 c155 -257 391 -650 526 -873 134 -223 247 -408 251 -413 4\n-4 233 -6 509 -5 l501 3 -267 445 c-147 245 -274 456 -283 470 -9 14 -38 62\n-65 108 -27 46 -75 127 -107 180 -32 53 -66 110 -75 126 -9 15 -44 73 -77 127\n-33 55 -84 139 -112 187 -29 48 -76 125 -104 172 -28 47 -66 110 -84 140 -87\n149 -144 235 -156 238 -8 1 -126 -66 -264 -149z M1975 2979 c-110 -67 -275\n-167 -367 -222 -93 -56 -168 -105 -168 -109 0 -3 38 -69 84 -145 175 -289 430\n-710 463 -765 l34 -58 504 0 c278 0 505 2 505 4 0 4 -580 973 -611 1021 -26\n40 -114 187 -180 303 -30 50 -56 92 -59 92 -3 0 -95 -54 -205 -121z M1150\n2238 c-63 -38 -221 -133 -350 -211 -129 -77 -241 -145 -248 -152 -11 -10 -3\n-29 41 -101 l53 -89 508 -3 507 -2 -13 24 c-59 108 -365 606 -373 606 -5 -1\n-62 -33 -125 -72z",
      B: "M2640 3838 c-272 -165 -507 -306 -522 -314 -16 -8 -28 -20 -28 -27 0\n-6 23 -48 50 -92 27 -43 46 -82 42 -86 -4 -4 -227 -141 -497 -304 -269 -163\n-492 -299 -494 -300 -1 -2 20 -43 49 -90 29 -48 48 -90 44 -95 -5 -4 -223\n-136 -484 -293 -261 -157 -482 -292 -491 -299 -15 -12 -4 -35 110 -226 l126\n-212 2088 -3 c1400 -1 2086 1 2083 8 -4 11 -1551 2589 -1570 2617 -10 15 -69\n-18 -506 -284z m1092 -1041 c362 -601 660 -1101 664 -1110 6 -16 -28 -17 -497\n-17 l-504 0 -76 128 c-66 111 -495 821 -520 862 -80 129 -461 770 -463 776 0\n4 96 66 215 138 284 172 314 191 422 258 51 32 94 58 97 58 3 0 301 -492 662\n-1093z m-1127 -399 c231 -385 422 -705 423 -709 2 -5 -214 -8 -503 -7 l-507 3\n-88 145 c-49 80 -109 179 -133 220 -24 41 -75 126 -113 188 -38 62 -90 148\n-115 190 -25 42 -65 107 -87 144 -23 37 -42 71 -42 76 0 8 728 452 740 452 3\n-1 194 -316 425 -702z m-1138 -390 c100 -167 185 -311 188 -320 7 -17 -21 -18\n-497 -18 l-504 0 -58 96 c-35 58 -54 100 -48 106 15 15 716 437 728 437 5 1\n92 -135 191 -301z",
    }
  },
  "Adidas (2022)": {
    viewBox: "0 0 512 512",
    transform: "translate(0.000000,512.000000) scale(0.100000,-0.100000)",
    regions: {
      R: "M2880 4028 c-63 -38 -130 -77 -147 -86 -18 -10 -59 -33 -90 -53 -32\n-20 -111 -67 -177 -105 -65 -37 -120 -74 -123 -80 -2 -6 16 -46 41 -89 25 -42\n46 -78 46 -79 0 -3 31 -57 155 -271 111 -192 208 -360 235 -410 25 -45 158\n-279 180 -315 23 -38 87 -149 195 -339 l80 -140 453 -1 c359 0 452 2 452 12 0\n7 -14 38 -31 68 -18 30 -42 73 -54 95 -12 22 -51 90 -87 150 -35 61 -111 191\n-168 290 -56 99 -115 200 -130 225 -15 25 -71 122 -124 215 -53 94 -101 177\n-106 185 -180 306 -387 664 -430 745 -15 28 -34 51 -41 52 -8 1 -66 -30 -129\n-69z\nM2020 3264 c-113 -64 -257 -145 -320 -181 -63 -35 -122 -71 -129 -78\n-17 -16 -19 -10 83 -190 61 -107 62 -109 114 -200 19 -33 46 -80 60 -105 27\n-48 37 -66 101 -177 58 -103 81 -142 109 -193 13 -25 28 -49 33 -55 5 -5 9\n-52 9 -105 0 -61 4 -100 12 -108 15 -15 124 -16 167 -1 l31 11 0 89 0 89 350\n0 350 0 0 -161 0 -160 -27 19 c-53 36 -139 55 -217 49 -168 -15 -295 -103\n-363 -254 -21 -47 -26 -73 -27 -143 0 -96 12 -142 59 -215 58 -90 134 -150\n233 -183 49 -16 202 -32 202 -21 0 4 28 17 63 30 34 13 65 25 68 27 4 1 9 -7\n12 -18 5 -19 11 -21 99 -18 l93 3 0 525 0 525 -95 3 -95 3 -107 187 c-58 103\n-141 248 -183 322 -42 74 -92 161 -111 192 -19 32 -40 68 -47 80 -69 131 -303\n528 -311 528 -6 -1 -103 -53 -216 -116z m839 -1664 c80 -40 142 -148 128 -220\n-25 -122 -102 -190 -217 -190 -226 0 -302 288 -106 401 63 36 137 39 195 9z\nM1394 2668 c-21 -11 -51 -29 -66 -39 -14 -11 -28 -19 -31 -19 -3 0\n-41 -21 -84 -46 -95 -57 -247 -145 -368 -214 -93 -53 -88 -47 -69 -83 9 -18\n21 -39 25 -47 5 -8 21 -37 35 -65 14 -27 35 -60 47 -72 l20 -23 443 0 c254 0\n445 4 448 9 5 7 -113 219 -194 351 -5 8 -41 70 -80 137 -39 68 -75 125 -79\n127 -4 3 -25 -4 -47 -16z\nM4638 2210 c-129 -15 -162 -179 -49 -237 20 -10 37 -21 39 -25 5 -10\n83 20 105 40 28 25 47 67 47 104 0 36 -50 108 -75 108 -7 0 -15 3 -17 8 -1 4\n-24 5 -50 2z m80 -65 c25 -29 29 -81 9 -109 -12 -17 -14 -16 -31 9 -16 24 -16\n28 -2 44 9 10 16 23 16 29 0 19 -43 42 -80 42 -27 0 -32 3 -20 11 24 16 83 2\n108 -26z m-128 -67 c0 -69 -1 -71 -16 -50 -19 27 -21 70 -5 100 6 12 14 22 16\n22 3 0 5 -33 5 -72z m70 32 c0 -5 -7 -10 -15 -10 -8 0 -15 5 -15 10 0 6 7 10\n15 10 8 0 15 -4 15 -10z m0 -91 c0 -4 10 -9 23 -12 21 -3 20 -4 -5 -11 -16 -5\n-40 -5 -55 0 -21 5 -24 8 -10 11 11 3 17 14 17 31 1 26 1 26 15 8 8 -11 15\n-23 15 -27z\nM4690 2156 c0 -2 8 -10 18 -17 15 -13 16 -12 3 4 -13 16 -21 21 -21\n13z\nM1794 2046 c-3 -14 -4 -86 -2 -161 3 -140 1 -147 -37 -122 -11 8 -46\n22 -79 32 -71 22 -174 16 -254 -14 -113 -42 -212 -149 -244 -264 -62 -219 54\n-432 277 -509 52 -18 180 -24 189 -9 3 4 24 11 47 15 23 4 51 13 62 21 23 16\n51 20 43 6 -14 -22 25 -32 111 -29 l88 3 0 525 0 525 -97 3 c-97 3 -97 2 -104\n-22z m-143 -440 c148 -62 189 -247 77 -352 -55 -53 -93 -67 -168 -62 -78 4\n-124 29 -167 92 -38 53 -45 154 -15 212 53 102 174 151 273 110z\nM610 1803 c-88 -13 -180 -63 -242 -131 -236 -257 -54 -668 302 -683\n52 -2 106 11 185 47 27 12 31 11 39 -7 9 -18 18 -19 105 -17 l96 3 3 393 2\n392 -93 0 c-93 0 -121 -9 -110 -36 7 -18 -21 -18 -39 -1 -13 13 -23 16 -113\n37 -40 9 -89 10 -135 3z m144 -197 c42 -18 98 -71 120 -113 24 -47 21 -143 -5\n-190 -44 -78 -101 -113 -187 -113 -164 0 -267 154 -203 302 44 103 174 156\n275 114z\nM2082 1418 l3 -393 103 -3 102 -3 -2 393 -3 393 -103 3 -102 3 2\n-393z\nM3590 1804 c-112 -22 -210 -87 -268 -177 -65 -99 -85 -216 -58 -337\n23 -107 164 -250 271 -276 17 -4 36 -11 43 -17 30 -24 192 0 264 39 35 19 45\n18 51 -6 5 -19 12 -21 94 -18 l88 3 3 393 2 393 -92 -3 c-88 -3 -93 -4 -96\n-25 -4 -26 -14 -28 -45 -11 -63 35 -188 55 -257 42z m165 -205 c86 -40 129\n-116 123 -215 -4 -68 -29 -111 -94 -161 -29 -21 -50 -28 -100 -31 -122 -8\n-219 68 -231 179 -7 69 8 124 47 170 62 76 166 100 255 58z\nM4410 1804 c-135 -26 -240 -134 -240 -249 0 -81 57 -170 127 -200 45\n-19 149 -45 203 -50 92 -10 150 -38 150 -74 -1 -21 -29 -56 -57 -70 -36 -18\n-134 -14 -170 9 -33 20 -58 54 -49 69 14 22 -26 32 -120 29 l-99 -3 3 -35 c5\n-50 34 -101 82 -144 45 -41 112 -75 146 -76 11 0 25 -5 31 -11 14 -14 144 -15\n181 -1 15 5 53 17 85 27 111 35 177 121 177 230 0 67 -17 109 -61 153 -57 58\n-110 76 -311 107 -21 3 -38 10 -38 15 0 4 -8 6 -19 3 -35 -9 -66 50 -43 83 15\n22 73 36 132 32 49 -3 64 -9 85 -32 14 -15 25 -35 25 -45 0 -23 27 -31 107\n-31 77 0 93 6 93 36 0 55 -55 134 -135 192 -36 27 -215 49 -285 36z",
    }
  },
  "Adidas (2023)": {
    viewBox: "0 0 512 512",
    transform: "translate(0.000000,512.000000) scale(0.100000,-0.100000)",
    regions: {
      R: "M2840 4008 c-91 -54 -177 -104 -192 -111 -16 -6 -28 -15 -28 -19 0\n-5 -4 -8 -10 -8 -5 0 -32 -14 -60 -31 -27 -17 -55 -27 -61 -23 -8 4 -9 3 -5\n-4 8 -14 -30 -36 -46 -26 -7 5 -8 3 -3 -6 6 -10 4 -12 -8 -7 -9 3 -19 1 -23\n-5 -4 -7 -3 -8 4 -4 7 4 12 5 12 3 0 -3 -20 -17 -45 -31 -25 -15 -45 -29 -45\n-33 0 -3 9 -21 21 -39 11 -19 17 -39 13 -46 -4 -7 -4 -10 1 -6 7 6 95 -121 95\n-137 0 -3 11 -22 24 -43 14 -20 38 -60 53 -89 23 -43 131 -233 168 -295 57\n-95 84 -151 79 -159 -3 -5 0 -8 6 -7 6 2 30 -31 53 -73 45 -82 282 -495 354\n-617 24 -41 43 -82 43 -91 0 -38 35 -41 495 -41 247 0 446 4 449 9 5 7 -77\n160 -144 271 -60 99 -108 181 -121 205 -8 17 -51 91 -94 165 -98 169 -105 182\n-105 198 0 6 -4 12 -8 12 -7 0 -39 49 -93 147 -25 43 -84 146 -199 343 -37 63\n-103 178 -148 255 -44 77 -89 156 -100 175 -12 19 -49 86 -84 147 -35 62 -67\n114 -73 116 -5 2 -84 -40 -175 -95z\nM2190 3364 c-25 -14 -70 -40 -100 -56 -30 -17 -68 -39 -85 -48 -61\n-35 -361 -204 -395 -222 -19 -11 -41 -26 -48 -33 -15 -14 -24 4 112 -233 42\n-74 76 -138 76 -143 0 -5 4 -9 9 -9 5 0 13 -10 17 -22 4 -13 18 -40 31 -61 24\n-39 49 -82 96 -168 13 -24 56 -100 95 -167 40 -68 72 -128 72 -133 0 -5 189\n-9 465 -9 256 0 465 3 465 6 0 7 -20 42 -189 336 -87 151 -140 252 -135 260 4\n7 4 10 -1 6 -10 -9 -74 90 -75 115 0 9 -4 17 -8 17 -7 0 -41 54 -100 160 -33\n60 -63 113 -104 182 -24 40 -37 72 -32 80 4 7 4 10 -1 6 -8 -8 -25 16 -76 107\n-15 27 -31 50 -36 52 -4 1 -28 -9 -53 -23z\nM1404 2678 c-21 -11 -93 -52 -159 -92 -66 -39 -129 -76 -140 -82 -11\n-6 -38 -21 -60 -33 -22 -12 -53 -30 -70 -40 -77 -47 -175 -101 -182 -101 -5 0\n-14 -9 -21 -20 -11 -18 -8 -29 23 -86 65 -118 77 -139 87 -151 16 -20 918 -19\n918 1 0 10 -176 321 -230 406 -5 8 -36 61 -68 117 l-59 102 -39 -21z",
    }
  },
  "Adidas Shiny (2023)": {
    viewBox: "0 0 512 512",
    transform: "translate(0.000000,512.000000) scale(0.100000,-0.100000)",
    regions: {
      R: "M2805 3730 c-143 -88 -287 -175 -320 -196 -33 -20 -81 -49 -107 -65\nl-47 -29 278 -462 c153 -255 391 -650 529 -878 l250 -415 506 -3 507 -2 -13\n24 c-42 77 -1313 2186 -1318 2185 -3 0 -122 -72 -265 -159z\nM1875 2919 c-165 -100 -330 -200 -367 -222 -38 -23 -68 -44 -68 -48\n0 -4 38 -70 84 -146 175 -289 430 -710 463 -765 l34 -58 505 0 c278 0 504 4\n502 8 -8 22 -844 1411 -848 1412 -3 0 -140 -82 -305 -181z\nM1150 2238 c-63 -38 -221 -133 -350 -211 -129 -77 -241 -145 -248\n-152 -10 -9 -2 -30 40 -103 l53 -91 508 -1 508 0 -13 24 c-59 108 -365 606\n-373 606 -5 -1 -62 -33 -125 -72z",
      B: "M2890 3997 c-129 -79 -355 -216 -502 -305 -147 -89 -270 -162 -273\n-162 -4 0 -13 -7 -22 -15 -14 -14 -10 -24 38 -102 50 -82 52 -86 33 -100 -37\n-28 -564 -343 -573 -343 -5 0 -11 -4 -13 -8 -1 -4 -91 -61 -198 -126 -107 -65\n-196 -119 -198 -121 -1 -1 20 -39 48 -83 27 -45 50 -86 50 -91 0 -5 -197 -127\n-437 -272 -541 -325 -553 -332 -553 -341 0 -4 57 -104 127 -222 l127 -216\n2093 0 c1151 0 2093 3 2093 6 0 3 -9 19 -21 35 -11 16 -17 29 -13 29 4 0 -2\n10 -13 23 -26 28 -115 177 -106 177 4 0 -3 10 -14 23 -26 28 -115 177 -106\n177 4 0 -3 10 -14 23 -11 12 -41 58 -67 102 -25 44 -51 87 -56 95 -16 27 -105\n174 -115 192 -96 170 -1063 1767 -1070 1767 -5 0 -116 -64 -245 -142z m848\n-1209 c364 -607 662 -1106 662 -1110 0 -5 -226 -8 -502 -8 l-503 0 -76 128\nc-58 97 -465 772 -520 862 -78 129 -118 195 -147 245 -19 33 -51 87 -72 120\n-20 33 -59 96 -85 140 -26 44 -74 124 -106 178 l-58 97 37 23 c20 13 129 79\n242 147 113 69 261 159 330 201 69 43 127 78 130 78 3 1 304 -495 668 -1101z\nm-1133 -390 c231 -385 422 -704 423 -709 2 -5 -211 -8 -503 -7 l-507 3 -88\n145 c-49 80 -109 179 -133 220 -24 41 -114 191 -200 333 -87 143 -157 262\n-157 266 0 3 10 13 23 20 101 64 713 431 717 431 3 -1 194 -316 425 -702z\nm-1138 -390 c100 -167 185 -311 188 -320 7 -17 -21 -18 -497 -18 l-504 0 -58\n96 c-35 58 -54 100 -48 106 15 15 716 437 728 437 5 1 92 -135 191 -301z",
    }
  },
  "Adidas WithText (2023)": {
    viewBox: "0 0 512 512",
    transform: "translate(0.000000,512.000000) scale(0.100000,-0.100000)",
    regions: {
      R: "M2840 4008 c-91 -54 -177 -104 -192 -111 -16 -6 -28 -15 -28 -19 0\n-5 -4 -8 -10 -8 -5 0 -32 -14 -60 -31 -27 -17 -55 -27 -61 -23 -8 4 -9 3 -5\n-4 8 -14 -30 -36 -46 -26 -7 5 -8 3 -3 -6 6 -10 4 -12 -8 -7 -9 3 -19 1 -23\n-5 -4 -7 -3 -8 4 -4 7 4 12 5 12 3 0 -3 -20 -17 -45 -31 -25 -15 -45 -29 -45\n-33 0 -3 9 -21 21 -39 11 -19 17 -39 13 -46 -4 -7 -4 -10 1 -6 7 6 95 -121 95\n-137 0 -3 11 -22 24 -43 14 -20 38 -60 53 -89 23 -43 131 -233 168 -295 57\n-95 84 -151 79 -159 -3 -5 0 -8 6 -7 6 2 30 -31 53 -73 45 -82 282 -495 354\n-617 24 -41 43 -82 43 -91 0 -38 35 -41 495 -41 247 0 446 4 449 9 5 7 -77\n160 -144 271 -60 99 -108 181 -121 205 -8 17 -51 91 -94 165 -98 169 -105 182\n-105 198 0 6 -4 12 -8 12 -7 0 -39 49 -93 147 -25 43 -84 146 -199 343 -37 63\n-103 178 -148 255 -44 77 -89 156 -100 175 -12 19 -49 86 -84 147 -35 62 -67\n114 -73 116 -5 2 -84 -40 -175 -95z\nM2190 3364 c-25 -14 -70 -40 -100 -56 -30 -17 -68 -39 -85 -48 -61\n-35 -361 -204 -395 -222 -19 -11 -41 -26 -48 -33 -15 -14 -24 4 112 -233 42\n-74 76 -138 76 -143 0 -5 4 -9 9 -9 5 0 13 -10 17 -22 4 -13 18 -40 31 -61 24\n-39 49 -82 96 -168 13 -24 56 -100 95 -167 40 -68 72 -127 72 -130 0 -6 570\n-14 848 -12 l72 0 0 -160 0 -160 -27 17 c-34 22 -91 43 -120 43 -12 0 -27 8\n-32 18 -6 9 -11 12 -11 6 0 -6 -28 -14 -63 -18 -162 -16 -287 -106 -354 -253\n-21 -47 -26 -73 -27 -143 0 -96 12 -142 59 -215 58 -90 134 -150 233 -183 49\n-16 202 -32 202 -21 0 4 28 17 63 30 34 13 65 25 68 27 4 1 9 -7 12 -18 5 -19\n11 -21 99 -18 l93 3 0 525 0 525 -94 5 -93 5 -22 40 c-13 22 -87 151 -165 287\n-87 151 -140 252 -135 260 4 7 4 10 -1 6 -10 -9 -74 90 -75 115 0 9 -4 17 -8\n17 -7 0 -41 54 -100 160 -33 60 -63 113 -104 182 -24 40 -37 72 -32 80 4 7 4\n10 -1 6 -8 -8 -25 16 -76 107 -15 27 -31 50 -36 52 -4 1 -28 -9 -53 -23z m668\n-1763 c52 -27 99 -79 117 -130 20 -57 19 -79 -5 -144 -34 -91 -101 -137 -200\n-137 -226 0 -302 288 -106 401 62 35 137 39 194 10z\nM1404 2678 c-21 -11 -93 -52 -159 -92 -66 -39 -129 -76 -140 -82 -11\n-6 -38 -21 -60 -33 -22 -12 -53 -30 -70 -40 -77 -47 -175 -101 -182 -101 -5 0\n-14 -9 -21 -20 -11 -18 -8 -29 23 -86 65 -118 77 -139 87 -151 16 -20 918 -19\n918 1 0 10 -176 321 -230 406 -5 8 -36 61 -68 117 l-59 102 -39 -21z\nM1803 2055 c-12 -9 -20 -21 -17 -29 8 -22 9 -276 1 -276 -5 0 -18 5\n-30 12 -34 19 -90 38 -114 38 -12 0 -27 8 -32 18 -6 9 -11 12 -11 6 0 -6 -28\n-14 -63 -18 -171 -17 -308 -126 -357 -283 -67 -219 49 -437 275 -515 52 -18\n180 -24 189 -9 3 4 24 11 47 15 23 4 51 13 62 21 23 16 51 20 43 6 -14 -22 25\n-32 111 -29 l88 3 3 521 2 521 -31 7 c-58 11 -144 7 -166 -9z m-152 -449 c148\n-62 189 -247 77 -352 -55 -53 -93 -67 -168 -62 -78 4 -124 29 -167 92 -38 53\n-45 154 -15 212 53 102 174 151 273 110z\nM2080 1965 l0 -96 103 3 102 3 3 70 c5 118 8 115 -108 115 l-100 0 0\n-95z\nM614 1809 c-10 -4 -39 -13 -64 -20 -88 -25 -192 -109 -239 -191 -148\n-264 48 -596 359 -609 52 -2 106 11 185 47 27 12 31 11 39 -7 9 -18 18 -19\n105 -17 l96 3 3 393 2 392 -93 0 c-93 0 -121 -9 -110 -36 7 -19 -22 -18 -41 1\n-8 8 -21 15 -30 15 -8 0 -25 4 -38 10 -34 14 -152 27 -174 19z m143 -204 c83\n-35 133 -112 133 -204 0 -125 -85 -211 -208 -211 -164 0 -267 154 -203 302 45\n104 174 156 278 113z\nM3605 1807 c-163 -47 -222 -85 -283 -180 -65 -99 -85 -216 -58 -337\n23 -107 164 -250 271 -276 17 -4 36 -11 43 -17 30 -24 192 0 264 39 35 19 45\n18 51 -6 5 -19 12 -21 94 -18 l88 3 3 393 2 393 -92 -3 c-88 -3 -93 -4 -96\n-25 -4 -26 -18 -29 -47 -10 -52 33 -189 59 -240 44z m150 -208 c86 -40 129\n-116 123 -215 -4 -68 -29 -111 -94 -161 -29 -21 -50 -28 -100 -31 -122 -8\n-219 68 -231 179 -7 69 8 124 47 170 62 76 166 100 255 58z\nM2082 1418 l3 -393 103 -3 102 -3 -2 393 -3 393 -103 3 -102 3 2\n-393z\nM4405 1804 c-140 -36 -235 -136 -235 -249 0 -82 57 -170 129 -201 41\n-17 151 -44 204 -49 88 -10 147 -39 147 -74 -1 -21 -29 -56 -57 -70 -36 -18\n-134 -14 -170 9 -33 20 -58 54 -49 69 14 22 -26 32 -120 29 l-99 -3 3 -35 c5\n-50 34 -101 82 -144 45 -41 112 -75 146 -76 11 0 25 -5 31 -11 14 -14 144 -15\n181 -1 15 5 53 17 85 27 111 35 177 121 177 230 0 68 -17 110 -60 153 -57 57\n-112 76 -312 107 -21 3 -38 10 -38 15 0 4 -8 6 -19 3 -35 -9 -66 49 -43 84 12\n19 60 33 115 33 62 0 113 -27 123 -65 9 -35 32 -45 108 -45 80 0 96 6 96 36 0\n55 -56 135 -135 192 -36 26 -233 51 -290 36z",
    }
  },
  "Under Armour Cotton (2022)": {
    viewBox: "0 0 512 512",
    transform: "translate(0.000000,512.000000) scale(0.100000,-0.100000)",
    regions: {
      R: "M1335 3806 c-281 -59 -633 -180 -888 -307 -159 -79 -177 -92 -177\n-134 0 -18 11 -73 26 -121 77 -270 337 -530 711 -714 51 -25 92 -48 92 -51 1\n-6 -50 -23 -58 -19 -2 1 -7 -2 -10 -7 -8 -12 -155 -93 -169 -93 -6 0 -22 -9\n-34 -21 -13 -12 -60 -47 -105 -80 -167 -119 -313 -281 -382 -423 -34 -70 -71\n-200 -71 -247 0 -37 29 -58 175 -129 314 -153 750 -294 1003 -324 l52 -7 1\n451 c1 247 2 453 3 458 1 4 6 22 10 40 4 17 12 32 17 32 6 0 8 4 4 10 -7 11\n44 113 78 154 l23 29 65 -16 c480 -119 1202 -121 1688 -6 46 11 89 18 96 15\n18 -6 83 -118 108 -186 20 -52 22 -77 25 -517 3 -445 4 -463 22 -463 30 0 208\n37 316 65 294 78 690 234 847 334 56 36 59 53 26 170 -55 202 -198 390 -419\n553 -83 61 -205 138 -219 138 -5 0 -11 3 -13 8 -1 4 -31 20 -65 37 -34 16 -60\n32 -57 36 2 4 -5 5 -16 2 -38 -10 -20 14 20 27 22 7 40 16 40 20 0 3 17 12 38\n19 20 8 39 17 42 20 3 4 36 24 73 45 163 90 375 278 466 415 52 76 94 167 111\n239 6 28 15 52 19 52 12 0 -1 85 -16 101 -20 24 -256 138 -403 197 -162 64\n-383 135 -535 171 -119 29 -149 35 -232 47 l-43 7 0 -454 c0 -501 1 -493 -65\n-618 -51 -97 -60 -103 -121 -91 -123 26 -314 60 -359 64 -197 20 -260 24 -336\n25 -48 1 -100 5 -115 9 -16 4 -40 6 -54 5 -14 -1 -106 -7 -204 -12 -162 -10\n-412 -35 -444 -46 -7 -3 -34 -7 -60 -11 -26 -3 -78 -13 -117 -23 -109 -26\n-114 -25 -156 44 -20 33 -47 87 -60 120 -24 60 -24 62 -27 523 l-3 462 -27 -1\nc-15 0 -76 -11 -137 -23z m1522 -1175 c61 -11 120 -24 130 -29 10 -5 33 -12\n52 -16 38 -7 231 -96 231 -106 0 -9 -139 -74 -215 -100 -290 -100 -714 -101\n-990 -2 -96 35 -215 91 -215 102 0 14 218 112 270 122 3 0 10 2 15 4 18 5 119\n26 153 31 181 27 394 25 569 -6z",
    }
  },
  "Under Armour Metallic (2022)": {
    viewBox: "0 0 512 512",
    transform: "translate(0.000000,512.000000) scale(0.100000,-0.100000)",
    regions: {
      R: "M1335 3806 c-281 -59 -633 -180 -888 -307 -159 -79 -177 -92 -177\n-134 0 -18 11 -73 26 -121 77 -270 337 -530 711 -714 51 -25 92 -48 92 -51 1\n-6 -50 -23 -58 -19 -2 1 -7 -2 -10 -7 -8 -12 -155 -93 -169 -93 -6 0 -22 -9\n-34 -21 -13 -12 -60 -47 -105 -80 -167 -119 -313 -281 -382 -423 -34 -70 -71\n-200 -71 -247 0 -37 29 -58 175 -129 314 -153 750 -294 1003 -324 l52 -7 1\n451 c1 247 2 453 3 458 1 4 6 22 10 40 4 17 12 32 17 32 6 0 8 4 4 10 -7 11\n44 113 78 154 l23 29 65 -16 c480 -119 1202 -121 1688 -6 46 11 89 18 96 15\n18 -6 83 -118 108 -186 20 -52 22 -77 25 -517 3 -445 4 -463 22 -463 30 0 208\n37 316 65 294 78 690 234 847 334 56 36 59 53 26 170 -55 202 -198 390 -419\n553 -83 61 -205 138 -219 138 -5 0 -11 3 -13 8 -1 4 -31 20 -65 37 -34 16 -60\n32 -57 36 2 4 -5 5 -16 2 -38 -10 -20 14 20 27 22 7 40 16 40 20 0 3 17 12 38\n19 20 8 39 17 42 20 3 4 36 24 73 45 163 90 375 278 466 415 52 76 94 167 111\n239 6 28 15 52 19 52 12 0 -1 85 -16 101 -20 24 -256 138 -403 197 -162 64\n-383 135 -535 171 -119 29 -149 35 -232 47 l-43 7 0 -454 c0 -501 1 -493 -65\n-618 -51 -97 -60 -103 -121 -91 -123 26 -314 60 -359 64 -197 20 -260 24 -336\n25 -48 1 -100 5 -115 9 -16 4 -40 6 -54 5 -14 -1 -106 -7 -204 -12 -162 -10\n-412 -35 -444 -46 -7 -3 -34 -7 -60 -11 -26 -3 -78 -13 -117 -23 -109 -26\n-114 -25 -156 44 -20 33 -47 87 -60 120 -24 60 -24 62 -27 523 l-3 462 -27 -1\nc-15 0 -76 -11 -137 -23z m1522 -1175 c61 -11 120 -24 130 -29 10 -5 33 -12\n52 -16 38 -7 231 -96 231 -106 0 -9 -139 -74 -215 -100 -290 -100 -714 -101\n-990 -2 -96 35 -215 91 -215 102 0 14 218 112 270 122 3 0 10 2 15 4 18 5 119\n26 153 31 181 27 394 25 569 -6z",
    }
  },
  "Under Armour Plastic (2023)": {
    viewBox: "0 0 512 512",
    transform: "translate(0.000000,512.000000) scale(0.100000,-0.100000)",
    regions: {
      R: "M525 4245 c-61 -37 -94 -77 -125 -159 -32 -83 12 -441 87 -711 61\n-219 157 -437 261 -593 23 -35 42 -67 42 -72 0 -5 4 -10 8 -12 5 -1 34 -33 65\n-69 l56 -67 -51 -58 c-261 -307 -448 -820 -476 -1310 -8 -133 -2 -161 52 -246\n20 -31 47 -55 86 -77 l58 -31 544 0 c600 0 615 1 683 61 52 46 61 89 46 212\n-21 177 -29 405 -20 547 9 130 35 290 48 290 3 0 7 12 8 26 2 42 14 46 89 30\n158 -32 282 -41 574 -41 292 0 416 9 574 41 38 8 73 11 77 7 4 -5 19 -52 33\n-107 46 -174 52 -499 15 -794 -15 -121 -6 -165 46 -211 68 -60 83 -61 683 -61\nl544 0 58 31 c39 22 66 46 86 77 54 85 60 113 52 246 -30 495 -214 1002 -476\n1310 l-51 58 56 67 c31 36 60 68 65 69 4 2 8 7 8 12 0 4 20 39 45 77 93 141\n189 354 251 558 33 107 25 74 63 275 16 91 34 226 38 300 l8 134 -38 76 c-34\n70 -43 80 -100 113 l-62 37 -545 0 c-602 0 -617 -1 -685 -61 -52 -46 -61 -89\n-46 -212 43 -357 27 -715 -40 -879 -10 -24 -14 -25 -42 -17 -114 33 -268 44\n-602 44 -332 -1 -527 -14 -632 -44 -28 -8 -32 -7 -42 17 -67 164 -83 522 -40\n879 15 123 6 166 -46 212 -68 60 -83 61 -685 61 l-545 0 -60 -35z m1121 -247\nc-31 -173 -32 -526 -1 -703 23 -137 80 -303 131 -386 25 -40 41 -75 37 -79 -4\n-4 -26 -14 -48 -22 -68 -27 -152 -67 -217 -104 -97 -56 -218 -136 -218 -144 0\n-8 121 -88 216 -143 65 -37 238 -117 253 -117 24 0 18 -23 -23 -90 -54 -87\n-110 -256 -132 -395 -30 -195 -29 -521 2 -692 l6 -33 -512 0 -512 0 6 88 c45\n565 290 1072 660 1360 l29 22 -29 22 c-216 169 -398 421 -514 714 -69 173\n-129 439 -146 648 l-7 86 513 0 512 0 -6 -32z m2840 -54 c-47 -570 -279 -1052\n-653 -1356 l-32 -26 81 -68 c246 -209 440 -533 534 -894 38 -142 64 -293 71\n-408 l6 -102 -506 0 c-278 0 -508 3 -510 8 -2 4 2 57 9 117 7 61 13 183 14\n272 0 325 -61 589 -181 770 l-21 33 29 11 c61 23 190 84 247 117 97 55 216\n134 216 142 0 23 -301 198 -415 241 -82 31 -81 28 -31 108 51 83 108 249 131\n386 31 177 30 530 -1 703 l-6 32 512 0 513 0 -7 -86z m-1705 -1014 c172 -17\n461 -73 502 -97 24 -14 -143 -169 -257 -237 l-55 -33 82 -53 c95 -62 246 -205\n232 -219 -15 -14 -148 -47 -280 -70 -317 -55 -573 -55 -890 0 -127 22 -264 56\n-278 69 -20 18 217 224 305 264 11 5 11 7 0 12 -85 39 -321 241 -307 263 5 9\n172 51 280 71 193 36 473 49 666 30z\nM2360 2630 c-56 -12 -200 -61 -200 -69 0 -8 69 -35 145 -58 49 -15\n96 -18 255 -18 159 0 206 3 255 18 78 23 145 50 145 58 0 7 -56 29 -140 55\n-64 20 -384 29 -460 14z",
      G: "M634 4017 c-9 -24 25 -281 55 -414 39 -173 79 -291 152 -443 113\n-235 269 -434 453 -578 l29 -22 -29 -22 c-184 -143 -340 -343 -453 -578 -71\n-149 -112 -270 -152 -445 -30 -130 -64 -388 -55 -412 4 -10 104 -13 504 -13\n274 0 501 2 504 5 2 3 0 33 -5 68 -6 34 -10 175 -11 312 0 217 3 265 22 366\n32 172 102 355 159 421 15 17 10 38 -9 38 -40 0 -367 175 -448 240 l-25 20 25\n20 c81 65 408 240 448 240 19 0 24 21 9 38 -56 64 -124 243 -158 414 -20 99\n-23 144 -23 368 0 140 5 282 11 315 6 33 9 63 6 68 -2 4 -229 7 -504 7 -400 0\n-501 -3 -505 -13z\nM3477 4023 c-3 -5 0 -35 6 -68 6 -33 11 -175 11 -315 0 -284 -15\n-394 -75 -568 -30 -86 -90 -205 -109 -217 -21 -13 -7 -23 78 -59 127 -52 402\n-214 402 -236 0 -10 -106 -80 -215 -143 -69 -39 -198 -100 -258 -121 -18 -6\n-18 -8 2 -39 72 -108 120 -235 153 -401 18 -94 22 -147 22 -336 1 -124 -3\n-271 -7 -327 l-9 -103 506 0 506 0 0 43 c-1 76 -28 270 -53 382 -92 404 -289\n752 -551 974 l-85 73 32 26 c190 154 334 338 446 572 73 152 113 270 152 443\n30 133 64 390 55 414 -4 10 -105 13 -505 13 -275 0 -502 -3 -504 -7z\nM2370 2934 c-219 -26 -512 -82 -533 -103 -20 -20 215 -224 305 -265\n11 -5 11 -7 0 -12 -85 -39 -321 -241 -307 -264 7 -12 204 -57 360 -82 187 -31\n543 -31 730 0 155 25 353 70 360 82 15 23 -205 217 -283 249 -18 7 -32 16 -32\n20 0 3 22 18 48 32 106 59 289 227 263 243 -18 12 -228 58 -351 77 -120 19\n-470 34 -560 23z m415 -309 c79 -21 175 -56 175 -64 0 -9 -101 -47 -180 -68\n-48 -13 -105 -17 -220 -17 -115 0 -172 4 -220 17 -74 20 -180 59 -180 67 0 14\n164 66 255 81 74 12 301 2 370 -16z",
    }
  },
  "Nike ShoeDuck (2025)": {
    viewBox: "0 0 512 512",
    transform: "translate(0.000000,512.000000) scale(0.100000,-0.100000)",
    regions: {
      R: "M2051 3314 c-26 -21 -31 -33 -31 -69 0 -36 5 -48 31 -69 20 -17 42\n-26 65 -26 83 0 117 104 53 163 -38 35 -78 35 -118 1z\nM2380 3325 c-19 -22 5 -45 46 -45 28 0 36 -5 45 -27 8 -22 4 -41 -22\n-107 -62 -159 -98 -253 -134 -346 -55 -144 -88 -224 -96 -234 -7 -8 -174 -45\n-206 -46 -8 0 -3 23 13 68 69 181 74 223 37 264 -9 10 -30 18 -47 18 -65 0\n-89 -25 -279 -299 l-72 -105 -69 -13 c-39 -7 -72 -11 -74 -8 -2 2 8 33 22 68\n49 123 86 242 86 277 0 46 -22 77 -61 85 -61 14 -172 -66 -268 -190 -22 -29\n-22 -29 -16 -5 17 69 18 140 1 165 -39 59 -111 36 -190 -64 -56 -69 -126 -193\n-126 -220 1 -9 7 -27 15 -41 l14 -25 22 50 c36 82 88 155 111 155 18 0 20 -5\n15 -34 -3 -19 -24 -82 -48 -140 -47 -120 -37 -116 -146 -66 -73 33 -131 88\n-164 156 -62 127 -7 337 150 573 23 35 40 65 38 67 -7 8 -201 -182 -300 -295\n-206 -233 -315 -403 -370 -576 -47 -145 -44 -252 8 -355 29 -57 126 -150 191\n-183 162 -82 410 -84 713 -6 111 29 509 159 714 233 114 42 121 43 107 17 -19\n-37 -13 -42 52 -39 l63 3 22 54 c20 52 24 56 78 75 65 23 75 18 75 -47 0 -21\n7 -53 14 -72 13 -30 20 -35 49 -35 29 0 56 17 161 100 69 55 128 100 131 100\n3 0 5 -11 5 -24 0 -40 32 -124 55 -146 71 -66 205 -16 303 113 62 83 78 121\n64 152 -6 14 -15 25 -19 25 -5 0 -18 -24 -31 -54 -28 -64 -109 -158 -152 -176\n-71 -30 -108 32 -89 150 18 112 14 107 71 126 29 9 69 25 88 34 19 10 69 29\n110 43 41 14 194 66 340 117 146 50 290 99 320 109 30 11 154 53 275 96 121\n42 245 85 275 94 117 39 495 173 500 178 5 6 -36 -1 -105 -17 -22 -5 -137 -28\n-255 -50 -118 -23 -442 -87 -720 -142 -323 -64 -506 -96 -508 -90 -11 34 -52\n78 -85 90 -70 27 -166 -22 -255 -132 -30 -37 -44 -46 -90 -55 -31 -6 -57 -10\n-58 -8 -2 2 6 28 18 59 34 94 5 148 -79 148 -60 0 -113 -24 -186 -84 -31 -25\n-57 -44 -57 -42 0 2 32 89 71 193 140 370 140 371 123 388 -22 22 -216 22\n-234 0z m-1605 -347 c-111 -244 -47 -457 169 -559 33 -16 66 -29 73 -29 19 0\n24 -17 13 -42 -5 -13 -30 -77 -56 -143 -25 -66 -48 -126 -51 -132 -4 -10 12\n-13 62 -13 55 0 68 3 72 18 2 9 28 78 56 152 l52 135 95 7 c52 3 97 5 98 3 2\n-2 -15 -54 -37 -115 -49 -134 -52 -180 -15 -209 31 -25 53 -26 97 -7 52 22\n106 84 210 239 78 116 104 147 125 151 70 14 102 18 102 12 0 -3 -12 -36 -26\n-73 -63 -165 -85 -239 -82 -282 l2 -45 -129 -44 c-333 -113 -500 -155 -682\n-173 -236 -23 -431 36 -534 160 -73 89 -91 243 -44 380 49 144 162 335 276\n466 140 160 171 195 174 195 2 0 -7 -24 -20 -52z m3474 -62 c-2 -3 -38 -16\n-79 -30 -41 -13 -187 -63 -325 -111 -483 -167 -735 -253 -735 -249 0 2 18 27\n39 56 22 28 46 71 53 95 11 38 16 44 48 49 19 3 242 48 495 99 430 86 515 102\n504 91z m-1143 -178 c-8 -4 -36 -11 -63 -15 l-48 -6 25 28 c38 41 61 48 83 22\n16 -18 16 -22 3 -29z m-1619 -4 c6 -15 -9 -61 -74 -234 l-29 -75 -94 -10 c-52\n-6 -96 -7 -98 -3 -9 20 215 317 251 331 23 10 38 7 44 -9z m1121 -10 c22 -15\n28 -48 13 -73 -7 -11 -208 -60 -249 -61 -22 0 23 55 76 93 76 55 123 67 160\n41z m-668 -3 c0 -12 -76 -221 -83 -227 -2 -3 -28 -7 -57 -11 -44 -5 -52 -4\n-45 8 89 150 185 269 185 230z m1175 -43 c-11 -38 -76 -127 -119 -165 -37 -32\n-124 -78 -132 -70 -5 5 85 200 99 214 7 8 42 20 78 27 85 19 81 19 74 -6z\nm-332 -85 c-9 -21 -30 -77 -46 -124 l-29 -86 -136 -47 c-74 -25 -136 -45 -138\n-44 -1 2 -5 37 -9 78 l-6 75 56 24 c61 26 195 116 195 131 0 9 66 27 108 29\n22 1 22 1 5 -36z m-224 -19 c-20 -25 -83 -53 -155 -70 -36 -8 -68 -13 -70 -11\n-3 2 0 15 4 28 8 21 22 27 113 46 130 26 124 26 108 7z m-363 -81 c-4 -10 -34\n-89 -68 -175 l-61 -157 -45 -16 c-25 -8 -49 -15 -54 -15 -4 0 7 24 26 53 42\n64 51 96 33 120 -12 17 -16 14 -48 -39 -33 -57 -80 -96 -95 -81 -8 8 8 58 65\n202 l36 90 90 16 c124 22 128 23 121 2z m-572 -85 c-21 -37 -144 -206 -157\n-216 -11 -10 -17 -9 -27 3 -9 11 -5 32 25 109 40 104 30 95 125 109 14 3 29 5\n33 6 5 0 5 -5 1 -11z m687 -159 c-9 -9 -82 -32 -87 -27 -2 3 8 34 22 69 52\n126 46 122 59 39 6 -41 9 -78 6 -81z m389 77 c0 -18 -186 -156 -210 -156 -21\n0 -50 36 -50 61 0 11 13 22 33 28 17 6 75 27 127 45 52 19 96 35 98 35 1 1 2\n-5 2 -13z",
      G: "M2049 3446 c-60 -21 -96 -54 -125 -111 -101 -208 155 -403 326 -249\n22 20 45 51 52 70 7 19 17 33 23 30 13 -5 16 2 -58 -186 l-64 -165 -15 35\nc-31 72 -102 120 -176 120 -75 0 -133 -36 -212 -130 l-48 -58 -6 37 c-7 46\n-46 99 -94 128 -64 39 -170 31 -245 -20 -27 -18 -27 -18 -58 7 -38 32 -101 50\n-148 41 -81 -15 -181 -103 -257 -225 -20 -33 -40 -57 -45 -54 -5 3 -6 -3 -2\n-12 4 -12 3 -15 -5 -10 -19 12 -14 90 13 173 24 76 92 205 160 305 38 55 42\n81 21 132 -32 78 -112 99 -182 47 -58 -42 -327 -322 -415 -431 -160 -199 -271\n-395 -310 -549 -17 -66 -20 -106 -17 -191 3 -100 6 -111 42 -186 54 -109 145\n-199 258 -252 117 -56 206 -74 363 -74 222 0 421 46 889 206 180 62 254 83\n266 76 10 -5 61 -10 114 -11 86 -2 100 0 127 20 31 23 31 23 52 3 87 -79 184\n-66 310 40 l37 32 16 -22 c48 -69 100 -96 189 -96 129 -1 242 76 352 241 62\n94 73 139 49 196 -12 29 -12 39 -3 42 7 3 149 52 317 109 322 110 1033 355\n1235 426 140 49 185 84 185 145 0 49 -22 88 -63 109 -41 22 49 38 -917 -154\nl-705 -140 -30 29 c-47 44 -88 61 -152 61 -78 0 -120 -13 -184 -58 l-54 -38\n-28 32 c-35 41 -102 74 -150 74 -20 0 -37 5 -37 11 0 5 4 7 10 4 5 -3 7 0 4 8\n-2 7 16 70 41 138 54 143 57 199 14 245 -45 48 -68 54 -216 54 -120 0 -142 -3\n-171 -20 -18 -11 -35 -27 -38 -35 -5 -12 -12 -10 -40 11 -65 50 -130 63 -195\n40z m115 -127 c38 -30 49 -64 36 -105 -34 -104 -180 -76 -180 33 0 77 85 119\n144 72z m450 6 c18 -18 20 -9 -115 -369 -44 -115 -79 -210 -79 -212 0 -3 26\n17 57 42 73 60 126 84 186 84 84 0 113 -54 79 -148 -12 -31 -20 -57 -18 -59 1\n-2 27 2 58 8 46 9 60 18 90 55 89 110 185 159 255 132 32 -12 74 -55 85 -89 3\n-10 124 13 1197 227 205 41 378 74 384 74 34 0 11 -8 -1258 -445 -472 -162\n-526 -181 -585 -208 -30 -13 -67 -27 -81 -30 -25 -6 -28 -14 -43 -94 -12 -67\n-13 -97 -5 -126 13 -48 45 -65 89 -47 43 18 124 112 152 176 13 30 26 54 31\n54 4 0 13 -11 19 -25 14 -32 -3 -72 -67 -155 -133 -172 -294 -190 -340 -37 -8\n28 -15 61 -15 74 0 13 -2 23 -5 23 -3 0 -62 -45 -130 -100 -104 -83 -132 -100\n-160 -100 -42 0 -52 17 -66 103 -6 34 -12 64 -15 66 -2 3 -29 -4 -60 -15 -53\n-19 -57 -23 -77 -75 l-22 -54 -63 -3 -64 -3 7 30 c8 36 10 35 -46 15 -435\n-158 -741 -253 -934 -290 -122 -24 -347 -24 -434 -1 -149 40 -288 156 -327\n273 -66 203 37 473 308 799 87 106 366 391 374 382 3 -2 -14 -33 -37 -68 -63\n-95 -125 -215 -149 -294 -32 -99 -31 -215 0 -280 32 -67 90 -122 163 -155 97\n-44 103 -45 115 -13 6 15 27 70 46 122 41 108 44 131 17 131 -22 0 -67 -63\n-102 -144 -13 -31 -27 -56 -30 -56 -8 0 -29 47 -29 64 0 24 72 150 122 213 74\n94 136 124 184 89 15 -12 19 -27 19 -78 0 -35 -4 -76 -8 -93 -7 -25 4 -17 68\n52 127 138 226 168 268 81 18 -36 18 -37 -16 -140 -19 -56 -46 -134 -61 -172\nl-26 -69 67 7 c36 4 70 9 74 12 5 2 47 62 95 132 48 70 107 153 131 185 51 66\n109 102 145 88 67 -25 71 -83 15 -231 -25 -63 -43 -116 -42 -118 6 -7 197 32\n209 42 8 6 44 90 81 186 38 96 88 227 112 290 25 63 49 127 55 142 5 14 8 41\n6 60 -3 30 -6 33 -40 36 -45 4 -66 25 -48 47 18 22 212 22 234 0z\nM703 2929 c-192 -220 -329 -441 -368 -594 -38 -151 -9 -283 81 -371\n158 -155 418 -179 814 -78 80 21 480 149 502 161 4 2 3 14 -3 27 -12 26 3 83\n70 260 23 60 41 110 39 111 -2 2 -31 -2 -65 -8 l-63 -10 -97 -145 c-54 -80\n-114 -161 -133 -180 -81 -80 -140 -93 -185 -41 -31 38 -30 47 26 199 21 58 39\n109 39 113 0 8 -42 5 -156 -9 -28 -3 -44 -11 -47 -22 -3 -9 -28 -75 -56 -147\nl-50 -130 -67 -3 c-51 -2 -65 0 -61 10 61 151 115 304 109 308 -4 4 -36 17\n-72 31 -94 35 -189 130 -218 218 -36 106 -23 240 34 354 14 26 22 47 20 47 -3\n0 -44 -45 -93 -101z\nM4165 2905 c-33 -7 -118 -24 -190 -38 -71 -13 -272 -53 -446 -87\nl-316 -63 -11 -41 c-6 -23 -29 -65 -52 -94 -22 -29 -40 -54 -40 -56 0 -4 209\n67 675 229 121 42 274 94 340 117 155 53 163 59 40 33z\nM3065 2780 c-11 -4 -31 -20 -45 -35 l-25 -27 50 7 c72 11 80 17 58\n42 -13 16 -23 19 -38 13z\nM1398 2698 c-62 -66 -123 -144 -171 -223 l-38 -60 38 -3 c21 -1 64 1\n97 5 l58 8 54 140 c30 77 53 149 52 160 -6 39 -38 29 -90 -27z\nM2504 2716 c-53 -25 -134 -94 -134 -116 0 -6 6 -10 13 -7 6 2 59 12\n115 22 57 10 110 25 118 32 21 21 17 60 -8 77 -30 21 -44 20 -104 -8z\nM1848 2633 c-35 -54 -73 -111 -83 -126 l-18 -28 54 7 c30 4 55 8 57\n9 4 3 82 219 82 228 0 4 -6 7 -13 7 -8 0 -43 -44 -79 -97z\nM3035 2681 l-70 -16 -42 -85 c-23 -47 -45 -97 -48 -113 l-7 -27 41\n17 c57 25 121 81 163 144 37 55 56 100 41 98 -4 -1 -39 -9 -78 -18z\nM2723 2620 c-17 -4 -51 -23 -75 -42 -60 -50 -146 -103 -192 -119\nl-38 -14 7 -70 c4 -38 9 -73 11 -77 2 -3 65 14 139 40 l134 46 26 85 c15 47\n31 91 35 96 5 6 13 23 19 38 10 24 8 27 -12 26 -12 -1 -36 -4 -54 -9z\nM2451 2565 c-90 -19 -106 -25 -113 -45 -5 -13 -7 -25 -4 -27 9 -9\n143 30 183 53 40 23 64 45 46 43 -4 -1 -55 -11 -112 -24z\nM2105 2494 c-33 -7 -73 -13 -88 -14 -31 0 -37 -12 -103 -186 -36 -98\n-40 -114 -24 -114 25 0 64 37 93 88 28 50 31 53 44 36 20 -28 16 -46 -27 -112\n-22 -34 -36 -62 -32 -62 4 0 28 7 54 17 l46 16 61 156 c33 86 63 164 67 174 7\n21 -5 21 -91 1z\nM1558 2407 l-57 -10 -31 -79 c-48 -126 -37 -170 22 -96 32 40 116\n158 132 186 4 6 4 11 -1 11 -4 -1 -34 -6 -65 -12z\nM2283 2380 c-40 -94 -62 -154 -59 -158 9 -8 77 20 83 34 3 8 1 45 -4\n82 -8 60 -11 64 -20 42z\nM2675 2330 c-11 -5 -68 -25 -127 -46 -78 -27 -108 -41 -108 -53 0\n-25 29 -61 50 -61 24 0 210 138 210 156 0 8 -1 14 -2 13 -2 0 -12 -4 -23 -9z",
    }
  },
  "Under Armour Cotton (2023)": {
    viewBox: "0 0 512 512",
    transform: "translate(0.000000,512.000000) scale(0.100000,-0.100000)",
    regions: {
      R: "M1280 3980 c-189 -40 -632 -200 -815 -293 -44 -22 -92 -58 -130 -96\nl-60 -62 -3 -166 c-3 -150 -1 -175 19 -238 37 -117 113 -220 305 -412 l172\n-172 -168 -168 c-184 -184 -232 -250 -281 -382 -30 -81 -32 -95 -37 -259 l-5\n-174 49 -50 c67 -69 123 -104 309 -191 216 -100 457 -180 605 -201 176 -24\n323 -36 450 -36 l116 0 56 57 57 58 3 402 c2 221 6 405 10 409 4 4 40 -2 80\n-14 66 -19 111 -27 258 -48 25 -3 124 -8 221 -11 169 -5 192 -3 454 33 22 3\n73 14 114 25 59 16 76 17 82 7 18 -29 21 -137 14 -456 l-7 -334 63 -64 63 -64\n112 0 c117 0 381 22 474 40 30 6 68 13 85 16 80 14 327 103 475 171 184 85\n274 140 339 207 l44 44 -6 164 c-3 101 -11 184 -21 219 -41 152 -123 266 -330\n467 -82 78 -144 142 -139 142 26 0 403 388 403 414 0 3 13 27 28 53 62 106 67\n132 67 330 l0 182 -58 59 c-91 92 -250 166 -657 307 -268 93 -298 98 -560 103\nl-235 3 -60 -61 -60 -61 -7 -367 c-4 -202 -10 -391 -13 -420 -6 -47 -9 -52\n-28 -48 -12 3 -67 14 -122 26 -151 31 -326 43 -550 37 -185 -6 -299 -20 -496\n-61 -23 -5 -28 -2 -34 22 -4 15 -10 203 -14 419 l-6 392 -60 61 -59 60 -211\n-1 c-164 0 -229 -4 -295 -19z m383 -224 c3 -7 6 -87 7 -177 2 -230 16 -630 23\n-657 12 -46 50 -148 65 -169 21 -33 55 -29 193 17 122 41 149 47 354 80 200\n32 386 25 615 -24 8 -2 35 -7 60 -11 25 -4 50 -11 55 -15 6 -5 37 -15 71 -24\n34 -9 77 -23 97 -31 20 -8 52 -15 71 -15 41 0 51 14 92 137 26 77 26 84 34\n468 5 215 12 400 16 413 6 20 13 22 70 22 62 0 212 -27 304 -55 198 -59 264\n-81 325 -105 39 -16 102 -41 140 -56 136 -52 236 -99 284 -133 27 -19 31 -28\n31 -67 0 -154 -146 -370 -380 -565 -105 -87 -185 -137 -278 -174 -106 -43\n-129 -67 -91 -96 13 -10 38 -23 54 -29 88 -30 205 -105 333 -213 223 -189 318\n-340 348 -554 6 -40 5 -42 -37 -69 -59 -37 -371 -184 -391 -184 -6 0 -24 -6\n-41 -14 -145 -65 -363 -112 -609 -131 l-88 -7 0 383 c-1 363 -6 442 -31 484\n-4 6 -9 22 -12 36 -4 14 -16 46 -27 72 -17 39 -24 45 -38 37 -9 -5 -37 -14\n-62 -19 -25 -5 -70 -19 -101 -30 -378 -136 -745 -140 -1129 -11 -92 31 -211\n63 -215 58 -26 -34 -79 -188 -85 -248 -3 -25 -5 -206 -5 -404 l0 -358 -75 7\nc-293 27 -329 34 -530 97 -81 25 -209 77 -318 129 -45 21 -85 39 -88 39 -2 0\n-38 19 -79 43 -74 42 -75 42 -75 84 0 23 4 53 10 68 5 14 12 39 15 56 17 96\n91 207 234 350 156 155 287 247 431 302 25 9 51 26 57 37 18 28 -11 52 -101\n85 -69 26 -170 83 -223 128 -107 90 -186 163 -233 218 -70 81 -120 145 -120\n154 0 4 -9 20 -20 36 -45 62 -76 218 -52 255 10 16 168 94 292 144 95 38 297\n109 440 155 170 53 401 82 413 51z M2345 2706 c-81 -18 -143 -40 -250 -91\n-164 -78 -164 -87 3 -170 172 -86 269 -110 442 -110 158 1 225 15 380 84 134\n60 192 97 188 119 -4 21 -175 108 -290 147 -76 25 -98 28 -248 31 -110 2 -185\n-1 -225 -10z m319 -26 c84 -13 194 -49 306 -101 101 -48 103 -44 -57 -120\n-141 -67 -217 -84 -383 -83 -165 0 -240 19 -402 100 l-111 56 29 17 c44 26\n192 87 259 107 108 31 244 40 359 24z",
      B: "M1425 3745 c-263 -49 -894 -292 -909 -350 -19 -70 8 -162 86 -295 57\n-98 239 -281 378 -381 54 -38 101 -69 105 -69 14 0 151 -63 177 -82 15 -10 25\n-25 22 -32 -3 -8 -38 -28 -77 -46 -114 -51 -137 -64 -226 -125 -111 -77 -297\n-261 -355 -352 -49 -76 -90 -192 -101 -284 l-7 -55 164 -81 c207 -102 281\n-132 478 -194 75 -23 274 -58 370 -65 36 -2 84 -6 108 -9 l42 -5 0 378 c0 343\n2 384 19 447 21 75 65 180 78 188 4 2 35 -4 68 -14 33 -11 98 -31 145 -45 47\n-15 103 -33 125 -41 67 -23 314 -58 420 -58 173 0 377 39 605 115 129 44 158\n50 168 37 16 -23 51 -123 72 -209 21 -82 22 -105 18 -442 l-3 -356 30 5 c17 2\n73 7 125 10 52 2 115 9 140 15 25 5 77 16 115 24 180 37 335 94 600 222 137\n66 156 80 151 106 -3 13 -7 43 -10 68 -18 161 -147 349 -363 526 -116 96 -162\n125 -263 171 -52 23 -103 50 -113 59 -18 14 -18 17 -2 34 18 20 98 60 160 80\n36 11 156 87 180 114 6 6 26 23 45 37 165 125 330 343 365 483 23 94 15 132\n-33 154 -20 9 -38 20 -40 24 -2 4 -20 12 -40 19 -20 6 -39 15 -42 18 -3 3 -43\n21 -90 40 -47 18 -98 39 -115 46 -16 8 -59 23 -95 35 -36 13 -78 28 -95 35\n-33 14 -159 53 -275 85 -44 12 -123 23 -192 27 l-117 6 -5 -24 c-3 -13 -7\n-192 -11 -397 -4 -275 -9 -383 -19 -415 -8 -23 -17 -55 -21 -72 -3 -16 -18\n-54 -32 -83 -25 -51 -28 -54 -57 -48 -40 8 -135 35 -161 47 -29 12 -164 49\n-205 55 -19 3 -87 14 -150 26 -137 24 -339 21 -485 -7 -117 -22 -294 -65 -314\n-75 -23 -12 -163 -50 -183 -50 -10 0 -18 5 -18 10 0 6 -9 30 -21 53 -11 23\n-22 49 -24 57 -2 8 -11 40 -20 70 -13 44 -17 123 -21 385 -3 182 -6 359 -7\n395 l-2 65 -85 2 c-47 0 -116 -5 -155 -12z m1403 -1065 c129 -43 259 -106 276\n-133 15 -24 -11 -46 -129 -106 -166 -84 -252 -105 -435 -106 -185 0 -278 23\n-453 113 -104 54 -132 75 -124 95 6 15 150 88 242 122 145 54 217 65 382 59\n110 -3 133 -7 241 -44z",
    }
  },
  "Nike Cotton (2022)": {
    viewBox: "0 0 512 512",
    transform: "translate(0.000000,512.000000) scale(0.100000,-0.100000)",
    regions: {
      R: "M1255 3266 c-85 -38 -253 -187 -349 -310 -221 -284 -297 -497 -255\n-722 25 -137 110 -248 239 -313 166 -83 363 -81 645 8 140 44 719 237 945 314\n418 144 1187 416 1263 448 26 11 52 17 56 14 5 -3 11 -1 13 4 1 4 75 34 163\n66 88 31 169 61 180 66 11 4 80 31 152 59 91 35 139 59 153 77 24 30 24 34 6\n58 -19 27 -51 24 -269 -24 -103 -22 -190 -40 -195 -39 -4 0 -14 -2 -22 -5 -19\n-8 -767 -158 -777 -155 -5 0 -15 -1 -23 -5 -8 -3 -71 -15 -140 -27 -69 -11\n-143 -24 -165 -29 -22 -5 -114 -21 -205 -36 -91 -15 -214 -35 -274 -45 -61\n-10 -122 -17 -138 -16 -15 1 -29 -1 -30 -5 -3 -5 -82 -16 -473 -64 -229 -28\n-349 -24 -425 15 -86 44 -137 150 -127 266 4 50 17 90 65 191 71 152 77 172\n56 201 -17 25 -27 26 -69 8z",
    }
  },
  "Adidas Trefoil (2025)": {
    viewBox: "0 0 512 512",
    transform: "translate(0.000000,512.000000) scale(0.100000,-0.100000)",
    regions: {
      R: "M2532 3611 c-39 -43 -92 -112 -118 -153 -64 -96 -66 -100 -109 -188\n-20 -41 -41 -84 -47 -94 -5 -11 -18 -42 -28 -70 -10 -28 -24 -64 -30 -81 -14\n-32 -16 -37 -23 -75 -3 -14 -10 -37 -15 -51 -6 -15 -9 -29 -6 -31 2 -3 -2 -27\n-10 -54 -8 -27 -17 -74 -20 -104 -4 -30 -9 -69 -11 -87 -19 -153 -21 -196 -11\n-318 8 -97 15 -136 28 -152 8 -10 118 -13 488 -13 417 0 479 2 490 15 7 9 17\n61 22 117 4 55 10 110 12 122 2 11 -5 82 -15 156 -10 74 -17 137 -17 140 0 3\n-1 8 -2 13 -5 13 -7 22 -14 62 -16 81 -49 201 -62 227 -8 15 -14 34 -14 43 0\n9 -10 37 -21 63 -45 98 -103 217 -108 222 -3 3 -14 23 -24 45 -10 21 -45 76\n-78 121 -32 45 -59 84 -59 87 0 11 -106 117 -117 117 -7 0 -43 -35 -81 -79z\nM697 2953 c-14 -22 -7 -269 8 -293 2 -4 7 -25 10 -46 8 -62 11 -74\n50 -190 50 -147 78 -212 109 -256 l20 -28 568 0 c448 0 568 3 568 13 0 10 -38\n65 -112 162 -39 50 -205 212 -237 231 -17 10 -31 22 -31 26 0 5 -26 25 -57 45\n-32 20 -62 42 -66 50 -4 7 -13 13 -19 13 -6 0 -19 6 -27 14 -19 17 -232 127\n-281 144 -38 14 -144 49 -229 75 -29 10 -64 17 -77 17 -12 0 -25 4 -29 9 -3 6\n-13 10 -23 10 -9 0 -45 3 -78 7 -38 4 -64 3 -67 -3z\nM4428 2950 c-15 -4 -29 -6 -32 -3 -3 3 -11 1 -18 -4 -7 -6 -31 -14\n-53 -17 -41 -8 -210 -59 -255 -78 -71 -29 -92 -39 -181 -82 -53 -26 -120 -63\n-148 -82 -29 -18 -55 -34 -57 -34 -8 0 -120 -88 -139 -110 -11 -12 -28 -25\n-37 -29 -20 -7 -158 -139 -158 -151 0 -5 -3 -10 -7 -12 -31 -13 -138 -181\n-128 -198 4 -6 214 -10 570 -10 l564 0 24 53 c83 176 157 427 173 587 16 167\n13 180 -48 179 -24 0 -55 -4 -70 -9z\nM4215 2009 c-25 -9 -3043 -13 -3195 -4 -19 1 -38 -3 -42 -8 -7 -11\n40 -77 82 -114 l25 -22 1528 -1 c1072 0 1534 3 1548 11 39 21 99 97 99 125 0\n17 -21 23 -45 13z\nM1203 1723 c-30 -12 -17 -28 93 -114 l52 -40 1273 1 1274 0 43 31\nc24 18 60 48 79 67 31 31 34 37 20 47 -10 7 -37 9 -79 4 -79 -9 -2707 -6\n-2728 3 -8 4 -21 4 -27 1z\nM1533 1427 c-11 -18 124 -102 267 -165 108 -48 118 -52 132 -52 8 0\n18 -4 24 -8 14 -12 130 -47 189 -58 11 -2 44 -8 73 -14 29 -6 72 -10 95 -8\nl42 3 1 70 c1 83 -22 226 -37 236 -18 11 -779 7 -786 -4z\nM2780 1428 c-30 -5 -130 -7 -222 -4 -92 3 -169 2 -172 -2 -2 -4 32\n-57 75 -117 44 -61 94 -131 112 -157 42 -62 64 -69 94 -32 13 16 23 32 23 36\n0 4 36 61 79 125 78 115 96 154 76 158 -5 1 -35 -2 -65 -7z\nM2920 1425 c-12 -14 -13 -18 -29 -168 -13 -115 -7 -137 41 -137 61 0\n353 81 473 131 17 7 32 13 35 14 14 5 119 57 145 73 107 62 128 79 120 92 -2\n4 -178 7 -389 7 -308 1 -388 -2 -396 -12z",
      G: "M2598 3856 c-10 -9 -18 -11 -20 -5 -6 17 -80 -20 -118 -60 -30 -30\n-121 -139 -148 -176 -4 -6 -19 -27 -34 -47 -16 -20 -28 -40 -28 -43 0 -4 -12\n-25 -27 -48 -48 -73 -52 -80 -91 -162 -70 -145 -138 -355 -158 -485 -3 -19 -9\n-48 -14 -65 -5 -16 -12 -57 -15 -90 -3 -33 -8 -72 -11 -88 l-6 -27 -51 49\nc-53 51 -113 101 -163 136 -15 11 -39 29 -53 41 -53 43 -237 149 -250 144 -2\n-1 -7 3 -10 8 -12 18 -314 128 -401 146 -14 3 -36 8 -50 11 -104 24 -250 46\n-250 37 0 -4 -14 -8 -32 -8 -18 -1 -34 -6 -36 -13 -2 -6 -8 -9 -13 -5 -13 8\n-42 -24 -33 -37 4 -8 3 -9 -5 -5 -17 11 -43 -18 -28 -33 8 -8 7 -11 -5 -11\n-21 0 -29 -40 -35 -163 -5 -107 7 -204 37 -317 7 -25 14 -54 16 -65 8 -44 83\n-254 113 -315 37 -76 49 -96 76 -127 11 -12 27 -37 36 -55 49 -104 64 -130\n101 -179 22 -30 45 -53 49 -51 5 1 9 -4 9 -11 0 -7 13 -21 30 -30 16 -10 33\n-29 36 -43 3 -13 10 -24 16 -24 5 0 7 -4 4 -9 -3 -5 1 -12 10 -15 8 -3 13 -9\n10 -14 -2 -4 31 -42 74 -85 42 -42 75 -77 71 -77 -3 -1 6 -8 22 -16 15 -8 32\n-12 37 -9 6 3 10 1 10 -4 0 -6 7 -11 15 -11 23 0 65 -22 65 -35 0 -7 14 -26\n30 -44 17 -17 27 -31 23 -31 -17 -1 194 -131 276 -171 88 -43 193 -85 246\n-100 17 -4 55 -14 85 -23 58 -16 85 -22 160 -36 25 -5 66 -13 92 -18 45 -9 65\n-8 126 3 15 3 33 6 40 7 6 1 12 5 12 10 0 5 5 6 10 3 6 -3 10 -2 10 4 0 15 41\n4 55 -15 6 -9 17 -14 22 -11 6 4 14 0 17 -9 3 -9 13 -14 21 -10 8 3 17 1 20\n-4 3 -5 25 -7 48 -5 23 2 47 4 54 4 6 1 19 8 27 17 9 8 16 12 16 8 0 -4 11 3\n25 16 15 14 25 18 25 11 0 -8 8 -11 20 -8 10 3 21 0 23 -6 2 -6 36 -11 83 -11\n78 0 110 4 189 26 22 7 42 12 45 13 3 0 15 4 28 9 12 4 32 9 45 10 23 3 147\n41 182 56 11 5 52 21 90 36 39 15 72 30 75 34 3 4 22 13 43 21 21 7 46 20 55\n29 9 8 33 23 52 32 67 34 99 55 93 62 -3 3 -1 6 5 6 17 0 44 31 38 46 -3 8 0\n11 10 7 7 -3 14 0 14 6 0 31 16 46 58 56 18 3 32 13 32 20 0 8 7 11 20 8 12\n-3 20 0 20 6 0 7 4 10 9 7 5 -4 47 32 93 80 79 82 110 122 103 134 -2 4 12 24\n31 45 19 21 34 35 34 31 0 -5 7 -3 15 4 8 7 12 16 9 21 -3 5 1 9 8 9 8 0 22\n15 33 33 10 17 23 35 29 39 6 4 11 11 11 15 0 4 10 24 23 45 12 20 22 40 21\n45 -4 13 23 63 34 63 6 0 7 3 4 6 -4 4 2 15 13 24 61 53 185 396 222 610 5 30\n11 66 15 80 12 51 13 252 1 274 -7 11 -11 24 -10 29 1 4 -2 7 -8 7 -5 0 -10 9\n-10 20 0 11 -7 20 -15 20 -9 0 -12 6 -9 15 7 18 -7 20 -23 4 -9 -9 -10 -6 -6\n11 4 17 2 21 -8 18 -8 -3 -26 0 -42 7 -44 18 -219 -7 -397 -59 -109 -32 -282\n-93 -289 -103 -3 -4 -10 -8 -16 -9 -24 -2 -75 -27 -75 -37 0 -6 -3 -7 -6 -4\n-4 4 -19 -2 -33 -12 -14 -10 -48 -30 -76 -45 -68 -36 -152 -91 -175 -116 -3\n-3 -31 -24 -62 -48 -31 -23 -76 -60 -100 -82 -50 -46 -48 -49 -67 80 -33 213\n-121 481 -221 675 -67 131 -195 317 -278 404 -21 23 -37 43 -34 46 3 3 -9 8\n-26 11 -18 4 -32 11 -32 16 0 6 -6 8 -14 5 -7 -3 -19 0 -26 6 -10 9 -14 9 -17\n-1 -4 -10 -8 -9 -17 4 -11 15 -14 15 -28 0z m79 -222 c29 -31 53 -59 53 -63 0\n-4 8 -16 18 -27 42 -47 182 -274 182 -295 0 -5 11 -31 24 -57 41 -80 66 -140\n66 -159 0 -10 6 -27 13 -38 12 -17 38 -114 63 -235 10 -46 11 -50 14 -52 1 -2\n3 -14 4 -28 7 -62 18 -150 25 -205 5 -33 7 -70 5 -81 -2 -12 -8 -67 -12 -122\n-5 -56 -15 -108 -22 -117 -11 -13 -70 -15 -494 -13 l-481 3 -11 25 c-11 23\n-26 163 -26 250 -1 61 13 202 29 295 8 50 18 110 22 135 4 25 10 51 14 58 5 6\n10 22 13 34 2 13 6 32 8 43 5 23 39 111 66 170 65 142 98 205 150 284 64 97\n194 251 213 251 6 0 35 -25 64 -56z m-1835 -685 c10 0 20 -4 23 -10 4 -5 17\n-9 29 -9 28 0 181 -46 306 -92 49 -17 262 -127 281 -144 8 -8 21 -14 28 -14 6\n0 14 -6 17 -14 3 -7 27 -26 54 -40 27 -15 55 -35 62 -44 7 -9 31 -30 53 -47\n56 -41 265 -255 265 -270 0 -3 16 -27 35 -54 19 -26 35 -53 35 -60 0 -8 -152\n-11 -568 -11 l-568 0 -20 28 c-11 15 -24 38 -31 52 -24 54 -41 97 -53 132 -6\n21 -16 40 -21 43 -5 4 -9 15 -9 25 0 11 -7 40 -16 66 -44 129 -73 399 -50 459\n6 15 15 17 69 11 34 -4 70 -7 79 -7z m3707 -11 c16 -42 -4 -215 -41 -358 -44\n-173 -74 -257 -140 -397 l-20 -43 -563 0 c-354 0 -566 4 -570 10 -3 5 2 24 11\n42 17 36 104 151 116 156 5 2 8 7 8 12 0 12 138 144 158 151 9 4 26 17 37 29\n19 22 131 110 139 110 2 0 28 16 57 34 72 48 332 176 357 176 8 0 28 6 45 14\n33 14 84 29 172 49 28 7 56 16 63 21 7 4 16 6 18 3 3 -3 17 -1 32 3 15 5 46 9\n70 9 35 1 44 -3 51 -21z m-289 -942 c0 -28 -60 -104 -99 -125 -14 -8 -476 -11\n-1548 -11 l-1528 1 -25 22 c-42 37 -89 99 -84 111 3 8 427 10 1593 8 873 -1\n1606 2 1627 6 43 10 64 6 64 -12z m-217 -285 c10 -10 -57 -80 -114 -118 l-35\n-23 -1273 -1 -1272 -1 -52 41 c-108 84 -125 103 -97 113 25 8 2834 -2 2843\n-11z m-340 -297 c-3 -9 -15 -20 -27 -25 -11 -5 -43 -22 -71 -39 -41 -25 -143\n-77 -165 -85 -3 -1 -18 -7 -35 -14 -94 -40 -213 -76 -355 -110 -186 -44 -183\n-50 -145 239 8 64 -20 60 399 62 209 2 386 -1 393 -5 6 -5 9 -15 6 -23z\nm-1386 18 c14 -9 43 -165 44 -240 2 -84 -12 -90 -151 -60 -25 5 -52 10 -60 12\n-154 28 -428 139 -555 225 -22 15 -48 30 -57 34 -11 4 -15 12 -12 21 5 13 58\n15 392 16 213 0 392 -4 399 -8z m333 -7 c85 2 166 5 180 7 39 5 28 -23 -61\n-155 -43 -64 -79 -121 -79 -125 0 -4 -10 -20 -23 -36 -30 -37 -53 -30 -89 26\n-15 24 -39 55 -53 70 -14 15 -25 30 -25 32 0 3 -27 43 -60 87 -69 95 -68 110\n7 98 27 -4 118 -6 203 -4z",
    }
  },
  "New Balance Cotton (2025)": {
    viewBox: "0 0 512 512",
    transform: "translate(0.000000,512.000000) scale(0.100000,-0.100000)",
    regions: {
      R: "M1515 3609 c-26 -44 -44 -84 -39 -88 5 -5 117 -16 249 -26 132 -9\n294 -21 360 -26 242 -18 355 -22 355 -13 0 35 -54 211 -67 222 -13 9 -112 12\n-413 12 l-397 0 -48 -81z\nM3003 3677 c0 -7 -30 -64 -67 -128 -36 -65 -66 -121 -66 -127 0 -10\n26 -13 387 -39 218 -15 241 -19 233 -33 -7 -14 -33 -18 -132 -23 -629 -34\n-598 -31 -598 -61 0 -12 -17 -51 -38 -87 -21 -35 -62 -104 -91 -153 -57 -95\n-57 -105 4 -106 76 -1 567 -39 573 -44 3 -4 1 -10 -4 -16 -9 -9 -114 -16 -939\n-65 -386 -23 -611 -37 -1085 -66 -96 -6 -177 -12 -181 -15 -11 -6 -99 -159\n-99 -171 0 -7 45 -13 113 -17 61 -4 171 -11 242 -17 72 -5 200 -14 285 -19 85\n-5 254 -16 375 -25 121 -8 398 -26 615 -40 217 -14 396 -28 399 -31 22 -21\n-60 -29 -578 -58 -308 -17 -562 -34 -566 -37 -5 -6 70 -317 79 -326 2 -2 70\n-8 152 -13 82 -5 255 -16 384 -25 129 -8 242 -15 250 -15 12 0 12 -3 -2 -16\n-13 -13 -83 -20 -379 -40 -200 -14 -365 -27 -367 -29 -2 -1 11 -62 29 -135 29\n-117 35 -133 58 -141 15 -6 318 -9 785 -6 l761 3 101 27 c286 74 512 209 648\n386 39 51 86 130 92 156 49 198 39 289 -42 384 -35 42 -123 99 -165 108 -29 5\n-27 7 43 34 40 16 79 29 86 29 7 0 18 5 25 11 7 5 48 33 91 62 44 29 86 57 94\n62 26 18 82 78 129 140 58 76 100 165 114 241 6 32 15 66 19 75 4 8 4 23 -2\n32 -6 11 -5 17 2 17 7 0 8 6 0 19 -5 11 -10 30 -10 43 0 41 -46 122 -92 165\n-58 53 -110 79 -206 104 -95 25 -160 28 -893 33 -422 3 -566 1 -566 -7z m988\n-437 c57 -31 66 -145 19 -227 -60 -104 -168 -148 -377 -152 l-136 -3 15 24 c8\n13 30 48 49 78 18 30 37 57 41 58 4 2 8 8 8 13 0 5 30 57 66 114 l66 105 114\n0 c64 0 124 -5 135 -10z m-477 -799 c73 -12 106 -52 106 -128 0 -97 -51 -173\n-153 -224 -75 -39 -135 -49 -290 -49 l-149 0 20 33 c10 17 65 110 121 205\nl102 172 97 -1 c53 0 119 -4 146 -8z\nM1975 3244 c-192 -12 -399 -25 -460 -28 -60 -3 -140 -9 -176 -12 -63\n-6 -67 -8 -83 -40 -8 -19 -21 -34 -28 -34 -6 0 -8 -3 -5 -6 3 -4 -5 -26 -18\n-49 -14 -23 -25 -44 -25 -48 0 -9 67 -16 325 -32 132 -8 407 -26 610 -40 204\n-14 390 -25 414 -25 l44 0 -6 33 c-4 17 -19 82 -35 142 -16 61 -32 122 -36\n138 -6 27 -7 27 -89 26 -45 -1 -239 -12 -432 -25z\nM1600 2293 c-166 -12 -496 -35 -550 -38 -36 -2 -114 -7 -175 -10\n-164 -9 -155 -5 -208 -94 -52 -87 -56 -101 -28 -101 10 0 218 -13 462 -30 244\n-16 456 -30 472 -30 21 0 31 7 44 35 9 19 20 35 25 35 4 0 8 4 8 9 0 5 27 56\n60 113 33 56 60 106 60 110 0 8 -77 8 -170 1z\nM917 1775 c-268 -18 -489 -34 -490 -36 -12 -15 -97 -167 -97 -172 0\n-4 229 -7 508 -7 l509 0 71 121 c40 66 72 122 72 125 0 6 -50 4 -573 -31z",
    }
  },
};

const PREVIEW_REGION_TO_TINT_FIELD = { R: 'colorR', G: 'colorG', B: 'colorB' };

function renderDecalPreview(catalogLabel, teamColors) {
  const entry = PREVIEW_SVGS[catalogLabel];
  if (!entry) {
    return `<div class="hint" style="margin-top:10px;">No traced preview available yet for "${escapeHtml(catalogLabel || '(none selected)')}" -- only Jumpman Cotton, Nike Plastic, Adidas Plastic, and Under Armour Cotton have one so far.</div>`;
  }
  const fallback = '#3a3d44'; // neutral gray for a region whose color isn't resolvable at all
  const fieldToTeamKey = { colorR: 'primary', colorG: 'secondary', colorB: 'tertiary' };
  const regionChars = Object.keys(entry.regions); // e.g. ['R','G'] or ['R','B']
  const overrideOn = state.decalPreviewOverride.enabled;

  // v0.75: restored the interactive editor here (v0.73 wrongly made this
  // read-only and moved editing into the Team Colors section -- corrected
  // per direct feedback). Still edits the ONE shared state.customPalette
  // (the actually-useful part of v0.73's fix: Apply All uses the same set
  // for every piece, not per-piece memory) -- just does it inline again,
  // where it's actually usable, instead of requiring a trip to a separate
  // section.
  const resolvedHex = {};
  regionChars.forEach(ch => {
    const custom = state.customPalette[ch];
    if (custom) { resolvedHex[ch] = custom; return; }
    const field = PREVIEW_REGION_TO_TINT_FIELD[ch];
    const color = teamColors[fieldToTeamKey[field]];
    resolvedHex[ch] = color ? colorToHex(color) : fallback;
  });

  const paths = regionChars.map(ch =>
    `<path id="livePreviewPath${ch}" d="${entry.regions[ch]}" fill="${resolvedHex[ch]}"/>`
  ).join('\n');

  const pickerLabelFor = { R: 'Primary', G: 'Secondary', B: 'Tertiary' };
  const pickers = regionChars.map(ch => {
    const field = PREVIEW_REGION_TO_TINT_FIELD[ch];
    const teamHex = teamColors[fieldToTeamKey[field]] ? colorToHex(teamColors[fieldToTeamKey[field]]) : null;
    return `
    <div class="ctrl" style="display:flex;align-items:center;gap:6px;margin-right:10px;">
      <input type="color" id="livePreviewPick${ch}" value="${resolvedHex[ch]}" style="width:26px;height:26px;border:none;border-radius:5px;padding:0;cursor:pointer;">
      <input type="text" id="livePreviewHex${ch}" value="${resolvedHex[ch]}" style="width:76px;font-family:var(--mono);font-size:11px;background:#14161a;border:1px solid #333640;border-radius:5px;color:var(--ink);padding:4px 6px;">
      <span style="font-size:11px;color:var(--ink-faint);">${pickerLabelFor[ch]}</span>
      ${teamHex ? `<button type="button" id="livePreviewReset${ch}" title="Back to this team's real ${pickerLabelFor[ch].toLowerCase()} color (${teamHex})" style="font-size:10.5px;padding:3px 6px;">↺ school color</button>` : ''}
    </div>`;
  }).join('');

  const untracedNote = regionChars.length < 3
    ? `<div class="hint" style="margin-top:4px;">This trace only found ${regionChars.length} distinct flat-colored region${regionChars.length === 1 ? '' : 's'} (${regionChars.join(', ')}) -- if the real overlay has a channel beyond these (common for shaded/metallic materials like Shiny, where a channel can affect rendering without showing as its own hard-edged region), Apply fills it with the resolved color for that channel automatically rather than leaving it untouched.</div>`
    : '';
  return `
    <div class="row" style="margin-top:10px;align-items:flex-start;gap:14px;">
      <div style="width:110px;height:110px;flex-shrink:0;background:#0d0e10;border:1px solid var(--line);border-radius:8px;padding:8px;">
        <svg viewBox="${entry.viewBox}" style="width:100%;height:100%;">
          <g transform="${entry.transform}">${paths}</g>
        </svg>
      </div>
      <div style="flex:1;">
        <div class="hint" style="margin-bottom:8px;">Custom palette for "${escapeHtml(catalogLabel)}" -- ONE shared set (not per-piece); Apply/Apply All use these same colors for jersey, pants, and socks alike. Number Color can pull from this too.</div>
        <div class="row" style="flex-wrap:wrap;gap:6px;margin-bottom:8px;">${pickers}</div>
        <label style="display:flex;align-items:center;gap:6px;font-size:12px;color:${overrideOn ? 'var(--ink)' : 'var(--ink-dim)'};cursor:pointer;">
          <input type="checkbox" id="useOverrideColorsBox" ${overrideOn ? 'checked' : ''}>
          Use this custom palette instead of team colors when I click Apply
        </label>
        <div class="hint" style="margin-top:4px;${overrideOn ? 'color:var(--warn,#c9a227);' : ''}">${overrideOn
          ? 'ON -- Apply/Apply All write the custom palette above, the same set for every piece.'
          : 'OFF (default) -- Apply always uses the real TEAM_BACKGROUNDCOLOR fields regardless of what\'s set above.'}</div>
        ${untracedNote}
      </div>
    </div>`;
}

// Attaches live input listeners for the interactive decal-color preview.
// Separate from the render function itself so it can be called once after
// innerHTML is set, same pattern as the rest of this file's dynamic
// sections. Edits state.customPalette directly -- the ONE shared palette,
// not per-piece (see renderDecalPreview's comment).
function wireDecalPreviewInteractivity() {
  document.querySelectorAll('[id^="livePreviewPick"]').forEach(picker => {
    const ch = picker.id.replace('livePreviewPick', '');
    const hexInput = document.getElementById('livePreviewHex' + ch);
    const path = document.getElementById('livePreviewPath' + ch);
    if (!hexInput || !path) return;
    picker.addEventListener('input', () => {
      hexInput.value = picker.value.toUpperCase();
      path.setAttribute('fill', picker.value);
      state.customPalette[ch] = picker.value;
      renderNumberColorSection();
    });
    hexInput.addEventListener('change', () => {
      let v = hexInput.value.trim();
      if (!v.startsWith('#')) v = '#' + v;
      if (/^#[0-9A-Fa-f]{6}$/.test(v)) {
        picker.value = v;
        hexInput.value = v.toUpperCase();
        path.setAttribute('fill', v);
        state.customPalette[ch] = v;
        renderNumberColorSection();
      }
    });
    const resetBtn = document.getElementById('livePreviewReset' + ch);
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        const teamColors = getTeamColors();
        const fieldToTeamKey = { colorR: 'primary', colorG: 'secondary', colorB: 'tertiary' };
        const field = PREVIEW_REGION_TO_TINT_FIELD[ch];
        const teamColor = teamColors[fieldToTeamKey[field]];
        const teamHex = teamColor ? colorToHex(teamColor) : null;
        if (!teamHex) return;
        picker.value = teamHex;
        hexInput.value = teamHex.toUpperCase();
        path.setAttribute('fill', teamHex);
        state.customPalette[ch] = null; // null = "follow the real team color again"
        renderNumberColorSection();
      });
    }
  });
  const overrideBox = document.getElementById('useOverrideColorsBox');
  if (overrideBox) {
    overrideBox.addEventListener('change', () => {
      state.decalPreviewOverride.enabled = overrideBox.checked;
      renderDecalSection();
    });
  }
}

// ---------- team colors (static reference) ----------
// PURE READ-ONLY reference. Always exactly what's currently in this
// payload's TEAM_BACKGROUNDCOLOR fields -- nothing here is editable, and
// nothing anywhere else in the tool writes to it. Fixed a real mix-up from
// v0.73: that version put the actual EDITABLE custom palette in this same
// section, which made it look like "the school colors" were changing as
// soon as you touched anything here, and it also stripped Decal Tint's own
// inline color editor entirely, redirecting all editing here instead. Per
// direct correction: this section only ever shows the real team colors,
// full stop. The editable custom palette lives back in Decal Tint, where
// it belongs -- see renderDecalPreview.
function renderTeamColorsSection() {
  const out = document.getElementById('teamColorsOut');
  if (!out) return;
  if (!state.payload || !state.variants.length) { out.innerHTML = ''; return; }

  const team = getTeamColors();
  const refSwatch = (c, label) => c
    ? `<span style="display:inline-flex;align-items:center;gap:4px;margin-right:14px;">
         <span style="width:14px;height:14px;border-radius:3px;border:1px solid var(--line);display:inline-block;background:${colorToHex(c)};"></span>
         <span style="font-family:var(--mono);font-size:11px;color:var(--ink-dim);">${label} ${colorToHex(c)}</span>
       </span>`
    : `<span style="font-size:11px;color:var(--ink-faint);margin-right:14px;">${label} —</span>`;

  out.innerHTML = `
    <div class="fieldblock">
      <div class="head">
        <div class="name">Team Colors</div>
        <span class="badge ${team.primary ? 'ok' : 'off'}">${team.primary ? 'team colors found' : 'no team colors on payload'}</span>
      </div>
      <div class="hint">Static reference only -- exactly what's currently in this payload's TEAM_BACKGROUNDCOLOR fields. Nothing on this page edits these; nothing here edits anything else. For actually changing colors, see Decal Tint's custom palette or Number Color below.</div>
      <div class="row" style="margin-top:6px;">
        ${refSwatch(team.primary, 'Primary')}
        ${refSwatch(team.secondary, 'Secondary')}
        ${refSwatch(team.tertiary, 'Tertiary')}
      </div>
    </div>`;
}

function renderDecalSection() {
  const out = document.getElementById('decalOut');
  if (!out) return;
  if (!state.payload || !state.variants.length) { out.innerHTML = ''; return; }

  const opts = CATALOG.decals || [];
  const listId = 'dl-decal';
  const datalist = `<datalist id="${listId}">${opts.map(o => `<option value="${escapeHtml(o.label)}">`).join('')}</datalist>`;
  const statuses = decalPieceStatus();
  const rows = statuses.map(s => {
    if (!s.found) return `<div class="current-val"><b>${s.kind}:</b> ${escapeHtml(s.note)}</div>`;
    return `<div class="current-val"><b>${s.kind} (overlay "${escapeHtml(s.label)}"):</b> ${escapeHtml(s.current)}</div>`;
  }).join('');

  // If the jersey's current decal matches a known catalog entry, prefill the picker
  // with it -- so the box shows what's actually equipped, not just a blank prompt.
  const jerseyStatus = statuses.find(s => s.kind === 'jersey');
  let currentValue = state.lastSelections['decal'] || '';
  if (!currentValue && jerseyStatus?.found) {
    const match = opts.find(o => o.col === jerseyStatus.current);
    if (match) currentValue = match.label;
  }

  const teamColors = getTeamColors();
  const swatch = (c, label) => c
    ? `<span style="display:inline-flex;align-items:center;gap:4px;margin-right:12px;">
         <span style="width:14px;height:14px;border-radius:3px;border:1px solid var(--line);display:inline-block;background:${colorToHex(c)};"></span>
         <span style="font-family:var(--mono);font-size:11px;color:var(--ink-dim);">${label} ${colorToHex(c)}</span>
       </span>`
    : `<span style="font-size:11px;color:var(--ink-faint);margin-right:12px;">${label} —</span>`;
  const pieceOptions = DECAL_PIECES.map(pd =>
    `<option value="${pd.kind}" ${state.tintSelectedPiece === pd.kind ? 'selected' : ''}>${pd.kind[0].toUpperCase() + pd.kind.slice(1)}</option>`
  ).join('');

  // Always show ALL pieces here -- this is a readout, not gated by which
  // piece is currently selected for editing/applying.
  const currentStatus = getCurrentTintStatus(findTintableDecalOverlays, { jersey: true, pants: true, socks: true });
  const currentStatusRows = currentStatus.map(s => {
    if (s.note) return `<div class="row" style="font-size:11.5px;color:var(--ink-faint);">${s.kind}: ${s.note}</div>`;
    const parts = [`colorR = ${s.colorR}`, `colorG = ${s.colorG}`];
    if (s.colorB !== null) parts.push(`colorB = ${s.colorB}`);
    return `<div class="row" style="font-size:11.5px;color:var(--ink-dim);font-family:var(--mono);">${s.kind}: ${parts.join(', ')}</div>`;
  }).join('');

  const overrideOn = state.decalPreviewOverride.enabled;
  const pieceLabel = state.tintSelectedPiece.charAt(0).toUpperCase() + state.tintSelectedPiece.slice(1);
  const tintBlock = `
    <div class="fieldblock">
      <div class="head">
        <div class="name">Decal Tint (team colors)</div>
        <span class="badge ${overrideOn ? 'warn' : (teamColors.primary ? 'ok' : 'off')}">${overrideOn ? 'PREVIEW OVERRIDE ON' : (teamColors.primary ? 'team colors found' : 'no team colors on payload')}</span>
      </div>
      <div class="hint">Writes this team's TEAM_BACKGROUNDCOLOR fields into the vendor decal's tint (colorR/colorG/colorB). Pick which piece to work on below -- "Apply" targets just that piece, "Apply All" writes every piece at once, using the SAME set of colors for all of them (the custom palette below if the override is on, or team colors if it's off). Only affects decal overlays that actually have a tint node (mask-in-col-channel decals like BIG10-style conference logos don't, and are skipped either way). See Team Colors above for the real static reference; the editable palette is below.</div>
      <div class="row" style="margin-top:6px;align-items:center;gap:8px;">
        <label for="tintPieceSelect" style="font-size:12.5px;color:var(--ink-dim);">Piece:</label>
        <select id="tintPieceSelect">${pieceOptions}</select>
      </div>
      <div class="row" style="margin-top:8px;gap:8px;">
        <button type="button" id="applyTintBtn" class="primary" ${(overrideOn || teamColors.primary) ? '' : 'disabled'}>${overrideOn ? `Apply PREVIEW colors to ${pieceLabel}` : `Apply team colors to ${pieceLabel}`}</button>
        <button type="button" id="applyTintAllBtn" ${(overrideOn || teamColors.primary) ? '' : 'disabled'}>Apply All (Jersey + Pants + Socks)</button>
      </div>
      <div class="hint" style="margin-top:10px;">Currently on the decal right now (re-reads after every Apply -- this is how you tell if it actually did anything):</div>
      ${currentStatusRows}
      ${renderDecalPreview(currentValue, teamColors)}
    </div>`;

  out.innerHTML = `
    <div class="fieldblock">
      <div class="head">
        <div class="name">Vendor Decal</div>
        <span class="badge ok">confirmed</span>
      </div>
      <div class="hint">Updates jersey, pants, and socks together -- brands can be mixed and matched freely, regardless of what's currently equipped. Placement (scale/offset/rotate) auto-adjusts to the brand's known value per piece where one exists.</div>
      <div class="row" style="align-items:flex-start;">
        <div class="field">
          <input type="text" list="${listId}" id="decalInput" value="${escapeHtml(currentValue)}" placeholder="Pick a brand + material — updates all three pieces at once">
        </div>
        <button type="button" id="decalGalleryBtn" title="Browse with color previews">Gallery</button>
        <button type="button" id="decalClearBtn" title="Clear this field">Clear</button>
      </div>
      ${datalist}
      ${rows}
    </div>
    ${tintBlock}`;

  const input = document.getElementById('decalInput');
  if (input) {
    input.addEventListener('change', () => applyDecalPick(input.value));
    input.addEventListener('focus', () => input.select());
  }
  const clearBtn = document.getElementById('decalClearBtn');
  if (clearBtn && input) {
    clearBtn.addEventListener('click', () => {
      input.value = '';
      input.focus();
    });
  }
  const decalGalleryBtn = document.getElementById('decalGalleryBtn');
  if (decalGalleryBtn && input) {
    decalGalleryBtn.addEventListener('click', () => openDecalGallery(opts, input));
  }
  const tintBtn = document.getElementById('applyTintBtn');
  if (tintBtn) {
    tintBtn.addEventListener('click', applyTeamColorsToDecalTint);
  }
  const tintAllBtn = document.getElementById('applyTintAllBtn');
  if (tintAllBtn) {
    tintAllBtn.addEventListener('click', applyTeamColorsToDecalTintAll);
  }
  const pieceSelect = document.getElementById('tintPieceSelect');
  if (pieceSelect) {
    pieceSelect.addEventListener('change', () => {
      state.tintSelectedPiece = pieceSelect.value;
      renderDecalSection();
    });
  }
  wireDecalPreviewInteractivity();
}

function applyDecalPick(typed) {
  const opts = CATALOG.decals || [];
  const match = opts.find(o => o.label === typed);
  if (!match) { log(`No catalog entry for "${typed}".`, 'err'); return; }

  const variant = state.variants[state.selectedVariantIdx];
  const updated = [];
  const skipped = [];
  const brandTransforms = BRAND_PIECE_TRANSFORM[match.brand] || {};

  DECAL_PIECES.forEach(pd => {
    const partKey = variant?.[pd.keyField];
    if (!partKey) { skipped.push(pd.kind + ' (no part)'); return; }
    const part = getDeep(state.payload, ['teamData', 'frostbiteData', 'uniformParts', pd.plural, partKey]);
    const idxs = findVendorDecalOverlays(part);
    if (!idxs.length) { skipped.push(pd.kind + ' (no vendor decal overlay)'); return; }

    idxs.forEach(idx => {
      const overlay = part.layerCompTexture.overlays[idx];
      setDeep(overlay, ['textures', 'color', 'textureId'], match.col);
      setDeep(overlay, ['textures', 'rsm', 'textureId'], match.rsm);
      setDeep(overlay, ['textures', 'normal', 'textureId'], match.norm);
    });

    // Placement only auto-applies when there's exactly one decal overlay on
    // this piece -- a multi-overlay piece (mirrored sides) has no confirmed
    // per-side data to apply safely, so texture updates but placement doesn't.
    // Material-specific override takes priority over the brand-level default,
    // when one exists (confirmed cases only -- most materials share their
    // brand's baseline, e.g. Jumpman Cotton/Diamond).
    const pieceTransform = MATERIAL_PIECE_OVERRIDES[match.label]?.[pd.kind] || brandTransforms[pd.kind];
    let placementNote = '';
    if (idxs.length === 1 && pieceTransform) {
      const overlay = part.layerCompTexture.overlays[idxs[0]];
      setDeep(overlay, ['transform', 'scale', 'u'], pieceTransform.scaleU);
      setDeep(overlay, ['transform', 'scale', 'v'], pieceTransform.scaleV);
      setDeep(overlay, ['transform', 'offset', 'u'], pieceTransform.offsetU);
      setDeep(overlay, ['transform', 'offset', 'v'], pieceTransform.offsetV);
      setDeep(overlay, ['transform', 'rotate'], pieceTransform.rotate);
      // scaledTransform is a separate cached copy of scale/offset (x=scale.u,
      // y=scale.v, z=offset.u, w=offset.v) that does NOT recompute itself --
      // confirmed from a real payload where scale/offset updated correctly
      // but scaledTransform stayed frozen at the old brand's values, which is
      // very likely why placement changes weren't visible in-game at all.
      setDeep(overlay, ['transform', 'scaledTransform', 'x'], pieceTransform.scaleU);
      setDeep(overlay, ['transform', 'scaledTransform', 'y'], pieceTransform.scaleV);
      setDeep(overlay, ['transform', 'scaledTransform', 'z'], pieceTransform.offsetU);
      setDeep(overlay, ['transform', 'scaledTransform', 'w'], pieceTransform.offsetV);
      // Confirmed root cause of the pants-specific placement bug: textures.layout
      // was null on the affected pants overlay, while Florida's own
      // (correctly-rendering) pants overlay had it set. This is brand-specific,
      // not a shared mesh constant -- Jumpman needs a set UV path, Nike is
      // confirmed to need explicit null, Adidas needs its own different UV
      // path. Whenever a brand has a KNOWN policy (the 'layout' key is present
      // at all, whether its value is a string or null), enforce it
      // unconditionally -- overwriting whatever's there, since we now know
      // what's correct and don't need to preserve potentially-contaminated
      // leftover state from a different brand's earlier test.
      if (pd.kind === 'pants' && 'layout' in pieceTransform) {
        const layoutValue = pieceTransform.layout === null
          ? null
          : { textureId: pieceTransform.layout, sourceType: 0 };
        setDeep(overlay, ['textures', 'layout'], layoutValue);
        placementNote = pieceTransform.layout ? ' +placement +layout' : ' +placement (layout reset to native null)';
      } else {
        placementNote = ' +placement';
      }
    } else if (idxs.length > 1) {
      placementNote = ' (multiple overlays, placement left unchanged)';
    } else if (!pieceTransform) {
      // This brand has no confirmed placement of its own for this piece, so
      // nothing gets written -- but check whether what's already there is
      // actually a DIFFERENT brand's known signature left over from an
      // earlier test in this session, rather than this team's true native
      // state. Detecting it doesn't fix it (we have no confirmed correct
      // value to fall back to), but it turns a silent wrong guess into a
      // visible warning instead of another round of screenshots.
      const overlay = idxs.length === 1 ? part.layerCompTexture.overlays[idxs[0]] : null;
      const currentLayoutId = overlay?.textures?.layout?.textureId;
      const contaminant = Object.entries(BRAND_PIECE_TRANSFORM).find(([brandName, pieces]) => {
        if (brandName === match.brand) return false;
        const t = pieces[pd.kind];
        return t?.layout && currentLayoutId && t.layout === currentLayoutId;
      });
      if (contaminant) {
        placementNote = ` (placement left unchanged, but currently carries ${contaminant[0]}'s layout -- likely leftover from testing that brand, not this team's native state)`;
      } else {
        placementNote = ' (no placement default for this brand/piece)';
      }
    }
    updated.push(pd.kind + placementNote);
  });

  document.getElementById('rawText').value = JSON.stringify(state.payload, null, 2);
  state.lastSelections['decal'] = typed;
  const parts = [`Set Vendor Decal (${variant.label}) → ${typed}.`];
  if (updated.length) parts.push(`Updated: ${updated.join(', ')}.`);
  if (skipped.length) parts.push(`Skipped: ${skipped.join(', ')}.`);
  log(parts.join(' '), updated.length ? 'ok' : 'err');
  renderDecalSection();
}

// ---------- team colors -> decal tint (conference/vendor logo recolor) ----------
// Reads TEAM_BACKGROUNDCOLOR[R/G/B] (+ 2/3 suffixed variants for secondary/
// tertiary) straight off teamData.teamInfos -- these are plain 0-255 ints on
// the payload, same values shown in the team editor's color pickers. No
// team_colors catalog lookup needed: confirmed from a real payload (UCLA)
// that overlay.tint.colorR/colorG can hold either a ref into that catalog
// OR a plain {r,g,b} value (0-1 floats) -- SEC's overlay uses the literal
// form already, so writing literals here matches an already-supported shape
// rather than inventing a new one.
function getTeamColors() {
  const ti = state.payload?.teamData?.teamInfos || {};
  const toUnit = (v) => {
    const n = Number(v);
    return Number.isFinite(n) ? Math.max(0, Math.min(1, n / 255)) : null;
  };
  const triple = (r, g, b) => {
    const rr = toUnit(ti[r]), gg = toUnit(ti[g]), bb = toUnit(ti[b]);
    return (rr === null || gg === null || bb === null) ? null : { r: rr, g: gg, b: bb };
  };
  return {
    primary: triple('TEAM_BACKGROUNDCOLORR', 'TEAM_BACKGROUNDCOLORG', 'TEAM_BACKGROUNDCOLORB'),
    secondary: triple('TEAM_BACKGROUNDCOLORR2', 'TEAM_BACKGROUNDCOLORG2', 'TEAM_BACKGROUNDCOLORB2'),
    tertiary: triple('TEAM_BACKGROUNDCOLORR3', 'TEAM_BACKGROUNDCOLORG3', 'TEAM_BACKGROUNDCOLORB3')
  };
}
function colorToHex(c) {
  if (!c) return null;
  const h = (n) => Math.round(Math.max(0, Math.min(1, n)) * 255).toString(16).padStart(2, '0');
  return '#' + h(c.r) + h(c.g) + h(c.b);
}
function hexToColor(hex) {
  if (!hex || !/^#[0-9A-Fa-f]{6}$/.test(hex)) return null;
  const n = parseInt(hex.slice(1), 16);
  return { r: ((n >> 16) & 255) / 255, g: ((n >> 8) & 255) / 255, b: (n & 255) / 255 };
}

// Same overlay-finding approach as findVendorDecalOverlays -- structural, not
// label-based -- but this only needs an overlay to HAVE a tint node at all;
// not every decal type uses one (BIG10-style auto-color decals encode their
// mask directly in the col texture's RGB channels instead, confirmed by
// pixel analysis, and carry no tint node to write into).
function findTintableDecalOverlays(part) {
  const overlays = part?.layerCompTexture?.overlays;
  if (!Array.isArray(overlays)) return [];
  const out = [];
  overlays.forEach((o, i) => {
    const tid = o?.textures?.color?.textureId;
    const isVendorDecal = typeof tid === 'string' && tid.toLowerCase().includes('/decals/vendors/');
    if (isVendorDecal && o?.tint) out.push(i);
  });
  return out;
}

// Describes whatever is actually sitting in a tint field right now -- a ref
// into the team_colors catalog (confirmed shape on UCLA's Jumpman overlay),
// a literal {r,g,b} (confirmed shape on SEC's overlay, and what our own
// applyTeamColors* writes), or genuinely unset. This exists specifically so
// the UI can show a before/after: the target-color swatches never change
// (they're always computed from teamInfos), so without reading the actual
// current field there's no way to tell whether Apply did anything.
function describeTintValue(v) {
  if (v === null || v === undefined) return 'not set';
  if (typeof v === 'object') {
    if (typeof v.r === 'number' && typeof v.g === 'number' && typeof v.b === 'number') {
      return `literal ${colorToHex(v)}`;
    }
    if (typeof v.textureId === 'string') {
      const short = v.textureId.split('/').pop();
      return `ref: ${short}`;
    }
  }
  try { return 'raw: ' + JSON.stringify(v); } catch { return 'unrecognized value'; }
}

// Reads the CURRENT tint state (not the target) for every checked piece, so
// the UI can render an actual before/after instead of only ever showing the
// same computed team-color swatches regardless of whether Apply was clicked.
function getCurrentTintStatus(findFn, pieceSelection) {
  const variant = state.variants[state.selectedVariantIdx];
  if (!variant) return [];
  return DECAL_PIECES.filter(pd => pieceSelection[pd.kind]).map(pd => {
    const partKey = variant?.[pd.keyField];
    if (!partKey) return { kind: pd.kind, note: 'no part for this variant' };
    const part = getDeep(state.payload, ['teamData', 'frostbiteData', 'uniformParts', pd.plural, partKey]);
    const idxs = findFn(part);
    if (!idxs.length) return { kind: pd.kind, note: 'no tintable overlay found' };
    const overlay = part.layerCompTexture.overlays[idxs[0]];
    return {
      kind: pd.kind,
      colorR: describeTintValue(overlay?.tint?.colorR),
      colorG: describeTintValue(overlay?.tint?.colorG),
      colorB: overlay?.tint?.colorB !== undefined ? describeTintValue(overlay?.tint?.colorB) : null
    };
  });
}

// Resolves the color set that should be written: real team colors when the
// override is off, or the ONE shared custom palette when it's on -- same
// set for every piece now, not per-piece. `pieceKind` param kept for call
// signature stability even though it's unused; nothing here varies by piece
// anymore.
//
// v0.73 replaced the per-piece preview-color system entirely. That system
// went through three rounds of bugs (v0.70, v0.71, v0.72) trying to get
// "visited vs. never-visited" piece tracking right, and even once that
// logic was correct, it produced a real, confusing outcome: Apply All would
// write jersey=red, pants=whatever green it was last left at, because each
// piece silently remembered its own colors with no obvious indication that
// was happening. The right fix was removing the per-piece model, not
// patching it again -- one palette, used the same way for every piece.
function getEffectiveDecalColorsForPiece(pieceKind) {
  const team = getTeamColors();
  if (state.decalPreviewOverride.enabled) {
    const cp = state.customPalette;
    return {
      primary: cp.R ? hexToColor(cp.R) : team.primary,
      secondary: cp.G ? hexToColor(cp.G) : team.secondary,
      tertiary: cp.B ? hexToColor(cp.B) : team.tertiary
    };
  }
  return team;
}

// Writes one piece's tint fields. Returns true if it found something to
// write to, false if skipped (no part for this variant, or the overlay
// isn't a tintable decal). Shared by both the single-piece and Apply All
// paths so the actual write logic only lives in one place.
function writeDecalTintForPiece(pd, colors) {
  const variant = state.variants[state.selectedVariantIdx];
  const partKey = variant?.[pd.keyField];
  if (!partKey) return { ok: false, reason: 'no part' };
  const part = getDeep(state.payload, ['teamData', 'frostbiteData', 'uniformParts', pd.plural, partKey]);
  const idxs = findTintableDecalOverlays(part);
  if (!idxs.length) return { ok: false, reason: 'no tintable decal overlay' };

  idxs.forEach(idx => {
    const overlay = part.layerCompTexture.overlays[idx];
    if (colors.primary) setDeep(overlay, ['tint', 'colorR'], colors.primary);
    if (colors.secondary) setDeep(overlay, ['tint', 'colorG'], colors.secondary);
    if (colors.tertiary && overlay.tint.colorB !== undefined) {
      setDeep(overlay, ['tint', 'colorB'], colors.tertiary);
    }
    setDeep(overlay, ['tint', 'TintMode'], 'LayerCompTintMode_WithValue');
  });
  return { ok: true };
}

function applyTeamColorsToDecalTint() {
  const pieceKind = state.tintSelectedPiece;
  const pd = DECAL_PIECES.find(p => p.kind === pieceKind);
  const usingOverride = state.decalPreviewOverride.enabled;
  const colors = getEffectiveDecalColorsForPiece(pieceKind);

  if (usingOverride && !colors.primary && !colors.secondary) {
    log('Custom palette is on, but neither it nor this team\'s real colors resolved to anything -- set a custom color or check this payload has team colors.', 'err');
    return;
  }
  if (!usingOverride && (!colors.primary || !colors.secondary)) {
    log('Could not read TEAM_BACKGROUNDCOLOR fields from teamInfos -- this payload may not have team colors set.', 'err');
    return;
  }

  const result = writeDecalTintForPiece(pd, colors);
  document.getElementById('rawText').value = JSON.stringify(state.payload, null, 2);
  const label = usingOverride ? 'the custom palette' : 'team colors';
  if (result.ok) {
    log(`Applied ${label} to decal tint. Updated: ${pieceKind}.`, 'ok');
  } else {
    log(`Applied ${label} to decal tint. Skipped: ${pieceKind} (${result.reason}).`, 'err');
  }
  renderDecalSection();
}

function applyTeamColorsToDecalTintAll() {
  const usingOverride = state.decalPreviewOverride.enabled;
  const updated = [];
  const skipped = [];

  DECAL_PIECES.forEach(pd => {
    const colors = getEffectiveDecalColorsForPiece(pd.kind);
    if (usingOverride && !colors.primary && !colors.secondary) {
      skipped.push(pd.kind + ' (no custom or team colors resolved)');
      return;
    }
    if (!usingOverride && (!colors.primary || !colors.secondary)) {
      skipped.push(pd.kind + ' (no team colors on payload)');
      return;
    }
    const result = writeDecalTintForPiece(pd, colors);
    if (result.ok) updated.push(pd.kind);
    else skipped.push(`${pd.kind} (${result.reason})`);
  });

  document.getElementById('rawText').value = JSON.stringify(state.payload, null, 2);
  const label = usingOverride ? 'the custom palette (same colors for every piece)' : 'team colors';
  const parts = [`Applied ${label} to decal tint (all pieces).`];
  if (updated.length) parts.push(`Updated: ${updated.join(', ')}.`);
  if (skipped.length) parts.push(`Skipped: ${skipped.join(', ')}.`);
  log(parts.join(' '), updated.length ? 'ok' : 'err');
  renderDecalSection();
}

// ---------- team colors -> conference logo tint ----------
// **PARKED as of v0.49 -- code kept intact, UI removed.**
// Every available test path was tried and hit a real structural wall:
//   - No way to export a real conference-assigned team's JSON (Frosty-only
//     access to those teams, no captured payload).
//   - No way to load a real school into Team Builder to capture live.
//   - Manually editing a custom team's conference-logo slot (texture path +
//     absurd test colors) got reverted on save -- consistent with the game
//     validating that conference-logo data shouldn't exist on a team with
//     no real conference, custom teams included.
// Net result: the underlying write logic is structurally identical to
// Vendor Decal Tint (same tint-node shape, same TintMode, same write path),
// which IS confirmed working in-game -- so there's reason to believe this
// works too -- but it has never been confirmed against a real conference
// decal, unlike vendor tint. Rather than ship an unverified feature as if
// it were proven, it's been pulled from the UI (renderConferenceTintSection
// is no longer called, conferenceTintOut container removed) but left
// fully intact below. Re-enabling it later just means restoring the
// container div and the three renderConferenceTintSection() call sites
// removed in v0.49 -- no logic needs to be rewritten.
//
// Deliberately "global" rather than a per-conference picker: this doesn't
// care WHICH conference logo is currently equipped (SEC, BIG10, ACC,
// whatever) -- it just finds whatever conference-logo overlay is already
// there (structurally, by /decals/conferences/ in its col texture path,
// same approach as findVendorDecalOverlays) and overwrites its tint with
// this team's colors. Useful specifically for teams running an off-palette
// jersey where the conference patch's normal/default colors would clash.
//
// Same tint-node requirement as vendor decals: BIG10-style conference logos
// that encode their mask directly in the col texture's RGB channels (no
// tint node at all, confirmed via pixel analysis) get skipped rather than
// silently no-op'd -- this only works on conference decals built the SEC
// way (tint node present, TintMode-driven).
function findConferenceDecalOverlays(part) {
  const overlays = part?.layerCompTexture?.overlays;
  if (!Array.isArray(overlays)) return [];
  const out = [];
  overlays.forEach((o, i) => {
    const tid = o?.textures?.color?.textureId;
    const isConferenceDecal = typeof tid === 'string' && tid.toLowerCase().includes('/decals/conferences/');
    if (isConferenceDecal && o?.tint) out.push(i);
  });
  return out;
}

function applyTeamColorsToConferenceTint() {
  const colors = getTeamColors();
  if (!colors.primary || !colors.secondary) {
    log('Could not read TEAM_BACKGROUNDCOLOR fields from teamInfos -- this payload may not have team colors set.', 'err');
    return;
  }
  if (!DECAL_PIECES.some(pd => state.conferenceTintPieces[pd.kind])) {
    log('No pieces checked -- select at least one of Jersey/Pants/Socks before applying.', 'err');
    return;
  }
  const variant = state.variants[state.selectedVariantIdx];
  const updated = [];
  const skipped = [];

  DECAL_PIECES.filter(pd => state.conferenceTintPieces[pd.kind]).forEach(pd => {
    const partKey = variant?.[pd.keyField];
    if (!partKey) { skipped.push(pd.kind + ' (no part)'); return; }
    const part = getDeep(state.payload, ['teamData', 'frostbiteData', 'uniformParts', pd.plural, partKey]);
    const idxs = findConferenceDecalOverlays(part);
    if (!idxs.length) { skipped.push(pd.kind + ' (no tintable conference decal)'); return; }

    idxs.forEach(idx => {
      const overlay = part.layerCompTexture.overlays[idx];
      setDeep(overlay, ['tint', 'colorR'], colors.primary);
      setDeep(overlay, ['tint', 'colorG'], colors.secondary);
      if (colors.tertiary && overlay.tint.colorB !== undefined) {
        setDeep(overlay, ['tint', 'colorB'], colors.tertiary);
      }
      setDeep(overlay, ['tint', 'TintMode'], 'LayerCompTintMode_WithValue');
    });
    updated.push(pd.kind);
  });

  const skippedByChoice = DECAL_PIECES.filter(pd => !state.conferenceTintPieces[pd.kind]).map(pd => pd.kind + ' (unchecked)');
  document.getElementById('rawText').value = JSON.stringify(state.payload, null, 2);
  const parts = [`Applied team colors to conference logo tint.`];
  if (updated.length) parts.push(`Updated: ${updated.join(', ')}.`);
  const allSkipped = [...skipped, ...skippedByChoice];
  if (allSkipped.length) parts.push(`Skipped: ${allSkipped.join(', ')}.`);
  log(parts.join(' '), updated.length ? 'ok' : 'err');
  renderConferenceTintSection();
}

function renderConferenceTintSection() {
  const out = document.getElementById('conferenceTintOut');
  if (!out) return;
  if (!state.payload || !state.variants.length) { out.innerHTML = ''; return; }

  const teamColors = getTeamColors();
  const swatch = (c, label) => c
    ? `<span style="display:inline-flex;align-items:center;gap:4px;margin-right:12px;">
         <span style="width:14px;height:14px;border-radius:3px;border:1px solid var(--line);display:inline-block;background:${colorToHex(c)};"></span>
         <span style="font-family:var(--mono);font-size:11px;color:var(--ink-dim);">${label} ${colorToHex(c)}</span>
       </span>`
    : `<span style="font-size:11px;color:var(--ink-faint);margin-right:12px;">${label} —</span>`;
  const pieceCheckboxes = DECAL_PIECES.map(pd => `
    <label style="display:inline-flex;align-items:center;gap:5px;margin-right:14px;font-size:12.5px;color:var(--ink-dim);cursor:pointer;">
      <input type="checkbox" class="conferenceTintPieceBox" data-kind="${pd.kind}" ${state.conferenceTintPieces[pd.kind] ? 'checked' : ''}>
      ${pd.kind[0].toUpperCase() + pd.kind.slice(1)}
    </label>`).join('');

  const currentStatus = getCurrentTintStatus(findConferenceDecalOverlays, state.conferenceTintPieces);
  const currentStatusRows = currentStatus.map(s => {
    if (s.note) return `<div class="row" style="font-size:11.5px;color:var(--ink-faint);">${s.kind}: ${s.note}</div>`;
    const parts = [`colorR = ${s.colorR}`, `colorG = ${s.colorG}`];
    if (s.colorB !== null) parts.push(`colorB = ${s.colorB}`);
    return `<div class="row" style="font-size:11.5px;color:var(--ink-dim);font-family:var(--mono);">${s.kind}: ${parts.join(', ')}</div>`;
  }).join('');

  out.innerHTML = `
    <div class="fieldblock">
      <div class="head">
        <div class="name">Conference Logo Tint (team colors)</div>
        <span class="badge ${teamColors.primary ? 'ok' : 'off'}">${teamColors.primary ? 'team colors found' : 'no team colors on payload'}</span>
      </div>
      <div class="hint">Global override, not a per-conference picker -- whatever conference logo is already equipped (SEC, ACC, etc.) gets its tint overwritten with this team's colors. Useful when running an off-palette jersey where the conference patch's default colors would clash. Only works on conference decals with a tint node (SEC-style) -- BIG10-style decals that encode color directly in the texture are skipped.</div>
      <div class="row" style="margin-top:8px;">
        ${swatch(teamColors.primary, 'Primary')}
        ${swatch(teamColors.secondary, 'Secondary')}
        ${swatch(teamColors.tertiary, 'Tertiary')}
      </div>
      <div class="row" style="margin-top:2px;">${pieceCheckboxes}</div>
      <div class="row">
        <button type="button" id="applyConferenceTintBtn" class="primary" ${teamColors.primary ? '' : 'disabled'}>Apply team colors to conference logo tint</button>
      </div>
      <div class="hint" style="margin-top:10px;">Currently on the decal right now (re-reads after every Apply -- this is how you tell if it actually did anything):</div>
      ${currentStatusRows}
    </div>`;

  const btn = document.getElementById('applyConferenceTintBtn');
  if (btn) btn.addEventListener('click', applyTeamColorsToConferenceTint);
  document.querySelectorAll('.conferenceTintPieceBox').forEach(box => {
    box.addEventListener('change', () => {
      state.conferenceTintPieces[box.dataset.kind] = box.checked;
    });
  });
}

// ---------- number spacing slider ----------
// Confirmed path: numberComp.numberMaterialSettings.offsetScaleSpacing.numberSpacing.x
// Only x is exposed -- y/z/w were confirmed to stay 0 and untouched. Range
// (-0.6 to -0.3) is a user-confirmed comfortable range, not the field's full
// technical bounds -- values outside it may still be valid, just untested.
// ---------- number font color tint ----------
// Same overlay.tint.colorR/colorG/colorB shape and LayerCompTintMode_WithValue
// write as Vendor Decal Tint -- confirmed number fonts carry a tint node too.
// UNLIKE decal tint, there's no per-font catalog of which channels a given
// font actually uses (that would need the same kind of DDS channel analysis
// done for vendor decal encoding, one font at a time). So this reads the
// CURRENTLY-equipped overlay's own tint node structurally -- whichever of
// colorR/colorG/colorB keys are actually present -- the same "check colorB
// !== undefined" approach already used for decals, rather than guessing.
// A channel showing up here means the overlay HAS that field, not that this
// specific font's texture is wired to render it -- worth an in-game check
// per font before trusting more than one channel does something.
// Built from a batch of 258 real JerseyPartItem XML exports (All_unis_TB_.zip),
// each resolved the same way as NUMBER_LAYOUT_PROFILES:
// numberComp ref -> TintArrayTexture -> Overlay_1 -> colorTexture for the font
// path, and that same overlay's own tint.colorR/colorG/colorB refs for which
// channels are actually populated (not null) across real school exports.
// "distinct" is true only when at least one real export set two of that
// font's channels to genuinely DIFFERENT team colors -- the strongest signal
// available short of decoding the DDS texture itself, since a channel that's
// always null, or always mirrors another channel, hasn't been proven to
// render as its own independent color by anything in this dataset.
// sampleSize of 1 means exactly that -- one school's export, not corroborated
// against a second. Keyed by lowercased, /comp/-stripped path to match how
// paths are normalized elsewhere in this file.
const NUMBER_FONT_TINT_CHANNELS = {"content/characters/player/parts/uniforms/jerseys/numbers/afa_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/afa_jersey_2025_alt_num_array":{"channels":["colorR"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/akr_jersey_2025_num_array":{"channels":["colorR"],"sampleSize":1,"distinct":false},"contentshared/characters/player/parts/uniforms/jerseys/numbers/nike_jersey_2025_strokedallleague2_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ark_jersey_2023_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/army_jersey_2021_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/army_jersey_2024_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/army_jersey_2025_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/arst_jersey_2023_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/asu_jersey_2024_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/asu_jersey_2025_num_array":{"channels":["colorR"],"sampleSize":2,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/asu_jersey_2025_02_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/nike_jersey_2025_strokedfullblock3_num_array":{"channels":["colorR","colorG"],"sampleSize":3,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/aub_jersey_2023_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":3,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_2021_ball_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/bay_jersey_2021_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/bc_jersey_2025_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/bgh_jersey_2024_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_2021_miss_num_array":{"channels":["colorR","colorG"],"sampleSize":4,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/bsu_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/nike_jersey_2025_strokedboulder3_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/nike_jersey_2025_strokedfullblock_num_array":{"channels":["colorR","colorG"],"sampleSize":4,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/byu_jersey_2024_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ccar_jersey_2021_02_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/char_jersey_2025_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":2,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/cin_jersey_2025_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/cmu_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":4,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/lsu_jersey_2024_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/colo_jersey_2024_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/conn_jersey_2021_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/csu_jersey_2021_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/del_jersey_2024_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_2021_duke_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ecu_jersey_2023_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":3,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ecu_jersey_2021_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/emu_jersey_2021_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/fau_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/fau_jersey_2025-2_num_array":{"channels":["colorR"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/fau_jersey_2025_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/nike_jersey_2025_strokedmichiganstate3_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_2012_ram2_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_1997_lio_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_2013_dol_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/fiu_jersey_2024_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/fla_jersey_2021_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/fres_jersey_2021_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/fsu_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/gsu_jersey_2023_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/haw_jersey_2021_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/nike_jersey_2025_widefullblock2_num_array":{"channels":["colorR"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/ill_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ind_jersey_2022_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/iowa_jersey_2021_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/isu_jersey_2023_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/isu_jersey_2024_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_2021_umass_num_array":{"channels":["colorR","colorG"],"sampleSize":4,"distinct":false},"contentshared/characters/player/parts/uniforms/jerseys/numbers/nike_jersey_2025_strokedvapor_strike_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/kenn_jersey_2025_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/kent_jersey_2023_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/kent_jersey_2025_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_2021_ksu_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/ku_jersey_2024_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ku_jersey_2023_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/lou_jersey_2024_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/smu_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/lou_jersey_2025_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/lsu_jersey_2023_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/lt_jersey_2023_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":2,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_2023_msu_stroked_num_array":{"channels":["colorR","colorG"],"sampleSize":3,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/miaoh_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/mia_jersey_2024_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/mia_jersey_2025_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/mia_jersey_2025_camo_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_2021_mich_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/minn_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/mist_jersey_2024_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/mizz_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_2021_mrsh_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/mrsh_jersey_2025_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/msst_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/msst_jersey_2025_throwback_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/msst_jersey_2024_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/mtsu_jersey_2023_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_1960_jet_num_array":{"channels":["colorR"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/navy_jersey_2023_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/navy_jersey_2024_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/navy_jersey_2025_num_array":{"channels":["colorR"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/ncst_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ncst_jersey_2025_num_array":{"channels":["colorR"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/ndsu_jersey_2026_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/navy_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/nd_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/nd_jersey_2024_shamrock_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/nd_jersey_2026_shamrock_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_2021_neb_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/neb_jersey_2026_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/nev_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/niu_jersey_2021_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/niu_jersey_2023_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/nw_jersey_2022_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/nw_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/odu_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ohio_jersey_2024_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ohio_jersey_2023_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/orst_jersey_2021_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ou_jersey_2024_02_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/ou_jersey_2022_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ou_jersey_2024_num_array":{"channels":["colorR"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/ou_jersey_2023_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/ore_jersey_2021_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/osu_jersey_2023_02_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ore_jersey_2024_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ore_jersey_2025_shoeduck_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/pitt_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/psu_jersey_2023_num_array":{"channels":["colorR","colorB"],"sampleSize":1,"distinct":false},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_2023_throwback_num_array":{"channels":["colorR","colorB"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/syr_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/pur_jersey_2023_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/tenn_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ark_jersey_2021_num_array":{"channels":["colorR"],"sampleSize":1,"distinct":false},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_2021_stan_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/rice_jersey_2026_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/rutg_jersey_2021_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/sacst_jersey_2026_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/sc_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/utah_jersey_2021_02_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/shsu_jersey_2025_num_array":{"channels":["colorR"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/sjsu_jersey_2023_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/smu_jersey_2022_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/wake_jersey_2022_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":false},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_2021_osu_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/tamu_jersey_2024_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/tamu_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/tcu_jersey_2026_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/tcu_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/tem_jersey_2021_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":2,"distinct":false},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_1960_bro_num_array":{"channels":["colorR"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/tenn_jersey_2026_num_array":{"channels":["colorR"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/tenn_jersey_2025_smokey_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/tex_jersey_2024_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/tlsa_jersey_2021_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/cmu_jersey_2023_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/troy_jersey_2023_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ttu_jersey_2026_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ttu_jersey_2025_num_array":{"channels":["colorR"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/tuln_jersey_2025_city_edition_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/txst_jersey_2023_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/txst_jersey_2024_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/uab_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ucf_jersey_2023_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/ucf_jersey_2025_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ucf_jersey_2025_4_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ucf_jersey_2024_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ucf_jersey_2024_space_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ucla_jersey_2021_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ucla_jersey_2023_alt_num_array":{"channels":["colorR"],"sampleSize":1,"distinct":false},"contentshared/characters/player/parts/uniforms/jerseys/numbers/nike_jersey_2025_strokedwidefullblock_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ull_jersey_2025_blockshadow_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ull_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/ulm_jersey_2016_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/ulm_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_1970_fal_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/umd_jersey_away_2023_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/unc_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/unc_jersey_2022_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/unm_jersey_2025_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/unm_jersey_2021_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/usa_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/usc_jersey_2024_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/usc_jersey_2024_throwback_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/usf_jersey_2023_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":2,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/usm_jersey_2025_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/usu_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/utah_jersey_2022_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/utsa_jersey_2025_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/uva_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/utep_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/van_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/vt_jersey_2023_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/vt_jersey_2024_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/wash_jersey_2024_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/wash_jersey_2023_num_array":{"channels":["colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/wash_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/wash_jersey_2025_camo_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/wis_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/wis_jersey_2025_throwback_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/wis_jersey_2026_shamrock_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/nike_jersey_2025_strokedallleagueshadow_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/wmu_jersey_2024_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/wsu_jersey_2023_num_array":{"channels":["colorR","colorG","colorB"],"sampleSize":1,"distinct":false},"content/characters/player/parts/uniforms/jerseys/numbers/wvu_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":2,"distinct":true},"contentshared/characters/player/parts/uniforms/jerseys/numbers/standard_jersey_1983_bro_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true},"content/characters/player/parts/uniforms/jerseys/numbers/wyo_jersey_2021_num_array":{"channels":["colorR","colorG"],"sampleSize":1,"distinct":true}};

function findNumberFontTintOverlay(part) {
  const overlay = getDeep(part, ['numberComp', 'overlays', 0]);
  return overlay && overlay.tint ? overlay : null;
}

// Looks up confirmed channel data for whatever font is CURRENTLY equipped on
// this overlay -- reads the live colorTexture path straight out of the
// payload (however it got there: catalog pick, pasted JSON, Re-sync) rather
// than tracking "which catalog entry was last picked", so it stays correct
// even if the payload was edited by hand. Falls back to structural detection
// (whichever of colorR/colorG/colorB the overlay's tint node currently has)
// when the font isn't in NUMBER_FONT_TINT_CHANNELS yet -- that fallback is
// a heuristic, not a confirmed per-font fact, and the UI says so.
function getNumberColorChannelInfo(part, overlay) {
  const rawPath = getDeep(part, ['numberComp', 'overlays', 0, 'textures', 'color', 'textureId']);
  const key = typeof rawPath === 'string' ? rawPath.toLowerCase() : null;
  const confirmed = key ? NUMBER_FONT_TINT_CHANNELS[key] : null;
  if (confirmed) {
    return { channels: confirmed.channels, source: 'catalog', sampleSize: confirmed.sampleSize, distinct: confirmed.distinct };
  }
  const structural = overlay?.tint ? ['colorR', 'colorG', 'colorB'].filter(ch => ch in overlay.tint) : [];
  return { channels: structural, source: 'fallback', sampleSize: 0, distinct: false };
}

function renderNumberColorSection() {
  const out = document.getElementById('numberColorOut');
  if (!out) return;
  if (!state.payload || !state.variants.length) { out.innerHTML = ''; return; }

  const group = FIELD_GROUPS.find(g => g.key === 'jerseyNumberFont');
  const part = getPart(group);
  const overlay = findNumberFontTintOverlay(part);

  if (!overlay) {
    out.innerHTML = `
      <div class="fieldblock">
        <div class="head">
          <div class="name">Number Color</div>
          <span class="badge off">no tint node found</span>
        </div>
        <div class="hint">This jersey's number overlay doesn't currently have a tint node to write into -- pick a Jersey Number Font above first, or this template may not support runtime number tinting.</div>
      </div>`;
    return;
  }

  const channelInfo = getNumberColorChannelInfo(part, overlay);
  const channels = channelInfo.channels;
  const teamColors = getTeamColors();
  const defaultFor = { colorR: teamColors.primary, colorG: teamColors.secondary, colorB: teamColors.tertiary };
  const chLabel = { colorR: 'Color R', colorG: 'Color G', colorB: 'Color B' };
  const chToPaletteKey = { colorR: 'R', colorG: 'G', colorB: 'B' };

  const rows = channels.map(ch => {
    const current = overlay.tint[ch];
    const currentHex = (current && typeof current === 'object' && typeof current.r === 'number') ? colorToHex(current) : null;
    const prefill = currentHex || colorToHex(defaultFor[ch]) || '#ffffff';
    const paletteKey = chToPaletteKey[ch];
    const paletteHex = state.customPalette[paletteKey] || (defaultFor[ch] ? colorToHex(defaultFor[ch]) : null);
    return `
      <div class="row" style="align-items:center;gap:8px;">
        <label style="min-width:70px;color:var(--ink-dim);font-size:12.5px;">${chLabel[ch]}</label>
        <input type="color" id="numColor_${ch}" value="${prefill}">
        <input type="text" id="numColorHex_${ch}" value="${prefill}" style="width:90px;font-family:var(--mono);font-size:11.5px;">
        ${paletteHex ? `<button type="button" id="numColorPalette_${ch}" title="Use this custom palette's ${chLabel[ch]} value from Decal Tint (${paletteHex})" style="font-size:10.5px;padding:4px 8px;">🎨 from palette</button>` : ''}
        <span class="current-val" style="margin:0;">currently: ${escapeHtml(describeTintValue(current))}</span>
      </div>`;
  }).join('');

  let badge, hint;
  if (!channels.length) {
    badge = '<span class="badge off">no channels found</span>';
    hint = 'Neither this font\'s confirmed data nor the overlay\'s own tint node show any usable channel.';
  } else if (channelInfo.source === 'catalog') {
    const confidence = channelInfo.sampleSize >= 2
      ? (channelInfo.distinct ? 'ok' : 'warn')
      : 'warn';
    const confidenceNote = channelInfo.sampleSize >= 2
      ? (channelInfo.distinct ? `confirmed across ${channelInfo.sampleSize} teams, channels shown to differ` : `seen across ${channelInfo.sampleSize} teams, channels never differed`)
      : 'seen in only 1 team\'s export -- not corroborated yet';
    badge = `<span class="badge ${confidence}">${channels.length} channel${channels.length === 1 ? '' : 's'} -- ${confidenceNote}</span>`;
    hint = 'Channel count for THIS font comes from real batch-exported XML data (All_unis_TB_.zip), not just whatever happens to be sitting in the current payload. A channel marked as never differing across teams may still be a real independent channel that every school just happened to color the same -- treat single-team or non-differing entries as a lead, not proof, until checked in-game.';
  } else {
    badge = `<span class="badge warn">${channels.length} channel${channels.length === 1 ? '' : 's'} -- unconfirmed for this font, read from current payload</span>`;
    hint = 'This font isn\'t in the confirmed channel catalog yet, so this falls back to reading whatever colorR/colorG/colorB the CURRENTLY-equipped overlay happens to have -- that may be leftover from a previous font/team, not necessarily what this font itself uses.';
  }

  out.innerHTML = `
    <div class="fieldblock">
      <div class="head">
        <div class="name">Number Color</div>
        ${badge}
      </div>
      <div class="hint">${hint}</div>
      ${rows}
      ${channels.length ? `<div class="row" style="margin-top:10px;"><button type="button" id="applyNumberColorBtn" class="primary">Apply number colors</button></div>` : ''}
    </div>`;

  channels.forEach(ch => {
    const colorInput = document.getElementById(`numColor_${ch}`);
    const hexInput = document.getElementById(`numColorHex_${ch}`);
    colorInput.addEventListener('input', () => { hexInput.value = colorInput.value; });
    hexInput.addEventListener('change', () => {
      let v = hexInput.value.trim();
      if (!v.startsWith('#')) v = '#' + v;
      if (/^#[0-9a-fA-F]{6}$/.test(v)) { hexInput.value = v; colorInput.value = v; }
    });
    const paletteBtn = document.getElementById(`numColorPalette_${ch}`);
    if (paletteBtn) {
      paletteBtn.addEventListener('click', () => {
        const paletteKey = chToPaletteKey[ch];
        const paletteHex = state.customPalette[paletteKey] || (defaultFor[ch] ? colorToHex(defaultFor[ch]) : null);
        if (!paletteHex) return;
        colorInput.value = paletteHex;
        hexInput.value = paletteHex;
      });
    }
  });

  const applyBtn = document.getElementById('applyNumberColorBtn');
  if (applyBtn) applyBtn.addEventListener('click', applyNumberFontColors);
}

function applyNumberFontColors() {
  const group = FIELD_GROUPS.find(g => g.key === 'jerseyNumberFont');
  const part = getPart(group);
  const overlay = findNumberFontTintOverlay(part);
  if (!overlay) { log('Apply number colors failed: no tint node on this overlay.', 'err'); return; }

  const channelInfo = getNumberColorChannelInfo(part, overlay);
  const channels = channelInfo.channels;
  const written = [];
  channels.forEach(ch => {
    const hexInput = document.getElementById(`numColorHex_${ch}`);
    if (!hexInput) return;
    const color = hexToColor(hexInput.value);
    if (!color) return;
    setDeep(overlay, ['tint', ch], color);
    written.push(`${ch} = ${hexInput.value}`);
  });
  if (written.length) {
    setDeep(overlay, ['tint', 'TintMode'], 'LayerCompTintMode_WithValue');
  }

  document.getElementById('rawText').value = JSON.stringify(state.payload, null, 2);
  if (written.length) {
    const sourceNote = channelInfo.source === 'catalog'
      ? (channelInfo.distinct ? 'confirmed from batch XML data, channels shown to differ across teams' : `from batch XML data (${channelInfo.sampleSize} team${channelInfo.sampleSize === 1 ? '' : 's'}), channels never seen to differ -- may still be a real independent channel`)
      : 'font not in the confirmed catalog -- channel list is a fallback read of the current payload, unconfirmed';
    log(`Applied number color -- written to numberComp overlay tint: ${written.join(', ')} (${sourceNote}).`, 'ok');
  } else {
    log('Apply number colors: nothing to write.', 'err');
  }
  renderNumberColorSection();
}

const NUMBER_SPACING_PATH = ['numberMaterialSettings', 'offsetScaleSpacing', 'numberSpacing', 'x'];
const NUMBER_SPACING_MIN = -0.6;
const NUMBER_SPACING_MAX = -0.3;

// ---------- number size (chest/back/shoulder/sleeve offset-scale) ----------
// Path structure and ranges confirmed from real XML exports across 257 teams
// in All_unis_TB_.zip -- NOT the same structure the v0.20 changelog claimed
// ("one level up" from offsetScaleSpacing, i.e. a sibling of it). The real
// XML shows chestNumberOffsetScale/backNumberOffsetScale/
// shoulderNumberOffsetScale/sleeveNumberOffsetScale nested INSIDE
// offsetScaleSpacing, as siblings of numberSpacing itself. Each is a Vec4
// (x, y, z, w); across all 257 real teams z is consistently the size/scale
// factor (x is always 0 in every sample seen, y is a vertical position
// offset, w's role is less clear -- chest/shoulder mostly 1, back/sleeve
// vary). Originally this only touched .z -- shipped in v0.64, then a real
// in-game check found it made numbers look "skinny" rather than bigger.
// Checked why against the same 257-team dataset: z and w are INDEPENDENT
// axes, not a single scale value -- they only match each other 58/257 times
// for chest, 68/257 for back. Touching .z alone while leaving whatever .w
// already was stretches one axis and leaves the other fixed, distorting the
// aspect ratio exactly as reported. Fixed in v0.66: the slider is now a
// percentage MULTIPLIER applied to both .z and .w together, scaled off each
// jersey's own starting z/w pair (captured once, like Number Spacing's
// "started at") -- this preserves whatever z:w ratio that font/team shipped
// with instead of assuming a universal one, since the real data shows no
// consistent ratio across teams to derive a formula from.
//
// These are the exact fields that caused real in-game corruption when
// auto-applied from an unconfirmed profile table in v0.25/26 and were pulled
// in v0.27 -- that revert covered ALL of them at once without isolating
// which one was actually the problem. The write itself is still unconfirmed
// beyond "doesn't look skinny anymore" -- worth a proper in-game check.
// Chest and back are used by every jersey; shoulder and sleeve are only used
// by templates with hasShoulder/hasSleeve true (Arizona's own profile
// flagged those two fields as unrendered/untested for that reason).
const NUMBER_SIZE_POSITIONS = [
  { key: 'chest', field: 'chestNumberOffsetScale', label: 'Chest' },
  { key: 'back', field: 'backNumberOffsetScale', label: 'Back' },
  { key: 'shoulder', field: 'shoulderNumberOffsetScale', label: 'Shoulder', note: 'only rendered on templates with hasShoulder true' },
  { key: 'sleeve', field: 'sleeveNumberOffsetScale', label: 'Sleeve', note: 'only rendered on templates with hasSleeve true, use with extra caution' },
];
const NUMBER_SIZE_MULT_MIN = 50;  // percent
const NUMBER_SIZE_MULT_MAX = 150; // percent

function numberSizeFieldPath(field) {
  return ['numberMaterialSettings', 'offsetScaleSpacing', field];
}

// **PARKED as of v0.74 -- code kept intact, UI removed (no #sizeOut
// container, no calls to renderSizeSection() anywhere).** Real in-game
// check: increasing the percentage made numbers SMALLER, the opposite of
// what the slider should do. The v0.66 fix (scaling .z and .w together,
// proportional to each jersey's own starting values) solved the "skinny"
// distortion from v0.64, but didn't solve the actual direction being
// inverted -- something about how the multiplier maps to in-game size is
// still wrong, not yet understood. Rather than ship a fourth attempt at
// this specific field group blind, pulling it from the UI per direct
// instruction. To re-enable: add `<div id="sizeOut">` back to the layout in
// renderEditor() and restore the renderSizeSection() calls removed there
// and in applyField(). NUMBER_SIZE_POSITIONS, numberSizeFieldPath,
// applyNumberSize, and the confirmed real field structure/nesting (see the
// long comment above NUMBER_SIZE_POSITIONS) are all still valid and don't
// need re-deriving -- only the percent-to-z/w mapping direction needs
// figuring out, ideally against a real stock/edited export pair the way
// the Adidas placement bug eventually got solved (v0.68).
function renderSizeSection() {
  const out = document.getElementById('sizeOut');
  if (!out) return;
  if (!state.payload || !state.variants.length) { out.innerHTML = ''; return; }

  const variant = state.variants[state.selectedVariantIdx];
  const jerseyKey = variant?.jerseyKey;
  const part = jerseyKey ? getDeep(state.payload, ['teamData', 'frostbiteData', 'uniformParts', 'jerseys', jerseyKey]) : null;

  const rows = NUMBER_SIZE_POSITIONS.map(pos => {
    const vec = part ? getDeep(part, numberSizeFieldPath(pos.field)) : undefined;
    if (!vec || vec.z === undefined || vec.w === undefined) {
      return `<div class="row" style="margin-top:8px;"><div style="min-width:70px;font-size:12.5px;color:var(--ink-dim);">${pos.label}</div><div class="hint" style="margin:0;">No ${pos.field} field found on this variant's jersey.</div></div>`;
    }
    if (!(jerseyKey in state.sizeOriginals)) state.sizeOriginals[jerseyKey] = {};
    if (!(pos.key in state.sizeOriginals[jerseyKey])) state.sizeOriginals[jerseyKey][pos.key] = { z: vec.z, w: vec.w };
    const original = state.sizeOriginals[jerseyKey][pos.key];
    // Current multiplier relative to the ORIGINAL z (not a running product),
    // so repeated drags stay anchored to one fixed starting point.
    const currentMult = original.z !== 0 ? Math.round((vec.z / original.z) * 100) : 100;

    return `
      <div style="margin-top:10px;padding-top:10px;border-top:1px solid var(--line);">
        <div class="row" style="align-items:center;justify-content:space-between;">
          <div style="font-weight:600;font-size:12.5px;">${pos.label}</div>
          ${pos.note ? `<div class="hint" style="margin:0;">${pos.note}</div>` : ''}
        </div>
        <div class="row" style="align-items:center;">
          <input type="range" data-size-key="${pos.key}" min="${NUMBER_SIZE_MULT_MIN}" max="${NUMBER_SIZE_MULT_MAX}" step="1" value="${currentMult}" style="flex:1;">
          <div data-size-value="${pos.key}" style="font-family:var(--mono); font-size:13px; min-width:44px; text-align:right;">${currentMult}%</div>
        </div>
        <div class="row" style="align-items:center; margin-top:4px;">
          <div class="current-val" style="margin-top:0;"><b>started at:</b> z=${escapeHtml(String(original.z))}, w=${escapeHtml(String(original.w))} -- both scale together, ratio preserved</div>
          <button type="button" data-size-reset="${pos.key}" title="Jump back to 100% (the starting values)">Reset</button>
        </div>
      </div>`;
  }).join('');

  out.innerHTML = `
    <div class="fieldblock">
      <div class="head">
        <div class="name">Number Size</div>
        <span class="badge warn">field structure confirmed, write NOT yet confirmed in-game</span>
      </div>
      <div class="hint">Scales both .z and .w of each position's offset-scale Vec4 together, as a percentage of THIS jersey's own starting values -- keeps whatever aspect ratio it shipped with instead of stretching one axis (v0.64 only touched .z and made numbers look skinny; fixed in v0.66). Leaves x/y untouched. Same field group that caused real in-game corruption when auto-applied from an unconfirmed profile back in v0.25/26 (reverted in v0.27) -- worth a careful in-game check before relying on it.</div>
      ${part ? rows : '<div class="hint">No jersey part found for this variant.</div>'}
    </div>`;

  if (!part) return;

  out.querySelectorAll('[data-size-key]').forEach(slider => {
    const key = slider.getAttribute('data-size-key');
    const valueLabel = out.querySelector(`[data-size-value="${key}"]`);
    slider.addEventListener('input', () => {
      valueLabel.textContent = `${slider.value}%`;
    });
    slider.addEventListener('change', () => {
      applyNumberSize(key, Number(slider.value));
    });
  });
  out.querySelectorAll('[data-size-reset]').forEach(btn => {
    const key = btn.getAttribute('data-size-reset');
    btn.addEventListener('click', () => {
      applyNumberSize(key, 100);
    });
  });
}

function applyNumberSize(posKey, percent) {
  const pos = NUMBER_SIZE_POSITIONS.find(p => p.key === posKey);
  if (!pos) return;
  const variant = state.variants[state.selectedVariantIdx];
  const jerseyKey = variant?.jerseyKey;
  if (!jerseyKey) return;
  const part = getDeep(state.payload, ['teamData', 'frostbiteData', 'uniformParts', 'jerseys', jerseyKey]);
  if (!part) return;
  const original = state.sizeOriginals[jerseyKey]?.[posKey];
  if (!original) return;

  const mult = percent / 100;
  const newZ = original.z * mult;
  const newW = original.w * mult;
  const okZ = setDeep(part, [...numberSizeFieldPath(pos.field), 'z'], newZ);
  const okW = setDeep(part, [...numberSizeFieldPath(pos.field), 'w'], newW);
  if (!okZ || !okW) { log(`Could not set Number Size (${pos.label}) — expected structure missing on this variant.`, 'err'); return; }

  document.getElementById('rawText').value = JSON.stringify(state.payload, null, 2);
  log(`Set Number Size (${pos.label}, ${variant.label}) → ${percent}% (z=${newZ.toFixed(3)}, w=${newW.toFixed(3)}) — NOT YET CONFIRMED IN-GAME, test before trusting.`, 'ok');
  renderSizeSection();
}

function renderSpacingSection() {
  const out = document.getElementById('spacingOut');
  if (!out) return;
  if (!state.payload || !state.variants.length) { out.innerHTML = ''; return; }

  const variant = state.variants[state.selectedVariantIdx];
  const jerseyKey = variant?.jerseyKey;
  const part = jerseyKey ? getDeep(state.payload, ['teamData', 'frostbiteData', 'uniformParts', 'jerseys', jerseyKey]) : null;
  const current = part ? getDeep(part, NUMBER_SPACING_PATH) : undefined;

  if (!part || current === undefined) {
    out.innerHTML = `
      <div class="fieldblock">
        <div class="head"><div class="name">Number Spacing</div>${STATUS_BADGE.warn}</div>
        <div class="hint">No numberSpacing field found on this variant's jersey.</div>
      </div>`;
    return;
  }

  // Capture the starting value the first time this jersey is seen -- never
  // overwritten by later slider drags, so there's always a fixed point to
  // get back to no matter how much experimenting happens in between.
  if (!(jerseyKey in state.spacingOriginals)) {
    state.spacingOriginals[jerseyKey] = current;
  }
  const original = state.spacingOriginals[jerseyKey];

  out.innerHTML = `
    <div class="fieldblock">
      <div class="head">
        <div class="name">Number Spacing</div>
        ${STATUS_BADGE.ok}
      </div>
      <div class="hint">Confirmed range is ${NUMBER_SPACING_MIN} to ${NUMBER_SPACING_MAX} -- values outside that haven't been tested.</div>
      <div class="row" style="align-items:center;">
        <input type="range" id="spacingSlider" min="${NUMBER_SPACING_MIN}" max="${NUMBER_SPACING_MAX}" step="0.01" value="${current}" style="flex:1;">
        <div id="spacingValue" style="font-family:var(--mono); font-size:13px; min-width:56px; text-align:right;">${Number(current).toFixed(2)}</div>
      </div>
      <div class="row" style="align-items:center; margin-top:6px;">
        <div class="current-val" style="margin-top:0;"><b>started at:</b> ${escapeHtml(String(original))} -- fixed, doesn't change as you drag</div>
        <button type="button" id="spacingResetBtn" title="Jump back to the starting value">Reset</button>
      </div>
    </div>`;

  const slider = document.getElementById('spacingSlider');
  const valueLabel = document.getElementById('spacingValue');
  slider.addEventListener('input', () => {
    valueLabel.textContent = Number(slider.value).toFixed(2);
  });
  slider.addEventListener('change', () => {
    applyNumberSpacing(Number(slider.value));
  });

  document.getElementById('spacingResetBtn').addEventListener('click', () => {
    applyNumberSpacing(original);
  });
}

function applyNumberSpacing(value) {
  const variant = state.variants[state.selectedVariantIdx];
  const jerseyKey = variant?.jerseyKey;
  if (!jerseyKey) return;
  const part = getDeep(state.payload, ['teamData', 'frostbiteData', 'uniformParts', 'jerseys', jerseyKey]);
  if (!part) return;

  const ok = setDeep(part, NUMBER_SPACING_PATH, value);
  if (!ok) { log('Could not set Number Spacing — expected structure missing on this variant.', 'err'); return; }

  document.getElementById('rawText').value = JSON.stringify(state.payload, null, 2);
  log(`Set Number Spacing (${variant.label}) → ${value.toFixed(2)}`, 'ok');
  renderSpacingSection();
}

function applyField(group, sub, typed) {
  const part = getPart(group);
  if (!part) return;
  const variant = state.variants[state.selectedVariantIdx];
  const label = group.label + (sub.label ? ' ' + sub.label : '');

  let value = typed;
  const opts = sub.options();
  const match = opts.find(o => (o.label || o.displayName) === typed);
  if (match) value = match.path;
  const resolvedLabel = match ? (match.label || match.displayName) : typed;
  // else: treat typed text as a raw path override (must contain a slash to be sane)

  let allOk = true;
  const skipped = [];
  sub.targets.forEach(t => {
    let v;
    if (t.lookupCatalog) {
      // Pull this target's value from a different catalog, matched by the same
      // resolved label -- e.g. picking a shell also looks up the accessory with
      // the identical label. If nothing matches there, leave this target alone
      // rather than writing something wrong.
      const hit = t.lookupCatalog().find(o => (o.label || o.displayName) === resolvedLabel);
      if (!hit) { skipped.push(t.label); return; }
      v = hit.path;
    } else {
      v = t.transform ? t.transform(value) : value;
    }
    if (!setDeep(part, t.path, v)) allOk = false;
  });
  if (!allOk) {
    log(`Could not fully set ${label} — expected structure missing on this variant for at least one of its ${sub.targets.length} target field(s).`, 'err');
    return;
  }
  if (skipped.length) {
    log(`No matching ${skipped.join(', ')} found for "${resolvedLabel}" — left unchanged.`, 'err');
  }

  // Number Layout Profile: some fonts have confirmed layout data -- flat
  // spacing, per-number kerning, chest/back/shoulder/sleeve offset+scale,
  // and/or numberSpacingOverrides -- that should travel with the font pick
  // instead of being left to whatever the target variant's own leftover
  // values are. Every category is independently optional per profile: a
  // profile can define just spacing + playerNumberAdjust and skip the rest
  // entirely (Arizona currently does, after the offset/scale + overrides
  // fields caused real in-game errors in testing and were pulled out in
  // v0.27). Fonts with no profile at all behave exactly as before this
  // system existed.
  let profileNote = '';
  if (sub.numberLayoutProfiles && match && match.displayName) {
    const profile = sub.numberLayoutProfiles[match.displayName];
    if (profile) {
      let allProfileOk = true;
      const applied = [];

      if (profile.numberSpacing !== undefined) {
        allProfileOk = setDeep(part, NUMBER_SPACING_PATH, profile.numberSpacing) && allProfileOk;
        applied.push(`numberSpacing=${profile.numberSpacing}`);
      }
      NUMBER_OFFSET_SCALE_FIELDS.forEach(f => {
        if (!profile[f]) return; // profile may not define every offset/scale field
        const ok = setDeep(part, ['numberMaterialSettings', 'offsetScaleSpacing', f], JSON.parse(JSON.stringify(profile[f])));
        allProfileOk = ok && allProfileOk;
        applied.push(f);
      });
      if (profile.playerNumberAdjust) {
        const ok = setDeep(
          part,
          ['numberMaterialSettings', 'playerNumberAdjust'],
          JSON.parse(JSON.stringify(profile.playerNumberAdjust)) // deep copy -- never share array/object refs across parts
        );
        allProfileOk = ok && allProfileOk;
        applied.push(`${profile.playerNumberAdjust.length} playerNumberAdjust entries`);
      }
      if (profile.numberSpacingOverrides) {
        const ok = setDeep(
          part,
          ['numberMaterialSettings', 'offsetScaleSpacing', 'numberSpacingOverrides'],
          JSON.parse(JSON.stringify(profile.numberSpacingOverrides))
        );
        allProfileOk = ok && allProfileOk;
        applied.push('numberSpacingOverrides (unconfirmed key)');
      }

      profileNote = allProfileOk
        ? ` + applied its Number Layout profile (${applied.join(', ')} — NOT YET CONFIRMED IN-GAME)`
        : ' [profile found but expected numberMaterialSettings structure missing on this variant -- layout profile NOT fully applied]';
    }
  }

  document.getElementById('rawText').value = JSON.stringify(state.payload, null, 2);
  state.lastSelections[group.key + ':' + sub.key] = typed;
  const writeNote = sub.targets.length > 1 ? ` [written to ${sub.targets.length} fields: ${sub.targets.map(t => t.label).join(', ')}]` : '';
  log(`Set ${label} (${variant.label}) → ${value}${writeNote}${profileNote}`, 'ok');
  renderFields();
  if (group.key === 'jerseyNumberFont') renderNumberColorSection();
  renderSpacingSection();
  // Number Size parked as of v0.74 -- see renderSizeSection. Not called here on purpose.
}


// ---------- push / status / clear ----------
document.getElementById('btnPush').addEventListener('click', async () => {
  if (!state.selectedUrl) { log('No URL selected — fetch a payload first.', 'err'); return; }
  const text = document.getElementById('rawText').value;
  try {
    JSON.parse(text);
  } catch (err) { log('Current text is not valid JSON: ' + err.message, 'err'); return; }
  try {
    const teamName = state.payload?.teamData?.teamInfos?.TEAM_NAME || '';
    const r = await sendToExtension('TB_SET_MOCK', { url: state.selectedUrl, text, teamName });
    log('Pushed mock for ' + (teamName || state.selectedUrl) + '. Reload the Team Builder tab to see it.', 'ok');
  } catch (err) {
    log('Push failed: ' + err.message, 'err');
  }
});

document.getElementById('btnCheck').addEventListener('click', refreshStatus);

document.getElementById('btnClear').addEventListener('click', async () => {
  if (!state.selectedUrl) { log('No URL selected.', 'err'); return; }
  try {
    await sendToExtension('TB_CLEAR_MOCK', { url: state.selectedUrl });
    log('Mock cleared.', 'ok');
    await refreshStatus(); // the connection panel above won't visibly change otherwise
  } catch (err) {
    log('Clear failed: ' + err.message, 'err');
  }
});

document.getElementById('btnReset').addEventListener('click', () => {
  if (!state.originalRawText) { log('Nothing loaded yet to reset to.', 'err'); return; }
  document.getElementById('rawText').value = state.originalRawText;
  loadFromRawText();
  log('Reset to the payload as originally loaded — all edits this session are discarded.', 'ok');
});

document.getElementById('versionTag').textContent = EDITOR_VERSION;
log('Ready (' + EDITOR_VERSION + '). Click "Refresh status" to connect to the helper extension.');
