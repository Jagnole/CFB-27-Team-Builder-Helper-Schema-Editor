# Schema editor changelog

Version number shown in the editor's header and in the activity log on load.
Bump `EDITOR_VERSION` in `editor.js` with each round of changes, and log what
changed here.

## v0.75
- **Fixed a real mistake from v0.73: it conflated "static team-color
  reference" with "editable custom palette" into one section, and in the
  process removed Decal Tint's own color editor entirely.** Per direct
  correction:
  - **Team Colors is now purely static** -- shows this payload's real
    TEAM_BACKGROUNDCOLOR values and nothing else. No inputs, no editing,
    nothing here ever changes based on anything done elsewhere in the tool.
  - **Decal Tint has its interactive color editor back**, inline where it
    was before v0.73 -- pickers, hex inputs, and per-channel "↺ school
    color" buttons live here again. Still edits the ONE shared
    `state.customPalette` (the actually-useful part of v0.73: Apply All
    writes the same colors to every piece, not per-piece memory that could
    drift apart) -- just does it in the place you'd actually go to use it,
    instead of requiring a trip to a separate section for what is
    fundamentally a Decal Tint action.
  - Number Color's "🎨 from palette" button is unchanged -- still pulls
    from the same shared `state.customPalette`, just now that palette is
    edited back in Decal Tint where it's visible in context.

## v0.74
- **Parked Number Size** -- removed from the UI (no `#sizeOut` container, no
  `renderSizeSection()` calls anywhere), code left fully intact, same
  treatment as Conference Logo Tint in v0.49. Real in-game check found the
  direction inverted: increasing the percentage made numbers SMALLER, not
  bigger. v0.66 fixed the "skinny" aspect-ratio distortion from v0.64 by
  scaling .z and .w together, but that didn't fix the underlying
  percent-to-size mapping also being backwards -- not yet understood why.
  Rather than ship a fourth attempt at this field group blind, pulling it
  per direct instruction. `NUMBER_SIZE_POSITIONS`, `numberSizeFieldPath`,
  `applyNumberSize`, `renderSizeSection`, and the confirmed real field
  structure (nested inside `offsetScaleSpacing`, siblings of `numberSpacing`
  -- see that long comment, still accurate) are all still there and don't
  need re-deriving when this gets picked back up. See the comment at the
  top of `renderSizeSection` for exact re-enable steps.

## v0.73
- **Removed the per-piece preview-color system entirely and replaced it with
  one shared custom palette.** This is the real fix behind v0.70/v0.71/v0.72
  -- each of those was a correct patch to the per-piece model, but the model
  itself was the problem. Confirmed directly from a user screenshot: Apply
  All logged "Updated: jersey, pants, socks" (a real, successful write) and
  the colors still looked wrong in the tool, because jersey had been set to
  red while pants/socks were independently still sitting on their own
  separately-remembered green -- each piece silently keeping its own colors
  was the design, not a bug, but it wasn't the design anyone actually wanted.
  - **New: "Team & Custom Colors" section**, its own fieldblock above Decal
    Tint and Number Color. Shows this team's real colors (read from
    TEAM_BACKGROUNDCOLOR) as a reference, plus ONE editable custom palette
    (Primary/Secondary/Tertiary) that both Decal Tint and Number Color pull
    from. Per-channel "↺ school color" buttons live here now -- moved out of
    the inline decal preview per direct request, one place instead of
    scattered per-picker buttons.
  - **Decal Tint's preview box is now read-only** -- shows what the
    currently-picked decal would look like with whichever colors are
    currently active (team colors, or the custom palette if the override
    checkbox is on), colored the same way for every piece. Editing happens
    in the new section above, not inline here anymore.
  - **Apply / Apply All now use the exact same color set for every piece,
    always** -- no more per-piece memory to get out of sync. Turning the
    override on and setting a custom palette, then hitting Apply All,
    writes that same palette to jersey, pants, and socks identically.
  - **Number Color gets a "🎨 from palette" button per channel** -- pulls
    that channel's current custom-palette-or-team-color value in directly,
    so the same custom colors used for decals can be reused for numbers
    without retyping hex codes.
  - `state.decalPreviewOverride` is now just an on/off flag; the old
    per-piece `.values{jersey,pants,socks}` and `.forLabel` tracking are
    gone. `state.tintSelectedPiece` still exists and still controls which
    single piece the "Apply" (not Apply All) button targets.

## v0.72
- **Fixed the actual usability problem behind the last two versions: Apply
  All required manually visiting Pants and Socks in the piece selector
  before it would do anything for them.** Root cause: preview colors were
  only ever seeded lazily, the first time a piece's preview actually
  rendered -- so a piece you never clicked into in the dropdown had no
  saved colors at all, and v0.71 correctly (but unhelpfully) skipped it.
  Now all three pieces -- jersey, pants, socks -- get seeded with real team
  colors immediately when a decal is picked, for every region that decal
  has, before you've touched the piece selector at all. Apply All now has
  real values for all three from the start. You can still switch to any
  piece and pick your own colors to override that starting point -- this
  only changes when the seeding happens, not the "each piece remembered
  independently" behavior from v0.53.
- **New: "↺ school color" button next to each preview color picker.** After
  experimenting with custom preview colors, one click puts that specific
  channel back to this team's real TEAM_BACKGROUNDCOLOR value -- reads live
  off the payload, not a cached snapshot, so it's always the actual current
  school color, not whatever it was when the picker first opened.

## v0.71
- **Fixed a real regression from v0.70: Apply All was silently overwriting
  never-visited pieces with plain team colors instead of skipping them.**
  v0.70 fixed Shiny's hidden `colorG` (a real channel that just never traced
  as its own flat region) by falling back to team color for any missing
  channel -- correct for a piece that was actually visited in the preview
  picker. But that fix couldn't distinguish "visited, one channel
  untraceable" from "never opened this piece in the picker at all" -- both
  looked like an empty/partial saved-colors object. Result: if only Jersey
  was ever customized, Apply All would quietly overwrite Pants and Socks
  with team colors instead of skipping them with the "no preview colors
  saved yet" message it used to show.
  `getEffectiveDecalColorsForPiece` now checks whether a piece has ANY saved
  keys at all first. Zero keys -- never visited -- returns nulls so the
  caller skips it and says so, same as before v0.70. Some keys -- genuinely
  visited -- falls back to team color only for that piece's individual
  untraceable channels, which is the part of v0.70's fix that was actually
  correct and needed to stay.

## v0.70
- **Fixed a real bug: pants stayed grey when using preview-override colors
  with Apply All, even though jersey colored correctly.** Root cause: Adidas
  Shiny's `PREVIEW_SVGS` trace only found 2 distinct flat-colored regions
  (R and B) -- its `colorG` channel is real (confirmed present on a live
  overlay from a real export) but doesn't show up as its own hard-edged
  region, likely because it affects shading/reflectivity rather than a flat
  fill. Since the preview picker only ever renders a swatch per TRACED
  region, it never collected a value for G, so `getEffectiveDecalColorsForPiece`
  returned `secondary: undefined` -- which `writeDecalTintForPiece`'s
  `if (colors.secondary)` guard silently skipped, leaving colorG at
  whatever it was before (often null/stale). Not the same thing as "this
  decal doesn't use that channel."
  `getEffectiveDecalColorsForPiece` now falls back to that piece's real
  team color for any channel the preview override never captured, so every
  channel the live overlay actually has still gets a real value. Added a
  note in the Decal Tint preview UI whenever a trace has fewer than 3
  regions, explaining this fallback so it isn't a silent behavior.
  Only affected the preview-override path -- plain "Apply team colors" (no
  override) was already unaffected, since it reads `getTeamColors()`
  directly regardless of how many regions got traced.

## v0.69
- **Adidas Shiny (2023) pants placement confirmed correct in-game**, with no
  per-material override at all -- just inheriting v0.68's corrected base
  Adidas transform. Real confirmation this time (screenshot, user-checked),
  not a computed estimate. Closes out the v0.45/v0.65/v0.66/v0.67 saga for
  at least this one material. Plastic and Trefoil haven't been re-checked
  yet under the corrected base -- given the same fallback mechanism fixed
  Shiny outright, reasonable to expect them to be much closer too, but that
  hasn't actually been looked at, so not claiming it here.

## v0.68
- **Found and fixed the real root cause behind the whole Adidas pants
  placement saga** (v0.45, v0.65, v0.66, v0.67). User supplied two real
  exports: a genuinely fresh stock team (never touched by this tool) and
  the same team after being pushed through this tool's own v0.66 test. The
  second one turned out to be a red herring -- its transform values were
  byte-identical to the v0.66 Shiny override this tool wrote, i.e. just our
  own bad guess echoed back, not new information. But the STOCK export was
  real: base Adidas Logo (2023) on pants, and its actual native transform
  (`scaleU 0.05, scaleV 0.095, offsetU 0.167, offsetV 0.242, rotate 5,
  layout: null`) does not match what this tool had hardcoded as the
  confirmed-correct Adidas brand default (`scaleU 0.04, scaleV 0.08,
  offsetU 0.16, offsetV 0.265, rotate 7, layout written`). That hardcoded
  value was the reference every Plastic/Shiny/Trefoil calculation in this
  file was built against -- if it was wrong, everything downstream of it
  was guaranteed wrong too, regardless of how carefully the per-material
  math was done. Corrected `BRAND_PIECE_TRANSFORM.Adidas.pants` to the real
  values, including removing the `layout` write entirely -- the real
  overlay has no layout field at all (null, not present), contradicting the
  v0.12-era assumption that Adidas pants need one written. That finding was
  apparently specific to whatever team was tested back then, not a rule
  that holds for a fresh stock team.
  Plastic/Shiny/Trefoil still have no per-material override (reverted in
  v0.67) -- they now fall through to this corrected base value instead of
  the old wrong one, which may get them much closer on its own. Worth
  testing before computing any further per-material compensation. Adidas
  WithText's own override is untouched -- it was confirmed via a direct
  in-game Team Builder render (v0.19), independent of what the brand
  default is, so it doesn't inherit this bug the same way -- but given the
  base reference it was built alongside just turned out wrong, it may be
  worth a fresh look too.

## v0.67
- **Reverted v0.66's computed Adidas Plastic/Shiny/Trefoil pants overrides --
  tested in-game and wrong in both directions (too small, too low) for all
  three.** The fact that all three showed the identical symptom despite each
  having a different computed value rules out a per-material measurement
  mistake -- the calculation method itself was flawed. Re-checked: Adidas
  (2023)'s stripes (the confirmed-correct reference) are tilted at the same
  diagonal angle as Plastic/Shiny's, so content rotation wasn't the
  unaccounted variable -- the `rotate: 7` field on the TRANSFORM itself was.
  The math assumed a simple linear offset+scale with no rotation, but real
  rotation happens around a pivot point this model never accounted for, and
  that pivot interacts with scale/offset in ways a flat estimate can't
  capture. All three reverted to no override -- falls through to the plain
  Adidas brand default as a clean, known baseline instead of compounding
  another unverified guess.
  Real next step, not done yet: either a stock/untouched team's direct JSON
  export with one of these materials already equipped (same source that
  actually confirmed UA and Nike pants placement -- see v0.17/v0.18), or
  manual trial-and-error in Team Builder with a live visual feedback loop,
  since computing placement blind from a screenshot has now failed twice.

## v0.66
- **Fixed a real bug in Number Size (v0.64)**: it made numbers look skinny
  instead of bigger. Root cause: it only touched each position's `.z`
  component, leaving whatever `.w` already was untouched. Checked the same
  257-team dataset used to build it -- `z` and `w` are independent axes, only
  matching each other 58/257 times for chest, 68/257 for back, so dragging
  `.z` alone while `.w` stayed fixed stretched one axis and left the other,
  distorting the aspect ratio exactly as reported.
  Rebuilt as a percentage MULTIPLIER applied to both `.z` and `.w` together,
  scaled off each jersey's own starting z/w pair -- preserves whatever
  aspect ratio that font/team shipped with (real data shows no consistent
  z:w ratio across teams to assume one instead). Reset now returns to 100%
  of the original pair, not a stored absolute value.
- **TEST -- not yet confirmed. Found the real cause of Adidas Plastic/Shiny/
  Trefoil's pants placement bug**, after v0.65's layout-field revert turned
  out not to fix Trefoil either (user confirmed still broken in-game).
  Measured the decoded textures directly: each one's artwork occupies a
  visibly different portion of its own canvas than Adidas (2023)'s
  (confirmed-correct) stripes art -- Plastic/Shiny's content is ~30% bigger
  and sits lower (bounding-box center Y 44.9% of canvas vs. 39.6% for base
  Adidas); Trefoil's is bigger and lower still (53.2%). Since scale/offset
  apply to the whole canvas uniformly rather than a crop of the content, one
  shared brand-level transform can't place them identically when the
  content itself differs -- same underlying gap Adidas WithText already
  needed its own override for, just not previously measured for these
  three. Added computed per-material overrides for all three (scaleU/
  scaleV/offsetU/offsetV), derived from matching each decal's own content
  bounding box to the same mesh-space center Adidas (2023) lands at, scaled
  so the visible logo comes out the same size. These are measurements-based
  estimates, not in-game confirmed -- next step is checking pants in Team
  Builder for all three.

## v0.65
- **Reverted v0.45's Adidas Plastic/Shiny layout-omission test -- it had the
  bug backwards.** User checked in-game: Adidas (2023) pants placement is
  confirmed correct, but Plastic and Shiny are both still wrong with the
  same "low and small" symptom v0.45 was trying to fix. Compared the actual
  numbers: Adidas (2023)'s brand-level pants transform (scaleU 0.04, scaleV
  0.08, offsetU 0.16, offsetV 0.265, rotate 7, `layout` written) is IDENTICAL
  to what Plastic/Shiny's v0.45 override carried, except v0.45 deliberately
  omitted the `layout` write on the theory that a stock Plastic pants overlay
  has no layout slot at all. Confirmed-correct Adidas (2023) writes layout
  with these exact same numbers; Plastic and Shiny, without the layout write,
  are both still broken. That's the opposite of what the test predicted --
  removed the override for both entirely, so they now fall through to the
  plain Adidas brand default (layout write included), matching what's
  actually confirmed working.

## v0.64
- **New: "Number Size" sliders** (Chest, Back, Shoulder, Sleeve) -- writes
  the .z (scale) component of each position's `*NumberOffsetScale` Vec4,
  same mechanism as the existing Number Spacing slider (a range input,
  starting-value capture, per-field Reset button).
  **Corrects a real structural error from v0.20's own changelog**: that
  entry claimed `chestNumberOffsetScale`/`backNumberOffsetScale`/
  `shoulderNumberOffsetScale`/`sleeveNumberOffsetScale` sit "one level up"
  from `offsetScaleSpacing`, as siblings of it. Traced the real XML
  structure across the 258-team batch (`All_unis_TB_.zip`) and confirmed
  they're actually nested INSIDE `offsetScaleSpacing`, as siblings of
  `numberSpacing` itself -- the dormant profile-write code (still present
  from before v0.27's revert, just never triggered since no profile
  populates these fields anymore) had the right path all along; the
  changelog note was wrong.
  Slider ranges are grounded in real data, not guessed: pulled the `.z`
  value for chest/back/shoulder/sleeve out of all 257 successfully-parsed
  team exports in that same batch --
  chest 0.53–1.36 (most common 1.0), back 0.475–1.26 (most common 0.85),
  shoulder 0.7–1.4, sleeve 0–2.0 (noisy, most teams don't use it).
  **Important distinction, flagged directly in the UI**: this confirms the
  field *structure* and *real observed value ranges* across shipped teams --
  it does NOT confirm that manually writing to `.z` through this slider
  renders correctly in-game. This is the same field group that caused real
  corruption when auto-applied from an unconfirmed profile in v0.25/26 and
  was pulled in v0.27 (that revert covered all four fields at once without
  isolating which one actually caused it). Only touches `.z` -- `x`, `y`,
  and `w` are left exactly as found on the payload.

## v0.63
- **Fixed a real bug: Adidas Trefoil (2025)'s path prefix was wrong.** User
  supplied the real in-game paths, which use plain `content/...` --
  `content/characters/player/parts/uniforms/decals/vendors/Adidas_Decal_2025_trefoil_*`
  -- not the `ContentShared/...` prefix guessed in v0.60. That guess had
  assumed it would follow the same pattern as Adidas Plastic (2023), which
  turned out wrong; the real pattern matches Nike ShoeDuck's plain-`content/`
  form instead. Corrected `col`, `norm`, and `rsm` for this entry.
  Worth the reminder this catalog's own `_meta.knownIssues` already carries:
  *"path prefix is source-aware, not a blanket rule... do not force one
  prefix onto all entries."* Same-brand entries sharing a prefix pattern is
  not something to assume without a real confirmed path per entry --
  exactly the mistake this fixes.

## v0.62
- **New Balance Cotton (2025)'s path prefix confirmed.** User supplied the
  real in-game path for `col` and `norm` --
  `ContentShared/characters/player/parts/uniforms/decals/vendors/NB_Decal_2025_Cotton_*`
  -- matching exactly what was already in the catalog from the v0.60 pattern
  guess (same prefix as Nike Cotton). Not a coincidence worth assuming twice,
  but genuinely checked now rather than inferred. Adidas Trefoil (2025)'s
  prefix is still unconfirmed -- no real path supplied for that one yet.

## v0.61
- **CATALOG.decals sorted alphabetically by label.** Adidas Trefoil and New
  Balance Cotton had been stuck at the end from being appended in v0.60 --
  same alphabetize-by-label treatment already applied to the number font
  catalog.
- **New: Vendor Decal gallery**, same Gallery/List modal shell as the Jersey
  Number Font picker, added next to the Vendor Decal input. Refactored the
  font gallery's modal into a shared `openGalleryPicker()` so both pickers
  use one implementation instead of two copies.
  Decal tiles render the actual traced `PREVIEW_SVGS` regions inline (colored
  with this team's real colors when available, falling back to the same
  red/green/blue default swatch colors used elsewhere in the tool) rather
  than a screenshot file -- there's no such thing as an "in-game screenshot"
  of an unequipped decal the way there is for a font, so the trace itself
  is the preview. Entries with no confirmed trace yet (Jumpman Diamond, Nike
  Diamond -- both still blocked on needing an RSM export, see v0.59) show
  the same placeholder tile treatment as an unscreenshotted font.

## v0.60
- **Removed "Under Armour Cotton 02 (2023)" as a real duplicate** -- confirmed
  by direct pixel comparison against "Under Armour Cotton (2023)": not
  byte-identical, but the difference is trivial (~0.02% of total pixel value
  across the whole image, consistent with compression rounding noise, not a
  meaningfully different asset). Removed the catalog entry and its preview
  entirely rather than just hiding it, consistent with how genuine duplicates
  have been handled before (see v0.32).
- **Fixed a real bug in the Nike ShoeDuck (2025) preview**: it only had a
  green channel. Re-inspecting the decoded texture at full resolution found
  a second, smaller red region -- the "nike" script wordmark layered over the
  green swoosh -- that the original pass missed. Re-traced with both R and G
  channels.
- **Added Nike Cotton (2022) preview**, traced from a `.dds` the user
  supplied directly -- this was the one confirmed catalog entry with no
  source file in `TB_Vendor_Logos.rar`. Clean single-channel (R), matches
  the plain Nike swoosh shape.
- **New catalog entries**: Adidas Trefoil (2025) and New Balance Cotton
  (2025). Both use the same `ContentShared/...` ​path-prefix pattern as
  their respective same-brand confirmed entries (Adidas Plastic and Nike
  Cotton) per direct instruction -- **this prefix choice itself is
  unconfirmed** for these two specific entries (no in-game test yet, may
  need correcting later). Adidas Trefoil traced as 2-channel (R+G, clean
  flat mask); New Balance Cotton traced as single-channel (R).
  Preview coverage: 15 of 17 decal catalog entries.
- Investigated the reported "Under Armour Plastic (2023)" preview distortion
  (pinched/self-intersecting pattern at the logo's center crossing) -- traced
  it to the original decoded texture itself showing the identical pattern,
  not a tracing artifact. Per direct instruction, left as-is; not treated as
  a bug.

## v0.59
- **Added 9 new Decal Tint previews**, traced from real DDS textures in
  `TB_Vendor_Logos.rar`: Adidas (2022), Adidas (2023), Adidas Shiny (2023),
  Adidas WithText (2023), Under Armour Cotton (2022), Under Armour Metallic
  (2022), Under Armour Cotton 02 (2023), Under Armour Plastic (2023), Nike
  ShoeDuck (2025). Preview coverage: 13 of 16 decal catalog entries.
  Pipeline: the `.dds` files use a DX10-extended-header BC3/DXT5 encoding
  that Pillow and ImageMagick's built-in DDS readers both silently reject
  (`Unimplemented DXGI format 78`/`image type not supported`) -- manually
  parsed the DX10 header to confirm the format, then decoded with
  `texture2ddecoder` instead. Same dominant-channel classification as the
  helmet stripe masks, traced with potrace, each region verified by
  re-rendering the traced SVG and comparing side-by-side against the
  decoded source texture before adding anything.
  **Resolves the open question on Under Armour Metallic (2022)**: it's
  Cotton-style, not Diamond -- confirmed visually (flat single-channel red
  logo, no shading/gradient baked into `col`, structurally identical to UA
  Cotton) rather than inferred. No RSM-blue-channel analysis needed after
  all.
  **Confirmed still blocked, need RSM not just col**: Jumpman Diamond
  (2022) and Nike Diamond (2022) -- both show real shading/gradient baked
  directly into the `col` texture (matches the "Diamond-style" description:
  mask hidden in RSM's blue channel, `col` alone isn't a clean region
  mask). `TB_Vendor_Logos.rar` only included `_col.dds` files, no `_rsm`,
  for anything -- these two still need an RSM export before they can be
  traced.
  **Still no file at all**: Nike Cotton (2022) -- not present in this
  batch; the archive has `Nike_Decal_2022_Diamond_col.dds` but no
  `Nike_Decal_2022_Cotton_col.dds`.
  **In the batch but NOT in the catalog yet** (need labels/confirmation
  before adding as real entries, not traced): `Adidas_Decal_2025_TPLonTwill`,
  `Adidas_Decal_2025_trefoil`, `Adidas_Decal_2025_Twill`,
  `Adidas_Decal_2025_Twill_wBorder` (clean flat 2-channel, Cotton-style, one
  looked duller/less clean-flat than the rest, worth a second look),
  `Adidas_Decal_2026_Iridescent` (genuine shaded/gradient texture, not a flat
  mask), `Adidas_LOGO_2021` (single-channel wordmark, different naming
  convention than the rest -- "LOGO" not "Decal"), `NB_Decal_2025_Cotton`
  (New Balance -- a brand not previously in the catalog at all),
  `Nike_Decal_2023_Plastic_02` (a second Nike Plastic variant, distinct
  path from the one already catalogued), `UA_Decal_2025_Copper` (mottled/
  textured fill, not flat), `UA_Decal_2025_iridescent` (shaded gradient,
  same issue as the Adidas iridescent one).

## v0.58
- **Number Color now switches per-font off real confirmed data, not a live-payload
  guess.** New `NUMBER_FONT_TINT_CHANNELS` catalog, built from batch-parsing all
  258 real JerseyPartItem XML exports in `All_unis_TB_.zip`: for each font, traced
  `numberComp ref -> TintArrayTexture -> Overlay_1` (same resolution used for
  `NUMBER_LAYOUT_PROFILES`) and read that overlay's own `tint.colorR/colorG/colorB`
  refs directly -- which channels are populated (not null) at all, and whether any
  two channels were ever set to genuinely DIFFERENT team colors across real
  schools (the strongest evidence available short of decoding the DDS texture
  itself that a channel is truly independent, not just present-but-unused or
  mirrored). 193 fonts got at least one confirmed channel this way; Arizona
  State's alt font (`ASU_Jersey_2024_NUM_Array`) came back with all three
  channels populated and confirmed to differ from each other.
  Number Color now reads the CURRENTLY-equipped overlay's own colorTexture path
  out of the live payload and looks it up in this catalog -- fixing the real gap
  from v0.56/v0.57, where the channel list was read from whatever tint values
  happened to already be sitting on the overlay (leftover from a previous
  font/team), not from the newly-picked font itself.
  Fonts not yet in the catalog fall back to that old structural read, now
  explicitly labeled as an unconfirmed heuristic rather than presented the same
  as catalog-confirmed data. UI badge reflects confidence: 2+ teams with a
  confirmed differing pair shows OK; single-team or never-differing shows a
  caution badge with the sample size, so a channel that's real but every sampled
  school happened to color the same isn't mistaken for definitively single-use.
  19 fonts found in this batch (mostly generic `Standard_Jersey_*` templates,
  plus a few real teams -- Kent State 2025, Arkansas 2021, Temple 2021, Tennessee
  Smokey 2025, Texas State 2023/2024, Oklahoma 2022/2024, USC 2024 Throwback,
  Texas A&M 2024) aren't in `CATALOG.numberFonts.jersey` at all yet -- channel
  data for them is sitting unused in the new catalog, ready to attach once those
  entries get added with confirmed labels the normal way.

## v0.57
- **Fixed a real bug**: clicking the "Mask & Stripe Studio" tab did nothing.
  Root cause: the tab-switcher click handlers were in an inline `<script>`
  block at the bottom of `editor.html`, and extension pages default to a
  `script-src 'self'` CSP that silently blocks inline scripts -- confirmed no
  `content_security_policy` override exists in `manifest.json`, so the
  default applies. Same root cause class as the v0.34.1 gallery `onerror`
  bug, just a different inline-script spot this time. Moved the switcher into
  its own external `toptabs.js`, loaded the normal way.

## v0.56
- **Fixed a real bug behind the reported "Cannot access a chrome-extension://
  URL of different extension" push failures.** Root cause was NOT a hardcoded
  extension ID (grepped the whole codebase -- none exist; `manifest.json`
  already has a stable `key`, confirmed the derived extension ID matches what
  a user's own install showed exactly). The actual cause: `findTeamBuilderTabId()`
  resolves a tab id through its own await chain (storage reads, `chrome.tabs.query`),
  and the tab can navigate away in that window -- most likely to widen right
  after a service-worker cold start, which lines up with when this has been
  reported. `enableNetworkMocking()` was then calling `chrome.debugger.attach()`
  on whatever that tab had since become, including another extension's own
  `chrome-extension://` page. Added `isStillLiveTeamBuilderTab()`, a fresh
  `chrome.tabs.get` re-check immediately before attaching, with one retry
  through full resolution if it's gone stale; failing that, a clear error
  message instead of the raw Chrome exception.
- **New: "Mask & Stripe Studio" tab**, a separate top-level tab next to the
  JSON editor -- deliberately NOT wired into the payload read/write pipeline,
  since it never touches teamData at all. Upload a texture, pick a mask
  (Collar, Upper Chest, Collar+Chest combo, or one of the 13 helmet stripe
  pattern variants pulled from `Team_Builder_Helmet_Stripes.psd`), set each
  detected region to a solid color or its own uploaded texture, and download
  a PNG to manually re-upload through Team Builder's own custom texture
  upload. Masking works off each bundled mask PNG's own alpha channel per
  region (classified by dominant R/G/B channel) -- confirmed by inspecting
  the source files directly, same channel-ID convention as the Cotton-style
  vendor decal masks. New files: `mask-studio.js`, `masks/*.png` (16 mask
  images bundled as real files, same pattern as the font preview gallery,
  rather than embedding base64 in JS).
- **New: "Number Color" section** under Jersey Number Font. Confirmed number
  fonts carry the same `overlay.tint.colorR/colorG/colorB` node as vendor
  decals -- this reads whichever of those channels the CURRENTLY-equipped
  overlay actually has (same "check colorB !== undefined" approach already
  used for decal tint) and exposes a color picker per channel found, writing
  back with the same `LayerCompTintMode_WithValue` mechanism as Decal Tint.
  **Not the same as decal tint's confirmation level**: there's no per-font
  catalog of which channels a given font's texture actually renders with
  (that would need the same DDS channel analysis done for vendor decal
  encoding, one font at a time) -- a channel showing up here means the
  overlay HAS that field, not that this specific font is wired to visibly
  use it. Flagged in the Activity log as unconfirmed per-write until that
  analysis exists.

## v0.55
- **Added preview images for the three v0.54 fonts**, cropped from the
  in-game screenshots supplied alongside their XML exports (same center-crop
  + resize to 360x300 as the rest of the gallery). Confirmed the
  team-to-screenshot mapping by color/branding before saving, not by upload
  order (red = Wisconsin, navy/gold dotted = Notre Dame, purple gothic =
  Northwestern) -- this is the same OCR-adjacent lesson as v0.35.1: verify
  the actual image content, don't infer from sequence.
  `previews/ND_Jersey_2026_Shamrock_NUM_Array.jpg`,
  `previews/WIS_Jersey_2026_Shamrock_NUM_Array.jpg`,
  `previews/NW_Jersey_2026_Gothic_NUM_Array.jpg` added.
  Preview coverage: 205 of 205 entries.

## v0.54
- **Added three new jersey number fonts**, sourced from user-supplied
  `JerseyPartItem` XML exports (each carrying `numberMaterialSettings`
  directly on the base item, same shape as the ARIZ_JERSEY_2026_PRABLUE.xml
  source used previously) -- resolved to their font asset name the same way
  as the v0.30 batch (numberComp ref -> TintArrayTexture instance ->
  Overlay_1.textures.colorTexture ref), not guessed from filename:
  - **Notre Dame Shamrock 2026** (`ND_Jersey_2026_Shamrock_NUM_Array`) --
    numberSpacing -0.47, 18 playerNumberAdjust entries (11 at -0.6, rest
    at -0.52). Distinct from the existing "Notre Dame (Current Shamrock
    Alternate)" 2024 entry -- different displayName, kept as its own font.
  - **Wisconsin Shamrock 2026** (`WIS_Jersey_2026_Shamrock_NUM_Array`) --
    numberSpacing -0.49, 18 entries (11 at -0.66, rest at -0.57).
  - **Northwestern Purple Gothic** (`NW_Jersey_2026_Gothic_NUM_Array`) --
    numberSpacing -0.5, 19 entries (11 at -0.73, an unusual extra Number 74
    at -0.65 taken as-is from the source file, rest at -0.6). Distinct from
    the existing "Northwestern (Current Gothic Alternate)" 2022 entry.
  Only `numberSpacing` + `playerNumberAdjust` were added for all three,
  matching the format used by the other 160+ batch-imported profiles --
  not the offset/scale + numberSpacingOverrides fields tried for Arizona in
  v0.25/26, which caused real in-game errors and were reverted in v0.27.
  All three source XMLs also had non-default shoulder/chest/back offset-scale
  values, but those aren't wired up since no currently-shipping profile uses
  that path.
  `CATALOG.numberFonts.jersey`: 202 -> 205.

## v0.53
- **Replaced the Jersey/Pants/Socks checkboxes with a piece selector**, and
  gave each piece its own remembered preview colors instead of one shared
  set. Switching the dropdown loads that piece's own saved preview
  colors -- go from Jersey to Pants and back, and Jersey's colors are
  still exactly where you left them.
  Two buttons now: **Apply** writes only the currently-selected piece;
  **Apply All** writes every piece at once, each using its own saved
  preview colors when the override is on (or team colors for all, same
  value everywhere, when it's off).
  `state.tintPieces` (checkbox on/off state) is gone, replaced by
  `state.tintSelectedPiece` (single active piece) and
  `state.decalPreviewOverride.values` restructured from a flat `{R,G,B}`
  to per-piece `{ jersey: {...}, pants: {...}, socks: {...} }`. The
  "Currently on the decal" readout is unaffected -- it always shows all
  three pieces regardless of which one is selected, since it's a readout
  not an action target.

## v0.52
- **Preview colors can now actually be applied**, closing the gap from
  v0.51 where the interactive preview was purely cosmetic. New "Use these
  preview colors instead of team colors when I click Apply" checkbox under
  the preview pickers.
  When ON: "Apply team colors to decal tint" (button text changes to
  "Apply PREVIEW colors...", header badge changes to "PREVIEW OVERRIDE ON")
  writes whatever hex values are currently in the preview pickers instead
  of reading `TEAM_BACKGROUNDCOLOR*`. When OFF (default): unchanged
  behavior from v0.48-v0.51, always writes real team colors.
  Preview values are per-decal -- switching the picked decal resets the
  override's stored colors rather than carrying over values that belonged
  to a different decal's regions. Off by default every time; has to be
  explicitly re-enabled per session, doesn't persist as an assumed intent.

## v0.51
- **Decal preview is now interactive**, matching the standalone staging
  gallery's color-picker behavior instead of just showing a frozen
  snapshot. Each traced region gets its own color swatch + hex input,
  starting from the current team colors, and updates the preview SVG live
  as you type/pick -- same interaction as the mock this was based on.
  **Deliberately NOT wired to Apply**: this is visual experimentation only.
  "Apply team colors to decal tint" always writes the real
  TEAM_BACKGROUNDCOLOR values regardless of what's been tried in the
  preview -- said explicitly in the block's hint text so it isn't
  mistaken for a color override control.

## v0.50
- **Brought the standalone staging-gallery preview into the tool itself.**
  Decal Tint block now shows a small live-recolored preview of the
  currently-selected vendor decal, using the same traced paths from the
  gallery (potrace, see trace_decal.py) -- Jumpman Cotton, Nike Plastic,
  Adidas Plastic, and Under Armour Cotton have one so far (the only four
  we've traced). Region letters map directly to tint fields (R->colorR,
  G->colorG, B->colorB); a region whose corresponding team color isn't set
  renders as neutral gray rather than guessing. Decals without a trace yet
  show a plain note instead of nothing, so it's clear it's a coverage gap
  and not a bug.
  This is a static reference preview using the picked decal + current team
  colors -- not a live view of the actual current payload's overlay state
  (that's what the "Currently on the decal" readout above it is for).

## v0.49
- **Parked Conference Logo Tint** -- removed from the UI (container div
  and all three render call sites), code left fully intact. Every
  available test path hit a real wall: no export access to a real
  conference-assigned team's JSON, no way to load a real school into Team
  Builder to capture live, and manually faking a conference-logo slot on a
  custom team got reverted on save. The write logic is structurally
  identical to Vendor Decal Tint (which IS confirmed working in-game), so
  there's reason to think it works, but "reason to think" isn't the bar --
  it's unconfirmed, so it's not shipping as if it were proven.
  Re-enabling later: restore the `conferenceTintOut` div and the three
  `renderConferenceTintSection()` calls removed here. No logic changes
  needed if/when a real test path opens up.

## v0.48
- **Added "Currently on the decal" readout to both Decal Tint and Conference
  Logo Tint blocks.** Root cause fixed: the swatches always showed the
  *target* team colors (computed from teamInfos), never what was actually
  in the overlay's tint fields -- so there was no way to see a before/after,
  since the swatches looked identical whether Apply had been clicked or
  not. This new readout re-reads `overlay.tint.colorR/colorG/colorB`
  directly from the payload after every render (including after Apply) and
  shows it as `literal #hex` (matches what Apply writes and what SEC's own
  overlay already used), `ref: <name>` (the team_colors catalog-ref form,
  confirmed on UCLA's Jumpman overlay), or `not set`. This is how to
  actually confirm Conference Logo Tint works in-game: check this readout
  before Apply, click Apply, confirm it changed.

## v0.47
- **Corrected `ASU_Jersey_2024_NUM_Array` numberSpacing: -0.157 -> -0.355.**
  User caught that the source file had an accidental save at the time of
  export; reverted and re-confirmed the real value. -0.355 is consistent
  with sibling Arizona State fonts, resolving the flag raised in v0.46.

## v0.46
- **Added `ASU_Jersey_2024_NUM_Array` ("Arizona State (Current 2nd Alternate)")
  to `NUMBER_LAYOUT_PROFILES`** — was previously missing entirely (no entry
  at all, not just an unconfirmed one). Source: `ASU_JERSEY_2023_YELLOW.xml`,
  user-confirmed as the matching JerseyPartItem.
  Flagged, not corrected: `numberSpacing` (-0.157) is notably smaller in
  magnitude than every sibling Arizona State font (-0.37 to -0.47) and
  outside the -0.6/-0.3 range treated as "comfortable" elsewhere in this
  file. Taken as-is from the source rather than clamped, consistent with
  how every other profile in this table was built -- worth an in-game check
  before treating it as fully confirmed.

## v0.45 -- TEST, not confirmed
- **Adidas Plastic (2023) and Adidas Shiny (2023) pants no longer get a
  `textures.layout` value written at all**, isolated to just those two
  material labels via `MATERIAL_PIECE_OVERRIDES`. Testing the theory that a
  stock/native Adidas Plastic pants overlay (screenshot-confirmed, real
  working in-game team) never has a layout slot at all -- if true, our code
  unconditionally writing one in (previously: brand-level maddenOld path for
  every Adidas pants pick) may have been corrupting structure rather than
  fixing placement, which would explain the reported "low and small"
  symptom better than a wrong-UV-set theory does.
  Rest of Adidas (base, 2022, WithText) UNCHANGED -- still writes layout as
  before. This is a narrow, reversible test on two labels only.
  **If this fixes placement:** worth revisiting whether WithText's layout
  write (confirmed only via Frosty preview, not a stock-JSON comparison
  like this test) should also be reconsidered.
  **If it doesn't fix placement:** revert these two entries, the bug is
  elsewhere.

## v0.44
- **New: "Conference Logo Tint" section**, same mechanism as the Decal Tint
  feature but keyed on `/decals/conferences/` instead of `/decals/vendors/`.
  Deliberately global rather than a per-conference picker -- doesn't matter
  whether SEC, ACC, BIG10, etc. is currently equipped, it just overwrites
  whatever conference logo overlay is already there with this team's colors.
  Main use case: an off-palette custom jersey where the conference patch's
  normal colors would clash. Same Jersey/Pants/Socks checkboxes, same
  tint-node requirement/skip behavior as the vendor decal version (BIG10-
  style mask-in-texture conference logos have no tint node and are skipped).

## v0.43
- **Decal Tint now targets checked pieces only.** Added Jersey/Pants/Socks
  checkboxes to the Decal Tint block (all checked by default, matching the
  prior all-three behavior) -- uncheck a piece to leave its decal tint
  untouched, e.g. tint the jersey to team colors but leave pants on a
  different combo. Unchecked pieces show up in the Activity log as
  "skipped (unchecked)", distinct from pieces skipped because they have no
  tintable decal overlay at all, so it's clear which is which.

## v0.42
- **New: "Apply team colors to decal tint" in the Vendor Decal section.**
  Reads `TEAM_BACKGROUNDCOLORR/G/B` (+ `2`/`3` for secondary/tertiary) off
  `teamData.teamInfos` and writes them as `{r,g,b}` (0-1 float) literals into
  the current vendor decal's `tint.colorR/colorG/colorB` on jersey, pants,
  and socks in one click, setting `TintMode` to
  `LayerCompTintMode_WithValue`. Confirmed via a real UCLA payload that this
  literal-value form is already supported (SEC's own conference-logo overlay
  uses it) as an alternative to the `team_colors` catalog ref form (which
  Jumpman/UCLA used) -- no catalog lookup needed, so this works even for
  custom/imported teams with no `team_colors` entry.
  Only touches overlays that structurally have a `tint` node at all --
  decals that encode their tint mask directly in the `col` texture's RGB
  channels (confirmed for BIG10-style conference logos via pixel analysis:
  a flat 3-region red/green/blue ID mask, no `tint` node, no `rsmTexture`
  slot) are skipped rather than silently no-op'd, and reported in the
  Activity log.
  Swatches next to the button show the read team colors (or "no team colors
  on payload" if `TEAM_BACKGROUNDCOLORR/G/B` aren't present) so it's visible
  before clicking whether there's anything to apply.

## v0.41
- **Found and fixed the root cause of cut-off number fonts**: the crop
  detection only looked for saturated (colorful) pixels, so white/gray
  numbers on dark jerseys (Army, low-saturation alternates, etc.) weren't
  reliably detected, producing overly wide/short crops (up to 2.0 aspect
  ratio) that cut off the number. Fixed by also detecting bright pixels
  regardless of saturation, and enforcing a minimum height:width ratio.
  Re-cropped all 19 affected images (Alabama, App State, Arkansas, Army x2,
  Arkansas State, Arizona State, BYU, FAU x2, FIU x2, Indiana, Iowa State,
  Navy, Northern Illinois, Oregon x2, Texas Tech).
- Zoomed in on all 6 UCF preview images (no longer have access to their
  original source screenshots, so this is a crop of the existing image
  rather than a fresh capture -- two of them are still a bit wide since
  there's a limit to how much can be recovered this way).
- Replaced Virginia Tech (2024) with a new screenshot that actually shows
  the 84 number.

## v0.40
- Confirmed Tulane's City Edition Alternate (already existed in the
  catalog as "Tulane (2025, CITY Edition)" -- relabeled, added an image).
- Added two new high school teams: HS Mustangs (Current Home, its own
  dedicated font -- first team confirmed using it) and HS Rattlers
  (Current Home, shares Tennessee's font).
- Replaced Cincinnati's preview image with a better crop.
- **Removed all remaining entries without a preview image** (38 of them)
  per direct instruction, rather than keeping them at the bottom of the
  list. Every entry in the catalog now has a real screenshot.
- `CATALOG.numberFonts.jersey`: 238 -> 202, alphabetized.

## v0.39
- Added Air Force (2021) preview image.
- **Reframed 189 preview images** (46 from the FB Uniform Editor batches +
  143 from the Frosty Editor batches) to a wider crop that excludes the
  helmet and shows the full team wordmark, number, and more of the torso,
  instead of the tighter/sometimes-cut-off framing from before. The 12
  images from the very first font-gallery session couldn't be re-cropped
  since their original uncropped screenshots are no longer accessible --
  left as-is.
- **Catalog reordered**: entries with a preview image now sort first
  (alphabetical within that group), entries without one sort after
  (also alphabetical), so the gallery view surfaces populated tiles before
  empty placeholders. The Jersey Number Font field's plain-text/datalist
  input pulls from the same array, so it follows this order too.
- Preview coverage: 199 of 238 entries.

## v0.38
- **Data quality pass** on the 22 cross-team-share entries added in v0.37,
  triggered by catching a real bug: Louisiana Tech's "Current Home" font
  was pointing at Virginia Tech's font ("LT" misread as "VT" during OCR).
  Auditing all 22 against their own donor paths found:
  - **15 were unnecessary duplicates** -- the team already had its own
    correctly-pathed entry under a different label (e.g. "North Texas
    (2023, Green)" already existed with the exact font "North Texas
    (Current Home)" was pointing to). Fixed by relabeling the pre-existing
    entry and deleting the redundant new one, in each case.
  - **1 had the wrong path** (New Mexico State -- same "LT" vs "VT" OCR
    confusion as Louisiana Tech). Path corrected, entry kept since it's a
    genuine cross-team share.
  - **6 were genuine** and needed no change (Stanford, UTEP Current
    Throwback, Virginia Current Throwback, Liberty, Louisville Current
    Alternate, North Dakota State Current Away Alternate).
  - Preview images for the 15 relabeled entries were re-cropped under
    their correct final displayName rather than lost.
- **Removed 90 stale/superseded catalog entries**: no profile data, no
  preview image, and the team already has a confirmed "(Current X)" entry
  elsewhere -- almost certainly leftover placeholders from the original
  bulk import that got superseded once the real font was confirmed via
  screenshot.
- **Catalog alphabetized** by label, A-Z.
- `CATALOG.numberFonts.jersey`: 343 -> 238.
- Preview coverage: 198 of 238 entries (up from 183 after accounting for
  the recovery above).

## v0.37
- **Massive confirmation batch**: 130 screenshots (Ohio through Notre Dame,
  roughly two-thirds of the alphabet), all OCR-read directly (Team dropdown,
  Uniform dropdown, and the NUM_Array font reference) rather than inferred
  from file order, after the v0.35.1 timestamp-mapping bug. 108 relabels to
  `Team (Uniform Name)`, plus 22 new team-split entries for cross-team font
  shares (e.g. Michigan State and Jacksonville State each share another
  team's font -- confirmed directly).
- **Bugfix**: the preview-image crop region from earlier batches picked up
  the Data Explorer / Properties side panels instead of the jersey for this
  batch's window layout. Replaced the fixed crop box with per-screenshot
  pixel-based detection (finds the contiguous saturated/bright region in
  the plausible viewport area, since the jersey renders in solid color
  against a near-black background while UI panels are flat gray) --
  auto-detected correctly on all 130 screenshots, spot-verified via OCR
  reading real jersey text ("PURDUE", "TECH") off the output thumbnails.
- `CATALOG.numberFonts.jersey`: 321 -> 343.
- Preview coverage: ~200 of 343 entries now have a real screenshot.

## v0.36
- Confirmed 10 more entries from Frosty Editor screenshots (a different
  tool than FB Uniform Editor, same underlying data): Miami (FL) x3
  (2024 Alternate, Current Camo Alternate, Current Home), Houston, Hawaii,
  Georgia State, Georgia, Florida, Georgia Tech -- all relabeled to
  `Team (Uniform Name)`.
- New cross-team share found: Georgia Southern's "Current Home" uses
  Duke's font (`Standard_Jersey_2021_DUKE_NUM_Array`). Added as its own
  entry so Duke's label is untouched.
- Added 10 new preview images from this batch (skipped one duplicate
  Georgia screenshot that used the same font as another shot). Preview
  coverage: 69 of 321 entries.
- `CATALOG.numberFonts.jersey`: 320 -> 321.

## v0.35.1
- **Bugfix**: every preview image added in v0.35 was mapped to the wrong
  displayName. Root cause: the file-to-team mapping was reconstructed from
  guessed upload/timestamp ordering across two separate screenshot batches,
  and the two batches got swapped relative to each other -- so e.g.
  `ASU_Jersey_2024_NUM_Array.jpg` (labeled "Arizona State, Current 2nd
  Alternate") actually contained Delaware's screenshot.
- Fixed by OCR-reading the actual Team/Uniform dropdown text out of all 49
  source screenshots directly (via tesseract) instead of inferring order,
  then re-cropping all 47 images against that verified mapping. Two of the
  47 crops were spot-verified by re-running OCR on the *output* thumbnail
  and confirming the visible team wordmark matches the filename.
- The 12 images from the original font-gallery session (Cincinnati, VT x2,
  NDSU, AFA, UCF x6, Akron) were untouched by this bug and were restored
  as-is.

## v0.35
- Added 47 new preview images to `previews/`, cropped and compressed from
  the recent screenshot batches (Buffalo through App State, East Carolina
  through BYU, Fresno State through Eastern Michigan). Two entries
  (App State's duplicate confirmation shot, FIU's duplicate Vice-font shot)
  reuse an adjacent image since they're the identical font. Cincinnati was
  skipped since it already had a preview from v0.34.
- Preview coverage: 59 of 320 catalog entries now have a real screenshot
  (up from 12).
- File-to-team mapping was reconstructed from each screenshot's embedded
  capture timestamp rather than upload order, then spot-verified against
  the Team/Uniform dropdown text in a couple of samples before batch
  processing.

## v0.34.1
- **Bugfix**: gallery tiles without a preview image were showing the raw
  broken-image icon instead of the clean placeholder. Cause: the fallback
  used an inline `onerror="..."` attribute, which extension pages' default
  Content-Security-Policy (`script-src 'self'`) silently blocks as inline
  script. Switched to `addEventListener('error', ...)` after the modal
  renders, which isn't affected by that CSP rule.
- Note: only 12 of 320 catalog entries currently have a real preview image
  (Cincinnati, Virginia Tech x2, North Dakota State, Air Force, UCF x6,
  Akron) -- every other entry, including the various Florida schools, is
  expected to show the placeholder until a screenshot gets cropped for it.

## v0.34
- **New: Jersey Number Font gallery picker.** A "Gallery" button next to the
  Jersey Number Font field opens a modal with Gallery/List toggle, search,
  and image tiles. Preview images live in `previews/{displayName}.jpg` and
  are added incrementally as real in-game screenshots get confirmed; entries
  without a file yet show a placeholder tile rather than erroring.
- Bundled 12 real preview images (Cincinnati, Virginia Tech x2, North Dakota
  State, Air Force, UCF x6, Akron) as actual JPGs in `previews/`.
- Relabeled 51 catalog entries from generic year-based labels to precise
  `Team (Uniform Name)` labels matching the actual in-game Team/Uniform
  dropdowns, confirmed via screenshots batch-by-batch.
- Added 6 new team-split entries for previously-undiscovered cross-team font
  shares: Alabama (shares BYU's font), Oregon "Home Gang Green" (shares Ohio
  State's), Clemson (shares Central Michigan's), California (shares
  Arkansas's), and Florida International "Current Home" (shares Eastern
  Michigan's).
- `CATALOG.numberFonts.jersey`: 315 -> 320.

## v0.33
- Removed `VT_Jersey_2020_NUM_Array`, `VT_Jersey_2021_NUM_Array`, and
  `VT_Jersey_2022_NUM_Array` from `CATALOG.numberFonts.jersey`, per direct
  instruction while confirming Virginia Tech reference screenshots. None had
  profile data yet, so nothing lost.
- `CATALOG.numberFonts.jersey`: 321 -> 318.

## v0.32
- **Catalog alphabetized**: `CATALOG.numberFonts.jersey` is now sorted by
  `label`, ascending.
- **Removed 5 helmet fonts miscategorized as jersey number fonts**:
  `ALA_Helmet_2021_NUM_Array`, `FAU_Helmet_2025_NUM_Array`,
  `GASO_Helmet_2025_NUM_Array`, `MINN_Helmet_2024_NUM_Array`,
  `NMSU_Helmet_2021_NUM_Array` -- these were pre-existing catalog entries
  from before this session, not something the recent batch import added.
  None had profile data, so nothing else needed cleanup.
- **Found and fixed 3 pure same-team duplicate entries that v0.31's per-file**
  **split created without recognizing they were the same team twice**:
  Kansas State (Purple/White), Arizona State (Black/Yellow), BYU
  (Black/Blue) -- each pair shared the identical font `path`, same team, same
  year, only the color differed. Merged each pair to one entry, relabeled to
  drop the now-meaningless color suffix (e.g. "Kansas State (2023, Purple)"
  -> "Kansas State (2023)").
- **Found 4 more duplicates that were actually the missing data for existing**
  **flagged entries**: `ECU_JERSEY_2023_BLACK`/`ECU_JERSEY_2023_PURPLEALT`,
  `MTSU_JERSEY_2023_BLUE`, `TROY_JERSEY_2023_RED`, and `KU_JERSEY_2023_BLUE`
  were each that exact team's own file -- same font path, same team, same
  year as an already-cataloged entry that had no profile yet. Merged into
  the original entry instead of kept as a separate one. This resolves 4 of
  the 7 "shared font, no confirmed value of its own" entries flagged in
  v0.31.
- `CATALOG.numberFonts.jersey`: 334 -> 321 (-5 helmets, -8 merged duplicates).
  `NUMBER_LAYOUT_PROFILES`: 220 -> 216 (-8 duplicates, +4 filled-in
  previously-empty entries).
- `LSU_Jersey_2024_NUM_Array` and `EMU_Jersey_2021_NUM_Array` are now
  "partially resolved" rather than fully unconfirmed -- the same team's data
  exists in the catalog under a different year (LSU 2023, EMU 2025) as its
  own separate entry, but the specifically-cataloged year still has nothing.
  Flagged with that nuance in `BATCH_IMPORT_FLAGS.md` rather than silently
  merged across years.
- `FONT_PROFILES_CHECKLIST.md` and `BATCH_IMPORT_FLAGS.md` both rewritten
  against the cleaned state: 216 ✅, 3 🟡 (down from 7), 102 ⬜.

## v0.31
- **Teams that share a font now get their own catalog entry instead of one**
  **shared entry.** 14 fonts from the v0.30 batch had multiple teams'
  exported values disagreeing for what was nominally "the same font" -- this
  version treats that as real per-team tuning rather than a conflict to
  arbitrate. Each team's own file, confirmed via its own `numberComp` texture
  ref, got a new catalog entry (same `path` as the original shared font, so
  the rendered glyphs are identical -- only `numberSpacing`/
  `playerNumberAdjust` differ) instead of forcing one team's numbers onto
  everyone who happens to use that font.
- `CATALOG.numberFonts.jersey`: 276 -> 334 (+58). `NUMBER_LAYOUT_PROFILES`:
  162 -> 220 (+58).
- Labels for the new entries are auto-generated ("Team (Year, Color)"),
  using existing catalog naming precedent where a team already had another
  entry, plain well-known team names otherwise. Not hand-verified one by
  one -- worth a skim in the font picker for anything that reads awkwardly.
- 8 files still held back (unclear team prefix: `EA`, five `FCS*` codes that
  look like generic conference-filler teams, and `MUSHS`) and 7 originally-
  shared fonts still have no confirmed value of their own (the team that
  namesakes the font wasn't itself in this batch, only other teams borrowing
  it). `BATCH_IMPORT_FLAGS.md` rewritten to reflect only what's still
  actually outstanding.
- `FONT_PROFILES_CHECKLIST.md` regenerated against the new 334-entry
  catalog: 220 ✅, 7 🟡, 107 ⬜.

## v0.30
- **Batch import from `All_uniforms_TB.zip`** (253 JerseyPartItem files):
  added 161 new `NUMBER_LAYOUT_PROFILES` entries in one pass. `NUMBER_LAYOUT_PROFILES`
  now covers 162 of 276 catalog fonts.
- Matching was NOT done by filename -- each file's `numberComp` field was
  resolved (ref -> `TintArrayTexture` instance -> `Overlay_1.textures.
  colorTexture` ref) to the actual font asset name it uses, then matched
  against `CATALOG.numberFonts.jersey` by `displayName`. This matters because
  filename/team-year guessing would have been wrong in both directions: some
  teams use two different fonts across their own jerseys (e.g. ASU), and
  several teams share one generic font (various `Nike_Jersey_2025_Stroked*`
  and `Standard_Jersey_*` templates).
- `numberSpacing` taken directly from each file, per the corrected default
  (Arizona was the exception, not the rule). `playerNumberAdjust` taken
  directly as well.
- Only fonts where every file referencing them agreed on both values went in
  automatically. **37 did not make the cut** -- documented in the new
  `BATCH_IMPORT_FLAGS.md`, not added to `editor.js`:
  - 23 resolved to a real font name not present in the catalog at all (mostly
    generic Nike/Standard templates -- likely just uncatalogued, not wrong).
  - 14 where multiple files sharing the exact same font disagreed on the
    values (small drift in some cases, real disagreement in others) --
    picking one arbitrarily risks repeating the Arizona situation.
  - 2 files that couldn't be processed the normal way at all (one had an
    empty `PlayerNumberAdjList` like Arizona's original wrong-file-type case,
    one didn't resolve to a font reference the way every other file did).
- `FONT_PROFILES_CHECKLIST.md` updated to match: 162 ✅, 7 🟡 (catalog-matched
  but conflicting, see `BATCH_IMPORT_FLAGS.md` part B), 107 ⬜ still needed.

## v0.29
- Corrected the default assumption in `FONT_PROFILES_CHECKLIST.md`: the
  file's `numberspacing.x` value is reliable for most teams. Arizona was the
  exception (file said -0.41, real value -0.48), not the norm -- default to
  what the JerseyPartItem file says for `numberSpacing` going forward, and
  only override it when a specific value is given for that team.
  `playerNumberAdjust` guidance is unchanged (still needs the JerseyPartItem
  file specifically, empty array = wrong file type, not "no overrides").
- No code changes in `editor.js` beyond the version bump.

## v0.28
- Added `FONT_PROFILES_CHECKLIST.md`: a full table of all 276 entries in
  `CATALOG.numberFonts.jersey`, tracking which ones have a confirmed
  `NUMBER_LAYOUT_PROFILES` entry and where the two independent pieces
  (`playerNumberAdjust` from a JerseyPartItem export, `numberSpacing` from
  in-game/Frosty rather than the file) came from. Update this file alongside
  every profile added -- it's the source of truth for progress, since
  session memory doesn't carry code state across chats.
- Arizona (2026) marked ✅ Done in the checklist, reflecting the v0.27 state.
- No code/behavior changes in `editor.js` beyond the version bump.

## v0.27
- **Reverted**, after real in-game errors: pulled `chestNumberOffsetScale`,
  `backNumberOffsetScale`, `shoulderNumberOffsetScale`,
  `sleeveNumberOffsetScale`, and `numberSpacingOverrides` entirely out of
  Arizona (2026)'s profile -- not zeroed, removed. One or more of these (most
  likely the unconfirmed-key `numberSpacingOverrides` from v0.26, but not
  isolated) is the suspected cause.
- `numberSpacing` is now `-0.48`, set directly from in-game observation --
  overriding both the v0.24 (`-0.36`) and v0.25/26 (`-0.41`) reference-file
  values. `playerNumberAdjust` is unchanged from v0.25/26 (11 at `-0.67`, 31
  at `-0.58`, everything else at `-0.53`) since that part was never
  implicated.
- Reworked how `applyField` builds and logs a profile application: each
  category (spacing, each offset/scale field, playerNumberAdjust,
  numberSpacingOverrides) is now fully independent and only mentioned in the
  log if the profile actually defines it, rather than a field count that
  didn't distinguish which categories were present. No behavior change for
  existing fully-populated profiles -- this only affects the log text and
  makes partial profiles (like Arizona's now) report accurately.
- **If a team already had v0.25 or v0.26 applied to it**, this version does
  NOT clean that up -- it only stops writing those fields going forward. A
  team that already has the bad data needs the font re-picked fresh (or the
  uniform reset some other way) to actually clear it.

## v0.26
- Added `numberSpacingOverrides` to the Number Layout profile: the XML's
  `number_spacing_overrides` block (per-position `chestNumberSpacing`/
  `backNumberSpacing`/`shoulderNumberSpacing`/`sleeveNumberSpacing` Vec4s,
  plus their four `override*` booleans) is now written wholesale to
  `numberMaterialSettings.offsetScaleSpacing.numberSpacingOverrides`
  alongside the rest of the profile.
- **Unlike every other field in this profile, the key name itself is
  unconfirmed.** The camelCase pattern (`numberSpacingOverrides`) matches
  what's held for every field we've actually verified against a live
  capture, but this specific sub-object never showed up in the Nike capture
  we checked -- not even zero-valued, the key was flat-out absent. It's
  possible this is authoring-only data that never reaches the live JSON at
  all. All values are 0/false for Arizona regardless, so right now this is a
  no-op bet either way -- `setDeep` will happily create the key even if the
  real one is named differently or doesn't exist, so a successful write does
  NOT confirm the guess is right. Only a font with real (non-zero/true)
  override data, applied and checked in-game, will actually test this.

## v0.25
- Found a better reference for Arizona's numbers: `ARIZ_JERSEY_2026_PRABLUE.xml`,
  a `JerseyPartItem` matching the "Arizona (2026)" catalog entry by name.
  Unlike v0.24's source, it carries `numberMaterialSettings.PlayerNumberAdjList`
  directly on the base item, at the same nesting level the live JSON actually
  uses (sibling to `offsetScaleSpacing`) -- no Mix & Match indirection needed.
  Treating this as the authoritative source now.
- **Corrected values, replacing v0.24's**: `numberSpacing` -0.36 -> -0.41,
  Number 11 -0.59 -> -0.67. Also surfaced a **second real outlier** the old
  (empty) source couldn't show at all -- Number 31 at -0.58, distinct from
  every other non-11 entry, which all sit at -0.53.
- **Expanded scope from spacing-only to full Number Layout**: profiles now
  also carry `chestNumberOffsetScale`, `backNumberOffsetScale`,
  `shoulderNumberOffsetScale`, and `sleeveNumberOffsetScale` -- each written
  as a full object replace, same reasoning as `playerNumberAdjust` (a stale
  leftover component from the previous font is worse than a clean swap).
  This is the fix for numbers sitting too high/low or too big/small after a
  font swap -- those values were calibrated for whatever font was there
  before, not the new one.
- Renamed `NUMBER_SPACING_PROFILES` -> `NUMBER_LAYOUT_PROFILES` (and the
  subfield hook `numberSpacingProfiles` -> `numberLayoutProfiles`) to match
  the wider scope. No behavior change for fonts without a profile entry.
- **Caveat carried over into this version**: the reference file has
  `hasShoulder: false` and `hasSleeve: false` -- Arizona's own jersey doesn't
  use those number positions. Their offset/scale values are structurally
  present but were never actually rendered or eyeballed for this font, unlike
  chest/back which Arizona's jersey does use. Specifically worth testing this
  font on a team whose jersey DOES have shoulder or sleeve numbers before
  trusting those two fields.
- Still **NOT confirmed in-game** even in this corrected form -- same test
  plan as v0.24, just checking more fields now.

## v0.24
- Added a **Number Spacing Profile** system: picking a Jersey Number Font can
  now also write a font-specific `numberMaterialSettings.playerNumberAdjust`
  table (per-number kerning, not just the flat `numberSpacing.x` the slider
  already covers) in the same action, when a profile exists for that font.
  Fonts with no profile behave exactly as before -- purely additive.
- **First (and only) profile: Arizona (2026)** (`ARIZ_Jersey_2026_NUM_Array`).
  Values sourced from `ARIZ_JERSEY_2023_BLUE.xml` (the base
  `CharacterUniformJerseyItem` -- `EnableNumberSpacingOverrides` was `true`
  but its own `NumberWidthAdjustmentList` was empty, so NOT the source) and
  `ARIZ_MixAndMatch.xml` (the Mix & Match `FootballMixMatchPart` entry for
  that same jersey, where `DefaultNumberSpacing` and `PlayerNumberAdjList`
  were the ones actually populated): `numberSpacing.x = -0.36`, plus 18
  `playerNumberAdjust` entries -- 10-19 and 21/31/41/51/61/71/81/91 (every
  number containing a "1", the narrow-glyph digit) each at `-0.4`, except
  Number 11 (both digits narrow) at `-0.59`.
- That the live payload even has this field, and its exact shape, is
  confirmed by a real in-game capture from a different team (Nike): same 18
  numbers, same "11 is the outlier" pattern, different tuned widths. What's
  **NOT yet confirmed** is that Arizona's specific values above actually move
  anything in Team Builder -- test before trusting, same as every other field
  in this tool.
- `NUMBER_SPACING_PROFILES` is a flat lookup keyed by font `displayName`, so
  adding the next font once its reference data is confirmed is one more
  entry, not a code change.

## v0.23
- **Fixed a real bug**: some teams were missing uniform variants from the
  dropdown entirely. The variant-name regex only allowed letters and digits
  (`[A-Za-z0-9]+`), but real variant names contain parentheses --
  `DarkMode(Home)`, `1920s(Reimagined)` -- which silently failed to match
  and dropped the whole variant. Confirmed against two real teams: UCLA
  lost 5 of its 9 variants this way, JT lost 2 of its 14 (less obvious,
  since 12 still worked). Now matches any characters in the variant name,
  tested against both teams (14/14 and 9/9 now show correctly) plus a
  synthetic case with a hyphen inside the variant name itself.

## v0.22
- Added a **Reset** button to the Number Spacing slider. The starting value
  is captured once, the first time each jersey is seen, and stays fixed no
  matter how much dragging happens afterward -- shown as "started at: X"
  next to the slider. Reset jumps straight back to it in one click, so
  experimenting freely doesn't risk losing track of where you began.

## v0.21
- **Fixed a real bug in v0.20's Number Spacing slider**: the stored path had
  an extra `numberComp.` prefix that shouldn't have been there.
  `numberMaterialSettings` is a *sibling* of `numberComp`, not nested inside
  it — confirmed by re-checking the original tree screenshot carefully.
  v0.20 would have shown "No numberSpacing field found" instead of a
  working slider on every real payload. Found while building an accurate
  demo, not from an in-game report — worth noting since it means this was
  silently broken from the moment it shipped.

## v0.20
- Added a **Number Spacing** slider — first non-picker control in the tool.
  Writes directly to
  `numberComp.numberMaterialSettings.offsetScaleSpacing.numberSpacing.x`,
  shown live as you drag. Range is `-0.6` to `-0.3`, a user-confirmed
  comfortable range rather than the field's full technical bounds — values
  outside it may still be valid, just untested. `y`/`z`/`w` on the same
  object are left untouched, as are the sibling `chestNumberOffsetScale` /
  `backNumberOffsetScale` / `shoulderNumberOffsetScale` /
  `sleeveNumberOffsetScale` fields that live one level up.

## v0.19
- Added a material-specific placement override layer, sitting on top of the
  brand-level defaults. First confirmed use: **Adidas WithText** needed its
  own pants placement (`scale 0.056/0.112`, `offset 0.16/0.33`) — genuinely
  different from base Adidas (`0.04/0.08`, `0.16/0.265`), confirmed via
  actual Team Builder renders, not just a raw-JSON comparison. Every other
  Adidas material (Cotton, Plastic, Shiny, base) is unaffected and still
  uses the shared brand baseline. For contrast: Jumpman Cotton vs. Diamond
  were confirmed earlier to need no override at all — same placement either
  way — so this layer only activates where a material's actually been
  checked and found to differ, not by default.

## v0.18
- **UA pants now has confirmed placement** — the last brand/piece gap. Source
  is a fresh, provably untouched team's direct JSON export, not Frosty.
  Notably, Frosty's Georgia Tech reading disagreed with this direct JSON
  pull in a real way (opposite-sign offset, near-mirrored rotation), not
  just rounding — going with the direct JSON value as the more trustworthy
  source of the two, consistent with how Nike/Jumpman/Adidas were already
  confirmed (all via raw JSON, not Frosty alone). `layout: null` confirmed
  and actively enforced, same tier as Nike now.
- All four brands (Nike, Jumpman, Under Armour, Adidas) now have full
  confirmed pants placement + layout enforcement. UA's jersey still shows
  a minor, unconfirmed discrepancy against this same fresh export
  (`offset (0.068, -0.12)` vs. the currently stored `(0, -0.1325)`) — left
  unchanged since jersey has never been reported as an issue, but worth
  knowing if UA jersey placement ever comes into question.

## v0.17
- **Nike pants placement is back, now confirmed by a second school** (this
  exact team, via Frosty Editor) — essentially identical to FSU's numbers.
  The earlier "Nike is broken" report that led to removing it in v0.15 was
  almost certainly the same layout-contamination issue diagnosed for Nike
  Plastic, not bad reference data.
- **Real fix this time, not just detection**: confirmed that Nike's native
  pants `layout` is genuinely `null` (no fourth UV-set slot in Frosty,
  unlike Jumpman/Adidas). Any brand with a known layout policy — a specific
  UV path, or explicit null — now enforces it unconditionally on swap,
  overwriting whatever was there. So swapping to Nike now actively resets
  `layout` back to `null` even if a prior Jumpman/Adidas test left a
  different UV set behind, instead of silently inheriting it. UA still has
  no confirmed policy either way, so it still only gets flagged (v0.16),
  not corrected, until real data exists for it too.

## v0.16
- Added contamination detection for brands with no confirmed placement of
  their own (Nike, UA): if the overlay already carries another *known*
  brand's exact layout signature (Jumpman's or Adidas's), the activity log
  now says so explicitly instead of silently leaving it — e.g. a Nike swap
  landing on an overlay that still has Jumpman's `Pants_UVSet_front` gets
  flagged as likely leftover from testing Jumpman, not this team's native
  state. Doesn't fix the numbers (no confirmed correct value to fall back
  to yet) — just makes the cause visible instead of requiring another round
  of screenshots to diagnose.
- Confirmed limitation surfaced by this: **Reset to loaded** only protects
  against edits made within the current session. If a team's live data was
  already permanently modified by an earlier push (e.g. Jumpman tested and
  pushed in a prior session), a fresh fetch pulls that same modified state
  back — there's no clean baseline left to reset to. Getting Nike/UA their
  own confirmed pants placement (the same Frosty Editor approach used for
  Jumpman and Adidas) is the actual fix; this version just makes the
  symptom diagnosable in the meantime.

## v0.15
- Removed pants placement auto-apply for Nike, Adidas, and UA — their pants
  were already rendering correctly untouched, and auto-applying reference
  numbers on top of an already-fine result was actively breaking it (Nike's
  pants going wrong after a Nike swap, reported directly). Pants now gets a
  texture-only swap for those three brands — no scale/offset/rotate/layout
  writes at all, leaving whatever was already there alone. Jumpman keeps
  its full confirmed placement + layout fix, since that's the one brand
  that was actually broken and needed it.

## v0.14
- QOL fix across all three pickers (Jersey Number Font, Helmet Shell, Vendor
  Decal): clicking into a field that already has a selection now
  auto-selects all the text, so typing immediately overwrites it instead of
  needing a manual select-all-and-delete first. Also added an explicit
  **Clear** button next to each picker for a guaranteed one-click reset,
  regardless of browser-specific datalist filtering quirks.

## v0.13
- **Corrected a wrong assumption from v0.12, before it caused a new bug**:
  `layout` isn't a universal mesh constant shared by every brand — it's
  brand-specific, same as the texture itself. Confirmed Adidas uses
  `Pants_UVSet_maddenOld`, genuinely different from Jumpman's
  `Pants_UVSet_front`. v0.12 would have written Jumpman's value onto an
  Adidas swap, introducing a new wrong-layout bug in the name of fixing
  the old one. Layout is now stored per-brand, alongside scale/offset/
  rotate, and only applied when that specific brand has a confirmed value
  — Nike and UA don't yet, so their pants layout is left untouched rather
  than guessed.

## v0.12
- **Found and fixed the real root cause of the pants-specific placement
  bug**, confirmed by an actual in-game test: `textures.layout` was `null`
  on the affected pants overlay, while Florida's own correctly-rendering
  pants overlay has it set to
  `ContentShared/.../uvsets/Pants_UVSet_front`. Scale, offset, and
  `scaledTransform` were all correct the entire time — this missing UV
  reference was the actual gap. Placement auto-apply now sets `layout` on
  pants whenever it's missing, without touching it if something's already
  there.
- Ruled out along the way, for the record: wrong catalog values (numbers
  matched Florida/Oklahoma/Frosty Editor exactly, three independent
  sources), a lookup bug (brand key matching verified correct in code),
  material differences (Cotton and Diamond share the same issue and same
  fix), and a mesh-wide coordinate mismatch (Adidas rendered correctly on
  the same team/template throughout).
- Corrected Jumpman's pants rotation from `5.5` (an average of two school
  exports) to `5.0`, now directly confirmed via Frosty Editor as the
  authoritative source rather than an estimate.

## v0.11
- Audited every stored placement value directly against all school examples
  gathered so far. Everything matched exactly except Jumpman's pants
  rotation — stored as Oklahoma's `6`, but Florida (the actual visual
  reference used throughout this feature) came in at `5`. Averaged to `5.5`
  rather than silently favor one school over the other. Scale and offset
  were already identical between both schools, unaffected.

## v0.10
- **Likely the real fix for the oversized-logo issue that's come up
  repeatedly**: every overlay carries a `transform.scaledTransform` field
  (`{x, y, z, w}`) that's a separate cached copy of scale/offset
  (`x=scale.u, y=scale.v, z=offset.u, w=offset.v`). Confirmed from a real
  payload that it does **not** recompute itself — `scale`/`offset` were
  being set correctly the whole time, but `scaledTransform` stayed frozen
  at the original brand's values. If the in-game renderer reads
  `scaledTransform` instead of recalculating from `scale`/`offset`, that
  would explain exactly what was reported: the texture pattern changes
  (visibly the right brand/material), but the size and position don't,
  because the field that likely actually controls rendering never updated.
  Placement auto-apply now keeps both in sync.

## v0.09
- **Fixed a real bug**: the decal search only ever found and updated the
  *first* matching overlay per piece. Confirmed from real recipe data that
  Nike's socks template carries two separate decal overlays (mirrored left/
  right) while Adidas/Jumpman/UA only carry one — on a Nike-style template,
  swapping brands would silently leave the second overlay on the old
  texture. Now updates every matching overlay found on a piece, not just
  the first.
- Extended placement defaults to **pants and socks**, not just jersey, now
  that real data exists for both — sourced from confirmed recipes across
  Nike, Jumpman, UA, and (new) Adidas. Placement only auto-applies when a
  piece has exactly one decal overlay; a multi-overlay piece (Nike socks)
  gets its texture updated everywhere but placement left alone, since
  there's no confirmed per-side value to apply safely.
- Confirmed Jumpman's jersey scale (`0.03`) is consistent across two
  different schools (Florida, Oklahoma) — not the source of any reported
  oversized-logo issue.

## v0.08
- Removed the manual scale/offset/rotate controls from v0.06 entirely. With
  the per-brand jersey default from v0.07 handling the common cases
  automatically, and no way to preview the effect of a manual tweak anyway,
  they were more clutter than value. Vendor Decal is back to just the
  picker and a plain current-state readout per piece.

## v0.07
- Reversed course on v0.06's "leave placement alone" default. With no way to
  preview the result, manual sliders you can't see the effect of aren't
  meaningfully better than a decent default — so a brand swap now
  auto-applies a per-brand jersey placement (scale/offset/rotate) sourced
  from the confirmed team examples. Nike and UA get their known values;
  Adidas has no confirmed example yet, so it's left untouched rather than
  guessed. Pants/socks also stay untouched — no confirmed data for those
  pieces yet, only jersey.
- The manual scale/offset/rotate controls from v0.06 are still there
  underneath, for whichever cases the default doesn't fit.

## v0.06
- Added manual **scale / offset / rotate** controls under each piece in the
  Vendor Decal section. A brand swap only ever changes the texture
  (col/rsm/normal) — it deliberately never touches placement, since
  placement is confirmed to vary by jersey *template*, not by brand (a
  Jumpman-templated team and a Nike-templated team don't share one correct
  scale). No safe way to auto-derive the right value, so this exposes the
  current values as editable and lets you dial it in by eye instead.
- Reference values on hand so far (jersey only): Nike scale 0.05, offset
  (0.085, -0.1), rotate 350. Jumpman scale 0.03, offset (0.08, -0.089),
  rotate 0. UA scale 0.035, offset (0, -0.133), rotate 0. These are examples
  from specific teams, not universal brand constants — don't assume they
  transfer to a different template.

## v0.05
- Fixed the decal catalog forcing `ContentShared/...` onto all 16 entries.
  That was only ever confirmed for entries whose source path had `/comp/` in
  it (Nike Cotton, Nike Plastic, UA). Nike ShoeDuck never had `/comp/` to
  begin with, and testing confirmed it needs to stay on plain `content/...`
  — forcing it onto `ContentShared` broke it. Same root cause as the earlier
  `/comp/` issue with number fonts: don't generalize one confirmed example
  across every entry in a catalog without checking whether they actually
  share the same source shape.

## v0.04
- **Fixed a real bug**: Vendor Decal always reported "no vendor decal overlay
  found" even when one clearly existed in the payload. The search was looking
  at `part.overlays` directly, but the real path is one level deeper:
  `part.layerCompTexture.overlays`. Confirmed against a real payload where the
  Nike Logo entry was visible in the raw JSON but the tool couldn't find it.
- The Vendor Decal picker now prefills with the currently-equipped brand +
  material when it matches a known catalog entry, instead of always starting
  blank — so switching reads as an actual swap ("Nike Cotton (2022)" → "Nike
  Plastic (2023)") rather than picking blind.

## v0.03
- Added the **Vendor Decal** swapper — confirmed working in-game across
  multiple brands (Nike, Adidas, Jumpman, Under Armour) and materials (Cotton,
  Plastic, Metallic, Shiny, etc.). One picker updates jersey, pants, and socks
  together; brands can be freely mixed and matched regardless of what's
  currently equipped.
- The vendor decal overlay is found **structurally** (whichever overlay's
  texture already points into `.../decals/vendors/...`), not by label text —
  confirmed that `info.label` changes to match whatever brand is currently
  equipped ("Nike Logo" vs "Adidas Logo" on different default teams), so
  label text isn't a safe search key on its own.
- Catalog paths normalized to the confirmed live form
  (`ContentShared/characters/player/parts/uniforms/decals/vendors/<name>`, no
  `/comp/`) — the source list used a different, unconfirmed path shape.

## v0.02
- Fixed the picker input resetting to its placeholder text ("Pick from
  catalog...") right after a selection was applied, even though the
  underlying field was set correctly. The box now shows what was actually
  picked. Clears automatically when a new payload loads or the variant
  changes, so it can't show a stale pick for the wrong context.

## v0.01
- Removed the standalone Accessory picker — Shell already sets the matching
  accessory automatically, so the separate tab was redundant.
- Removed Facemask entirely (not needed).
- Removed the "Set this field only" override inputs/buttons added for testing;
  reverted to plain read-only "what's already there" display under each field.
- Added a **Reset to loaded** button — snapshots the payload the moment it's
  fetched, and reverts to exactly that snapshot, discarding session edits.
- Fixed **Clear mock** giving no visible feedback — it now refreshes the
  Connection panel right after, so "Mocks stored" / "Network mocking" visibly
  update instead of appearing to do nothing.
